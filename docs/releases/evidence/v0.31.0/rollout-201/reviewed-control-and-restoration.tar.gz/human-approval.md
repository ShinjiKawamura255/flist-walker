# Human authority — v0.31.0

On 2026-10-24 JST the user explicitly answered all three pending questions:

1. Permit the limited operation for PR201 after CI Gate success: temporarily close draft PR180; independent-watchdog guarded temporary removal of Guardian only; rebase merge; restore and read back original full protection and PR180 open/draft state; then ordinary protected proof. No other settings or PR code changes.
2. Accept, only for v0.31.0, selected changed native GUI interactions (settings/display/Browse/stop/resume), Windows TC193 and clipboard, OS theme delivery and real-share outage/recovery NOT RUN, disclosed publicly. Thresholds100ms/ratio0.70 remain; CI/audit/signature/distribution gates remain mandatory.
3. Accept, only for v0.31.0, unknown cause of the historical Linux coverage SIGSEGV, preserving original failures/diagnostics and requiring all new-candidate test/coverage75% gates.

Original TC207 cause/OS tracing NOT RUN was separately accepted by the release request. No acceptance extends to new defects, unknown warnings, other versions or unrelated operations.
