import json,os,signal,subprocess,sys,tempfile,time,unittest,shutil
from unittest import mock
from pathlib import Path
import test_rollout_control as t
c=t.CONTROL;ROOT=Path(__file__).resolve().parent
def wait_for_group_exit(pid, timeout=5):
    end=time.monotonic()+timeout
    while time.monotonic()<end:
        try:os.killpg(pid,0)
        except ProcessLookupError:return
        time.sleep(.02)
    raise AssertionError('owned watchdog group did not exit: '+str(pid))

def stop_owned_group(pid, folder):
    try:os.killpg(pid,0)
    except ProcessLookupError:return
    result=subprocess.run(['/bin/ps','-p',str(pid),'-o','command='],capture_output=True,text=True,timeout=5)
    if result.returncode==0:
        if str(folder/'bundle/controller.py') not in result.stdout or 'watchdog' not in result.stdout:
            raise AssertionError('unverified watchdog identity; fixture retained')
        try:os.killpg(pid,signal.SIGKILL)
        except ProcessLookupError:pass
    # An exited leader may have briefly remaining children. Do not signal a
    # reused PID; require its originally owned group to disappear before cleanup.
    wait_for_group_exit(pid)

def cleanup_fixture(folder, watchdog_pid, parent_pid):
    if watchdog_pid is None:
        try:
            ready=json.loads((folder/'output/watchdog-ready.json').read_text())
        except (OSError,ValueError) as error:
            raise AssertionError('unconfirmed watchdog identity; fixture retained') from error
        if (type(ready.get('pid')) is not int or ready['pid']<=1 or ready.get('head')!=c.HEAD
                or ready.get('parent_pid')!=parent_pid or ready.get('parent_process_group')!=parent_pid):
            raise AssertionError('unverified watchdog owner; fixture retained')
        watchdog_pid=ready['pid']
    stop_owned_group(watchdog_pid,folder)
    shutil.rmtree(folder)

class CleanupOwnershipTests(unittest.TestCase):
    def test_pid_not_yet_observed_is_recovered_or_fixture_is_retained(self):
        for mode in ('valid-ready','missing-ready','wrong-parent'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory(prefix='cleanup-owner-') as tmp:
                folder=Path(tmp)/'fixture';folder.mkdir();output=folder/'output';output.mkdir()
                if mode!='missing-ready':
                    (output/'watchdog-ready.json').write_text(json.dumps(dict(pid=123456,head=c.HEAD,
                        parent_pid=789 if mode=='valid-ready' else 790,parent_process_group=789)))
                with mock.patch(__name__+'.stop_owned_group') as stop:
                    if mode=='valid-ready':
                        cleanup_fixture(folder,None,789)
                        stop.assert_called_once_with(123456,folder)
                        self.assertFalse(folder.exists())
                    else:
                        with self.assertRaises(AssertionError):cleanup_fixture(folder,None,789)
                        stop.assert_not_called();self.assertTrue(folder.exists())

class ActualProcessTests(unittest.TestCase):
    def test_actual_watchdog_entrypoint_cannot_run_without_approval(self):
        with tempfile.TemporaryDirectory(prefix='rollout-no-authority-') as tmp:
            output=Path(tmp)/'output';output.mkdir()
            result=subprocess.run([sys.executable,str(ROOT/'rollout_control.py'),'watchdog',
                '--bundle',str(Path(tmp)/'no-bundle'),'--output',str(output),
                '--deadline',str(time.monotonic()+10)],capture_output=True,text=True,timeout=5)
            self.assertEqual(result.returncode,2);self.assertIn('--approval',result.stderr)
            self.assertEqual(list(output.iterdir()),[])

    def test_controller_death_and_sigterm_restore_via_real_independent_watchdog(self):
        for sig,restore_failed,stage in ((signal.SIGKILL,False,'patch'),(signal.SIGTERM,False,'patch'),(signal.SIGKILL,True,'patch'),(signal.SIGSTOP,False,'patch'),(signal.SIGSTOP,False,'restored'),(signal.SIGSTOP,False,'before')):
            with self.subTest(signal=sig,restore_failed=restore_failed,stage=stage):
                folder=Path(tempfile.mkdtemp(prefix='rollout-inert-'));bundle=folder/'bundle';bundle.mkdir();state=t.FakeApi().state
                (folder/'state.json').write_text(json.dumps(state));binfolder=folder/'bin';binfolder.mkdir()
                fake=binfolder/'gh';fake.write_bytes((ROOT/'fake_gh_rollout.py').read_bytes().replace(b'#!/usr/bin/env python3',('#!'+sys.executable).encode(),1));fake.chmod(0o700)
                restore,temporary=c.check_payloads(state['protection'])
                guardian=dict(head=c.HEAD,app_id=c.APP,check_run_id=2,conclusion='failure',paths=c.EXPECTED_PATHS,log_sha256='a'*64)
                for name,value in [('snapshot.json',state),('restore.json',restore),('temporary.json',temporary),('guardian.json',guardian)]:c.save(bundle/name,value)
                (bundle/'controller.py').write_bytes((ROOT/'rollout_control.py').read_bytes())
                manifest=dict(schema=1,deadline_seconds=c.DEADLINE_SECONDS,hashes={name:c.sha(bundle/name) for name in ['snapshot.json','restore.json','temporary.json','guardian.json','controller.py']})
                c.save(bundle/'manifest.json',manifest);approval=folder/'approval.json'
                c.save(approval,dict(accepted=True,repo=c.REPO,pr=c.PR,head=c.HEAD,base=c.BASE,manifest_sha256=c.sha(bundle/'manifest.json'),deadline_seconds=c.DEADLINE_SECONDS))
                output=folder/'output';output.mkdir();driver=folder/'driver.py'
                driver.write_text('''import sys,signal,time,os\nfrom pathlib import Path\nsys.path.insert(0,sys.argv[1])\nimport controller as c\ndef stopped(sig,frame):raise KeyboardInterrupt('simulated SIGTERM')\nsignal.signal(signal.SIGTERM,stopped)\nbundle,output,approval=map(Path,sys.argv[1:4])\npinned,restore,temporary,manifest=c.validate_bundle(bundle);c.validate_approval(bundle,approval)\n# Test-only acceleration of the existing controller deadline; watchdog\n# runs the unmodified reviewed control and validates the normal upper bound.\nc.DEADLINE_SECONDS=3\noriginal_patch=c.GhApi.patch\ndef held_patch(self,endpoint,payload):\n result=original_patch(self,endpoint,payload)\n if len(payload['checks'])==1:time.sleep(.2) # inert test: observe suspension while main owns its lock\n return result\nc.GhApi.patch=held_patch\nif os.environ.get('ROLLOUT_TEST_STOP_RESTORED')=='1':\n original_save=c.save\n def held_save(path,data):\n  original_save(path,data)\n  if Path(path).name=='verified-restored.json':os.kill(os.getpid(),signal.SIGSTOP)\n c.save=held_save\ndef arm(deadline):\n wd=c.WatchdogProcess(bundle,output,deadline,approval)\n if os.environ.get('ROLLOUT_TEST_BEFORE')=='1':time.sleep(.2)\n return wd\nc.run_rollout(c.GhApi(),pinned,restore,temporary,output,arm,poll_seconds=2.5)\n''')
                env={**os.environ,'PATH':str(binfolder),'ROLLOUT_FAKE_ROOT':str(ROOT),'ROLLOUT_FAKE_STATE':str(folder),'ROLLOUT_TEST_STOP_RESTORED':'1' if stage=='restored' else '0','ROLLOUT_TEST_BEFORE':'1' if stage=='before' else '0'}
                log=(folder/'driver.log').open('w');process=subprocess.Popen([sys.executable,str(driver),str(bundle),str(output),str(approval)],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                watchdog_pid=None
                try:
                    deadline=time.monotonic()+8
                    while time.monotonic()<deadline:
                        self.assertIsNone(process.poll(),'parent exited before test interruption: '+(folder/'driver.log').read_text())
                        if (output/'watchdog-ready.json').exists():watchdog_pid=json.loads((output/'watchdog-ready.json').read_text())['pid']
                        current=json.loads((folder/'state.json').read_text())
                        if (stage=='before' and watchdog_pid is not None) or len(current['protection']['required_status_checks']['checks'])==1:break
                        time.sleep(.02)
                    else:self.fail('temporary simulated check mutation not observed')
                    if restore_failed:(folder/'force-restore-failure').touch()
                    os.kill(process.pid,signal.SIGTERM if stage=='restored' else sig);process.wait(timeout=8)
                    deadline=time.monotonic()+12
                    while time.monotonic()<deadline and not (output/'watchdog-complete.json').exists():time.sleep(.03)
                    calls=[json.loads(s) for s in (folder/'calls.jsonl').read_text().splitlines()];self.assertEqual(calls.count('register'),0 if stage=='before' else 1)
                    final=json.loads((folder/'state.json').read_text())
                    if stage=='before':
                        self.assertEqual(calls,[]);self.assertEqual(c.policy_view(final),c.policy_view(state))
                        self.assertFalse((output/'verified-restored.json').exists())
                        status=json.loads((output/'watchdog-complete.json').read_text())['status']
                        self.assertEqual(status,'no-owned-mutation')
                    elif restore_failed:
                        self.assertFalse((output/'watchdog-complete.json').exists())
                        self.assertFalse((output/'verified-restored.json').exists())
                        self.assertIn('restoration unconfirmed',(output/'watchdog.log').read_text())
                        self.assertEqual(sum(type(x) is dict and 'restore_failed_payload' in x for x in calls),3)
                        self.assertNotEqual(c.policy_view(final),c.policy_view(state))
                        status='restoration-unconfirmed; no success marker/protected proof'
                        # Local inert fixture rescue after the negative assertion.
                        c.save(folder/'state.json',state)
                    else:
                        self.assertTrue((output/'watchdog-complete.json').exists(),(output/'watchdog.log').read_text())
                        self.assertEqual(c.policy_view(final),c.policy_view(state));self.assertIsNone(final['pr']['auto_merge'])
                        self.assertIn(restore,calls)
                        status=json.loads((output/'watchdog-complete.json').read_text())['status']
                        self.assertEqual(status,'verified-main-restoration' if sig==signal.SIGTERM else 'deadline-restored')
                    wait_for_group_exit(watchdog_pid)
                    print('INERT ACTUAL PROCESS',sig.name,stage,status,'registration count',calls.count('register'),'; no network')
                finally:
                    if process.poll() is None:process.kill();process.wait(timeout=5)
                    log.close()
                    try:
                        cleanup_fixture(folder,watchdog_pid,process.pid)
                    except BaseException:
                        print('RETAINED INERT FIXTURE',str(folder),flush=True)
                        raise

if __name__=='__main__':unittest.main()
