"""Retain only completed owned v9 campaign originals and declared supporting evidence."""
from pathlib import Path
import json,hashlib,tarfile,io,zipfile,subprocess,datetime
R=Path.cwd();P=R/'rust/target/warm-reclaim-calibration';B=P/'campaign-active-v9';D=R/'docs/history/warm-reclaim-v9-2026-10-18'
sha=lambda b:hashlib.sha256(b).hexdigest()
def main():
 complete=json.loads((B/'complete.json').read_text());assert complete['status']=='five-whole-null-sessions-pass'
 protocol=json.loads((B/'protocol-reservation-original.json').read_text());reserved=datetime.datetime.fromisoformat(protocol['reserved_at_utc']);finished=datetime.datetime.fromtimestamp((B/'complete.json').stat().st_mtime,datetime.timezone.utc);wall_seconds=(finished-reserved).total_seconds();assert 0<wall_seconds<=protocol['budget_seconds']['campaign']==21600
 replay=P/'post-campaign-verification-v9/active-v9-five-descriptive-replay.json';recount=json.loads(replay.read_text());assert recount['status']=='five-whole-PASS'
 assert complete['source']==recount['source']=='63fc68aa72b873d1c8181f3d3f6cf37cfc94d9c5' and complete['reference']==recount['reference']=='6edfb599d69fc31657032a1419bdd255a165fe80'
 members={}
 def add(n,p):
  assert n not in members;members[n]=p.read_bytes()
 for p in sorted(B.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:add('campaign/'+str(p.relative_to(B)),p)
 for n in ['campaign-v9-controller.log','campaign-protocol-active-v9.json','verify_active_v9_campaign.py','archive_active_v9_campaign.py','v9-native-reference-original-logs.zip','v9-native-reference-original-logs.json','v9-source-original-logs.zip','v9-source-original-logs.json','v9-native-test-recount.json','v9-five-replay-verification.log']:
  add('support/'+n,P/n)
 add('support/independent-recount.json',replay)
 for n in ['warm-reclaim-red-confirmed.log','warm-reclaim-green-final.log','warm-reclaim-nine-leaves.log','warm-reclaim-root-identity-red.log','warm-reclaim-root-identity.log','warm-reclaim-contract.log','warm-reclaim-review-before.local.md']:
  add('repair/'+n,R/'rust/target'/n)
 add('repair/original-macos-job117425811574.log',Path('/private/tmp/flistwalker-pr188-macos-job.log'))
 for i in range(1,6):
  folder=B/f'session-{i}';state=json.loads((folder/'state-final.json').read_text());run=json.loads((folder/'admission.json').read_text())['run'];z=P/f'v9-session-{i}-original-logs.zip'
  assert state['conclusion']=='success' and state['attempt']==1
  assert z.exists()
  with zipfile.ZipFile(z) as archive:assert archive.testzip() is None
  add('workflow-logs/'+z.name,z)
 archive=D/'accepted-v9-original-artifacts.tar.gz';assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=9) as t:
  for n,data in sorted(members.items()):
   info=tarfile.TarInfo(n);info.size=len(data);info.mtime=0;info.mode=0o644;t.addfile(info,io.BytesIO(data))
 with tarfile.open(archive,'r:gz') as t:
  assert len(t.getmembers())==len(members)
  for n,data in members.items():assert t.extractfile(n).read()==data
 manifest={'source':complete['source'],'reference':complete['reference'],'protocol':'same-job-RCR-f1-matched-21-observer-v9','archive':archive.name,'archive_sha256':sha(archive.read_bytes()),'archive_size':archive.stat().st_size,'roundtrip_sha256':'PASS','campaign_wall_seconds':wall_seconds,'campaign_completion_observed_mtime_utc':finished.isoformat(),'campaign_budget_seconds':21600,'members':{n:{'size':len(data),'sha256':sha(data)} for n,data in sorted(members.items())}}
 (D/'accepted-v9-evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 (D/'accepted-v9-recount.json').write_bytes(replay.read_bytes());print(json.dumps({k:manifest[k] for k in ['archive','archive_size','archive_sha256','roundtrip_sha256']})+' members='+str(len(members)))
if __name__=='__main__':main()
