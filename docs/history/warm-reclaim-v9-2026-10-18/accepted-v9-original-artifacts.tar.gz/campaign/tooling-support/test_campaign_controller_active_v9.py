"""Offline controller regressions; synthetic bytes never calibrate performance."""
import ast,copy,datetime,hashlib,json,pathlib,re,subprocess,sys,tempfile,time,unittest
from types import SimpleNamespace
sys.path.insert(0,str(pathlib.Path.cwd()))
from scripts import indexing_perf_gate as gate,indexing_perf_contract as contract,indexing_perf as collector
from scripts.tests.test_indexing_perf_gate import write_fixture
SCRIPT=pathlib.Path(sys.argv.pop(1))
class ControllerControls(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.folder=pathlib.Path(self.temp.name);self.addCleanup(self.temp.cleanup)
  tree=ast.parse(SCRIPT.read_text());self.tree=tree
  self.env={'hashlib':hashlib,'datetime':datetime,'json':json,'pathlib':pathlib,'subprocess':subprocess,'sys':sys,'time':time,'ROOT':pathlib.Path.cwd(),'OUT':self.folder,'HEAD':'a'*40,'REPO':'synthetic/repo','BRANCH':'control','DEADLINE':time.monotonic()+60,'gate':gate,'contract':contract,'COMPONENT_IDS':set(),'PROTOCOL':{'synthetic':True},'re':re}
  exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(SCRIPT),'exec'),self.env)
 def prepare(self,enforced=True):
  arts=self.folder/'artifacts';arts.mkdir();sources={}
  for group in contract.GROUPS:
   p=arts/group;p.mkdir();write_fixture(p,group,enforced=enforced)
   r=json.loads((p/'receipt.json').read_text());comparison=r['comparison']
   for role in gate.ROLES:
    q=p/(role+'-receipt.log');comp=json.loads(q.read_text());comp['run_id']=group+'-'+role;q.write_text(json.dumps(comp));comparison['legs'][role]['receipt_sha256']=collector.sha(q)
    sources[comp['source_before']['head']]=comp['source_before']
    if role=='candidate':r={**comp,'comparison':comparison}
   (p/'receipt.json').write_text(json.dumps(r))
  jobs=[{'name':f'Indexing Contention ({g})','conclusion':'success','startedAt':'2026-10-05T00:00:00Z','completedAt':'2026-10-05T00:00:10Z'} for g in contract.GROUPS]
  (self.folder/'state-final.json').write_text(json.dumps({'jobs':jobs}))
  self.env['command']=lambda *a,**k:'';self.env['git_identity']=lambda rev:copy.deepcopy(sources[rev]);
  reports={g:gate.load_comparison(arts/g,g) for g in contract.GROUPS}
  self.env['source_cli']=lambda p,g:copy.deepcopy(reports[g]);return sources
 def test_admission_keeps_full_source_revision_and_partition(self):
  self.prepare();v=self.env['download_and_admit']('123','a'*40,self.folder)
  self.assertEqual(v['source'],'a'*40);self.assertEqual(v['leg_rows'],1638);self.assertEqual((v['decision_count'],v['enforced_count'],v['diagnostic_count']),(136,68,68))
 def test_stop_during_command_cannot_return_for_dispatch(self):
  marker=self.folder/'STOP_REQUESTED';calls=[]
  def run(*a,**k):calls.append(k);marker.touch();return SimpleNamespace(returncode=0,stdout='remote-read',stderr='')
  old=self.env['subprocess'];self.env['subprocess']=SimpleNamespace(run=run)
  with self.assertRaisesRegex(RuntimeError,'stop marker'):self.env['command'](['synthetic','read'])
  self.assertEqual(len(calls),1);self.env['subprocess']=old
 def test_blocking_command_is_limited_by_remaining_campaign_time(self):
  self.env['DEADLINE']=time.monotonic()+.5;limits=[]
  def run(*a,**k):limits.append(k['timeout']);return SimpleNamespace(returncode=0,stdout='',stderr='')
  self.env['subprocess']=SimpleNamespace(run=run);self.env['command'](['synthetic','read'],timeout=45)
  self.assertTrue(0<limits[0]<=.5)
 def test_expiry_during_whole_validation_prevents_admission(self):
  self.prepare();real=gate.load_comparison;calls=[]
  def load(*a,**k):r=real(*a,**k);calls.append(1);self.env['DEADLINE']=time.monotonic()-1;return r
  self.env['gate']=SimpleNamespace(ROLES=gate.ROLES,REFERENCE=gate.REFERENCE,POLICY=gate.POLICY,load_comparison=load)
  with self.assertRaisesRegex(RuntimeError,'finite6h'):self.env['download_and_admit']('123','a'*40,self.folder)
  self.assertEqual(len(calls),3)
 def test_expiry_during_remote_identity_read_prevents_new_dispatch(self):
  self.env['PROTOCOL']={'sessions':[{'index':1,'role':'exploratory'}]};self.env['BRANCH']='synthetic';self.env['REPO']='synthetic';dispatched=[]
  def api(*args):self.env['DEADLINE']=time.monotonic()-1;return {'object':{'sha':'a'*40}}
  self.env['api']=api;self.env['command']=lambda argv,*a,**k:dispatched.append(argv) or 'https://example.invalid/actions/runs/123';self.env['wait']=lambda *a,**k: (_ for _ in ()).throw(RuntimeError('unexpected-dispatch'))
  outer=next(n for n in self.tree.body if isinstance(n,ast.Try));loop=next(n for n in outer.body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='reserved')
  with self.assertRaisesRegex(RuntimeError,'finite6h'):exec(compile(ast.Module(body=[loop],type_ignores=[]),str(SCRIPT),'exec'),self.env)
  self.assertEqual(dispatched,[])
class ActiveModeControls(ControllerControls):
 def test_inactive_receipt_cannot_supply_active_campaign(self):
  self.prepare(enforced=False)
  with self.assertRaisesRegex(RuntimeError,'enforcement mismatch'):
   self.env['download_and_admit']('123','a'*40,self.folder)

class ActiveSourceControls(ControllerControls):
 def source_context(self, ordinary_attempt=1, guardian_attempt=1, ordinary_head=None, guardian_head=None, ordinary_result='success', guardian_result='success'):
  head='a'*40
  self.env['PROTOCOL']={'source_ci_run':'37366863724','source_ci_before_dispatch':{'attempt':1,'guardian':'37366753997'}}
  pr={'headRefOid':head,'isDraft':False,'autoMergeRequest':None,'state':'OPEN','statusCheckRollup':[{'name':n,'conclusion':'SUCCESS'} for n in ['CI Gate','CI Policy Guardian']]}
  ordinary={'headSha':ordinary_head or head,'attempt':ordinary_attempt,'status':'completed','conclusion':ordinary_result,'jobs':[]}
  guardian={'headSha':guardian_head or head,'attempt':guardian_attempt,'status':'completed','conclusion':guardian_result,'jobs':[]}
  self.reads=[]
  def command(argv,*a,**k):
   if argv[1:3]==['pr','view']:return json.dumps(pr)
   self.reads.append(argv[3])
   return json.dumps(ordinary if argv[3]=='37366863724' else guardian)
  self.env['command']=command
 def test_valid_both_exact_attempt1_admitted(self):
  self.source_context();self.assertIsNone(self.env['wait_ci']())
  self.assertEqual(self.reads,['37366863724','37366753997'])
 def test_wrong_ordinary_attempts_rejected(self):
  for attempt in [2,3]:
   with self.subTest(attempt=attempt):
    self.source_context(ordinary_attempt=attempt)
    with self.assertRaisesRegex(RuntimeError,'source CI identity'):self.env['wait_ci']()
 def test_wrong_guardian_attempts_rejected(self):
  for attempt in [2,3]:
   with self.subTest(attempt=attempt):
    self.source_context(guardian_attempt=attempt)
    with self.assertRaisesRegex(RuntimeError,'Guardian identity'):self.env['wait_ci']()
 def test_wrong_ordinary_head_rejected(self):
  self.source_context(ordinary_head='b'*40)
  with self.assertRaisesRegex(RuntimeError,'source CI identity'):self.env['wait_ci']()
 def test_wrong_guardian_head_rejected(self):
  self.source_context(guardian_head='b'*40)
  with self.assertRaisesRegex(RuntimeError,'Guardian identity'):self.env['wait_ci']()
 def test_ordinary_failure_rejected(self):
  self.source_context(ordinary_result='failure')
  with self.assertRaisesRegex(RuntimeError,'source CI failed'):self.env['wait_ci']()
 def test_guardian_failure_rejected(self):
  self.source_context(guardian_result='failure')
  with self.assertRaisesRegex(RuntimeError,'Guardian failed'):self.env['wait_ci']()
class NormalCliControls(ControllerControls):
 def configure_export(self):
  real=self.env['source_cli'];self.prepare();self.env['source_cli']=real
  folder=self.folder/'source-contract/scripts';folder.mkdir(parents=True)
  contents={n:(pathlib.Path.cwd()/'scripts'/n).read_bytes() for n in ('indexing_perf.py','indexing_perf_contract.py','indexing_perf_gate.py')}
  for n,data in contents.items():(folder/n).write_bytes(data)
  self.env['command_bytes']=lambda argv,**kwargs:contents[argv[-1].split(':scripts/')[1]]
  return self.folder/'artifacts/f1',contents
 def test_actual_normal_export_cli_pass_and_receipt_are_retained(self):
  packet,_=self.configure_export();report=self.env['source_cli'](packet,'f1')
  self.assertEqual(report,gate.load_comparison(packet,'f1'))
  execution=json.loads((packet/'actual-source-normal-cli-execution.json').read_text())
  self.assertEqual(execution['exit'],0);self.assertEqual(execution['source'],'a'*40)
  self.assertEqual(set(execution['script_hashes']),{'indexing_perf.py','indexing_perf_contract.py','indexing_perf_gate.py'})
  self.assertTrue((packet/'actual-source-normal-cli-stdout.json').exists())
  self.assertTrue((packet/'actual-source-normal-cli-stderr.log').exists())
 def test_exported_import_source_drift_rejects_before_cli(self):
  packet,_=self.configure_export();p=self.folder/'source-contract/scripts/indexing_perf_contract.py';p.write_bytes(p.read_bytes()+b'\n# synthetic drift\n')
  with self.assertRaisesRegex(RuntimeError,'import source drift'):self.env['source_cli'](packet,'f1')
  self.assertFalse((packet/'actual-source-normal-cli-execution.json').exists())
 def test_failed_normal_cli_logs_exit_stdout_stderr_and_rejects(self):
  packet,_=self.configure_export()
  self.env['subprocess']=SimpleNamespace(run=lambda *a,**k:SimpleNamespace(returncode=1,stdout='synthetic stdout',stderr='synthetic stderr'))
  with self.assertRaisesRegex(RuntimeError,'normal source CLI failed'):self.env['source_cli'](packet,'f1')
  self.assertEqual(json.loads((packet/'actual-source-normal-cli-execution.json').read_text())['exit'],1)
  self.assertEqual((packet/'actual-source-normal-cli-stderr.log').read_text(),'synthetic stderr')
class ReservationControls(ControllerControls):
 def config_guard(self):
  return next(n for n in self.tree.body if isinstance(n,ast.If) and 'source contract/reservation mismatch' in ast.unparse(n))
 def configure(self,active=True):
  self.env['PROTOCOL']={'reference':gate.REFERENCE,'comparison_protocol':gate.PROTOCOL,'policy_before_outcomes':gate.POLICY,'enforcement_active':active}
 def test_active_reservation_and_real_default_accepted(self):
  self.configure();exec(compile(ast.Module(body=[self.config_guard()],type_ignores=[]),str(SCRIPT),'exec'),self.env)
 def test_inactive_reservation_rejected(self):
  self.configure(False)
  with self.assertRaisesRegex(RuntimeError,'reservation mismatch'):exec(compile(ast.Module(body=[self.config_guard()],type_ignores=[]),str(SCRIPT),'exec'),self.env)
 def test_inactive_default_rejected(self):
  self.configure();self.env['gate']=SimpleNamespace(REFERENCE=gate.REFERENCE,PROTOCOL=gate.PROTOCOL,POLICY=gate.POLICY,ENFORCE_TIMING=False)
  with self.assertRaisesRegex(RuntimeError,'reservation mismatch'):exec(compile(ast.Module(body=[self.config_guard()],type_ignores=[]),str(SCRIPT),'exec'),self.env)
if __name__=='__main__':unittest.main()
