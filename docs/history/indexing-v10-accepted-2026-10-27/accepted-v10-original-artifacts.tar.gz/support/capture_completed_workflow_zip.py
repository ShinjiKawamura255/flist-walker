"""Read-only GitHub log acquisition for an already admitted original whole slot."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parent
BASE=ROOT/'candidate-v10-null/rust/target/warm-reclaim-calibration/campaign-active-v10'
def main():
 index=int(sys.argv[1])
 if index not in range(1,6):raise SystemExit('not an original reserved slot')
 folder=BASE/f'session-{index}'
 state=json.loads((folder/'state-final.json').read_text())
 admission=json.loads((folder/'admission.json').read_text())
 if not(admission['whole_null_pass'] is True and state['status']=='completed' and state['conclusion']=='success' and state['attempt']==1 and state['headSha']=='597a7d4dd48ffca67b9529a3afcec5459c3a9276'):raise SystemExit('not admitted original source/attempt')
 protocol=json.loads((BASE/'protocol-reservation-original.json').read_text())
 reservation=json.loads((folder/'reservation-before-dispatch.json').read_text())
 dispatch=json.loads((folder/'dispatch-confirmed.json').read_text())
 if not(reservation==protocol['sessions'][index-1]==dispatch['session'] and reservation['index']==index and admission['role']==reservation['role'] and dispatch['source']==admission['source']==state['headSha'] and str(dispatch['run'])==str(admission['run'])):raise SystemExit('original reservation/dispatch/admission mismatch')
 run=str(admission['run']);target=folder/'whole-workflow-original-logs.zip';identity=folder/'whole-workflow-logs-identity.json'
 if target.exists() or identity.exists():raise SystemExit('already retained or uncertain outcome; inspect first')
 temporary=folder/'whole-workflow-original-logs.acquiring'
 with temporary.open('xb') as output:
  result=subprocess.run(['gh','api',f'repos/ShinjiKawamura255/flist-walker/actions/runs/{run}/attempts/1/logs'],stdout=output,stderr=subprocess.PIPE,timeout=120)
 if result.returncode:raise SystemExit('read-only acquisition failed; partial retained: '+result.stderr.decode())
 with zipfile.ZipFile(temporary) as archive:
  if archive.testzip() is not None:raise SystemExit('ZIP CRC invalid; original retained')
  names=archive.namelist()
 data=temporary.read_bytes();temporary.rename(target)
 proof={'utc':datetime.now(timezone.utc).isoformat(),'run':run,'attempt':1,'source':state['headSha'],'file':target.name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest(),'ZIP_CRC':'PASS','members':names,'purpose':'Original admitted workflow logs; no rerun/dispatch/new measurement'}
 with identity.open('x') as stream:json.dump(proof,stream,indent=2);stream.write('\n')
 print(json.dumps({k:proof[k] for k in ('run','attempt','size','sha256','ZIP_CRC')}))
if __name__=='__main__':main()
