"""Package only the completed five original slots and declared owned provenance.

Post-outcome archival utility; it is not prospectively frozen campaign control.
This never dispatches, measures, edits a source tree or changes acceptance.
"""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import hashlib,io,json,tarfile,zipfile
ROOT=Path(__file__).resolve().parent
P=ROOT/'candidate-v10-null/rust/target/warm-reclaim-calibration'
B=P/'campaign-active-v10'
D=ROOT/'v10-completed-campaign-evidence'
SOURCE='597a7d4dd48ffca67b9529a3afcec5459c3a9276'
REFERENCE='fcdea8ee05a5f08c5ee19a9ae8b58b8c8736a645'
PROTOCOL_SHA='70c1f2016d3a67414b95782ed092434c0b97bb488a52fdafa05417770ef5bf44'
PRELAUNCH_SHA='b1fa36d5cb9621450f2cebf0e80e4665945c9c8f37a726e63642d13386be3624'
RECOVERY_SHA='0e317e39e2c6191ff9e933fe5b3fd9f1741999de0c7500090346498bea89f0ce'
ANCHOR='2026-10-27T18:26:48.357394+00:00'
DEADLINE='2026-10-28T00:26:48.357394+00:00'
RECOVERY_FILES=['campaign_recover_v10.py','campaign_recover_v10_v2.py','launch_recovery_v10_v2.py',
 'recovery-manifest.json','recovery-manifest-v2.json','recovery-manifest-v2-reviewed.json',
 'test_campaign_recover_v10.py','test_campaign_recover_v10_v2.py','unlaunched-launcher-before-review.py']
sha=lambda b:hashlib.sha256(b).hexdigest()
def require(ok,message):
 if not ok:raise RuntimeError(message)
def read(p):return json.loads(p.read_text())
def check_stop_markers(base):
 require(not any((base/n).exists() for n in ['STOP_REQUESTED','STOP','stopped.json','recovery-after-local-interruption/stopped.json','recovery-after-second-local-interruption/stopped.json']),'campaign stopped')
def recovery_inventory(directory):
 require({p.name for p in directory.iterdir() if p.name!='__pycache__'}==set(RECOVERY_FILES),'undeclared recovery-control entry')
 return [directory/name for name in RECOVERY_FILES]
def slot_identity(index,protocol,folder):
 reservation=read(folder/'reservation-before-dispatch.json');dispatch=read(folder/'dispatch-confirmed.json');admission=read(folder/'admission.json')
 require(reservation==protocol['sessions'][index-1]==dispatch['session'],'original slot reservation mismatch')
 require(reservation['index']==index and admission['role']==reservation['role'],'slot role/index mismatch')
 require(dispatch['source']==admission['source']==SOURCE,'slot source mismatch')
 require(str(dispatch['run'])==str(admission['run']),'dispatch/admission run mismatch')
 return admission
def original_time_boundary(recovered,workflow_finished):
 prelaunch=ROOT/'v10-revision2-final-pre-dispatch-review.json';recovery=ROOT/'v10-campaign-recovery/recovery-manifest-v2-reviewed.json'
 require(sha(prelaunch.read_bytes())==PRELAUNCH_SHA and sha(recovery.read_bytes())==RECOVERY_SHA,'reviewed time authority digest mismatch')
 require(read(prelaunch)['utc']==ANCHOR,'original prelaunch anchor mismatch')
 recovery_data=read(recovery)
 require(recovery_data['campaign_anchor_utc']==ANCHOR and recovery_data['absolute_deadline_utc']==DEADLINE,'reviewed recovery time authority mismatch')
 require(recovered['deadline_utc']==DEADLINE,'recovery finished deadline mismatch')
 start=datetime.fromisoformat(ANCHOR);deadline=datetime.fromisoformat(DEADLINE);finish=datetime.fromisoformat(recovered['utc'])
 require(deadline==start+timedelta(seconds=21600) and start<workflow_finished<=finish<=deadline,'recorded workflow/recovery completion outside original budget')
 return start,deadline,finish
def main():
 require(not D.exists(),'exclusive output already exists; inspect, do not overwrite')
 check_stop_markers(B)
 complete=read(B/'complete.json');replay_path=P/'post-campaign-verification-v10/active-v10-five-descriptive-replay.json';replay=read(replay_path)
 require(complete['status']=='five-whole-null-sessions-pass' and replay['status']=='five-whole-PASS','five-original-pass/replay missing')
 require(complete['source']==replay['source']==SOURCE and complete['reference']==replay['reference']==REFERENCE,'source mismatch')
 require((replay['leg_rows'],replay['observations'],replay['enforced_medians'],replay['MAX_diagnostics'],replay['unique_UUIDs'])==(8190,680,340,340,45),'replay inventory mismatch')
 protocol=P/'campaign-protocol-active-v10.json';require(sha(protocol.read_bytes())==PROTOCOL_SHA,'original protocol changed')
 require((B/'protocol-reservation-original.json').read_bytes()==protocol.read_bytes(),'original reservation changed')
 recovered=read(B/'recovery-after-second-local-interruption/recovery-finished.json')
 require(recovered['all_original_slots_completed'] is True,'finite recovery did not finish')
 protocol_data=read(protocol)
 for name,digest in protocol_data['support_files'].items():
  require(sha((P/name).read_bytes())==sha((B/'tooling-support'/name).read_bytes())==digest,'prospectively bound support changed '+name)
 workflow_finished=max(datetime.fromisoformat(j['completedAt'].replace('Z','+00:00')) for i in range(1,6) for j in read(B/f'session-{i}/state-final.json')['jobs'] if j['name'].startswith('Indexing Contention ('))
 start,deadline,finish=original_time_boundary(recovered,workflow_finished)
 complete_mtime=datetime.fromtimestamp((B/'complete.json').stat().st_mtime,timezone.utc)
 members={};sources={}
 def add(name,path):
  require(name not in members and not path.is_symlink() and path.is_file(),'duplicate/nonordinary member '+name)
  require(not name.startswith('/') and '..' not in Path(name).parts,'unsafe archive path')
  members[name]=path.read_bytes();sources[name]=path
 for path in sorted(B.rglob('*')):
  if path.is_file() and '__pycache__' not in path.parts:add('campaign/'+path.relative_to(B).as_posix(),path)
 for n in ['campaign-protocol-active-v10.json','campaign_runner_active_v10.py','verify_active_v10_campaign.py']:
  add('support/'+n,P/n)
 add('support/independent-source-replay.json',replay_path)
 add('support/archive_completed_campaign.py',Path(__file__))
 add('support/capture_completed_workflow_zip.py',ROOT/'v10_capture_completed_workflow_zip.py')
 add('support/test_archive_completed_campaign.py',ROOT/'test_v10_archive_completed_campaign.py')
 add('support/archive-offline-fault-controls.log',ROOT/'v10-archive-offline-fault-controls.log')
 add('support/capture-source-binding-red.log',ROOT/'v10-capture-source-binding-red.log')
 recovery_dir=ROOT/'v10-campaign-recovery'
 for path in recovery_inventory(recovery_dir):add('recovery-control/'+path.name,path)
 for n in ['attempt-starting.json','pid-result.json']:add('recovery-launch/'+n,ROOT/'v10-recovery-v2-launch'/n)
 support=[
 'v10-revision2-final-pre-dispatch-review.json','v10-frozen-reservation-revision2-identity.json',
 'v10-heldout-boundary-proof-fully-checked.json','v10-heldout-boundary-proof.json','v10-heldout-freeze-observation.json',
 'v10-recovery-final-independent-review.json','v10-recovery-final-read-only-preflight.json','v10-recovery-frozen-identity.json',
 'v10-recovery-offline-controls-final.log','v10-recovery-offline-controls-initial-fixture-errors.log',
 'v10-recovery-v2-final-independent-review.json','v10-recovery-v2-final-read-only-preflight.json',
 'v10-recovery-v2-reviewed-frozen-identity.json','v10-recovery-v2-reviewed-validate-only.log',
 'v10-recovery-v2-offline-controls-reviewed.log','v10-recovery-v2-wrapper-before-import-red.log',
 'v10-pre-recovery-snapshot-identity.json','v10-pre-recovery-v2-snapshot-identity.json',
 'v10-e2-interruption-preservation-identity.json',
 'v10-actual-campaign-controller-revision2.log','v10-campaign-recovery-controller.log','v10-campaign-recovery-v2-controller.log',
 'v10-current-product-comparison-scope-read-only.json']
 for n in support:add('provenance/'+n,ROOT/n)
 for i in range(1,6):
  folder=B/f'session-{i}';state=read(folder/'state-final.json');admission=slot_identity(i,protocol_data,folder)
  require(state['attempt']==1 and state['conclusion']=='success' and admission['whole_null_pass'] is True,'unaccepted original slot')
  z=folder/'whole-workflow-original-logs.zip'
  if i==2:
   identity=read(ROOT/'v10-e2-interruption-preservation-identity.json')
   require(str(identity['run'])==str(admission['run'])=='40567759395' and identity['attempt']==1 and identity['source']==SOURCE,'E2 preserved ZIP identity mismatch')
   require(identity['files']['whole-workflow-original-logs.zip']==sha(z.read_bytes()),'E2 preserved ZIP digest mismatch')
   require(z.read_bytes()==(ROOT/'v10-e2-interruption-preservation/whole-workflow-original-logs.zip').read_bytes(),'E2 preserved ZIP bytes differ')
  else:
   identity=read(folder/'whole-workflow-logs-identity.json')
   require(str(identity['run'])==str(admission['run']) and identity['sha256']==sha(z.read_bytes()),'workflow ZIP identity mismatch')
  with zipfile.ZipFile(z) as archive:require(archive.testzip() is None,'workflow ZIP CRC invalid')
 D.mkdir()
 archive=D/'accepted-v10-original-artifacts.tar.gz'
 with tarfile.open(archive,'w:gz',compresslevel=9) as t:
  for name,data in sorted(members.items()):
   info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;t.addfile(info,io.BytesIO(data))
 require(archive.stat().st_size<90*1024*1024,'archive exceeds conservative single-Git-file bound; retain and review packaging')
 with tarfile.open(archive,'r:gz') as t:
  require(len(t.getmembers())==len(members),'member count mismatch')
  for name,data in members.items():require(t.extractfile(name).read()==data,'archive roundtrip mismatch '+name)
 for name,path in sources.items():require(path.read_bytes()==members[name],'source artifact changed during archive '+name)
 manifest={'source':SOURCE,'reference':REFERENCE,'protocol':'same-job-RCR-f1-matched-21-observer-v10','archive':archive.name,'archive_sha256':sha(archive.read_bytes()),'archive_size':archive.stat().st_size,'roundtrip_sha256':'PASS','original_controller_start_conservative_utc':start.isoformat(),'original_absolute_deadline_utc':deadline.isoformat(),'recorded_recovery_completion_utc':finish.isoformat(),'last_indexing_workflow_completion_utc':workflow_finished.isoformat(),'complete_json_mtime_auxiliary_diagnostic_utc':complete_mtime.isoformat(),'campaign_wall_seconds_including_interruptions':(finish-start).total_seconds(),'campaign_budget_seconds':21600,'canonical_counts':{'leg_rows':8190,'observations':680,'enforced_medians':340,'MAX_diagnostics':340,'unique_UUIDs':45},'duplicate_revalidation_provenance':'Retained copies/checkpoint restoration do not constitute new samples or additional slots','control_provenance':'Original source/policy/work/five slots frozen before outcomes; two post-outcome recovery wrappers reviewed separately, no resampling/refit/deadline reset. Archival utility is post-outcome, not frozen campaign control.','numerical_adoption':'Independent acceptance required separately; no merge authority implied','members':{name:{'size':len(data),'sha256':sha(data)} for name,data in sorted(members.items())}}
 (D/'accepted-v10-evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(D/'accepted-v10-recount.json').write_bytes(replay_path.read_bytes())
 print(json.dumps({k:manifest[k] for k in ['archive','archive_size','archive_sha256','roundtrip_sha256','campaign_wall_seconds_including_interruptions']})+' members='+str(len(members)))
if __name__=='__main__':main()
