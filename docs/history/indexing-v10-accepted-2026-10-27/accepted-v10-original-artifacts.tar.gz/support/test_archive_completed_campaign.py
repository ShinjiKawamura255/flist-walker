"""Offline fault controls; no campaign writes, network, dispatch or acceptance."""
import copy,json,tempfile,unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch
import v10_archive_completed_campaign as a
import v10_capture_completed_workflow_zip as capture
class FaultControls(unittest.TestCase):
 def test_real_reviewed_deadline_and_late_completion(self):
  good={'deadline_utc':a.DEADLINE,'utc':'2026-10-27T23:00:00+00:00'}
  finished=datetime.fromisoformat('2026-10-27T22:59:00+00:00')
  self.assertEqual(a.original_time_boundary(good,finished)[0].isoformat(),a.ANCHOR)
  for bad in [{'deadline_utc':'2026-10-28T01:26:48.357394+00:00','utc':good['utc']},{'deadline_utc':a.DEADLINE,'utc':'2026-10-28T00:27:00+00:00'},{'deadline_utc':a.DEADLINE,'utc':'2026-10-27T22:58:00+00:00'}]:
   with self.subTest(bad=bad),self.assertRaises(RuntimeError):a.original_time_boundary(bad,finished)
 def test_jointly_shifted_untrusted_anchor_deadline_rejected(self):
  with tempfile.TemporaryDirectory() as td:
   root=Path(td);(root/'v10-campaign-recovery').mkdir()
   for rel in ['v10-revision2-final-pre-dispatch-review.json','v10-campaign-recovery/recovery-manifest-v2-reviewed.json']:
    e=a.read(a.ROOT/rel)
    if 'utc' in e:e['utc']='2026-10-27T19:26:48.357394+00:00'
    else:e['campaign_anchor_utc']='2026-10-27T19:26:48.357394+00:00';e['absolute_deadline_utc']='2026-10-28T01:26:48.357394+00:00'
    (root/rel).write_text(json.dumps(e))
   with patch.object(a,'ROOT',root),self.assertRaisesRegex(RuntimeError,'digest mismatch'):
    a.original_time_boundary({'deadline_utc':'2026-10-28T01:26:48.357394+00:00','utc':'2026-10-28T01:00:00+00:00'},datetime.fromisoformat('2026-10-28T00:59:00+00:00'))
 def test_every_actual_stop_marker_rejects(self):
  for name in ['STOP_REQUESTED','STOP','stopped.json','recovery-after-local-interruption/stopped.json','recovery-after-second-local-interruption/stopped.json']:
   with self.subTest(name=name),tempfile.TemporaryDirectory() as td:
    root=Path(td);a.check_stop_markers(root);p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('stop')
    with self.assertRaises(RuntimeError):a.check_stop_markers(root)
 def test_undeclared_recovery_file_rejects(self):
  with tempfile.TemporaryDirectory() as td:
   root=Path(td)
   for n in a.RECOVERY_FILES:(root/n).write_text('owned')
   self.assertEqual(len(a.recovery_inventory(root)),9)
   (root/'unreviewed-acquisition.partial').write_text('unknown')
   with self.assertRaises(RuntimeError):a.recovery_inventory(root)
 def test_actual_e2_slot_then_foreign_run_source_role_uuid_reject(self):
  protocol=a.read(a.B/'protocol-reservation-original.json');original=a.B/'session-2'
  with tempfile.TemporaryDirectory() as td:
   root=Path(td)
   files={n:a.read(original/n) for n in ['reservation-before-dispatch.json','dispatch-confirmed.json','admission.json']}
   def save(data):
    for n,e in data.items():(root/n).write_text(json.dumps(e))
   save(files);self.assertEqual(a.slot_identity(2,protocol,root)['run'],'40567759395')
   for target,key,value in [('admission.json','run','40560125984'),('admission.json','source','foreign'),('admission.json','role','held-out'),('reservation-before-dispatch.json','slot_id','foreign')]:
    bad=copy.deepcopy(files);bad[target][key]=value;save(bad)
    with self.subTest(target=target,key=key),self.assertRaises(RuntimeError):a.slot_identity(2,protocol,root)
 def test_capture_joint_foreign_source_rejects_before_network(self):
  with tempfile.TemporaryDirectory() as td:
   root=Path(td);folder=root/'session-4';folder.mkdir()
   for name in ['state-final.json','admission.json','reservation-before-dispatch.json','dispatch-confirmed.json']:
    e=a.read(a.B/'session-4'/name)
    if name in ('admission.json','dispatch-confirmed.json'):e['source']='foreign-source'
    (folder/name).write_text(json.dumps(e))
   (root/'protocol-reservation-original.json').write_bytes((a.B/'protocol-reservation-original.json').read_bytes())
   with patch.object(capture,'BASE',root),patch.object(capture.sys,'argv',['capture','4']),patch.object(capture.subprocess,'run',side_effect=RuntimeError('NETWORK_REACHED')) as network:
    with self.assertRaisesRegex(SystemExit,'reservation/dispatch/admission mismatch'):capture.main()
    network.assert_not_called()
if __name__=='__main__':unittest.main()
