"""Offline controller regressions; synthetic bytes never calibrate performance."""
import ast,copy,datetime,hashlib,io,json,pathlib,re,subprocess,sys,tempfile,time,unittest,zipfile
from types import SimpleNamespace
sys.path.insert(0,str(pathlib.Path.cwd()))
from scripts import indexing_perf_gate as gate,indexing_perf_contract as contract,indexing_perf as collector
from scripts.tests.test_indexing_perf_gate import write_fixture
SCRIPT=pathlib.Path(sys.argv.pop(1))
class ControllerControls(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.folder=pathlib.Path(self.temp.name);self.addCleanup(self.temp.cleanup)
  tree=ast.parse(SCRIPT.read_text());self.tree=tree
  self.env={'hashlib':hashlib,'datetime':datetime,'json':json,'pathlib':pathlib,'subprocess':subprocess,'sys':sys,'time':time,'ROOT':pathlib.Path.cwd(),'OUT':self.folder,'HEAD':'a'*40,'REPO':'synthetic/repo','BRANCH':'control','DEADLINE':time.monotonic()+60,'gate':gate,'contract':contract,'COMPONENT_IDS':set(),'PR':999,'io':io,'zipfile':zipfile,'PROTOCOL':{'synthetic':True},'re':re}
  exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(SCRIPT),'exec'),self.env)
 def prepare(self,enforced=True):
  arts=self.folder/'artifacts';arts.mkdir();sources={}
  for group in contract.GROUPS:
   p=arts/group;p.mkdir();write_fixture(p,group,enforced=enforced)
   r=json.loads((p/'receipt.json').read_text());comparison=r['comparison']
   for role in gate.ROLES:
    q=p/(role+'-receipt.log');comp=json.loads(q.read_text());comp['run_id']=group+'-'+role;q.write_text(json.dumps(comp));comparison['legs'][role]['receipt_sha256']=collector.sha(q)
    sources[comp['source_before']['head']]=comp['source_before']
    if role=='candidate':r={**comp,'comparison':comparison}
   (p/'receipt.json').write_text(json.dumps(r))
  jobs=[{'name':f'Indexing Contention ({g})','conclusion':'success','startedAt':'2026-10-05T00:00:00Z','completedAt':'2026-10-05T00:00:10Z'} for g in contract.GROUPS]
  (self.folder/'state-final.json').write_text(json.dumps({'jobs':jobs}))
  self.env['command']=lambda *a,**k:'';self.env['git_identity']=lambda rev:copy.deepcopy(sources[rev]);
  reports={g:gate.load_comparison(arts/g,g) for g in contract.GROUPS}
  self.env['source_cli']=lambda p,g:copy.deepcopy(reports[g]);return sources
 def test_admission_keeps_full_source_revision_and_partition(self):
  self.prepare();v=self.env['download_and_admit']('123','a'*40,self.folder)
  self.assertEqual(v['source'],'a'*40);self.assertEqual(v['leg_rows'],1638);self.assertEqual((v['decision_count'],v['enforced_count'],v['diagnostic_count']),(136,68,68))
 def test_stop_during_command_cannot_return_for_dispatch(self):
  marker=self.folder/'STOP_REQUESTED';calls=[]
  def run(*a,**k):calls.append(k);marker.touch();return SimpleNamespace(returncode=0,stdout='remote-read',stderr='')
  old=self.env['subprocess'];self.env['subprocess']=SimpleNamespace(run=run)
  with self.assertRaisesRegex(RuntimeError,'stop marker'):self.env['command'](['synthetic','read'])
  self.assertEqual(len(calls),1);self.env['subprocess']=old
 def test_blocking_command_is_limited_by_remaining_campaign_time(self):
  self.env['DEADLINE']=time.monotonic()+.5;limits=[]
  def run(*a,**k):limits.append(k['timeout']);return SimpleNamespace(returncode=0,stdout='',stderr='')
  self.env['subprocess']=SimpleNamespace(run=run);self.env['command'](['synthetic','read'],timeout=45)
  self.assertTrue(0<limits[0]<=.5)
 def test_expiry_during_whole_validation_prevents_admission(self):
  self.prepare();real=gate.load_comparison;calls=[]
  def load(*a,**k):r=real(*a,**k);calls.append(1);self.env['DEADLINE']=time.monotonic()-1;return r
  self.env['gate']=SimpleNamespace(ROLES=gate.ROLES,REFERENCE=gate.REFERENCE,POLICY=gate.POLICY,load_comparison=load)
  with self.assertRaisesRegex(RuntimeError,'finite6h'):self.env['download_and_admit']('123','a'*40,self.folder)
  self.assertEqual(len(calls),3)
 def test_expiry_during_remote_identity_read_prevents_new_dispatch(self):
  self.env['PROTOCOL']={'sessions':[{'index':1,'role':'exploratory'}]};self.env['BRANCH']='synthetic';self.env['REPO']='synthetic';self.env['admitted']=[];dispatched=[]
  def api(*args):self.env['DEADLINE']=time.monotonic()-1;return {'object':{'sha':'a'*40}}
  self.env['api']=api;self.env['command']=lambda argv,*a,**k:dispatched.append(argv) or 'https://example.invalid/actions/runs/123';self.env['wait']=lambda *a,**k: (_ for _ in ()).throw(RuntimeError('unexpected-dispatch'))
  outer=next(n for n in self.tree.body if isinstance(n,ast.Try));loop=next(n for n in outer.body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='reserved')
  with self.assertRaisesRegex(RuntimeError,'finite6h'):exec(compile(ast.Module(body=[loop],type_ignores=[]),str(SCRIPT),'exec'),self.env)
  self.assertEqual(dispatched,[])
class ActiveModeControls(ControllerControls):
 def test_inactive_receipt_cannot_supply_active_campaign(self):
  self.prepare(enforced=False)
  with self.assertRaisesRegex(RuntimeError,'enforcement mismatch'):
   self.env['download_and_admit']('123','a'*40,self.folder)

class ActiveSourceControls(ControllerControls):
 def source_context(self, ordinary_attempt=1, guardian_attempt=1, ordinary_head=None, guardian_head=None, ordinary_result='success', guardian_result='success'):
  head='a'*40
  self.env['PROTOCOL']={'source_ci_run':'37366863724','source_ci_before_dispatch':{'attempt':1,'guardian':'37366753997'}}
  pr={'headRefOid':head,'isDraft':True,'autoMergeRequest':None,'state':'OPEN','statusCheckRollup':[{'name':n,'conclusion':'SUCCESS'} for n in ['CI Gate','CI Policy Guardian']]}
  ordinary={'headSha':ordinary_head or head,'attempt':ordinary_attempt,'status':'completed','conclusion':ordinary_result,'jobs':[]}
  guardian={'headSha':guardian_head or head,'attempt':guardian_attempt,'status':'completed','conclusion':guardian_result,'jobs':[]}
  self.reads=[];self.pr=pr
  def command(argv,*a,**k):
   if argv[1:3]==['pr','view']:return json.dumps(pr)
   self.reads.append(argv[3])
   return json.dumps(ordinary if argv[3]=='37366863724' else guardian)
  self.env['command']=command
 def test_valid_both_exact_attempt1_admitted(self):
  self.source_context();self.assertIsNone(self.env['wait_ci']())
  self.assertEqual(self.reads,['37366863724','37366753997'])
 def test_wrong_ordinary_attempts_rejected(self):
  for attempt in [2,3]:
   with self.subTest(attempt=attempt):
    self.source_context(ordinary_attempt=attempt)
    with self.assertRaisesRegex(RuntimeError,'source CI identity'):self.env['wait_ci']()
 def test_wrong_guardian_attempts_rejected(self):
  for attempt in [2,3]:
   with self.subTest(attempt=attempt):
    self.source_context(guardian_attempt=attempt)
    with self.assertRaisesRegex(RuntimeError,'Guardian identity'):self.env['wait_ci']()
 def test_wrong_ordinary_head_rejected(self):
  self.source_context(ordinary_head='b'*40)
  with self.assertRaisesRegex(RuntimeError,'source CI identity'):self.env['wait_ci']()
 def test_wrong_guardian_head_rejected(self):
  self.source_context(guardian_head='b'*40)
  with self.assertRaisesRegex(RuntimeError,'Guardian identity'):self.env['wait_ci']()
 def test_ordinary_failure_rejected(self):
  self.source_context(ordinary_result='failure')
  with self.assertRaisesRegex(RuntimeError,'source CI failed'):self.env['wait_ci']()
 def test_guardian_failure_rejected(self):
  self.source_context(guardian_result='failure')
  with self.assertRaisesRegex(RuntimeError,'Guardian failed'):self.env['wait_ci']()
 def test_ready_or_registered_pr_cannot_dispatch_calibration(self):
  for change in ({'isDraft':False},{'autoMergeRequest':{'enabled':True}},{'state':'MERGED'}):
   with self.subTest(change=change):
    self.source_context();self.pr.update(change)
    with self.assertRaisesRegex(RuntimeError,'draft/no-registration'):self.env['wait_ci']()
class NormalCliControls(ControllerControls):
 def configure_export(self):
  real=self.env['source_cli'];self.prepare();self.env['source_cli']=real
  folder=self.folder/'source-contract/scripts';folder.mkdir(parents=True)
  contents={n:(pathlib.Path.cwd()/'scripts'/n).read_bytes() for n in ('indexing_perf.py','indexing_perf_contract.py','indexing_perf_gate.py')}
  for n,data in contents.items():(folder/n).write_bytes(data)
  self.env['command_bytes']=lambda argv,**kwargs:contents[argv[-1].split(':scripts/')[1]]
  return self.folder/'artifacts/f1',contents
 def test_actual_normal_export_cli_pass_and_receipt_are_retained(self):
  packet,_=self.configure_export();report=self.env['source_cli'](packet,'f1')
  self.assertEqual(report,gate.load_comparison(packet,'f1'))
  execution=json.loads((packet/'actual-source-normal-cli-execution.json').read_text())
  self.assertEqual(execution['exit'],0);self.assertEqual(execution['source'],'a'*40)
  self.assertEqual(set(execution['script_hashes']),{'indexing_perf.py','indexing_perf_contract.py','indexing_perf_gate.py'})
  self.assertTrue((packet/'actual-source-normal-cli-stdout.json').exists())
  self.assertTrue((packet/'actual-source-normal-cli-stderr.log').exists())
 def test_exported_import_source_drift_rejects_before_cli(self):
  packet,_=self.configure_export();p=self.folder/'source-contract/scripts/indexing_perf_contract.py';p.write_bytes(p.read_bytes()+b'\n# synthetic drift\n')
  with self.assertRaisesRegex(RuntimeError,'import source drift'):self.env['source_cli'](packet,'f1')
  self.assertFalse((packet/'actual-source-normal-cli-execution.json').exists())
 def test_failed_normal_cli_logs_exit_stdout_stderr_and_rejects(self):
  packet,_=self.configure_export()
  self.env['subprocess']=SimpleNamespace(run=lambda *a,**k:SimpleNamespace(returncode=1,stdout='synthetic stdout',stderr='synthetic stderr'))
  with self.assertRaisesRegex(RuntimeError,'normal source CLI failed'):self.env['source_cli'](packet,'f1')
  self.assertEqual(json.loads((packet/'actual-source-normal-cli-execution.json').read_text())['exit'],1)
  self.assertEqual((packet/'actual-source-normal-cli-stderr.log').read_text(),'synthetic stderr')
class ReservationControls(ControllerControls):
 def config_guard(self):
  return next(n for n in self.tree.body if isinstance(n,ast.If) and 'source contract/reservation mismatch' in ast.unparse(n))
 def configure(self,active=True):
  self.env['PROTOCOL']={'reference':gate.REFERENCE,'comparison_protocol':gate.PROTOCOL,'policy_before_outcomes':gate.POLICY,'enforcement_active':active}
 def test_active_reservation_and_real_default_accepted(self):
  self.configure();exec(compile(ast.Module(body=[self.config_guard()],type_ignores=[]),str(SCRIPT),'exec'),self.env)
 def test_inactive_reservation_rejected(self):
  self.configure(False)
  with self.assertRaisesRegex(RuntimeError,'reservation mismatch'):exec(compile(ast.Module(body=[self.config_guard()],type_ignores=[]),str(SCRIPT),'exec'),self.env)
 def test_inactive_default_rejected(self):
  self.configure();self.env['gate']=SimpleNamespace(REFERENCE=gate.REFERENCE,PROTOCOL=gate.PROTOCOL,POLICY=gate.POLICY,ENFORCE_TIMING=False)
  with self.assertRaisesRegex(RuntimeError,'reservation mismatch'):exec(compile(ast.Module(body=[self.config_guard()],type_ignores=[]),str(SCRIPT),'exec'),self.env)
class OfflineControllerEnvironment(unittest.TestCase):
 setUp=ControllerControls.setUp

class StrictJsonControls(OfflineControllerEnvironment):
 def parsers(self):
  yield self.env['strict_json']
  tree=ast.parse(SCRIPT.with_name('verify_active_v10_campaign.py').read_text());env={'json':json}
  funcs=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('reject_nonfinite','finite_float','strict_json')]
  exec(compile(ast.Module(body=funcs,type_ignores=[]),'offline verifier JSON','exec'),env)
  yield env['strict_json']
 def test_finite_json_is_unchanged(self):
  for parser in self.parsers():self.assertEqual(parser('{"ratio":1.5,"enabled":true}'),{'ratio':1.5,'enabled':True})
 def test_json_constants_and_overflow_are_rejected(self):
  for parser in self.parsers():
   for value in ('NaN','Infinity','-Infinity','1e999','-1e999'):
    with self.subTest(value=value),self.assertRaisesRegex(ValueError,'nonfinite'):
     parser('{"value":'+value+'}')

class ReservedGeometryControls(OfflineControllerEnvironment):
 def protocol(self):
  geometry={'groups':list(contract.GROUPS),'required_cells':17,'required_leg_rows':1638,'required_observations':136,'required_enforced_medians':68,'required_maximum_diagnostics':68}
  return {'sessions':[dict(copy.deepcopy(geometry),index=i,role='exploratory' if i<=3 else 'held-out') for i in range(1,6)],'budget_seconds':{'build':1800,'measurement':2700,'job':5400,'campaign':21600},'source_ci_run':1,'source_ci_before_dispatch':{'run':1,'source':'a'*40,'pr':999},'reference_ci_before_dispatch':{'source':gate.REFERENCE},'core_source':'a'*40,'reference':gate.REFERENCE,'source_pr':999,'heldout_freeze_guard_seconds':2}
 def test_all_five_whole_slots_and_original_caps_accepted(self):
  self.env['validate_reserved_geometry'](self.protocol())
 def test_missing_reordered_and_boolean_index_rejected(self):
  for mutation in ('missing','reordered','boolean'):
   p=self.protocol()
   if mutation=='missing':p['sessions'].pop()
   elif mutation=='reordered':p['sessions'][0]['role']='held-out'
   else:p['sessions'][0]['index']=True
   with self.subTest(mutation=mutation),self.assertRaisesRegex(RuntimeError,'five-session order'):
    self.env['validate_reserved_geometry'](p)
 def test_partial_group_rows_or_diagnostics_cannot_be_reserved(self):
  for key,value in [('groups',['f1','matched']),('required_leg_rows',1637),('required_maximum_diagnostics',67)]:
   p=self.protocol();p['sessions'][4][key]=value
   with self.subTest(key=key),self.assertRaisesRegex(RuntimeError,'whole-session geometry'):
    self.env['validate_reserved_geometry'](p)
 def test_resource_extension_rejected(self):
  for field in ('build','measurement','job','campaign'):
   p=self.protocol();p['budget_seconds'][field]+=1
   with self.subTest(field=field),self.assertRaisesRegex(RuntimeError,'resource bounds'):
    self.env['validate_reserved_geometry'](p)
 def test_source_and_native_identity_must_agree(self):
  for field in ('run','source','pr'):
   p=self.protocol();p['source_ci_before_dispatch'][field]='wrong'
   with self.subTest(field=field),self.assertRaisesRegex(RuntimeError,'native declarations'):
    self.env['validate_reserved_geometry'](p)
 def test_heldout_boundary_guard_is_fixed_before_outcomes(self):
  p=self.protocol();p['heldout_freeze_guard_seconds']=0
  with self.assertRaisesRegex(RuntimeError,'freeze guard'):self.env['validate_reserved_geometry'](p)

class NullSourceControls(OfflineControllerEnvironment):
 def configure(self):
  before='REFERENCE = "'+'e'*40+'"\nPROTOCOL = "old-control"\nPOLICY = unchanged\n'
  after=before.replace('e'*40,gate.REFERENCE).replace('old-control',gate.PROTOCOL)
  tests_before='self.assertEqual(gate.REFERENCE, "'+'e'*40+'")\nself.assertEqual(gate.PROTOCOL, "old-control")\n'
  tests_after=tests_before.replace('e'*40,gate.REFERENCE).replace('old-control',gate.PROTOCOL)
  common={'rust/Cargo.toml':'1'*64,'rust/src/indexer/mod.rs':'2'*64}
  blobs={gate.REFERENCE:{'scripts/indexing_perf_gate.py':before.encode(),'scripts/tests/test_indexing_perf_gate.py':tests_before.encode()},'a'*40:{'scripts/indexing_perf_gate.py':after.encode(),'scripts/tests/test_indexing_perf_gate.py':tests_after.encode()}}
  identities={revision:{'head':revision,'tree':('c' if revision==gate.REFERENCE else 'd')*40,'files':{**common,**{path:hashlib.sha256(content).hexdigest() for path,content in values.items()}}} for revision,values in blobs.items()}
  self.env['git_identity']=lambda revision:copy.deepcopy(identities[revision])
  self.env['command_bytes']=lambda argv:blobs[argv[-1].split(':',1)[0]][argv[-1].split(':',1)[1]]
  return identities,blobs
 def test_only_pin_protocol_and_equal_rust_can_be_null(self):
  self.configure();self.env['verify_null_inputs']()
  result=json.loads((self.folder/'null-input-identity-before-dispatch.json').read_text())
  self.assertEqual(result['equal_rust_inputs'],2)
 def test_product_or_extra_source_change_is_rejected(self):
  for path in ('rust/src/indexer/mod.rs','scripts/unreviewed.py'):
   with self.subTest(path=path):
    identities,_=self.configure();identities['a'*40]['files'][path]='3'*64
    with self.assertRaisesRegex(RuntimeError,'only comparator pin/protocol'):self.env['verify_null_inputs']()
 def test_comparator_policy_change_cannot_hide_in_null(self):
  _,blobs=self.configure();blobs['a'*40]['scripts/indexing_perf_gate.py']+=b'POLICY = weakened\n'
  with self.assertRaisesRegex(RuntimeError,'beyond fixed reference/protocol'):self.env['verify_null_inputs']()
 def test_pin_test_weakening_or_other_edits_are_rejected(self):
  for suffix in (b'\n# unrelated edit\n',b'\nself.assertTrue(True)\n'):
   _,blobs=self.configure();blobs['a'*40]['scripts/tests/test_indexing_perf_gate.py']+=suffix
   with self.assertRaisesRegex(RuntimeError,'beyond the two fixed expected literals'):self.env['verify_null_inputs']()

class NativeAdmissionControls(OfflineControllerEnvironment):
 def configure(self):
  expected='a'*40;checkout='d'*40;tree='c'*40
  mandatory=['Detect Changes','CI Policy','CI Gate','Clippy and Coverage','Rust Test and Build (linux-native)','Rust Test and Build (macos-native)','Rust Test and Build (windows-native)','Windows GNU Updater Build','Windows GNU Updater E2E']
  ci={'headSha':expected,'attempt':1,'status':'completed','conclusion':'success','jobs':[{'name':n,'conclusion':'success'} for n in mandatory]+[{'name':'Cargo Audit','conclusion':'skipped'}]}
  guardian={'headSha':expected,'attempt':1,'status':'completed','conclusion':'success','jobs':[]}
  self.env['state']=lambda run:copy.deepcopy(ci if run==1 else guardian)
  pr={'headRefOid':expected,'isDraft':True,'state':'OPEN','autoMergeRequest':None}
  self.env['command']=lambda *args,**kwargs:json.dumps(pr)
  commit={'tree':{'sha':tree},'parents':[{'sha':'b'*40},{'sha':expected}]}
  self.env['api']=lambda endpoint:copy.deepcopy(commit)
  self.env['git_identity']=lambda revision:{'tree':tree,'files':{}}
  entries={n+'/2_Checkout.txt':('actual checkout\n'+checkout+'\n').encode() for n in mandatory if n!='CI Gate'}
  for n in mandatory:
   if n.startswith('Rust Test and Build') or n=='Clippy and Coverage':
    entries[n+('/11_Generate coverage report.txt' if n=='Clippy and Coverage' else '/6_Run tests.txt')]=b'test result: ok. 1600 passed; 0 failed; 19 ignored;\n'
  declaration={'source':expected,'run':1,'guardian':2,'pr':999,'actual_checkout':{'sha':checkout,'tree':tree,'parents':['b'*40,expected]},'expected_log_hashes':{n:hashlib.sha256(b).hexdigest() for n,b in entries.items()}}
  for i,n in enumerate(mandatory+['Cargo Audit']):entries[str(i)+'_'+n+'.txt']=('aggregate '+n+'\n').encode()
  support=self.folder/'tooling-support';support.mkdir(exist_ok=True)
  declaration['native_original_zip']='synthetic-native-original.zip'
  def archive(*args,**kwargs):
   out=io.BytesIO()
   with zipfile.ZipFile(out,'w') as z:
    for n,b in entries.items():z.writestr(n,b)
   return out.getvalue()
  def bind_cached():
   raw=archive();(support/declaration['native_original_zip']).write_bytes(raw)
   declaration['native_original_zip_sha256']=hashlib.sha256(raw).hexdigest()
   self.env['PROTOCOL']={'support_files':{declaration['native_original_zip']:declaration['native_original_zip_sha256']}}
  self.bind_cached=bind_cached;bind_cached()
  self.env['command_bytes']=archive
  return expected,declaration,ci,guardian,pr,commit,entries
 def test_actual_native_source_all_axes_logs_and_tree_admitted(self):
  expected,declaration,*_=self.configure();self.env['verify_native_context']('source',declaration,expected)
  self.assertTrue((self.folder/'source-native-before-dispatch.json').exists())
 def test_whole_success_cannot_hide_skipped_windows_axis(self):
  expected,declaration,ci,*_=self.configure()
  next(j for j in ci['jobs'] if j['name']=='Rust Test and Build (windows-native)')['conclusion']='skipped'
  with self.assertRaisesRegex(RuntimeError,'axis skipped'):self.env['verify_native_context']('source',declaration,expected)
 def test_native_rerun_or_wrong_guardian_head_rejected(self):
  for field in ('attempt','head'):
   with self.subTest(field=field):
    expected,declaration,ci,guardian,*_=self.configure()
    if field=='attempt':ci['attempt']=2
    else:guardian['headSha']='e'*40
    with self.assertRaisesRegex(RuntimeError,'fresh exact-source'):self.env['verify_native_context']('source',declaration,expected)
 def test_same_head_with_wrong_actual_tree_rejected(self):
  expected,declaration,_,_,_,commit,_=self.configure();commit['tree']['sha']='e'*40
  with self.assertRaisesRegex(RuntimeError,'tree/parent'):self.env['verify_native_context']('source',declaration,expected)
 def test_changed_original_log_hash_rejected(self):
  expected,declaration,_,_,_,_,entries=self.configure();name=next(iter(entries));entries[name]+=b'new output\n';self.bind_cached()
  with self.assertRaisesRegex(RuntimeError,'log identities changed'):self.env['verify_native_context']('source',declaration,expected)
 def test_missing_checkout_cannot_be_declared_away(self):
  expected,declaration,_,_,_,_,entries=self.configure();name='Rust Test and Build (windows-native)/2_Checkout.txt';del entries[name];del declaration['expected_log_hashes'][name];self.bind_cached()
  with self.assertRaisesRegex(RuntimeError,'checkout inventory'):self.env['verify_native_context']('source',declaration,expected)
 def test_each_native_test_log_cannot_be_declared_away(self):
  names=['Rust Test and Build (linux-native)/6_Run tests.txt','Rust Test and Build (macos-native)/6_Run tests.txt','Rust Test and Build (windows-native)/6_Run tests.txt','Clippy and Coverage/11_Generate coverage report.txt']
  for missing in [[n] for n in names]+[names]:
   with self.subTest(missing=missing):
    expected,declaration,_,_,_,_,entries=self.configure()
    for name in missing:del entries[name];del declaration['expected_log_hashes'][name]
    self.bind_cached()
    with self.assertRaisesRegex(RuntimeError,'required four native'):self.env['verify_native_context']('source',declaration,expected)

 def test_live_aggregate_only_format_admitted_with_original_step_evidence(self):
  expected,declaration,*rest=self.configure();entries=rest[-1]
  for name in list(entries):
   if '/' in name:del entries[name]
  self.env['verify_native_context']('source',declaration,expected)
  proof=json.loads((self.folder/'source-native-before-dispatch.json').read_text())
  self.assertEqual(proof['log_packaging']['live_step_logs'],0)
  self.assertEqual(proof['log_packaging']['cached_step_logs'],12)
 def test_live_aggregate_missing_extra_or_mutation_rejected(self):
  for mode in ('missing','extra','mutation'):
   with self.subTest(mode=mode):
    expected,declaration,*rest=self.configure();entries=rest[-1];name=next(n for n in entries if '/' not in n)
    if mode=='missing':del entries[name]
    elif mode=='extra':entries['99_unexpected.txt']=b'new job'
    else:entries[name]+=b'changed'
    with self.assertRaisesRegex(RuntimeError,'live aggregate inventory or bytes'):self.env['verify_native_context']('source',declaration,expected)
 def test_live_partial_or_changed_step_logs_rejected(self):
  for mode in ('partial','changed'):
   with self.subTest(mode=mode):
    expected,declaration,*rest=self.configure();entries=rest[-1];name=next(n for n in entries if n.endswith('/6_Run tests.txt'))
    if mode=='partial':del entries[name]
    else:entries[name]+=b'changed'
    with self.assertRaisesRegex(RuntimeError,'live partial or changed step'):self.env['verify_native_context']('source',declaration,expected)
 def test_cached_corruption_replacement_or_support_binding_rejected(self):
  for mode in ('corrupt','replace','unbound'):
   with self.subTest(mode=mode):
    expected,declaration,*_=self.configure();p=self.folder/'tooling-support'/declaration['native_original_zip']
    if mode=='corrupt':p.write_bytes(p.read_bytes()[:-20])
    elif mode=='replace':p.write_bytes(b'unrelated ZIP')
    else:self.env['PROTOCOL']['support_files'][declaration['native_original_zip']]='0'*64
    with self.assertRaisesRegex(RuntimeError,'cached original ZIP hash'):self.env['verify_native_context']('source',declaration,expected)
 def test_duplicate_native_archive_entry_rejected(self):
  expected,declaration,*rest=self.configure();entries=rest[-1];raw=io.BytesIO()
  with zipfile.ZipFile(raw,'w') as z:
   for n,b in entries.items():z.writestr(n,b)
   with self.assertWarns(UserWarning):z.writestr(next(iter(entries)),b'duplicate')
  self.env['command_bytes']=lambda *a,**k:raw.getvalue()
  with self.assertRaisesRegex(RuntimeError,'duplicate entry'):self.env['verify_native_context']('source',declaration,expected)

class DispatchHistoryControls(OfflineControllerEnvironment):
 def configure(self):
  pr={'headRefOid':'a'*40,'isDraft':True,'state':'OPEN','autoMergeRequest':None}
  runs=[]
  self.env['command']=lambda *args,**kwargs:json.dumps(pr)
  self.env['api']=lambda endpoint:{'workflow_runs':runs}
  return pr,runs
 def test_only_prior_reserved_admitted_runs_are_allowed(self):
  _,runs=self.configure();self.env['verify_dispatch_identity']([])
  runs.append({'id':123,'head_sha':'a'*40,'run_attempt':1,'status':'completed','conclusion':'success'});self.env['verify_dispatch_identity']([{'run':'123'}])
 def test_unexpected_same_branch_run_stops_even_if_completed(self):
  _,runs=self.configure();runs.append({'id':123,'head_sha':'a'*40,'status':'completed'})
  with self.assertRaisesRegex(RuntimeError,'unexpected same-branch'):self.env['verify_dispatch_identity']([])
 def test_wrong_run_head_or_ready_pr_stops(self):
  pr,runs=self.configure();runs.append({'id':123,'head_sha':'b'*40})
  with self.assertRaisesRegex(RuntimeError,'unexpected same-branch'):self.env['verify_dispatch_identity']([{'run':'123'}])
  runs.clear();pr['isDraft']=False
  with self.assertRaisesRegex(RuntimeError,'draft/open/no-auto'):self.env['verify_dispatch_identity']([])
 def test_late_rerun_or_state_change_of_an_admitted_id_stops(self):
  for change in ({'run_attempt':2},{'status':'in_progress'},{'conclusion':'failure'}):
   with self.subTest(change=change):
    _,runs=self.configure();run={'id':123,'head_sha':'a'*40,'run_attempt':1,'status':'completed','conclusion':'success'};run.update(change);runs.append(run)
    with self.assertRaisesRegex(RuntimeError,'unexpected same-branch'):self.env['verify_dispatch_identity']([{'run':'123'}])

class DispatchResponseControls(OfflineControllerEnvironment):
 def url(self,run,repo=None):return 'https://github.com/'+(repo or self.env['REPO'])+'/actions/runs/'+str(run)
 def test_one_repository_id_including_repeated_same_url_is_unique(self):
  text=self.url(123)+'\nview '+self.url(123)+'?check_suite_focus=true'
  self.assertEqual(self.env['resolve_dispatch_run'](text,[]),'123')
 def test_two_candidates_missing_foreign_or_admitted_id_stop(self):
  for text,admitted in [(self.url(123)+'\n'+self.url(456),[]),('event created',[]),(self.url(123,'foreign/repository'),[]),(self.url(123),[{'run':'123'}])]:
   with self.subTest(text=text),self.assertRaisesRegex(RuntimeError,'do not retry'):
    self.env['resolve_dispatch_run'](text,admitted)
 def test_ambiguous_dispatch_keeps_starting_and_never_dispatches_again(self):
  self.env['PROTOCOL']={'sessions':[{'index':1,'role':'exploratory'},{'index':2,'role':'exploratory'}]};self.env['admitted']=[];calls=[]
  def api(endpoint):return {'object':{'sha':'a'*40}} if endpoint.startswith('git/') else {'workflow_runs':[]}
  def command(argv,*args,**kwargs):
   if argv[1:3]==['pr','view']:return json.dumps({'headRefOid':'a'*40,'isDraft':True,'state':'OPEN','autoMergeRequest':None})
   calls.append(argv);return self.url(123)+'\n'+self.url(456)
  self.env['api']=api;self.env['command']=command;self.env['wait']=lambda *args:self.fail('ambiguous response must not select a run')
  outer=next(n for n in self.tree.body if isinstance(n,ast.Try));loop=next(n for n in outer.body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='reserved')
  with self.assertRaisesRegex(RuntimeError,'no unique run ID'):exec(compile(ast.Module(body=[loop],type_ignores=[]),'ambiguous dispatch','exec'),self.env)
  self.assertEqual(len(calls),1);self.assertTrue((self.folder/'session-1/dispatch-attempt.json').exists())
  self.assertFalse((self.folder/'session-1/dispatch-confirmed.json').exists());self.assertFalse((self.folder/'session-2').exists())

class FinalInventoryControls(DispatchHistoryControls):
 def finish_context(self,extra=False):
  _,runs=self.configure();admitted=[{'run':str(i),'role':'exploratory' if i<=3 else 'held-out'} for i in range(1,6)]
  runs.extend({'id':i,'head_sha':'a'*40,'run_attempt':1,'status':'completed','conclusion':'success'} for i in range(1,7 if extra else 6))
  self.env['COMPONENT_IDS']={str(i) for i in range(45)}
  return admitted
 def test_all_five_remote_ids_are_saved_before_complete(self):
  self.env['finish_campaign'](self.finish_context())
  self.assertTrue((self.folder/'complete.json').exists());self.assertTrue((self.folder/'final-remote-run-inventory.json').exists())
 def test_extra_run_after_last_slot_preserves_inventory_and_stops_complete(self):
  with self.assertRaisesRegex(RuntimeError,'unexpected same-branch'):self.env['finish_campaign'](self.finish_context(extra=True))
  self.assertFalse((self.folder/'complete.json').exists())
  inventory=json.loads((self.folder/'remote-run-inventory-latest.json').read_text());self.assertEqual(len(inventory['workflow_runs']),6)

if __name__=='__main__':unittest.main()
