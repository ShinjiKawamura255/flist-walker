#!/usr/bin/env python3
"""Owned serial readonly/dispatch campaign. No policy writes or merge registration."""
import datetime,hashlib,io,json,pathlib,re,subprocess,sys,time,zipfile
ROOT=pathlib.Path.cwd();sys.path.insert(0,str(ROOT))
from scripts import indexing_perf_gate as gate
from scripts import indexing_perf_contract as contract
def reject_nonfinite(value):
    raise ValueError('nonfinite JSON value: '+value)
def finite_float(value):
    number=float(value)
    if number in (float('inf'),float('-inf')):reject_nonfinite(value)
    return number
def strict_json(value):
    return json.loads(value,parse_constant=reject_nonfinite,parse_float=finite_float)
def validate_reserved_geometry(protocol):
    sessions=protocol['sessions']
    if ([s['role'] for s in sessions]!=['exploratory']*3+['held-out']*2
        or [s['index'] for s in sessions]!=[1,2,3,4,5]
        or any(type(s['index']) is not int for s in sessions)):
        raise RuntimeError('five-session order mismatch')
    expected={'groups':list(contract.GROUPS),'required_cells':17,'required_leg_rows':1638,
        'required_observations':136,'required_enforced_medians':68,'required_maximum_diagnostics':68}
    if any(any(s.get(k)!=v for k,v in expected.items()) for s in sessions):
        raise RuntimeError('reserved whole-session geometry mismatch')
    if protocol['budget_seconds']!={'build':1800,'measurement':2700,'job':5400,'campaign':21600}:
        raise RuntimeError('reserved resource bounds changed')
    if (str(protocol['source_ci_run'])!=str(protocol['source_ci_before_dispatch']['run'])
        or protocol['source_ci_before_dispatch']['source']!=protocol['core_source']
        or protocol['reference_ci_before_dispatch']['source']!=protocol['reference']
        or protocol['source_ci_before_dispatch']['pr']!=protocol['source_pr']):
        raise RuntimeError('reserved source/native declarations disagree')
    if protocol['heldout_freeze_guard_seconds']!=2:
        raise RuntimeError('reserved heldout freeze guard changed')
REPO='ShinjiKawamura255/flist-walker'
OUT=ROOT/'rust/target/warm-reclaim-calibration/campaign-active-v10'
PROTOCOL_PATH=ROOT/'rust/target/warm-reclaim-calibration/campaign-protocol-active-v10.json'
PROTOCOL=strict_json(PROTOCOL_PATH.read_text())
BRANCH=PROTOCOL['source_branch'];PR=PROTOCOL['source_pr']
HEAD=PROTOCOL['core_source']
if (PROTOCOL['repository']!=REPO or not re.fullmatch(r'codex/[a-z0-9/-]+',BRANCH)
    or type(PR) is not int or PR<=0 or not re.fullmatch(r'[0-9a-f]{40}',HEAD)):
    raise RuntimeError('reserved repository/branch/PR/head identity invalid')
if PROTOCOL['controller_sha256'] != hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest():
    raise RuntimeError('controller changed after reservation')
if PROTOCOL['reference'] != gate.REFERENCE or PROTOCOL['comparison_protocol'] != gate.PROTOCOL or PROTOCOL['policy_before_outcomes'] != gate.POLICY or gate.ENFORCE_TIMING is not True or PROTOCOL["enforcement_active"] is not True:
    raise RuntimeError('source contract/reservation mismatch')
validate_reserved_geometry(PROTOCOL)
if sys.flags.optimize:
    raise RuntimeError('campaign requires assertions enabled for its offline verifier')
if sys.argv[1:] == ['--validate-only']:
    print('VALIDATED active v10 reservation/controller/source: five sessions, 68 enforced medians and 68 MAX diagnostics per session')
    sys.exit(0)
if sys.argv[1:]:
    raise RuntimeError('unknown controller option')
OUT.mkdir(exist_ok=False)
COMPONENT_IDS=set()
DEADLINE=time.monotonic()+6*3600

def save(path,data):
    path.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')

def command(argv,timeout=45):
    ensure_time()
    limit=min(timeout,DEADLINE-time.monotonic())
    result=subprocess.run(argv,cwd=ROOT,text=True,capture_output=True,timeout=limit)
    ensure_time()
    if result.returncode:
        raise RuntimeError(f'command exit{result.returncode}: '+str(argv[:4])+' '+result.stderr[-1000:])
    return result.stdout

def command_bytes(argv,timeout=45):
    ensure_time()
    result=subprocess.run(argv,cwd=ROOT,capture_output=True,timeout=min(timeout,DEADLINE-time.monotonic()))
    ensure_time()
    if result.returncode:
        raise RuntimeError('byte command failed '+str(argv[:3]))
    return result.stdout

def api(endpoint):return strict_json(command(['gh','api',f'repos/{REPO}/'+endpoint]))
def state(run):return strict_json(command(['gh','run','view',str(run),'--repo',REPO,'--json','status,conclusion,headSha,jobs,createdAt,attempt']))
def ensure_time():
    if (OUT/'STOP_REQUESTED').exists():raise RuntimeError('explicit local stop marker; no further dispatch')
    if time.monotonic()>=DEADLINE:raise RuntimeError('campaign finite6h bound exhausted')
def wait(run,expected,folder):
    old=None
    while True:
        ensure_time();s=state(run);save(folder/'state-latest.json',s)
        if s['headSha']!=expected:raise RuntimeError('run source mismatch')
        key=(s['status'],s['conclusion'],tuple((j['name'],j['status'],j['conclusion']) for j in s['jobs']))
        if key!=old:
            print(json.dumps({'run':run,'status':s['status'],'conclusion':s['conclusion'],
                'jobs':key[2]}),flush=True);old=key
        if s['status']=='completed':save(folder/'state-final.json',s);return s
        time.sleep(30)

def git_identity(revision):
    names=command(['git','ls-tree','-r','--name-only','-z',revision]).split('\0')
    files={}
    for name in names:
        if name.startswith(('rust/','scripts/','.github/workflows/','.cargo/')):
            content=command_bytes(['git','show',revision+':'+name])
            files[name]=hashlib.sha256(content).hexdigest()
    return {'head':revision,'tree':command(['git','rev-parse',revision+'^{tree}']).strip(),
            'files':files,'local_controls':[]}

def download_and_admit(run,expected,folder,required_null=True):
    command(['gh','run','download',run,'--repo',REPO,'--pattern',f'indexing-contention-{run}-1-*',
        '--dir',str(folder/'artifacts')],timeout=180)
    dirs=[p for p in (folder/'artifacts').iterdir() if p.is_dir()]
    if len(dirs)!=3:raise RuntimeError('exactly3artifacts required')
    measured=git_identity(expected);reference=git_identity(gate.REFERENCE)
    reports={};legrows=0;decisions=0;enforced=0;diagnostics=0;rejected=[];resources=[];session_ids=set()
    for packet in dirs:
        receipt=strict_json((packet/'receipt.json').read_text());group=receipt['group']
        if group in reports:raise RuntimeError('duplicate group')
        if receipt['comparison']['enforced'] is not True:raise RuntimeError('calibration enforcement mismatch')
        if receipt['source_before']!=measured:raise RuntimeError('candidate source/tree/allfiles mismatch')
        proposal=gate.load_comparison(packet,group)
        actual_cli=source_cli(packet,group)
        if actual_cli!=proposal:raise RuntimeError('actual normal source CLI differs from normal comparator')
        expected_count=len(contract.cells_for(group))*4
        if proposal['decision_count']!=expected_count*2 or proposal['enforced_count']!=expected_count or proposal['diagnostic_count']!=expected_count:
            raise RuntimeError('per-group observation/median/diagnostic count mismatch')
        for d in proposal['decisions']:
            if (d['statistic']=='median' and (d['enforced'] is not True or d['status'] not in ('pass','timing-fail','indeterminate'))) or (d['statistic']=='max' and (d['enforced'] is not False or d['status']!='diagnostic')) or d['statistic'] not in ('median','max'):
                raise RuntimeError('observation enforcement role mismatch')
        elapsed={'build':0.,'measurement':0.}
        if required_null and (proposal['status']!='pass' or not proposal['null_rust_sources_equal']):
            save(folder/(group+'-rejected-proposal.json'),proposal)
            rejected.append(group+' '+proposal['status'])
        for role in gate.ROLES:
            component=strict_json((packet/(role+'-receipt.log')).read_text())
            component_id=component['run_id']
            if component_id in COMPONENT_IDS or component_id in session_ids:
                raise RuntimeError('component UUID reused')
            session_ids.add(component_id)
            for phase in elapsed:
                elapsed[phase]+=component['processes'][phase]['elapsed_seconds']
            runner=component['runner']
            if runner['GITHUB_RUN_ID']!=str(run) or runner['GITHUB_RUN_ATTEMPT']!='1' or runner['GITHUB_SHA']!=HEAD or runner['GITHUB_WORKFLOW_SHA']!=HEAD:
                raise RuntimeError('actual execution context mismatch')
            if runner['GITHUB_WORKFLOW_REF']!=f'{REPO}/.github/workflows/perf-regression.yml@refs/heads/{BRANCH}':
                raise RuntimeError('actual execution workflow/ref mismatch')
            if role!='candidate' and component['source_before']!=reference:
                raise RuntimeError('reference source/tree/allfiles mismatch')
            raw=packet/('measurement.log' if role=='candidate' else role+'-measurement.log')
            admitted=contract.validate_log(raw.read_bytes().decode(),group)
            legrows+=len(admitted['rows'])
        if elapsed['build']>1800 or elapsed['measurement']>2700:
            raise RuntimeError('shared build/measurement budget exceeded')
        final=strict_json((folder/'state-final.json').read_text())
        job=next(j for j in final['jobs'] if j['name']==f'Indexing Contention ({group})')
        duration=(datetime.datetime.fromisoformat(job['completedAt'])-datetime.datetime.fromisoformat(job['startedAt'])).total_seconds()
        if job['conclusion']!='success' or not 0<duration<=5400:
            raise RuntimeError('job physical/resource admission failed')
        resources.append(dict(group=group,shared_build_seconds=elapsed['build'],shared_measurement_seconds=elapsed['measurement'],job_seconds=duration))
        decisions+=proposal['decision_count'];enforced+=proposal['enforced_count'];diagnostics+=proposal['diagnostic_count'];reports[group]=proposal
        save(folder/(group+'-proposal.json'),proposal)
    if set(reports)!=set(contract.GROUPS) or legrows!=1638 or decisions!=136 or enforced!=68 or diagnostics!=68 or len(session_ids)!=9:
        raise RuntimeError('whole17cell/1638row/136observation/68median/68diagnostic coverage incomplete')
    ensure_time()
    verdict={'run':run,'source':expected,'whole_null_pass':required_null,'leg_rows':legrows,
        'decision_count':decisions,'enforced_count':enforced,'diagnostic_count':diagnostics,'component_ids':sorted(session_ids),'resources':resources,'groups':{k:{'status':v['status'],'null_rust_sources_equal':v['null_rust_sources_equal'],
            'worst_enforced_median_ratio':max(d['candidate_ratio'] for d in v['decisions'] if d['enforced']),
            'worst_maximum_ratio_diagnostic':max(d['candidate_ratio'] for d in v['decisions'] if not d['enforced']),
            'worst_reference_median_drift':max(d['reference_median_drift_ratio'] for d in v['decisions']),
            'worst_reference_tail_ratio':max(d['reference_tail_ratio'] for d in v['decisions']),
            'worst_reference_max_drift_diagnostic':max(d['reference_drift_ratio'] for d in v['decisions'] if d['statistic']=='max')} for k,v in reports.items()},
        'policy':gate.POLICY,'protocol':PROTOCOL}
    verdict['whole_null_pass']=required_null and not rejected
    save(folder/'admission.json',verdict)
    COMPONENT_IDS.update(session_ids)
    if rejected:raise RuntimeError('whole null session rejected: '+', '.join(rejected))
    return verdict

def source_cli(packet,group):
    ensure_time()
    # Exported siblings resolve as the same actual source package, not local modules.
    scripts=OUT/'source-contract/scripts'
    for name in ('indexing_perf.py','indexing_perf_contract.py','indexing_perf_gate.py'):
        if (scripts/name).read_bytes()!=command_bytes(['git','show',HEAD+':scripts/'+name]):
            raise RuntimeError('exported actual CLI/import source drift')
    argv=[sys.executable,str(scripts/'indexing_perf.py'),'validate','--group',group,str(packet)]
    result=subprocess.run(argv,cwd=ROOT,text=True,capture_output=True,
        timeout=min(90,DEADLINE-time.monotonic()))
    (packet/'actual-source-normal-cli-stdout.json').write_text(result.stdout)
    (packet/'actual-source-normal-cli-stderr.log').write_text(result.stderr)
    save(packet/'actual-source-normal-cli-execution.json',{'argv':argv,'exit':result.returncode,
        'source':HEAD,'script_hashes':{n:hashlib.sha256((scripts/n).read_bytes()).hexdigest()
            for n in ('indexing_perf.py','indexing_perf_contract.py','indexing_perf_gate.py')}})
    ensure_time()
    if result.returncode:raise RuntimeError('actual normal source CLI failed; no diagnostic fallback')
    report=strict_json(result.stdout)
    if report['status']!='pass':raise RuntimeError('normal source CLI did not PASS')
    return report

def verify_null_inputs():
    source=git_identity(HEAD);reference=git_identity(gate.REFERENCE)
    changed={p for p in source['files'].keys()|reference['files'].keys()
             if source['files'].get(p)!=reference['files'].get(p)}
    if changed!={'scripts/indexing_perf_gate.py','scripts/tests/test_indexing_perf_gate.py'}:
        raise RuntimeError('null source may change only comparator pin/protocol and their fixed test literals outside docs')
    before=command_bytes(['git','show',gate.REFERENCE+':scripts/indexing_perf_gate.py']).decode()
    after=command_bytes(['git','show',HEAD+':scripts/indexing_perf_gate.py']).decode()
    expected,nref=re.subn(r'^REFERENCE = "[0-9a-f]{40}"$',f'REFERENCE = "{gate.REFERENCE}"',before,flags=re.M)
    expected,nprotocol=re.subn(r'^PROTOCOL = "[^"]+"$',f'PROTOCOL = "{gate.PROTOCOL}"',expected,flags=re.M)
    if nref!=1 or nprotocol!=1 or after!=expected:
        raise RuntimeError('null comparator changed beyond fixed reference/protocol')
    oldref=re.search(r'^REFERENCE = "([0-9a-f]{40})"$',before,re.M).group(1)
    oldprotocol=re.search(r'^PROTOCOL = "([^"]+)"$',before,re.M).group(1)
    tests_before=command_bytes(['git','show',gate.REFERENCE+':scripts/tests/test_indexing_perf_gate.py']).decode()
    tests_after=command_bytes(['git','show',HEAD+':scripts/tests/test_indexing_perf_gate.py']).decode()
    ref_assert=f'self.assertEqual(gate.REFERENCE, "{oldref}")'
    protocol_assert=f'self.assertEqual(gate.PROTOCOL, "{oldprotocol}")'
    if tests_before.count(ref_assert)!=1 or tests_before.count(protocol_assert)!=1:
        raise RuntimeError('reference pin tests have unexpected identity')
    tests_expected=tests_before.replace(ref_assert,f'self.assertEqual(gate.REFERENCE, "{gate.REFERENCE}")').replace(
        protocol_assert,f'self.assertEqual(gate.PROTOCOL, "{gate.PROTOCOL}")')
    if tests_after!=tests_expected:
        raise RuntimeError('null pin tests changed beyond the two fixed expected literals')
    save(OUT/'null-input-identity-before-dispatch.json',{
        'source':source,'reference':reference,'equal_rust_inputs':sum(p.startswith('rust/') for p in source['files']),
        'changed_source_files':sorted(changed),'only_fixed_pin_protocol_and_expected_test_literals_delta':True})

def admit_native_log_archives(live,cached):
    suffixes=('/2_Checkout.txt','/6_Run tests.txt','/11_Generate coverage report.txt')
    def read_archive(raw):
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            names=archive.namelist()
            if len(names)!=len(set(names)):raise RuntimeError('native archive duplicate entry')
            if archive.testzip() is not None:raise RuntimeError('native archive CRC failed')
            aggregates={n:archive.read(n) for n in names if re.fullmatch(r'[0-9]+_[^/]+\.txt',n)}
            steps={n:archive.read(n) for n in names if n.endswith(suffixes)}
            return aggregates,steps
    cached_aggregates,cached_steps=read_archive(cached)
    live_aggregates,live_steps=read_archive(live)
    if len(cached_aggregates)!=10 or live_aggregates!=cached_aggregates:
        raise RuntimeError('native live aggregate inventory or bytes mismatch')
    if live_steps and live_steps!=cached_steps:
        raise RuntimeError('native live partial or changed step logs')
    observed={n:hashlib.sha256(data).hexdigest() for n,data in cached_steps.items()}
    checkouts={}
    for name,data in cached_steps.items():
        if name.endswith('/2_Checkout.txt'):
            shas=re.findall(r'(?m)^.*?\b([0-9a-f]{40})\s*$',data.decode())
            if not shas:raise RuntimeError('native actual checkout missing')
            checkouts[name.rsplit('/',1)[0]]=shas[-1]
    return observed,checkouts,{'live_step_logs':len(live_steps),'cached_step_logs':len(cached_steps),
        'aggregate_sha256':{n:hashlib.sha256(b).hexdigest() for n,b in cached_aggregates.items()},
        'live_aggregates_equal_original':True}

def verify_native_context(label,declaration,expected):
    if declaration['source']!=expected:
        raise RuntimeError('declared native source mismatch')
    ci=state(declaration['run']);guardian=state(declaration['guardian'])
    for record in (ci,guardian):
        if (record['headSha']!=expected or record['attempt']!=1 or record['status']!='completed'
            or record['conclusion']!='success'):
            raise RuntimeError('fresh exact-source native/Guardian admission failed')
    mandatory={'Detect Changes','CI Policy','CI Gate','Clippy and Coverage',
        'Rust Test and Build (linux-native)','Rust Test and Build (macos-native)',
        'Rust Test and Build (windows-native)','Windows GNU Updater Build','Windows GNU Updater E2E'}
    jobs={j['name']:j for j in ci['jobs']}
    if any(jobs.get(n,{}).get('conclusion')!='success' for n in mandatory):
        raise RuntimeError('required native axis skipped or unsuccessful')
    pr=strict_json(command(['gh','pr','view',str(declaration['pr']),'--repo',REPO,
        '--json','headRefOid,isDraft,autoMergeRequest,state']))
    if (pr['headRefOid']!=expected or pr['isDraft'] is not True or pr['state']!='OPEN'
        or pr['autoMergeRequest'] is not None):
        raise RuntimeError('native carrier must retain exact draft/open/no-auto identity')
    raw=command_bytes(['gh','api','--allow-escape-sequences',
        f"repos/{REPO}/actions/runs/{declaration['run']}/attempts/1/logs"],180)
    (OUT/(label+'-native-original-logs.zip')).write_bytes(raw)
    cached_name=declaration['native_original_zip']
    cached=(OUT/'tooling-support'/cached_name).read_bytes()
    if (PROTOCOL['support_files'].get(cached_name)!=declaration['native_original_zip_sha256']
        or hashlib.sha256(cached).hexdigest()!=declaration['native_original_zip_sha256']):
        raise RuntimeError('native cached original ZIP hash mismatch')
    observed,checkouts,packaging=admit_native_log_archives(raw,cached)
    required_tests={n+'/6_Run tests.txt' for n in mandatory if n.startswith('Rust Test and Build (')}
    required_tests.add('Clippy and Coverage/11_Generate coverage report.txt')
    actual_tests={n for n in observed if n.endswith(('/6_Run tests.txt','/11_Generate coverage report.txt'))}
    if actual_tests!=required_tests:
        raise RuntimeError('required four native test/coverage logs missing or unexpected')
    if observed!=declaration['expected_log_hashes']:
        raise RuntimeError('native original log identities changed')
    required_checkouts={n for n,j in jobs.items() if j['conclusion']=='success' and n!='CI Gate'}
    actual=declaration['actual_checkout'];tree=git_identity(expected)['tree']
    if set(checkouts)!=required_checkouts or set(checkouts.values())!={actual['sha']}:
        raise RuntimeError('native actual checkout inventory mismatch')
    commit=api('git/commits/'+actual['sha'])
    if (commit['tree']['sha']!=tree or actual['tree']!=tree
        or [p['sha'] for p in commit['parents']]!=actual['parents']
        or (actual['sha']!=expected and expected not in actual['parents'])):
        raise RuntimeError('native actual tree/parent source mismatch')
    save(OUT/(label+'-native-before-dispatch.json'),{'source':expected,'ci':ci,'guardian':guardian,
        'actual_checkout':actual,'observed_log_hashes':observed,'archive_sha256':hashlib.sha256(raw).hexdigest(),
        'cached_original_sha256':hashlib.sha256(cached).hexdigest(),'log_packaging':packaging})

def verify_dispatch_identity(admitted):
    ensure_time()
    pr=strict_json(command(['gh','pr','view',str(PR),'--repo',REPO,
        '--json','headRefOid,isDraft,autoMergeRequest,state']))
    if (pr['headRefOid']!=HEAD or pr['isDraft'] is not True or pr['state']!='OPEN'
        or pr['autoMergeRequest'] is not None):
        raise RuntimeError('dispatch source draft/open/no-auto identity changed')
    observed=api(f'actions/workflows/perf-regression.yml/runs?branch={BRANCH}&per_page=100')['workflow_runs']
    inventory={'source':HEAD,'pr':pr,'workflow_runs':observed,
        'checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    save(OUT/'remote-run-inventory-latest.json',inventory)
    if ({str(r['id']) for r in observed}!={str(a['run']) for a in admitted}
        or any(r['head_sha']!=HEAD or r.get('run_attempt')!=1 or r.get('status')!='completed'
            or r.get('conclusion')!='success' for r in observed)):
        raise RuntimeError('unexpected same-branch performance run; no new dispatch')
    return inventory

def resolve_dispatch_run(output,admitted):
    urls=re.findall(r'https://github\.com/([^/\s]+/[^/\s]+)/actions/runs/([1-9][0-9]*)(?=[/?#\s]|$)',output)
    if any(repository!=REPO for repository,_ in urls):
        raise RuntimeError('dispatch response contains another repository; do not retry')
    ids={run for _,run in urls}
    if len(ids)!=1:
        raise RuntimeError('dispatch returned no unique run ID; do not retry')
    run=next(iter(ids))
    if run in {str(a['run']) for a in admitted}:
        raise RuntimeError('dispatch reused an admitted run ID; do not retry')
    return run

def finish_campaign(admitted):
    ensure_time()
    if (len(admitted)!=5 or len({str(a['run']) for a in admitted})!=5
        or [a['role'] for a in admitted]!=['exploratory']*3+['held-out']*2
        or len(COMPONENT_IDS)!=45):
        raise RuntimeError('five whole sessions and45 distinct component IDs required')
    inventory=verify_dispatch_identity(admitted)
    save(OUT/'final-remote-run-inventory.json',inventory)
    ensure_time()
    save(OUT/'complete.json',{'source':HEAD,'reference':gate.REFERENCE,'sessions':admitted,'status':'five-whole-null-sessions-pass',
        'leg_rows':8190,'observations':680,'enforced_count':340,'diagnostic_count':340,'unique_components':45,'enforcement_active':True})
    print('CAMPAIGN_COMPLETE five whole null sessions; active normal-CLI execution verified; overall FINAL/merge/master proof pending',flush=True)

def wait_ci():
    while True:
        ensure_time();pr=strict_json(command(['gh','pr','view',str(PR),'--repo',REPO,'--json','headRefOid,statusCheckRollup,isDraft,autoMergeRequest,state']))
        save(OUT/'core-pr-checks.json',pr)
        if pr['headRefOid']!=HEAD or pr['isDraft'] is not True or pr['autoMergeRequest'] is not None or pr['state']!='OPEN':
            raise RuntimeError('calibration PR source/open/draft/no-registration identity changed')
        checks={x.get('name',x.get('context')):x for x in pr['statusCheckRollup']}
        bad=[n for n,x in checks.items() if x.get('conclusion') in ('FAILURE','CANCELLED','TIMED_OUT','ACTION_REQUIRED') or x.get('state') in ('ERROR','FAILURE')]
        # This is a new source, never the old attempt2 external-recovery exception.
        ci=strict_json(command(['gh','run','view',str(PROTOCOL['source_ci_run']),'--repo',REPO,'--json','status,conclusion,headSha,attempt,jobs']))
        save(OUT/'source-ci-attempt1-latest.json',ci)
        if ci['headSha']!=HEAD or ci['attempt']!=1:raise RuntimeError('source CI identity changed')
        guardian=strict_json(command(['gh','run','view',str(PROTOCOL['source_ci_before_dispatch']['guardian']),'--repo',REPO,'--json','status,conclusion,headSha,attempt,jobs']))
        save(OUT/'source-guardian-attempt1-latest.json',guardian)
        if guardian['headSha']!=HEAD or guardian['attempt']!=1:raise RuntimeError('Guardian identity changed')
        if ci['status']=='completed' and ci['conclusion']!='success':raise RuntimeError('source CI failed; stop and diagnose, no unchanged retry')
        if guardian['status']=='completed' and guardian['conclusion']!='success':raise RuntimeError('Guardian failed; stop and diagnose, no unchanged retry')
        if ci['status']==guardian['status']=='completed':
            if bad:raise RuntimeError('source PR checks failed: '+','.join(bad))
            if all(checks.get(n,{}).get('conclusion')=='SUCCESS' for n in ('CI Gate','CI Policy Guardian')):return
        time.sleep(30)

try:
    save(OUT/'protocol-before-outcomes.json',PROTOCOL)
    (OUT/'protocol-reservation-original.json').write_bytes(PROTOCOL_PATH.read_bytes())
    save(OUT/'previous-rejection.json',PROTOCOL['previous_rejection'])
    contracts=OUT/'source-contract/scripts';contracts.mkdir(parents=True)
    for filename in ('indexing_perf.py','indexing_perf_contract.py','indexing_perf_gate.py'):
        content=command_bytes(['git','show',HEAD+':scripts/'+filename])
        (contracts/filename).write_bytes(content)
    save(OUT/'source-contract-identity.json',git_identity(HEAD))
    support=OUT/'tooling-support';support.mkdir()
    for filename in PROTOCOL['support_files']:
        target=support/filename;target.parent.mkdir(parents=True,exist_ok=True)
        content=(ROOT/'rust/target/warm-reclaim-calibration'/filename).read_bytes()
        if hashlib.sha256(content).hexdigest()!=PROTOCOL['support_files'][filename]:
            raise RuntimeError('reserved support source changed')
        target.write_bytes(content)
    if command(['git','rev-parse','HEAD']).strip()!=HEAD:
        raise RuntimeError('local source changed before first dispatch')
    for filename in ('indexing_perf.py','indexing_perf_contract.py','indexing_perf_gate.py'):
        if (ROOT/'scripts'/filename).read_bytes()!=(contracts/filename).read_bytes():
            raise RuntimeError('imported/local CLI contract differs from actual published source')
    wait_ci()
    verify_null_inputs()
    verify_native_context('reference',PROTOCOL['reference_ci_before_dispatch'],gate.REFERENCE)
    verify_native_context('source',PROTOCOL['source_ci_before_dispatch'],HEAD)
    admitted=[]
    for reserved in PROTOCOL['sessions']:
        ensure_time()
        current=api('git/ref/heads/'+BRANCH)['object']['sha']
        if current!=HEAD:raise RuntimeError('remote branch source changed before dispatch')
        verify_dispatch_identity(admitted)
        folder=OUT/('session-'+str(reserved['index']));folder.mkdir()
        save(folder/'reservation-before-dispatch.json',reserved)
        save(folder/'dispatch-attempt.json',{'session':reserved,'source':HEAD,
            'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'status':'STARTING; reconcile outcome before any retry'})
        ensure_time()
        output=command(['gh','workflow','run','perf-regression.yml','--repo',REPO,'--ref',BRANCH,'-f','indexing_calibration=true'])
        (folder/'dispatch.txt').write_text(output)
        run=resolve_dispatch_run(output,admitted)
        save(folder/'dispatch-confirmed.json',{'run':run,'source':HEAD,'session':reserved})
        s=wait(run,HEAD,folder)
        if s['attempt']!=1:raise RuntimeError('rerun cannot be silently accepted')
        if s['conclusion']!='success':
            try:
                command(['gh','run','download',run,'--repo',REPO,'--dir',str(folder/'artifacts')],180)
            finally:
                try:
                    (folder/'whole-workflow-original-logs.zip').write_bytes(command_bytes(['gh','api','--allow-escape-sequences',f'repos/{REPO}/actions/runs/{run}/attempts/1/logs'],180))
                finally:raise RuntimeError('whole intended comparison run failed; preserve and diagnose')
        verdict=download_and_admit(run,HEAD,folder)
        ensure_time()
        verdict['role']=reserved['role'];save(folder/'admission.json',verdict);admitted.append(verdict)
        print(json.dumps({'session':reserved['index'],'role':reserved['role'],'run':run,
            'status':'whole-null-pass','groups':verdict['groups']}),flush=True)
        if reserved['index']==3:
            ensure_time()
            save(OUT/'frozen-before-held-out.json',{'source':HEAD,'reference':gate.REFERENCE,'comparison_protocol':gate.PROTOCOL,'enforcement_active':True,'policy':gate.POLICY,'sessions':[a['run'] for a in admitted],
                'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'held_out_reservations':[x for x in PROTOCOL['sessions'] if x['role']=='held-out'],
                'nothing_refit_from_heldouts':True})
            # Outside every measurement: separate this local UTC marker from
            # GitHub's whole-second run timestamps before the first held-out.
            time.sleep(2)
            ensure_time()
    finish_campaign(admitted)
except BaseException as error:
    save(OUT/'stopped.json',{'source':HEAD,'error':type(error).__name__+': '+str(error),
        'enforcement_active':True,'no_unchanged_retry':True})
    print('CAMPAIGN_STOPPED '+type(error).__name__+': '+str(error),flush=True)
    raise
