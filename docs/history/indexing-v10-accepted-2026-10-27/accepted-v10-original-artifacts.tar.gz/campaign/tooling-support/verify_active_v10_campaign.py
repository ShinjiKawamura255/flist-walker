"""Read/replay all five original active sessions; no API, dispatch or policy refit."""
import hashlib, json, subprocess, sys
from pathlib import Path
ROOT = Path.cwd()
sys.path.insert(0,str(ROOT))
from scripts import indexing_perf_gate as gate, indexing_perf_contract as contract
BASE = ROOT/'rust/target/warm-reclaim-calibration/campaign-active-v10'
V = ROOT/'rust/target/warm-reclaim-calibration/post-campaign-verification-v10'
def reject_nonfinite(value):
    raise ValueError('nonfinite JSON value: '+value)
def finite_float(value):
    number=float(value)
    if number in (float('inf'),float('-inf')):reject_nonfinite(value)
    return number
def strict_json(value):
    return json.loads(value,parse_constant=reject_nonfinite,parse_float=finite_float)
PROTOCOL = strict_json((BASE/'protocol-reservation-original.json').read_text())
HEAD = PROTOCOL['core_source']
REF = PROTOCOL['reference']
BRANCH = PROTOCOL['source_branch']

def main():
    if sys.flags.optimize:
        raise RuntimeError("verification requires enabled assertions; run without Python optimization")
    V.mkdir(exist_ok=True)
    complete = strict_json((BASE/'complete.json').read_text())
    assert complete['source']==HEAD and complete['reference']==REF and complete['enforcement_active'] is True
    assert complete['status']=='five-whole-null-sessions-pass'
    assert gate.REFERENCE==REF and gate.ENFORCE_TIMING is True
    protocol = strict_json((BASE/'protocol-reservation-original.json').read_text())
    assert protocol['core_source']==HEAD and protocol['reference']==REF and protocol['enforcement_active'] is True
    assert protocol['comparison_protocol']==gate.PROTOCOL and protocol['policy_before_outcomes']==gate.POLICY
    assert [s['role'] for s in protocol['sessions']]==['exploratory']*3+['held-out']*2
    frozen=strict_json((BASE/'frozen-before-held-out.json').read_text())
    assert frozen['source']==HEAD and frozen['reference']==REF and frozen['policy']==gate.POLICY and frozen['enforcement_active'] is True
    scripts=BASE/'source-contract/scripts'
    for name in ['indexing_perf.py','indexing_perf_contract.py','indexing_perf_gate.py']:
        expected=subprocess.check_output(['git','show',HEAD+':scripts/'+name])
        assert (scripts/name).read_bytes()==expected and (ROOT/'scripts'/name).read_bytes()==expected
    from datetime import datetime
    timestamp=lambda text: datetime.fromisoformat(text.replace('Z','+00:00'))
    reserved_at=timestamp(protocol['reserved_at_utc'])
    states=[]
    rows=obs=medians=maxima=0; uuids=set();runs=[]; sessions=[]; replays=[]
    all_decisions=[]
    for index in range(1,6):
        folder=BASE/f'session-{index}'
        state=strict_json((folder/'state-final.json').read_text())
        admission=strict_json((folder/'admission.json').read_text())
        assert reserved_at < timestamp(state['createdAt'])
        if states:
            last=states[-1]
            assert max(timestamp(j['completedAt']) for j in last['jobs'] if j['name'].startswith('Indexing Contention (')) <= timestamp(state['createdAt'])
        states.append(state)
        run=str(admission['run']);assert run not in runs;runs.append(run)
        assert state['headSha']==HEAD and state['attempt']==1 and state['status']=='completed' and state['conclusion']=='success'
        assert admission['source']==HEAD and admission['whole_null_pass'] is True
        assert admission['role']==protocol['sessions'][index-1]['role']
        packets=sorted((folder/'artifacts').iterdir());assert len(packets)==3 and all(p.is_dir() for p in packets)
        groups={};session_rows=0;session_uuids=set()
        for packet in packets:
            receipt=strict_json((packet/'receipt.json').read_text());group=receipt['group'];assert group not in groups
            assert receipt['comparison']['enforced'] is True
            report=gate.load_comparison(packet,group)
            assert report['status']=='pass' and report['policy']==gate.POLICY and report['null_rust_sources_equal'] is True
            actual=subprocess.run([sys.executable,str(scripts/'indexing_perf.py'),'validate','--group',group,str(packet)],cwd=ROOT,text=True,capture_output=True,timeout=90)
            (packet/'campaign-replay-normal-cli-stdout.json').write_text(actual.stdout)
            (packet/'campaign-replay-normal-cli-stderr.log').write_text(actual.stderr)
            assert actual.returncode==0 and strict_json(actual.stdout)==report
            original=strict_json((packet/'actual-source-normal-cli-execution.json').read_text());assert original['source']==HEAD and original['exit']==0
            assert strict_json((packet/'actual-source-normal-cli-stdout.json').read_text())==report
            assert report['enforced_count']==report['diagnostic_count']==report['decision_count']//2
            assert all(d['enforced'] is (d['statistic']=='median') and d['status']==('pass' if d['enforced'] else 'diagnostic') for d in report['decisions'])
            obs+=report['decision_count'];medians+=report['enforced_count'];maxima+=report['diagnostic_count'];all_decisions.extend(report['decisions'])
            elapsed={'build':0.,'measurement':0.}
            for role in gate.ROLES:
                component=strict_json((packet/(role+'-receipt.log')).read_text());uid=component['run_id']
                assert uid not in uuids and uid not in session_uuids;session_uuids.add(uid)
                assert component['source_before']['head']==(HEAD if role=='candidate' else REF)
                runner=component['runner'];assert runner['GITHUB_RUN_ID']==run and runner['GITHUB_RUN_ATTEMPT']=='1'
                assert runner['GITHUB_SHA']==runner['GITHUB_WORKFLOW_SHA']==HEAD
                assert runner['GITHUB_WORKFLOW_REF']==f'ShinjiKawamura255/flist-walker/.github/workflows/perf-regression.yml@refs/heads/{BRANCH}'
                raw=packet/('measurement.log' if role=='candidate' else role+'-measurement.log')
                count=len(contract.validate_log(raw.read_text(),group)['rows']);rows+=count;session_rows+=count
                for phase in elapsed:elapsed[phase]+=component['processes'][phase]['elapsed_seconds']
            assert elapsed['build']<=1800 and elapsed['measurement']<=2700
            job=next(j for j in state['jobs'] if j['name']==f'Indexing Contention ({group})')
            assert job['conclusion']=='success' and 0 < (timestamp(job['completedAt'])-timestamp(job['startedAt'])).total_seconds() <= 5400
            groups[group]={'normal_actual_source_CLI':'PASS','observations':report['decision_count'],'enforced_medians':report['enforced_count'],'MAX_diagnostics':report['diagnostic_count'],'all_samples_retained':True}
            replays.append({'session':index,'run':run,'group':group,'exit':actual.returncode,'normal_original_source_CLI':'PASS'})
        assert set(groups)==set(contract.GROUPS) and session_rows==1638 and len(session_uuids)==9
        uuids.update(session_uuids);sessions.append({'index':index,'role':admission['role'],'run':run,'groups':groups})
    inventory=strict_json((BASE/'final-remote-run-inventory.json').read_text())
    assert inventory['source']==HEAD and {str(r['id']) for r in inventory['workflow_runs']}==set(runs)
    assert all(r['head_sha']==HEAD and r['run_attempt']==1 and r['status']=='completed' and r['conclusion']=='success' for r in inventory['workflow_runs'])
    assert inventory['pr']['headRefOid']==HEAD and inventory['pr']['isDraft'] is True and inventory['pr']['state']=='OPEN' and inventory['pr']['autoMergeRequest'] is None
    assert frozen['sessions']==runs[:3]
    freeze_at=timestamp(frozen['frozen_at_utc'])
    assert max(timestamp(j['completedAt']) for j in states[2]['jobs'] if j['name'].startswith('Indexing Contention (')) <= freeze_at < timestamp(states[3]['createdAt'])
    assert frozen['held_out_reservations']==protocol['sessions'][3:]
    assert (rows,obs,medians,maxima,len(uuids))==(8190,680,340,340,45)
    output={'source':HEAD,'reference':REF,'mode':'defaultTrue-normal-sourceCLI','status':'five-whole-PASS','sessions':sessions,
        'leg_rows':rows,'observations':obs,'enforced_medians':medians,'MAX_diagnostics':maxima,'unique_UUIDs':len(uuids),
        'candidate_worst_median_ratio':max(d['candidate_ratio'] for d in all_decisions if d['enforced']),
        'reference_worst_median_drift':max(d['reference_median_drift_ratio'] for d in all_decisions),
        'candidate_worst_MAX_ratio_diagnostic':max(d['candidate_ratio'] for d in all_decisions if not d['enforced']),
        'policy':gate.POLICY,'original_normal_CLI_replays':replays,'raw_work_physical_guards':'allrevalidated','claim_limits':'No originalfailurecausalfix/AFDDbinaryeq/isolateddelay/p95/falsepositive guarantee; independentacceptance/FINAL/merge/master separate'}
    target=V/'active-v10-five-descriptive-replay.json'
    with target.open('x') as stream:json.dump(output,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({k:output[k] for k in ['status','leg_rows','observations','unique_UUIDs','candidate_worst_median_ratio','reference_worst_median_drift']}))

if __name__=='__main__': main()
