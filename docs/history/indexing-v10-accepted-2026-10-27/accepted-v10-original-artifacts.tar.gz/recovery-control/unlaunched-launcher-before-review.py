"""Launch one finite reviewed recovery independently of a tool wait session."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys


def save_new(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, indent=2, allow_nan=False)
        stream.write('\n')


def spawn_once(command, cwd, log, launch_dir, identity, popen=subprocess.Popen, metadata=None):
    launch_dir.mkdir(exist_ok=False)
    start = dict(identity, status='STARTING_RECONCILE_BEFORE_ANY_RETRY',
                 utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), command=command,
                 cwd=str(cwd), log=str(log), start_new_session=True)
    save_new(launch_dir / 'attempt-starting.json', start)
    try:
        with log.open('xb') as output:
            child = popen(command, cwd=cwd, stdin=subprocess.DEVNULL, stdout=output,
                          stderr=subprocess.STDOUT, close_fds=True, start_new_session=True)
        details = metadata(child.pid) if metadata else {'process_group': os.getpgid(child.pid), 'session': os.getsid(child.pid)}
        result = dict(identity, status='PID_RECORDED', pid=child.pid,
                      utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), log=str(log), **details)
        save_new(launch_dir / 'pid-result.json', result)
        if details.get('process_group') != child.pid or details.get('session') != child.pid:
            raise RuntimeError('unexpected child process group/session; reconcile, never relaunch')
        return result
    except BaseException as error:
        save_new(launch_dir / 'launch-error.json', {'error': type(error).__name__ + ': ' + str(error),
                 'outcome': 'RECONCILE_PROCESS_AND_LOG_BEFORE_ANY_RETRY', 'log': str(log)})
        raise


def main(path, expected_sha):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected_sha:
        raise RuntimeError('reviewed recovery manifest changed')
    plan = json.loads(raw)
    script = Path(__file__).with_name('campaign_recover_v10_v2.py').resolve()
    if hashlib.sha256(Path(__file__).read_bytes()).hexdigest() != plan['launcher_sha256']:
        raise RuntimeError('reviewed launcher changed')
    spec = importlib.util.spec_from_file_location('fixed_recovery', script)
    recovery = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(recovery)
    root = Path(plan['source_root'])
    recovery.validate_plan(plan, root, script)
    if recovery.deadline_remaining(datetime.datetime.now(datetime.timezone.utc)) <= 0:
        raise RuntimeError('original absolute deadline exhausted; no launch')
    rows = subprocess.run(['ps', '-axo', 'pid=,ppid=,comm=,args='], text=True,
                          capture_output=True, timeout=10, check=True).stdout
    recovery.check_process_rows(rows, os.getpid())
    command = [sys.executable, str(script), str(path), expected_sha]
    identity = {'manifest_sha256': expected_sha, 'wrapper_sha256': plan['wrapper_sha256'],
                'launcher_sha256': plan['launcher_sha256'], 'absolute_deadline_utc': recovery.DEADLINE_UTC,
                'same_fixed_five': True, 'original_measurements_repeated': False}
    result = spawn_once(command, root, Path(plan['controller_log']), Path(plan['launch_directory']), identity)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('usage: launch_recovery_v10_v2.py ABS_MANIFEST EXPECTED_SHA256')
    main(Path(sys.argv[1]).resolve(), sys.argv[2])
