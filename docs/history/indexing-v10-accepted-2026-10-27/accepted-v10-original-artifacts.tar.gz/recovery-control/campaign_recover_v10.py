"""Recover the same five fixed slots after local process loss; never resample."""
import ast
import copy
import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import zipfile

SOURCE = '597a7d4dd48ffca67b9529a3afcec5459c3a9276'
REFERENCE = 'fcdea8ee05a5f08c5ee19a9ae8b58b8c8736a645'
PROTOCOL_SHA = '70c1f2016d3a67414b95782ed092434c0b97bb488a52fdafa05417770ef5bf44'
CONTROLLER_SHA = 'a1035edd152d17e6f35215a1f7e61b3126469b6e585b251cd501f02d53a2107d'
EXISTING_RUNS = ['40560125984', '40567759395']
ANCHOR = '2026-10-27T18:26:48.357394+00:00'
DEADLINE_UTC = '2026-10-28T00:26:48.357394+00:00'
REPO = 'ShinjiKawamura255/flist-walker'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def strict_json(data):
    def reject(value):
        raise ValueError('nonfinite JSON: ' + value)
    def number(value):
        result = float(value)
        if result in (float('inf'), float('-inf')):
            reject(value)
        return result
    return json.loads(data, parse_constant=reject, parse_float=number)


def deadline_remaining(now):
    return (datetime.datetime.fromisoformat(DEADLINE_UTC) - now).total_seconds()


def save(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')


def validate_plan(plan, root, wrapper):
    expected = {'source': SOURCE, 'reference': REFERENCE,
                'original_protocol_sha256': PROTOCOL_SHA,
                'original_controller_sha256': CONTROLLER_SHA,
                'existing_runs': EXISTING_RUNS, 'remaining_indices': [3, 4, 5],
                'campaign_anchor_utc': ANCHOR, 'absolute_deadline_utc': DEADLINE_UTC}
    if any(plan.get(k) != v for k, v in expected.items()):
        raise RuntimeError('recovery identity, slots or original deadline changed')
    if sha(wrapper.read_bytes()) != plan['wrapper_sha256']:
        raise RuntimeError('recovery wrapper changed after review')
    control = root / 'rust/target/warm-reclaim-calibration'
    original = control / 'campaign-protocol-active-v10.json'
    controller = control / 'campaign_runner_active_v10.py'
    out = control / 'campaign-active-v10'
    if sha(original.read_bytes()) != PROTOCOL_SHA or sha(controller.read_bytes()) != CONTROLLER_SHA:
        raise RuntimeError('original reservation/controller changed')
    protocol = strict_json(original.read_text())
    if protocol['core_source'] != SOURCE or protocol['reference'] != REFERENCE:
        raise RuntimeError('original source changed')
    for name, digest in protocol['support_files'].items():
        for folder in (control, out / 'tooling-support'):
            if sha((folder / name).read_bytes()) != digest:
                raise RuntimeError('frozen support changed: ' + name)
    for name in ('STOP_REQUESTED', 'stopped.json', 'complete.json'):
        if (out / name).exists():
            raise RuntimeError('existing stop/completion marker forbids recovery: ' + name)
    if sorted(p.name for p in out.glob('session-*')) != ['session-1', 'session-2']:
        raise RuntimeError('unexpected session directory; reconcile before recovery')
    saved = out / 'session-1/admission.json'
    if sha(saved.read_bytes()) != plan['first_admission_sha256']:
        raise RuntimeError('saved first admission changed')
    if sha((out / 'session-1/state-final.json').read_bytes()) != plan['first_state_final_sha256']:
        raise RuntimeError('saved first final state changed')
    if any((out / 'session-2' / name).exists() for name in ('admission.json', 'artifacts', 'state-final.json')):
        raise RuntimeError('unexpected existing second admission/artifacts; reconcile before recovery')
    for index in (1, 2):
        folder = out / ('session-' + str(index))
        reservation = protocol['sessions'][index - 1]
        if strict_json((folder / 'reservation-before-dispatch.json').read_text()) != reservation:
            raise RuntimeError('existing reservation changed')
        dispatch = strict_json((folder / 'dispatch-confirmed.json').read_text())
        if dispatch != {'run': EXISTING_RUNS[index - 1], 'source': SOURCE, 'session': reservation}:
            raise RuntimeError('known dispatch changed; never redispatch')
        attempt = strict_json((folder / 'dispatch-attempt.json').read_text())
        if attempt['source'] != SOURCE or attempt['session'] != reservation:
            raise RuntimeError('existing dispatch attempt changed')
    return protocol, controller, out


def check_inventory(records, source):
    runs = records['workflow_runs']
    if len(runs) != 2 or {str(x['id']) for x in runs} != set(EXISTING_RUNS):
        raise RuntimeError('unknown/missing/duplicate recovery run inventory')
    for run in runs:
        if run['head_sha'] != source or type(run['run_attempt']) is not int or run['run_attempt'] != 1:
            raise RuntimeError('recovery run source/attempt changed')
        if str(run['id']) == EXISTING_RUNS[0]:
            if run['status'] != 'completed' or run['conclusion'] != 'success':
                raise RuntimeError('first admitted workflow changed')
        elif run['status'] not in ('queued', 'in_progress', 'completed'):
            raise RuntimeError('unknown pending second-run state')


def check_process_rows(rows, own_pid):
    others = []
    for row in rows.splitlines():
        fields = row.split(None, 3)
        if len(fields) != 4:
            continue
        pid, _, executable, args = fields
        if ('python' in Path(executable).name.lower()
            and any(name in args for name in ('campaign_runner_active_v10.py', 'campaign_recover_v10.py'))
            and int(pid) != own_pid):
            others.append(row)
    if others:
        raise RuntimeError('existing/unknown controller or recovery process: ' + repr(others))


def controller_segments(controller):
    tree = ast.parse(controller.read_text())
    outer = next(n for n in tree.body if isinstance(n, ast.Try))
    loops = [n for n in outer.body if isinstance(n, ast.For) and isinstance(n.target, ast.Name) and n.target.id == 'reserved']
    if len(loops) != 1:
        raise RuntimeError('frozen loop identity ambiguous')
    original = loops[0]
    starts = [i for i, n in enumerate(original.body) if isinstance(n, ast.Assign)
              and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name)
              and n.targets[0].id == 's' and isinstance(n.value, ast.Call)
              and isinstance(n.value.func, ast.Name) and n.value.func.id == 'wait']
    if len(starts) != 1:
        raise RuntimeError('frozen wait/admission tail ambiguous')
    tail = copy.deepcopy(original.body[starts[0]:])
    remaining = copy.deepcopy(original)
    remaining.iter = ast.parse("PROTOCOL['sessions'][2:]", mode='eval').body
    tail_code = compile(ast.fix_missing_locations(ast.Module(body=tail, type_ignores=[])), str(controller), 'exec')
    loop_code = compile(ast.fix_missing_locations(ast.Module(body=[remaining], type_ignores=[])), str(controller), 'exec')
    identities = {'original_loop_ast_sha256': sha(ast.dump(original, include_attributes=False).encode()),
                  'original_wait_tail_ast_sha256': sha(ast.dump(ast.Module(body=tail, type_ignores=[]), include_attributes=False).encode()),
                  'remaining_loop_ast_sha256': sha(ast.dump(remaining, include_attributes=False).encode()),
                  'only_loop_change': "iter PROTOCOL['sessions'] -> PROTOCOL['sessions'][2:]"}
    return tree, tail_code, loop_code, identities


def restore_first(env, out, recovery):
    original = strict_json((out / 'session-1/admission.json').read_text())
    folder = recovery / 'first-original-revalidation'
    folder.mkdir()
    (folder / 'state-final.json').write_bytes((out / 'session-1/state-final.json').read_bytes())
    result = env['download_and_admit'](EXISTING_RUNS[0], SOURCE, folder)
    result['role'] = env['PROTOCOL']['sessions'][0]['role']
    if result != original or set(result['component_ids']) != env['COMPONENT_IDS'] or len(env['COMPONENT_IDS']) != 9:
        raise RuntimeError('revalidated first verdict differs from complete saved admission')
    save(recovery / 'first-restored.json', result)
    env['admitted'] = [result]


def execute_resume(env, out, tail, loop):
    env.update(reserved=env['PROTOCOL']['sessions'][1], folder=out / 'session-2', run=EXISTING_RUNS[1])
    exec(tail, env)
    env['recheck_before_third']()
    exec(loop, env)
    env['finish_campaign'](env['admitted'])


def main(manifest_path, expected_sha, validate_only=False):
    root = Path.cwd()
    wrapper = Path(__file__).resolve()
    raw = manifest_path.read_bytes()
    if sha(raw) != expected_sha:
        raise RuntimeError('recovery manifest changed after review')
    plan = strict_json(raw)
    protocol, controller, out = validate_plan(plan, root, wrapper)
    tree, tail, loop, segments = controller_segments(controller)
    if segments != plan['ast_segments']:
        raise RuntimeError('reviewed frozen AST identities changed')
    remaining = deadline_remaining(datetime.datetime.now(datetime.timezone.utc))
    if remaining <= 0:
        raise RuntimeError('original absolute six-hour deadline exhausted; no reset')
    if validate_only:
        print('VALIDATED recovery identity, original frozen AST, same five slots and original absolute deadline; no entrypoint/dispatch')
        return
    sys.path.insert(0, str(root))
    from scripts import indexing_perf_gate as gate, indexing_perf_contract as contract
    conservative_mono = time.monotonic()
    remaining = deadline_remaining(datetime.datetime.now(datetime.timezone.utc))
    if remaining <= 0:
        raise RuntimeError('original absolute six-hour deadline exhausted; no reset')
    env = {'ROOT': root, 'OUT': out, 'HEAD': SOURCE, 'REPO': REPO, 'BRANCH': protocol['source_branch'],
           'PR': protocol['source_pr'], 'PROTOCOL': protocol, 'COMPONENT_IDS': set(),
           'DEADLINE': conservative_mono + remaining, 'gate': gate, 'contract': contract,
           'datetime': datetime, 'hashlib': hashlib, 'io': io, 'json': json, 'pathlib': __import__('pathlib'),
           're': re, 'subprocess': subprocess, 'sys': sys, 'time': time, 'zipfile': zipfile}
    functions = ast.Module(body=[n for n in tree.body if isinstance(n, ast.FunctionDef)], type_ignores=[])
    exec(compile(functions, str(controller), 'exec'), env)
    env['ensure_time']()
    if (gate.REFERENCE != REFERENCE or gate.PROTOCOL != protocol['comparison_protocol']
        or gate.POLICY != protocol['policy_before_outcomes'] or gate.ENFORCE_TIMING is not True
        or protocol['enforcement_active'] is not True or sys.flags.optimize):
        raise RuntimeError('actual source policy/normal Python changed')
    env['validate_reserved_geometry'](protocol)
    def process_check():
        rows = env['command'](['ps', '-axo', 'pid=,ppid=,comm=,args='], timeout=10)
        check_process_rows(rows, os.getpid())
    process_check()
    recovery = out / 'recovery-after-local-interruption'
    recovery.mkdir(exist_ok=False)
    save(recovery / 'recovery-started.json', {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'manifest_sha256': expected_sha, 'wrapper_sha256': sha(wrapper.read_bytes()),
         'absolute_deadline_utc': DEADLINE_UTC, 'remaining_seconds': remaining,
         'no_deadline_reset': True, 'pid': os.getpid(), 'segments': segments})
    (recovery / 'recovery-manifest-original.json').write_bytes(raw)
    def source_check():
        if env['command'](['git', 'rev-parse', 'HEAD']).strip() != SOURCE or env['command'](['git', 'status', '--porcelain']):
            raise RuntimeError('local source changed or dirty')
        for name in ('indexing_perf.py', 'indexing_perf_contract.py', 'indexing_perf_gate.py'):
            committed = env['command_bytes'](['git', 'show', SOURCE + ':scripts/' + name])
            if (root / 'scripts' / name).read_bytes() != committed or (out / 'source-contract/scripts' / name).read_bytes() != committed:
                raise RuntimeError('actual exported/source CLI changed')
    def native_checks(phase):
        source_check()
        for name in protocol['support_files']:
            digest = protocol['support_files'][name]
            for folder in (root / 'rust/target/warm-reclaim-calibration', out / 'tooling-support'):
                if sha((folder / name).read_bytes()) != digest:
                    raise RuntimeError('support changed during recovery')
        env['verify_native_context']('recovery-reference-' + phase, protocol['reference_ci_before_dispatch'], REFERENCE)
        env['verify_native_context']('recovery-source-' + phase, protocol['source_ci_before_dispatch'], SOURCE)
    def inventory_check():
        data = env['api']('actions/workflows/perf-regression.yml/runs?branch=' + env['BRANCH'] + '&per_page=100')
        save(recovery / 'known-two-inventory-before-resume.json', data)
        check_inventory(data, SOURCE)
    def recheck():
        process_check()
        native_checks('before-third')
        inventory_check()
        env['verify_dispatch_identity'](env['admitted'])
        env['ensure_time']()
        save(recovery / 'before-third-ready.json', {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'admitted': [v['run'] for v in env['admitted']], 'deadline_utc': DEADLINE_UTC})
    env['recheck_before_third'] = recheck
    try:
        source_check()
        env['wait_ci']()
        native_checks('before-resume')
        env['verify_null_inputs']()
        inventory_check()
        restore_first(env, out, recovery)
        execute_resume(env, out, tail, loop)
        save(recovery / 'recovery-finished.json', {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'all_original_slots_completed': True, 'deadline_utc': DEADLINE_UTC})
    except BaseException as error:
        record = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source': SOURCE,
                  'error': type(error).__name__ + ': ' + str(error), 'recovery': True,
                  'enforcement_active': True, 'no_unchanged_retry': True, 'deadline_utc': DEADLINE_UTC}
        save(recovery / 'stopped.json', record)
        if not (out / 'stopped.json').exists():
            save(out / 'stopped.json', record)
        print('RECOVERY_STOPPED ' + record['error'], flush=True)
        raise


if __name__ == '__main__':
    if len(sys.argv) not in (3, 4) or (len(sys.argv) == 4 and sys.argv[3] != '--validate-only'):
        raise SystemExit('usage: campaign_recover_v10.py ABS_MANIFEST EXPECTED_SHA256 [--validate-only]')
    main(Path(sys.argv[1]), sys.argv[2], len(sys.argv) == 4)
