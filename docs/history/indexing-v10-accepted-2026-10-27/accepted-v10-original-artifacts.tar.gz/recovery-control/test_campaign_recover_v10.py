"""Offline fault controls; never invoke a workflow or a live recovery entrypoint."""
import ast
import contextlib
import copy
import datetime
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
from types import SimpleNamespace
import tempfile
import unittest

SCRIPT = Path(__file__).with_name('campaign_recover_v10.py')
ROOT = SCRIPT.parent.parent
CONTROL = ROOT / 'candidate-v10-null/rust/target/warm-reclaim-calibration'
spec = importlib.util.spec_from_file_location('recovery_control', SCRIPT)
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
PROTOCOL = json.loads((CONTROL / 'campaign-protocol-active-v10.json').read_text())
CONTROLLER = CONTROL / 'campaign_runner_active_v10.py'


class RecoveryIdentity(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.control = self.root / 'rust/target/warm-reclaim-calibration'
        self.out = self.control / 'campaign-active-v10'
        self.out.mkdir(parents=True)
        shutil.copyfile(CONTROL / 'campaign-protocol-active-v10.json', self.control / 'campaign-protocol-active-v10.json')
        for name in PROTOCOL['support_files']:
            for folder in (self.control, self.out / 'tooling-support'):
                target = folder / name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(CONTROL / name, target)
        for index in (1, 2):
            folder = self.out / ('session-' + str(index))
            folder.mkdir()
            original = CONTROL / 'campaign-active-v10' / folder.name
            for name in ('reservation-before-dispatch.json', 'dispatch-confirmed.json', 'dispatch-attempt.json'):
                shutil.copyfile(original / name, folder / name)
        saved = CONTROL / 'campaign-active-v10/session-1/admission.json'
        shutil.copyfile(saved, self.out / 'session-1/admission.json')
        state = CONTROL / 'campaign-active-v10/session-1/state-final.json'
        shutil.copyfile(state, self.out / 'session-1/state-final.json')
        self.plan = {'source': r.SOURCE, 'reference': r.REFERENCE, 'original_protocol_sha256': r.PROTOCOL_SHA,
                     'original_controller_sha256': r.CONTROLLER_SHA, 'existing_runs': r.EXISTING_RUNS,
                     'remaining_indices': [3, 4, 5], 'campaign_anchor_utc': r.ANCHOR,
                     'absolute_deadline_utc': r.DEADLINE_UTC, 'wrapper_sha256': r.sha(SCRIPT.read_bytes()),
                     'first_admission_sha256': r.sha(saved.read_bytes()),
                     'first_state_final_sha256': r.sha(state.read_bytes())}

    def validate(self):
        return r.validate_plan(self.plan, self.root, SCRIPT)

    def test_same_fixed_e1_e2_sources_and_frozen_support_validate(self):
        p, _, out = self.validate()
        self.assertEqual(p, PROTOCOL)
        self.assertEqual(out, self.out)

    def test_deadline_reset_or_slot_replacement_rejected(self):
        for field, value in [('absolute_deadline_utc', '2026-10-28T06:00:00Z'), ('existing_runs', ['1', '2']),
                             ('remaining_indices', [2, 3, 4, 5]), ('source', '0' * 40), ('reference', '0' * 40)]:
            with self.subTest(field=field):
                plan = copy.deepcopy(self.plan)
                plan[field] = value
                with self.assertRaisesRegex(RuntimeError, 'identity, slots or original deadline'):
                    r.validate_plan(plan, self.root, SCRIPT)

    def test_changed_cached_or_copied_frozen_support_rejected(self):
        for folder in (self.control, self.out / 'tooling-support'):
            p = folder / 'controller-adaptation-v10.local.md'
            original = p.read_bytes()
            p.write_bytes(original + b'changed')
            with self.assertRaisesRegex(RuntimeError, 'support changed'):
                self.validate()
            p.write_bytes(original)

    def test_explicit_stop_or_existing_completion_is_never_removed(self):
        for name in ('STOP_REQUESTED', 'stopped.json', 'complete.json'):
            p = self.out / name
            p.write_text('existing marker')
            with self.assertRaisesRegex(RuntimeError, 'marker forbids'):
                self.validate()
            self.assertEqual(p.read_text(), 'existing marker')
            p.unlink()

    def test_unknown_third_directory_prevents_duplicate_dispatch(self):
        (self.out / 'session-3').mkdir()
        with self.assertRaisesRegex(RuntimeError, 'unexpected session directory'):
            self.validate()

    def test_saved_admission_tamper_rejected(self):
        p = self.out / 'session-1/admission.json'
        p.write_text(p.read_text() + ' ')
        with self.assertRaisesRegex(RuntimeError, 'first admission changed'):
            self.validate()

    def test_saved_first_state_tamper_rejected(self):
        p = self.out / 'session-1/state-final.json'
        p.write_text(p.read_text() + ' ')
        with self.assertRaisesRegex(RuntimeError, 'first final state changed'):
            self.validate()

    def test_unknown_second_admission_cannot_be_overwritten(self):
        p = self.out / 'session-2/admission.json'
        p.write_text('{}')
        with self.assertRaisesRegex(RuntimeError, 'unexpected existing second admission'):
            self.validate()

    def test_second_dispatch_run_or_reservation_tamper_rejected(self):
        for name, field, value in [('dispatch-confirmed.json', 'run', 'other'),
                                   ('reservation-before-dispatch.json', 'slot_id', 'replacement')]:
            p = self.out / 'session-2' / name
            raw = p.read_bytes()
            d = json.loads(raw)
            d[field] = value
            p.write_text(json.dumps(d))
            with self.assertRaisesRegex(RuntimeError, 'dispatch changed|reservation changed'):
                self.validate()
            p.write_bytes(raw)


class RecoveryInventory(unittest.TestCase):
    def data(self):
        return {'workflow_runs': [{'id': int(n), 'run_attempt': 1, 'head_sha': r.SOURCE,
                 'status': 'completed' if i == 0 else 'in_progress', 'conclusion': 'success' if i == 0 else None}
                 for i, n in enumerate(r.EXISTING_RUNS)]}

    def test_exact_known_second_may_be_pending_or_terminal_for_preservation(self):
        data = self.data()
        r.check_inventory(data, r.SOURCE)
        data['workflow_runs'][1].update(status='completed', conclusion='failure')
        r.check_inventory(data, r.SOURCE)  # Frozen tail must preserve then reject it.

    def test_missing_extra_duplicate_wrong_source_or_rerun_stops(self):
        for mode in ('missing', 'extra', 'duplicate', 'source', 'rerun', 'bool_attempt', 'first_failure'):
            with self.subTest(mode=mode):
                data = self.data()
                if mode == 'missing':data['workflow_runs'].pop()
                elif mode == 'extra':data['workflow_runs'].append({'id': 999})
                elif mode == 'duplicate':data['workflow_runs'][1] = copy.deepcopy(data['workflow_runs'][0])
                elif mode == 'source':data['workflow_runs'][1]['head_sha'] = 'b' * 40
                elif mode == 'rerun':data['workflow_runs'][1]['run_attempt'] = 2
                elif mode == 'bool_attempt':data['workflow_runs'][1]['run_attempt'] = True
                else:data['workflow_runs'][0]['conclusion'] = 'failure'
                with self.assertRaises(RuntimeError):r.check_inventory(data, r.SOURCE)

    def test_other_controller_or_recovery_process_prevents_start(self):
        r.check_process_rows('123 1 python3 /a/campaign_recover_v10.py\n124 1 zsh -c python3 /a/campaign_recover_v10.py', 123)
        for name in ('campaign_recover_v10.py', 'campaign_runner_active_v10.py'):
            with self.assertRaisesRegex(RuntimeError, 'unknown controller or recovery'):
                r.check_process_rows('999 1 python3 /a/' + name, 123)

    def test_original_absolute_deadline_does_not_reset_after_downtime(self):
        deadline = datetime.datetime.fromisoformat(r.DEADLINE_UTC)
        self.assertEqual(r.deadline_remaining(deadline), 0)
        self.assertEqual(r.deadline_remaining(deadline + datetime.timedelta(seconds=1)), -1)
        self.assertEqual(r.deadline_remaining(deadline - datetime.timedelta(seconds=7)), 7)
        anchor = datetime.datetime.fromisoformat(r.ANCHOR)
        self.assertEqual((deadline - anchor).total_seconds(), 21600)


class RestoreFirst(unittest.TestCase):
    def run_restore(self, mutate=None):
        with tempfile.TemporaryDirectory() as name:
            out = Path(name)
            (out / 'session-1').mkdir()
            recovery = out / 'recovery'
            recovery.mkdir()
            original = {'run': r.EXISTING_RUNS[0], 'role': 'exploratory', 'whole_null_pass': True,
                        'component_ids': [str(i) for i in range(9)], 'preserved_field': {'exact': 12}}
            (out / 'session-1/admission.json').write_text(json.dumps(original))
            (out / 'session-1/state-final.json').write_text('{}')
            env = {'PROTOCOL': PROTOCOL, 'COMPONENT_IDS': set()}
            def revalidate(run, source, folder):
                self.assertEqual((run, source), (r.EXISTING_RUNS[0], r.SOURCE))
                result = copy.deepcopy(original)
                del result['role']
                if mutate:mutate(result)
                env['COMPONENT_IDS'].update(result['component_ids'])
                return result
            env['download_and_admit'] = revalidate
            r.restore_first(env, out, recovery)
            self.assertEqual(env['admitted'], [original])

    def test_complete_saved_verdict_and_all_nine_components_restored(self):
        self.run_restore()

    def test_any_saved_verdict_field_or_component_change_rejected(self):
        for mutate in (lambda d:d['preserved_field'].update(exact=13), lambda d:d['component_ids'].pop()):
            with self.assertRaisesRegex(RuntimeError, 'complete saved admission'):
                self.run_restore(mutate)


class FrozenResume(unittest.TestCase):
    def scenario(self, fail_run=None, expire_second=False, wrong_remote=False):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        out = Path(temp.name)
        (out / 'session-2').mkdir()
        tree, tail, loop, identities = r.controller_segments(CONTROLLER)
        clock = [0]
        events = []
        next_ids = iter(['303', '404', '505'])
        env = {'PROTOCOL': PROTOCOL, 'OUT': out, 'HEAD': r.SOURCE, 'REPO': r.REPO,
               'BRANCH': PROTOCOL['source_branch'], 'DEADLINE': 1, 'COMPONENT_IDS': set(),
               'admitted': [{'run': r.EXISTING_RUNS[0], 'role': 'exploratory'}], 'json': json,
               'datetime': datetime, 'gate': SimpleNamespace(REFERENCE=r.REFERENCE, PROTOCOL=PROTOCOL['comparison_protocol'], POLICY=PROTOCOL['policy_before_outcomes']), 'time': SimpleNamespace(monotonic=lambda:clock[0], sleep=lambda n:events.append(('guard', n)))}
        defs = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in ('ensure_time', 'save')]
        exec(compile(ast.Module(body=defs, type_ignores=[]), str(CONTROLLER), 'exec'), env)
        def wait(run, source, folder):
            events.append(('wait', run))
            if run == r.EXISTING_RUNS[1] and expire_second:clock[0] = 2
            return {'attempt': 1, 'conclusion': 'failure' if run == fail_run else 'success'}
        def command(argv, *a, **k):
            if argv[:3] == ['gh', 'workflow', 'run']:
                run = next(next_ids)
                events.append(('dispatch', run))
                return run
            events.append(('preserve', tuple(argv)))
            return ''
        def admit(run, source, folder):
            events.append(('admit', run))
            return {'run': run, 'groups': {}, 'whole_null_pass': True}
        env.update(wait=wait, command=command, command_bytes=lambda *a, **k:b'preserved original bytes',
                   download_and_admit=admit, resolve_dispatch_run=lambda output, admitted:output,
                   api=lambda endpoint:{'object': {'sha': 'x' * 40 if wrong_remote else r.SOURCE}},
                   verify_dispatch_identity=lambda admitted:events.append(('inventory', len(admitted))),
                   recheck_before_third=lambda:events.append(('before-third', len(env['admitted']))),
                   finish_campaign=lambda admitted:events.append(('finish', [v['run'] for v in admitted])))
        with contextlib.redirect_stdout(io.StringIO()):
            try:r.execute_resume(env, out, tail, loop)
            except RuntimeError as error:return events, out, str(error), identities
        return events, out, None, identities

    def test_only_three_remaining_dispatches_known_second_is_waited_once(self):
        events, out, error, _ = self.scenario()
        self.assertIsNone(error)
        self.assertEqual([v for k, v in events if k == 'dispatch'], ['303', '404', '505'])
        self.assertEqual([v for k, v in events if k == 'wait'], [r.EXISTING_RUNS[1], '303', '404', '505'])
        self.assertEqual([v for k, v in events if k == 'before-third'], [2])
        frozen = json.loads((out / 'frozen-before-held-out.json').read_text())
        self.assertEqual(frozen['sessions'], r.EXISTING_RUNS + ['303'])
        self.assertEqual(frozen['held_out_reservations'], PROTOCOL['sessions'][3:])
        self.assertLess(events.index(('guard', 2)), events.index(('dispatch', '404')))
        self.assertEqual(events[-1], ('finish', r.EXISTING_RUNS + ['303', '404', '505']))

    def test_second_failure_preserves_then_stops_without_any_dispatch(self):
        events, out, error, _ = self.scenario(fail_run=r.EXISTING_RUNS[1])
        self.assertIn('whole intended comparison run failed', error)
        self.assertFalse([x for x in events if x[0] == 'dispatch'])
        self.assertTrue((out / 'session-2/whole-workflow-original-logs.zip').exists())

    def test_third_failure_cannot_start_heldouts(self):
        events, out, error, _ = self.scenario(fail_run='303')
        self.assertIn('whole intended comparison run failed', error)
        self.assertEqual([v for k, v in events if k == 'dispatch'], ['303'])
        self.assertFalse((out / 'frozen-before-held-out.json').exists())

    def test_deadline_expires_during_existing_second_no_new_dispatch(self):
        events, _, error, _ = self.scenario(expire_second=True)
        self.assertIn('finite6h', error)
        self.assertFalse([x for x in events if x[0] == 'dispatch'])

    def test_changed_remote_source_prevents_third_dispatch(self):
        events, _, error, _ = self.scenario(wrong_remote=True)
        self.assertIn('remote branch source changed', error)
        self.assertFalse([x for x in events if x[0] == 'dispatch'])


if __name__ == '__main__':
    unittest.main()
