#!/usr/bin/env python3
# Inert local test executable. No network and no actual GitHub calls.
import fcntl,json,os,sys,importlib.util
from pathlib import Path
base=Path(os.environ['ROLLOUT_FAKE_ROOT']);spec=importlib.util.spec_from_file_location('tests',base/'test_rollout_control.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
folder=Path(os.environ['ROLLOUT_FAKE_STATE']);args=sys.argv[1:]
with (folder/'fake.lock').open('a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    api=m.FakeApi();api.state=json.loads((folder/'state.json').read_text());api.merge=False
    if args[0]=='api':
        if '--method' in args:
            endpoint=args[args.index('PATCH')+1];payload=json.load(sys.stdin)
            if len(payload['checks'])==2 and (folder/'force-restore-failure').exists():
                with (folder/'calls.jsonl').open('a') as stream:stream.write(json.dumps({'restore_failed_payload':payload})+'\n')
                sys.exit(1)
            value=api.patch(endpoint,payload)
        else:value=api.get(args[1])
    elif args[:2]==['pr','merge']:
        api.cancel() if '--disable-auto' in args else api.register();value={}
    else:raise RuntimeError('Unexpected fake gh command')
    (folder/'state.json').write_text(json.dumps(api.state))
    with (folder/'calls.jsonl').open('a') as stream:
        for call in api.calls:stream.write(json.dumps(call)+'\n')
    print(json.dumps(value))
