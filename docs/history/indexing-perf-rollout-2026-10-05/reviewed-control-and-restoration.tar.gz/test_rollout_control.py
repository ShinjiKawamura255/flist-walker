import importlib.util
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parent
SPEC=importlib.util.spec_from_file_location('rollout_control',ROOT/'rollout_control.py')
CONTROL=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CONTROL)

class RolloutControlTests(unittest.TestCase):
    def test_restore_preserves_check_sources_and_strictness(self):
        protection={'required_status_checks': {'strict':True,'contexts':['CI Gate','CI Policy Guardian'],
                    'checks':[{'context':'CI Gate','app_id':15368},{'context':'CI Policy Guardian','app_id':15368}]}}
        restore,temporary=CONTROL.check_payloads(protection)
        self.assertEqual(restore,{'strict':True,'checks':protection['required_status_checks']['checks']})
        self.assertEqual(temporary,{'strict':True,'checks':[{'context':'CI Gate','app_id':15368}]})
        self.assertEqual(len(protection['required_status_checks']['checks']),2)


import copy
import json
import tempfile
from unittest import mock

class FakeApi:
    def __init__(self):
        self.state={
            'actor':{'login':'owner','id':1},
            'repository':{'allow_auto_merge':True,'allow_rebase_merge':True,'allow_merge_commit':False,
                          'allow_squash_merge':False,'delete_branch_on_merge':True,'default_branch':'master'},
            'protection':{'required_status_checks':{'strict':True,'contexts':['CI Gate','CI Policy Guardian'],
                'checks':[{'context':'CI Gate','app_id':15368},{'context':'CI Policy Guardian','app_id':15368}]},
                'enforce_admins':{'enabled':True},'required_linear_history':{'enabled':True}},
            'rules':[],'rulesets':[], 'master':{'object':{'sha':CONTROL.BASE}},
            'pr':{'number':169,'state':'open','merged':False,'base':{'ref':'master','sha':CONTROL.BASE},
                  'head':{'sha':CONTROL.HEAD,'ref':CONTROL.BRANCH},'auto_merge':None,'merge_commit_sha':None},
            'open_prs':[{'number':169}],
            'checks':{'total_count':2,'check_runs':[
                {'name':name,'conclusion':conclusion,'status':'completed','head_sha':CONTROL.HEAD,
                 'app':{'id':15368},'id':i,'details_url':'https://github.com/run/'+str(i)}
                for i,(name,conclusion) in enumerate([('CI Gate','success'),('CI Policy Guardian','failure')],1)]}}
        self.calls=[];self.merge=True;self.fail_register=False;self.fail_patch=False;self.interrupt=False
        self.repo_drift=False
    def get(self,endpoint):
        if endpoint=='user':return copy.deepcopy(self.state['actor'])
        tail=endpoint.removeprefix('repos/'+CONTROL.REPO)
        keys={'':'repository','/branches/master/protection':'protection','/rules/branches/master':'rules',
              '/rulesets':'rulesets','/git/ref/heads/master':'master','/pulls/169':'pr',
              '/pulls?state=open&base=master&per_page=100':'open_prs',
              '/commits/'+CONTROL.HEAD+'/check-runs?filter=latest&per_page=100':'checks'}
        if tail.startswith('/compare/'):
            return dict(status='ahead',merge_base_commit=dict(sha=CONTROL.BASE),ahead_by=1,total_commits=1,
                        commits=[dict(sha=tail.split('...')[1],parents=[dict(sha=CONTROL.BASE)],
                            commit=dict(tree=dict(sha='a'*40),message='candidate',author=dict(name='author',email='author@example.test',date='now')))])
        if tail.startswith('/git/commits/'):
            return {'parents':[{'sha':CONTROL.BASE}],'tree':{'sha':'a'*40},'message':'candidate',
                    'author':{'name':'author','email':'author@example.test','date':'2026-10-05'}}
        return copy.deepcopy(self.state[keys[tail]])
    def register(self):
        self.calls.append('register');self.state['pr']['auto_merge']={'merge_method':'rebase','enabled_by':copy.deepcopy(self.state['actor'])}
        if self.fail_register:raise CONTROL.ControlError('uncertain registration')
    def cancel(self):
        self.calls.append('cancel');self.state['pr']['auto_merge']=None
    def patch(self,endpoint,payload):
        self.calls.append(copy.deepcopy(payload));self.state['protection']['required_status_checks']={
            **copy.deepcopy(payload),'contexts':[c['context'] for c in payload['checks']]}
        if len(payload['checks'])==1:
            if self.fail_patch:raise CONTROL.ControlError('uncertain applied PATCH')
            if self.interrupt:raise KeyboardInterrupt('interrupted after applied PATCH')
            if self.merge:
                self.state['pr'].update(merged=True,state='closed',merge_commit_sha='f'*40)
                self.state['master']['object']['sha']='f'*40;self.state['open_prs']=[]
        elif self.repo_drift:self.state['repository']['allow_squash_merge']=True
        return copy.deepcopy(self.state['protection']['required_status_checks'])

class FakeWatchdog:
    def __init__(self):self.disarmed=False
    def alive(self):return True
    def disarm(self):self.disarmed=True

class StateControlTests(unittest.TestCase):
    def run_control(self,api,pinned=None,poll_seconds=0):
        pinned=copy.deepcopy(api.state) if pinned is None else pinned
        payload,temporary=CONTROL.check_payloads(pinned['protection']);watchdog=FakeWatchdog()
        with tempfile.TemporaryDirectory() as name, mock.patch.object(CONTROL.time,'sleep'):
            result=CONTROL.run_rollout(api,pinned,payload,temporary,name,lambda deadline:watchdog,poll_seconds)
        return result,watchdog
    def test_success_restores_full_policy_and_registers_once(self):
        api=FakeApi();pinned=copy.deepcopy(api.state)
        result,watchdog=self.run_control(api,pinned,1)
        self.assertEqual(result,'merged');self.assertTrue(watchdog.disarmed)
        self.assertEqual(api.calls.count('register'),1)
        self.assertEqual(CONTROL.policy_view(api.state),CONTROL.policy_view(pinned))
    def test_rebase_audit_covers_every_source_commit(self):
        source=[dict(sha='a'*40,parents=[dict(sha=CONTROL.BASE)],commit=dict(tree=dict(sha='1'*40),message='one',author=dict(name='a',email='a@example.test',date='now'))),
                dict(sha=CONTROL.HEAD,parents=[dict(sha='a'*40)],commit=dict(tree=dict(sha='2'*40),message='two',author=dict(name='a',email='a@example.test',date='now')))]
        merged=copy.deepcopy(source);merged[0]['sha']='b'*40;merged[1]['sha']='f'*40;merged[1]['parents']=[dict(sha='b'*40)]
        valid=lambda rows:dict(status='ahead',merge_base_commit=dict(sha=CONTROL.BASE),ahead_by=2,total_commits=2,commits=rows)
        CONTROL.verify_rebase_range(valid(source),valid(merged),'f'*40)
        for field in ('message','tree','author'):
            wrong=copy.deepcopy(merged);wrong[0]['commit'][field]='different'
            with self.assertRaises(CONTROL.ControlError):CONTROL.verify_rebase_range(valid(source),valid(wrong),'f'*40)
        wrong=copy.deepcopy(merged);wrong[0]['parents'].append(dict(sha='0'*40))
        with self.assertRaises(CONTROL.ControlError):CONTROL.verify_rebase_range(valid(source),valid(wrong),'f'*40)

    def test_precondition_drift_never_mutates_external_state(self):
        for axis in ('head','master','competitor','source','result','registration','protection','rules'):
            with self.subTest(axis=axis):
                api=FakeApi();pinned=copy.deepcopy(api.state)
                if axis=='head':api.state['pr']['head']['sha']='0'*40
                elif axis=='master':api.state['master']['object']['sha']='0'*40
                elif axis=='competitor':api.state['open_prs'].append({'number':170})
                elif axis=='source':api.state['checks']['check_runs'][0]['app']['id']=7
                elif axis=='result':api.state['checks']['check_runs'][0]['conclusion']='failure'
                elif axis=='registration':api.state['pr']['auto_merge']={'merge_method':'rebase'}
                elif axis=='protection':api.state['protection']['enforce_admins']['enabled']=False
                else:api.state['rules']=[{'type':'new-rule'}]
                with self.assertRaises(CONTROL.ControlError):self.run_control(api,pinned)
                self.assertEqual(api.calls,[])
    def test_uncertain_registration_and_patch_restore_and_cancel(self):
        for field in ('fail_register','fail_patch'):
            with self.subTest(field=field):
                api=FakeApi();setattr(api,field,True);pinned=copy.deepcopy(api.state)
                with self.assertRaises(CONTROL.ControlError):self.run_control(api,pinned)
                self.assertEqual(CONTROL.policy_view(api.state),CONTROL.policy_view(pinned))
                self.assertIsNone(api.state['pr']['auto_merge'])
                self.assertEqual(api.calls.count('register'),1)
                self.assertEqual(api.calls.count('cancel'),1)
    def test_bounded_merge_failure_restores_without_claiming_merge(self):
        api=FakeApi();api.merge=False;pinned=copy.deepcopy(api.state)
        with self.assertRaises(CONTROL.ControlError):self.run_control(api,pinned)
        self.assertEqual(CONTROL.policy_view(api.state),CONTROL.policy_view(pinned))
        self.assertFalse(api.state['pr']['merged']);self.assertIsNone(api.state['pr']['auto_merge'])
    def test_interrupt_after_applied_patch_still_restores(self):
        api=FakeApi();api.interrupt=True;pinned=copy.deepcopy(api.state)
        with self.assertRaises(KeyboardInterrupt):self.run_control(api,pinned)
        self.assertEqual(CONTROL.policy_view(api.state),CONTROL.policy_view(pinned));self.assertIsNone(api.state['pr']['auto_merge'])
    def test_full_policy_drift_cannot_report_restoration_success(self):
        api=FakeApi();api.repo_drift=True;pinned=copy.deepcopy(api.state)
        with self.assertRaisesRegex(CONTROL.ControlError,'restoration unconfirmed'):self.run_control(api,pinned,1)
        self.assertEqual(api.state['protection'],pinned['protection'])
        self.assertTrue(api.state['repository']['allow_squash_merge'])
    def test_dead_watchdog_prevents_registration_and_temporary_patch(self):
        api=FakeApi();pinned=copy.deepcopy(api.state);restore,temporary=CONTROL.check_payloads(pinned['protection'])
        watchdog=FakeWatchdog();watchdog.alive=lambda:False
        with tempfile.TemporaryDirectory() as name, mock.patch.object(CONTROL.time,'sleep'):
            with self.assertRaisesRegex(CONTROL.ControlError,'watchdog exited'):
                CONTROL.run_rollout(api,pinned,restore,temporary,name,lambda deadline:watchdog)
        self.assertNotIn('register',api.calls);self.assertNotIn(temporary,api.calls)
        self.assertEqual(CONTROL.policy_view(api.state),CONTROL.policy_view(pinned))

    def test_deadline_or_watchdog_firing_prevents_late_mutation(self):
        with tempfile.TemporaryDirectory() as name:
            with self.assertRaises(CONTROL.ControlError):CONTROL.ensure_window(name,CONTROL.time.monotonic()-1)
            Path(name,'watchdog-fired.json').write_text('{}')
            with self.assertRaises(CONTROL.ControlError):CONTROL.ensure_window(name,CONTROL.time.monotonic()+100)

class WatchdogBoundaryTests(unittest.TestCase):
    def test_watchdog_requires_exact_approval_and_finite_bounded_deadline(self):
        expected={'accepted':True,'repo':CONTROL.REPO,'pr':CONTROL.PR,'head':CONTROL.HEAD,'base':CONTROL.BASE,
                  'manifest_sha256':'a'*64,'deadline_seconds':CONTROL.DEADLINE_SECONDS}
        for change in [dict(accepted=1),dict(head='0'*40),dict(manifest_sha256='b'*64)]:
            wrong={**expected,**change}
            with self.assertRaises(CONTROL.ControlError):CONTROL.validate_approval_record(wrong,'a'*64)
        CONTROL.validate_approval_record(expected,'a'*64)
        for deadline in (float('nan'),float('inf'),True,CONTROL.time.monotonic()-1,CONTROL.time.monotonic()+1000):
            with self.assertRaises(CONTROL.ControlError):CONTROL.validate_watchdog_deadline(deadline)
        CONTROL.validate_watchdog_deadline(CONTROL.time.monotonic()+10)
    def test_failed_watchdog_readiness_reaps_child_without_mutation(self):
        process=mock.Mock();process.poll.return_value=None;process.wait.return_value=0
        with tempfile.TemporaryDirectory() as name, mock.patch.object(CONTROL.os,'getpgrp',return_value=CONTROL.os.getpid()), mock.patch.object(CONTROL.subprocess,'Popen',return_value=process), \
                mock.patch.object(CONTROL.time,'sleep'), mock.patch.object(CONTROL.time,'monotonic',side_effect=[0,6]):
            with self.assertRaises(CONTROL.ControlError):CONTROL.WatchdogProcess(name,name,10,'approval.json')
        process.terminate.assert_called_once();process.wait.assert_called_once()

class AdmissionOwnershipTests(unittest.TestCase):
    def test_drift_after_arming_before_registration_never_repairs_foreign_checks(self):
        api=FakeApi();pinned=copy.deepcopy(api.state);payload,temp=CONTROL.check_payloads(pinned['protection']);wd=FakeWatchdog()
        def arm(deadline):
            api.state['protection']['required_status_checks']['checks'].append({'context':'other','app_id':2})
            api.state['protection']['required_status_checks']['contexts'].append('other')
            return wd
        with tempfile.TemporaryDirectory() as folder,self.assertRaises(CONTROL.ControlError):
            CONTROL.run_rollout(api,pinned,payload,temp,folder,arm,poll_seconds=0)
        self.assertEqual(api.calls,[]);self.assertTrue(wd.disarmed)
        self.assertEqual(len(api.state['protection']['required_status_checks']['checks']),3)
    def test_drift_after_owned_registration_cancels_only_owned_registration(self):
        api=FakeApi();pinned=copy.deepcopy(api.state);payload,temp=CONTROL.check_payloads(pinned['protection']);wd=FakeWatchdog();original=api.register
        def changed():
            original();api.state['protection']['required_status_checks']['checks'].append({'context':'other','app_id':2})
            api.state['protection']['required_status_checks']['contexts'].append('other')
        api.register=changed
        with tempfile.TemporaryDirectory() as folder,mock.patch.object(CONTROL.time,'sleep'),self.assertRaises(CONTROL.ControlError):
            CONTROL.run_rollout(api,pinned,payload,temp,folder,lambda deadline:wd,poll_seconds=0)
        self.assertEqual(api.calls,['register','cancel'])
        self.assertEqual(len(api.state['protection']['required_status_checks']['checks']),3)

class ActorOwnershipTests(unittest.TestCase):
    def test_registered_rebase_by_other_actor_is_rejected(self):
        api=FakeApi();pinned=copy.deepcopy(api.state)
        api.state['pr']['auto_merge']={'merge_method':'rebase','enabled_by':{'login':'other','id':2}}
        with self.assertRaises(CONTROL.ControlError):CONTROL.verify_fixed(api.state,pinned,registered=True)
    def test_restore_never_cancels_other_actors_registration(self):
        api=FakeApi();pinned=copy.deepcopy(api.state);payload,_=CONTROL.check_payloads(pinned['protection'])
        api.state['pr']['auto_merge']={'merge_method':'rebase','enabled_by':{'login':'other','id':2}}
        with mock.patch.object(CONTROL.time,'sleep'),self.assertRaises(CONTROL.ControlError):CONTROL.restore(api,pinned,payload)
        self.assertNotIn('cancel',api.calls)

class SessionOwnershipTests(unittest.TestCase):
    def test_watchdog_lock_wait_obeys_deadline_while_main_holds_lock(self):
        with tempfile.TemporaryDirectory() as folder, CONTROL.locked(folder):
            with self.assertRaises(CONTROL.LockDeadlineExpired):
                with CONTROL.locked(folder,CONTROL.time.monotonic()+.03):self.fail('lock leaked across owner')

    def test_watchdog_rejects_shared_parent_session_before_spawn(self):
        with mock.patch.object(CONTROL.os,'getpgrp',return_value=1), mock.patch.object(CONTROL.subprocess,'Popen') as spawn:
            with self.assertRaises(CONTROL.ControlError):CONTROL.WatchdogProcess('unused','unused',10,'approval.json')
        spawn.assert_not_called()

if __name__=='__main__': unittest.main()
