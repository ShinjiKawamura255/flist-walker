#!/usr/bin/env python3
"""One-campaign, reviewed control. Live execution requires recorded exact approval."""
import argparse
import concurrent.futures
import contextlib
import copy
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

REPO = 'ShinjiKawamura255/flist-walker'
PR = 169
HEAD = '2e4f6766867e8867693dabddd9b32e6eb2d000fb'
BASE = '956976e2d5d0e717b2b4200e2342120621692a4a'
BRANCH = 'codex/indexing-perf-observation'
APP = 15368
EXPECTED_PATHS = ['.github/workflows/perf-regression.yml','scripts/check_ci_policy.py','scripts/tests/test_check_ci_policy.py']
DEADLINE_SECONDS = 180
READONLY_REPO = {'id','node_id','owner','fork','created_at','updated_at','pushed_at','size','stargazers_count','watchers_count','language','forks_count','mirror_url','open_issues_count','license','forks','open_issues','watchers','permissions','network_count','subscribers_count'}

class ControlError(RuntimeError): pass
class LockDeadlineExpired(ControlError): pass

def require(value, reason):
    if not value: raise ControlError(reason)

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path, data):
    path=Path(path); temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(data,sort_keys=True,indent=2)+'\n')
    temporary.replace(path)

def canonical(value):
    if isinstance(value,dict):
        return {k:canonical(v) for k,v in value.items() if k!='url' and not k.endswith('_url')}
    if isinstance(value,list): return [canonical(v) for v in value]
    return value

def policy_view(state):
    repo={k:v for k,v in state['repository'].items() if k not in READONLY_REPO}
    return canonical(dict(repository=repo,protection=state['protection'],rules=state['rules'],rulesets=state['rulesets']))

def check_payloads(protection):
    checks=protection['required_status_checks']
    expected=[{'context':'CI Gate','app_id':APP},{'context':'CI Policy Guardian','app_id':APP}]
    require(checks['strict'] is True and checks['contexts']==['CI Gate','CI Policy Guardian'] and checks['checks']==expected,
            'unexpected required contexts/source/strictness')
    restore={'strict':True,'checks':copy.deepcopy(expected)}
    return restore,{'strict':True,'checks':copy.deepcopy(expected[:1])}

class GhApi:
    def command(self, argv, payload=None):
        try:
            p=subprocess.run(argv,input=None if payload is None else json.dumps(payload),
                             text=True,capture_output=True,timeout=12)
        except subprocess.SubprocessError as error:
            raise ControlError('bounded gh request failed: '+type(error).__name__) from error
        require(p.returncode==0,'gh request failed; exit '+str(p.returncode))
        return p.stdout
    def get(self, endpoint): return json.loads(self.command(['gh','api',endpoint]))
    def patch(self, endpoint, payload):
        return json.loads(self.command(['gh','api','--method','PATCH',endpoint,'--input','-'],payload))
    def register(self):
        self.command(['gh','pr','merge',str(PR),'--repo',REPO,'--auto','--rebase','--delete-branch','--match-head-commit',HEAD])
    def cancel(self):
        self.command(['gh','pr','merge',str(PR),'--repo',REPO,'--disable-auto'])

def read_state(api):
    prefix='repos/'+REPO
    endpoints={'repository':prefix,'protection':prefix+'/branches/master/protection',
               'rules':prefix+'/rules/branches/master','rulesets':prefix+'/rulesets',
               'master':prefix+'/git/ref/heads/master','pr':prefix+'/pulls/'+str(PR),
               'open_prs':prefix+'/pulls?state=open&base=master&per_page=100',
               'checks':prefix+'/commits/'+HEAD+'/check-runs?filter=latest&per_page=100','actor':'user'}
    with concurrent.futures.ThreadPoolExecutor(max_workers=9) as executor:
        futures={key:executor.submit(api.get,endpoint) for key,endpoint in endpoints.items()}
        state={key:future.result() for key,future in futures.items()}
    state['repository'].pop('temp_clone_token',None)
    state['actor']={k:state['actor'][k] for k in ('login','id')}
    require(len(state['open_prs'])<100 and state['checks']['total_count']<100,'truncated API list')
    return state

def verify_checks(state, pinned=None):
    for name,conclusion in [('CI Gate','success'),('CI Policy Guardian','failure')]:
        found=[x for x in state['checks']['check_runs'] if x['name']==name]
        require(len(found)==1,'missing/duplicate '+name)
        check=found[0]
        require(check['head_sha']==HEAD and check['app']['id']==APP and check['status']=='completed'
                and check['conclusion']==conclusion,'wrong source/head/result for '+name)
        if pinned is not None:
            expected=next(x for x in pinned['checks']['check_runs'] if x['name']==name)
            require(check['id']==expected['id'] and check['details_url']==expected['details_url'],'check identity changed')

def registration_owned(pr,pinned):
    auto=pr['auto_merge']
    return auto is not None and auto.get('merge_method')=='rebase' and auto.get('enabled_by') is not None and {k:auto['enabled_by'].get(k) for k in ('login','id')}==pinned['actor']

def verify_fixed(state, pinned, registered=False):
    require(policy_view(state)==policy_view(pinned),'repository/protection/rule drift')
    require(state['actor']==pinned['actor'],'authenticated actor drift')
    require(state['rules']==state['rulesets']==[],'unexpected applied rules/rulesets')
    p=state['pr']
    require(p['number']==PR and p['state']=='open' and not p['merged'] and
            p['base']['ref']=='master' and p['base']['sha']==BASE and p['head']['sha']==HEAD and
            p['head']['ref']==BRANCH,'candidate PR/base/head changed')
    require(state['master']['object']['sha']==BASE,'master changed')
    require(len(state['open_prs'])==1 and state['open_prs'][0]['number']==PR,'competing master PR')
    auto=p['auto_merge']
    require(registration_owned(p,pinned) if registered else auto is None,'auto-merge actor/method drift')
    verify_checks(state,pinned)

@contextlib.contextmanager
def locked(folder,deadline=None):
    with (Path(folder)/'control.lock').open('a') as stream:
        if deadline is None:
            fcntl.flock(stream,fcntl.LOCK_EX)
        else:
            while True:
                if time.monotonic()>=deadline:raise LockDeadlineExpired('owned lock deadline')
                try:
                    fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB);break
                except BlockingIOError:time.sleep(.02)
        try: yield
        finally: fcntl.flock(stream,fcntl.LOCK_UN)

def validate_bundle(folder):
    folder=Path(folder);manifest=json.loads((folder/'manifest.json').read_text())
    require(type(manifest['schema']) is int and manifest['schema']==1 and manifest['deadline_seconds']==DEADLINE_SECONDS and set(manifest['hashes'])=={'snapshot.json','restore.json','temporary.json','guardian.json','controller.py'},'bundle schema')
    for name,digest in manifest['hashes'].items(): require(sha(folder/name)==digest,'bundle hash changed: '+name)
    require(sha(__file__)==manifest['hashes']['controller.py'],'executing unreviewed control')
    pinned=json.loads((folder/'snapshot.json').read_text())
    restore,temporary=check_payloads(pinned['protection'])
    require(json.loads((folder/'restore.json').read_text())==restore and json.loads((folder/'temporary.json').read_text())==temporary,'payload drift')
    evidence=json.loads((folder/'guardian.json').read_text())
    guardian=next(x for x in pinned['checks']['check_runs'] if x['name']=='CI Policy Guardian')
    require(evidence['head']==HEAD and evidence['app_id']==APP and evidence['check_run_id']==guardian['id'] and
            evidence['conclusion']=='failure' and evidence['paths']==EXPECTED_PATHS and
            re.fullmatch(r'[0-9a-f]{64}',evidence['log_sha256']) is not None,'Guardian proof mismatch')
    verify_fixed(pinned,pinned)
    return pinned,restore,temporary,manifest

def verify_rebase_range(source,merged,merged_head):
    for result,head in ((source,HEAD),(merged,merged_head)):
        commits=result['commits']
        require(result['status']=='ahead' and result['merge_base_commit']['sha']==BASE and
                type(result['total_commits']) is int and 1 <= result['total_commits'] <= 4 and
                result['ahead_by']==result['total_commits']==len(commits), 'incomplete/unexpected commit range')
        parent=BASE
        for commit in commits:
            require([p['sha'] for p in commit['parents']]==[parent], 'nonlinear rebase range')
            parent=commit['sha']
        require(parent==head,'range head mismatch')
    require(len(source['commits'])==len(merged['commits']),'rebase commit count changed')
    for original,replayed in zip(source['commits'],merged['commits']):
        for key in ('tree','message','author'):
            require(original['commit'][key]==replayed['commit'][key], 'rebase ordered '+key+' mismatch')


def post_restore(api,pinned):
    state=read_state(api)
    require(policy_view(state)==policy_view(pinned),'full settings/rules restoration readback mismatch')
    require(state['actor']==pinned['actor'],'restoration actor drift')
    p=state['pr']
    require(p['head']['sha']==HEAD and p['head']['ref']==BRANCH and p['base']['ref']=='master','restored PR identity')
    if p['merged']:
        require(p['state']=='closed' and state['master']['object']['sha']==p['merge_commit_sha'],'merged master identity')
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            source=executor.submit(api.get,'repos/'+REPO+'/compare/'+BASE+'...'+HEAD)
            merged=executor.submit(api.get,'repos/'+REPO+'/compare/'+BASE+'...'+p['merge_commit_sha'])
            verify_rebase_range(source.result(),merged.result(),p['merge_commit_sha'])
        require(state['open_prs']==[],'new competing PR after restore')
    else:
        require(p['state']=='open' and p['base']['sha']==BASE and state['master']['object']['sha']==BASE
                and p['auto_merge'] is None and len(state['open_prs'])==1 and state['open_prs'][0]['number']==PR,
                'failed rollout did not restore blocked PR identity/registration')
    return state

def restore(api,pinned,payload,restore_checks=True):
    endpoint='repos/'+REPO+'/branches/master/protection/required_status_checks'
    # Identical complete check/source payload is idempotent even after an uncertain request.
    last=None
    for _ in range(3):
        try:
            if restore_checks:api.patch(endpoint,payload)
            p=api.get('repos/'+REPO+'/pulls/'+str(PR))
            if not p['merged'] and p['auto_merge'] is not None:
                require(p['head']['sha']==HEAD and registration_owned(p,pinned),'unowned registration during restoration')
                api.cancel()
            return post_restore(api,pinned)
        except (ControlError,OSError,KeyError,ValueError) as error:
            last=error;time.sleep(.2)
    raise ControlError('restoration unconfirmed; do not disarm watchdog or start protected proof') from last

def ensure_window(folder,deadline,watchdog=None):
    if watchdog is not None:require(watchdog.alive(),'independent watchdog exited; no further mutation')
    require(time.monotonic()<deadline and not (Path(folder)/'watchdog-fired.json').exists(),'restoration deadline fired; no further mutation')

def run_rollout(api,pinned,restore_payload,temporary,folder,watchdog_factory,poll_seconds=60):
    folder=Path(folder);deadline=time.monotonic()+DEADLINE_SECONDS;watchdog=None;result=None
    try:
        with locked(folder):
            verify_fixed(read_state(api),pinned)
            watchdog=watchdog_factory(deadline)
            ensure_window(folder,deadline,watchdog)
            verify_fixed(read_state(api),pinned)
            ensure_window(folder,deadline,watchdog)
            save(folder/'registration-admitted.json',{'head':HEAD,'actor':pinned['actor']})
            api.register()  # Exactly once, only after the independent process is armed.
            verify_fixed(read_state(api),pinned,registered=True)
            ensure_window(folder,deadline,watchdog)
            save(folder/'temporary-admitted.json',{'head':HEAD,'actor':pinned['actor']})
            api.patch('repos/'+REPO+'/branches/master/protection/required_status_checks',temporary)
        limit=min(deadline,time.monotonic()+poll_seconds)
        while time.monotonic()<limit:
            p=api.get('repos/'+REPO+'/pulls/'+str(PR))
            require(p['head']['sha']==HEAD and p['head']['ref']==BRANCH and p['base']['ref']=='master','PR drift during merge wait')
            if p['merged']:
                result='merged';break
            require(p['state']=='open' and p['base']['sha']==BASE,'PR/base changed during merge wait')
            time.sleep(1)
        require(result=='merged','bounded merge wait expired')
    finally:
        # This also handles uncertain register/PATCH results, interrupts and merge failure.
        if watchdog is not None:
            with locked(folder):
                if (folder/'registration-admitted.json').exists():
                    state=restore(api,pinned,restore_payload,restore_checks=(folder/'temporary-admitted.json').exists())
                    save(folder/'verified-restored.json',{'head':HEAD,'base':BASE,'pr':PR,'policy':policy_view(state),'result':result})
                else:
                    save(folder/'aborted-before-mutation.json',{'head':HEAD,'actor':pinned['actor']})
            watchdog.disarm()
    return result

def validate_approval_record(approval,manifest_digest):
    require(type(approval) is dict and type(approval.get('accepted')) is bool and
            approval=={'accepted':True,'repo':REPO,'pr':PR,'head':HEAD,'base':BASE,
                       'manifest_sha256':manifest_digest,'deadline_seconds':DEADLINE_SECONDS},
            'missing exact recorded approval')

def validate_approval(bundle,approval_file):
    validate_approval_record(json.loads(Path(approval_file).read_text()),sha(Path(bundle)/'manifest.json'))

def validate_watchdog_deadline(deadline):
    require(type(deadline) in (float,int) and math.isfinite(deadline) and
            0 < deadline-time.monotonic() <= DEADLINE_SECONDS,
            'invalid watchdog deadline')

class WatchdogProcess:
    def __init__(self,bundle,folder,deadline,approval):
        require(os.getpgrp()==os.getpid(),'controller must own its process session')
        self.folder=Path(folder);self.log=(self.folder/'watchdog.log').open('x');self.process=None
        try:
            self.process=subprocess.Popen([sys.executable,str(Path(bundle)/'controller.py'),'watchdog','--bundle',str(bundle),
                '--output',str(folder),'--deadline',str(deadline),'--approval',str(approval),
                '--parent-pid',str(os.getpid())],
                stdout=self.log,stderr=subprocess.STDOUT,start_new_session=True)
            limit=time.monotonic()+5
            while time.monotonic()<limit and not (self.folder/'watchdog-ready.json').exists():
                require(self.process.poll() is None,'watchdog exited before arming');time.sleep(.02)
            require((self.folder/'watchdog-ready.json').exists(),'watchdog readiness unconfirmed')
            ready=json.loads((self.folder/'watchdog-ready.json').read_text())
            require(ready['pid']==self.process.pid and ready['head']==HEAD and ready['deadline_monotonic']==deadline
                    and ready['parent_pid']==os.getpid() and ready['parent_process_group']==os.getpid(),
                    'watchdog readiness identity mismatch')
        except BaseException:
            # No main mutation has been admitted until this constructor returns.
            # Stop and reap an unsuccessful helper rather than lose its ownership.
            try:
                if self.process is not None:
                    if self.process.poll() is None:self.process.terminate()
                    try:self.process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        self.process.kill();self.process.wait(timeout=5)
            finally:self.log.close()
            raise
    def alive(self):return self.process.poll() is None
    def disarm(self):
        try:
            require(self.process.wait(timeout=30)==0,'watchdog did not verify restoration')
        finally: self.log.close()

def watchdog(bundle,folder,deadline,approval,parent_pid):
    validate_approval(bundle,approval);validate_watchdog_deadline(deadline)
    require(type(parent_pid) is int and parent_pid>1 and os.getppid()==parent_pid
            and os.getpgid(parent_pid)==parent_pid,'watchdog parent/session identity mismatch')
    pinned,payload,_temporary,_manifest=validate_bundle(bundle);folder=Path(folder);api=GhApi()
    save(folder/'watchdog-ready.json',{'pid':os.getpid(),'deadline_monotonic':deadline,'head':HEAD,
        'parent_pid':parent_pid,'parent_process_group':parent_pid})
    while time.monotonic()<deadline:
        if (folder/'aborted-before-mutation.json').exists():
            require(not (folder/'registration-admitted.json').exists(),'conflicting mutation admission')
            save(folder/'watchdog-complete.json',{'status':'aborted-before-mutation'});return
        if (folder/'verified-restored.json').exists():
            try:
                with locked(folder,deadline): post_restore(api,pinned)
            except LockDeadlineExpired:break
            save(folder/'watchdog-complete.json',{'status':'verified-main-restoration'});return
        time.sleep(.1)
    # At the deadline a live, original parent can be suspended holding the lock.
    # Parent relation plus its dedicated session proves ownership; never kill a
    # reused PID after reparenting. The separate watchdog session survives.
    if os.getppid()==parent_pid:
        try:
            require(os.getpgid(parent_pid)==parent_pid,'controller process session changed')
            os.killpg(parent_pid,signal.SIGKILL)
        except ProcessLookupError: pass
    with locked(folder):
        save(folder/'watchdog-fired.json',{'head':HEAD,'deadline_monotonic':deadline})
        registration=folder/'registration-admitted.json';temporary=folder/'temporary-admitted.json'
        require(not temporary.exists() or registration.exists(),'temporary without registration admission')
        if not registration.exists():
            save(folder/'watchdog-complete.json',{'status':'no-owned-mutation'});return
        expected={'head':HEAD,'actor':pinned['actor']}
        require(json.loads(registration.read_text())==expected,'registration admission identity drift')
        if temporary.exists():require(json.loads(temporary.read_text())==expected,'temporary admission identity drift')
        state=restore(api,pinned,payload,restore_checks=temporary.exists())
        save(folder/'watchdog-complete.json',{'status':'deadline-restored','policy':policy_view(state)})

def make_bundle(output,guardian_file):
    output=Path(output);require(not output.exists(),'bundle already exists');api=GhApi();state=read_state(api)
    verify_fixed(state,state);payload,temporary=check_payloads(state['protection'])
    require(state['repository']['allow_auto_merge'] is True and state['repository']['allow_rebase_merge'] is True
            and state['repository']['allow_merge_commit'] is False and state['repository']['allow_squash_merge'] is False
            and state['repository']['delete_branch_on_merge'] is True,'repository merge policy')
    output.mkdir();save(output/'snapshot.json',state);save(output/'restore.json',payload);save(output/'temporary.json',temporary)
    (output/'guardian.json').write_bytes(Path(guardian_file).read_bytes());(output/'controller.py').write_bytes(Path(__file__).read_bytes())
    hashes={name:sha(output/name) for name in ['snapshot.json','restore.json','temporary.json','guardian.json','controller.py']}
    save(output/'manifest.json',{'schema':1,'hashes':hashes,'deadline_seconds':DEADLINE_SECONDS,'authority':'pending explicit human approval after independent FINAL'})
    print('Prepared exact bundle; no external mutation')

def main():
    parser=argparse.ArgumentParser();commands=parser.add_subparsers(dest='command',required=True)
    snap=commands.add_parser('snapshot');snap.add_argument('--output',required=True);snap.add_argument('--guardian',required=True)
    for name in ['execute','watchdog']:
        sub=commands.add_parser(name);sub.add_argument('--bundle',required=True);sub.add_argument('--output',required=True)
        sub.add_argument('--approval',required=True)
        if name=='watchdog':
            sub.add_argument('--deadline',type=float,required=True)
            sub.add_argument('--parent-pid',type=int,required=True)
    args=parser.parse_args()
    def interrupt(_signum,_frame): raise KeyboardInterrupt('control interrupted')
    signal.signal(signal.SIGTERM,interrupt)
    if args.command=='snapshot':make_bundle(args.output,args.guardian)
    elif args.command=='watchdog':watchdog(args.bundle,args.output,args.deadline,args.approval,args.parent_pid)
    else:
        pinned,payload,temporary,manifest=validate_bundle(args.bundle)
        validate_approval(args.bundle,args.approval)
        if os.getpgrp()!=os.getpid():os.setsid()
        require(os.getpgrp()==os.getpid(),'controller session creation failed')
        output=Path(args.output);require(not output.exists(),'execution output exists');output.mkdir()
        run_rollout(GhApi(),pinned,payload,temporary,output,lambda deadline:WatchdogProcess(args.bundle,output,deadline,args.approval))
        print('Rollout merged; full restoration independently verified. Protected proof still required.')

if __name__=='__main__':main()
