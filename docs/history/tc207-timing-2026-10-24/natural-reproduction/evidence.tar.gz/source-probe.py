import pathlib,importlib.util,json,xml.etree.ElementTree as E
r=pathlib.Path('/Users/shinji/work/flist-walker');p=r/'docs/history/tc207-timing-2026-10-24/natural-reproduction/project.py';s=importlib.util.spec_from_file_location('p',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
d=r/'rust/target/tc207-natural-20261024/threads48-3';receipt=json.loads((d/'receipt.json').read_text());pid=receipt['pid'];target='tc_207_background_finalization_survives_promotion_to_active';tables=list(E.parse(d/'toc.xml').find('.//data'));ids=m.index_ids(d/'events.xml')
def res(e):return m.legacy.resolve(e,ids)
def num(e):return int(res(e).text)
def proc(e):return num(res(e).find('pid'))
def tid(e):return num(res(e).find('tid'))
def stack(e):return [] if e.tag=='sentinel' else [res(f).get('name','UNKNOWN') for f in res(e).findall('frame')]
matches=[]
for i,row in m.iter_rows(d/'events.xml'):
 schema=tables[i-1].get('schema');c=list(row)
 if schema=='time-profile' and len(c)==7 and proc(c[2])==pid:
  names=stack(c[6]);time=num(c[0]);t=tid(c[1])
 elif schema=='context-switch-sample' and len(c)==6 and proc(c[2])==pid:
  names=stack(c[5]);time=num(c[0]);t=tid(c[1])
 else:continue
 if any(target in name for name in names):matches.append(dict(pid=pid,tid=t,time=time,source=schema,stack=names))
tids={x['tid'] for x in matches};states=[];switches=[];transitions=[]
for i,row in m.iter_rows(d/'events.xml'):
 schema=tables[i-1].get('schema');c=list(row)
 if schema=='thread-state' and len(c)>=5 and proc(c[4])==pid and tid(c[1]) in tids:states.append(dict(pid=pid,tid=tid(c[1]),start=num(c[0]),end=num(c[0])+num(c[3]),state=res(c[2]).text or res(c[2]).get('fmt')))
 elif schema=='context-switch' and len(c)>=4 and proc(c[3])==pid and tid(c[1]) in tids:switches.append(dict(pid=pid,tid=tid(c[1]),time=num(c[0]),event=res(c[2]).text or res(c[2]).get('fmt')))
 elif schema=='context-switch-sample' and len(c)==6 and proc(c[2])==pid and tid(c[1]) in tids:transitions.append(dict(pid=pid,tid=tid(c[1]),time=num(c[0]),stack=stack(c[5])))
output=dict(pid=pid,test=target,matched_tids=sorted(tids),matching_samples=matches,states=states,switches=switches,transition_stacks=transitions,limits=['test-thread attribution by exact target function symbol; no inferred precise failed-frame start/end'])
(d/'promotion-thread-inputs.json').write_text(json.dumps(output,separators=(',',':'))+'\n')
print('matched tids',sorted(tids),'matching samples',len(matches),'states',len(states))
for row in sorted(states,key=lambda x:x['end']-x['start'],reverse=True)[:10]:
 print(row,'duration_ns',row['end']-row['start'])
 relevant=[x for x in transitions if x['tid']==row['tid'] and (abs(x['time']-row['start'])<=1000 or abs(x['time']-row['end'])<=1000) and x['stack']]
 for x in relevant:print('transition',x)
