import pathlib,json,shutil,hashlib,gzip,tarfile,importlib.util,re
repo=pathlib.Path('/Users/shinji/work/flist-walker');root=repo/'rust/target/tc207-natural-20261024';src=repo/'docs/history/tc207-timing-2026-10-24/natural-reproduction';out=root/'public-evidence';out.mkdir(mode=0o700,exist_ok=False)
spec=importlib.util.spec_from_file_location('p',src/'project.py');projection=importlib.util.module_from_spec(spec);spec.loader.exec_module(projection)
spec=importlib.util.spec_from_file_location('q',src/'promotion.py');promotion=importlib.util.module_from_spec(spec);spec.loader.exec_module(promotion)
retained=['plan.json','capture-ledger.json','first-natural-failure.json','test-inventory.txt','raw-inventory.json','project-red.txt','assertion-red.txt','unmeasured-red.txt','index-red.txt','unique-failures-red.txt','promotion-proof-red.txt','promotion-proof-fixture-failure.txt','missing-witness-red.txt','project-green.txt','legacy-tests.txt','reference-check.stdout','reference-check.stderr','reference-check-repaired.stdout','reference-check-repaired.stderr','reference-summary.json','canonical-promotion-check.stdout','canonical-promotion-check.stderr','inventory-v1.stderr','resource-check-threads48-1.json','resource-check-threads48-2.json','resource-check-threads48-3.json','validation-quick.txt']
for name in retained:shutil.copy2(root/name,out/name)
for name in ['projector-v1','projector-v2-pre-unique']:shutil.copytree(root/name,out/name)
method=out/'method/natural-reproduction';method.mkdir(parents=True)
for name in ['project.py','promotion.py','test_project.py','test_promotion.py']:shutil.copy2(src/name,method/name)
legacy=out/'method/system-trace';legacy.mkdir()
for name in ['analyze.py','record.py','clock-anchor.c']:shutil.copy2(src.parent/'system-trace'/name,legacy/name)
for name in ['finalization_timing.rs','tab_background_responses.rs']:
 p=out/'source/rust/src/app/tests';p.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/'rust/src/app/tests'/name,p/name)
for name in ['Cargo.lock','rust-toolchain.toml']:shutil.copy2(repo/'rust'/name,out/'source/rust'/name)
shutil.copy2('/private/tmp/tc207-unmeasured-probe.py',out/'source-probe.py');shutil.copy2('/private/tmp/tc207-raw-inventory.py',out/'inventory.py');shutil.copy2(root/'inventory-v1.py',out/'inventory-v1.py');shutil.copy2('/private/tmp/tc207-retain-natural.py',out/'projection-retention.py')
summaries={}
for entry in json.loads((root/'plan.json').read_text())['captures']:
 label=entry['label'];d=root/label;dest=out/label;dest.mkdir()
 for name in ['receipt.json','projected-inputs.json','projected-summary.json','test-outcomes.json','analysis-exit.txt','analysis-repaired-exit.txt','project.stderr','project-repaired.stderr']:
  if (d/name).is_file():shutil.copy2(d/name,dest/name)
 data=json.loads((d/'projected-inputs.json').read_text());summary=projection.summarize(data);expected=json.loads((d/'projected-summary.json').read_text());assert summary==expected,label
 pid=data['receipt']['pid']
 for key in ['states','switches','cpu_samples','supplemental_samples','transition_stacks']:assert all(r['pid']==pid for r in data[key]),(label,key)
 # Only clock anchors and runner totals from stdout; raw environment or runtime settings are not shared.
 text=(d/'test.log').read_text();(dest/'runner-summary.txt').write_text('\n'.join(x for x in text.splitlines() if x.startswith(('TC207_CLOCK ','test result:','running ')))+'\n')
 summaries[label]=summary
 if label=='threads48-3':
  for name in ['promotion-inputs.json','promotion-proof.json']:shutil.copy2(d/name,dest/name)
  assert promotion.prove(json.loads((d/'promotion-inputs.json').read_text()))==json.loads((d/'promotion-proof.json').read_text())
failure_details=[dict(capture='default-3',test='app::tests::stateful_endurance::tc_184_restored_preview_kind_resolution_survives_index_refresh',source='src/app/tests/stateful_endurance/harness.rs:514',seed='0x1840002e',step=337,event='CompleteNewestIndex(Failed)',message='stateful response changed unrelated tab15',root_before=0,root_after=1,lifecycle_before='Failed',lifecycle_after='Dormant',cause='UNKNOWN'),dict(capture='threads48-3',test='app::tests::tab_background_responses::tc_207_background_finalization_survives_promotion_to_active',source='src/app/tests/tab_background_responses.rs:3812',message='promotion finalization frame exceeded budget',threshold_ns=100_000_000,wall_lower_bound_ns=100_000_000,wall_ns=None,cpu_ns=None,trace_proof='threads48-3/promotion-proof.json'),dict(capture='threads48-3',test='runtime_config::tests::editable_settings_save_preserves_unknown_json_and_defers_effective_config',source='src/runtime_config/tests/mod.rs:179',message='runtime settings equality assertion failed',search_parallel_threshold_left=7,search_parallel_threshold_right=25000,filelist_auto_check_enabled_left=False,filelist_auto_check_enabled_right=True,private_paths='redacted; exact original stderr hash and local log retained',cause='UNKNOWN')]
(out/'failure-details.json').write_text(json.dumps(failure_details,indent=2)+'\n')
manifest=dict(source_base='9ab1b8be7d23b67706f33e48cc8b4592b5413eb5',threshold_ns=100_000_000,captures=len(summaries),clocked_frames=sum(s['frames'] for s in summaries.values()),short_uncertain_frames=sum(s['uncertain_frames'] for s in summaries.values()),coverage_gap_frames=sum(s['coverage_gap_frames'] for s in summaries.values()),raw_location='private Git-ignored local captures; raw trace/XML/TOC/stdout/stderr not uploaded',bundle_digest_recipe='SHA256(canonical JSON list of sorted relative entries {path,type,bytes,sha256}; symlinks use {path,type,target}); metadata/xattrs excluded. Full entry lists remain private.',projection='target-PID frame inputs and exact numeric/stack projections; every summary replayed with final code. Canonical promotion extraction matches retained probe numeric fields; all7 previous full-suite fields match frozen PR207 inputs.',test_outcome_limits='individual stdout lines interrupted by parallel output remain UNKNOWN/AMBIGUOUS; authoritative suite totals and all unique FAILED names retained; no gap is promoted to PASS',source_order_proof='conditional on recorded state/stack timestamps, confirmed immediate100ms assertion and unique case thread; no independent zero-event-loss certification',summaries=summaries)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
checks={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.rglob('*')) if p.is_file()};(out/'sha256.json').write_text(json.dumps(checks,indent=2)+'\n')
archive=src/'evidence.tar.gz'
with archive.open('xb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as g,tarfile.open(fileobj=g,mode='w') as tar:
 for p in sorted(out.rglob('*')):
  if p.is_file():
   info=tar.gettarinfo(str(p),arcname=str(p.relative_to(out)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
   with p.open('rb') as f2:tar.addfile(info,f2)
print(json.dumps(dict(archive_bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=len(checks)+1),indent=2))
