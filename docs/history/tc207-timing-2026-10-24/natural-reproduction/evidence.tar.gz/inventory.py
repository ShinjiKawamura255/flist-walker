import pathlib,json,hashlib,subprocess,re,collections
root=pathlib.Path('/Users/shinji/work/flist-walker/rust/target/tc207-natural-20261024')
r=subprocess.run([str(root/'test-binary'),'--list'],capture_output=True,text=True,timeout=10);assert r.returncode==0
(root/'test-inventory.txt').write_text(r.stdout);names={line[:-6] for line in r.stdout.splitlines() if line.endswith(': test')};assert len(names)==1679
plan=json.loads((root/'plan.json').read_text());results={}
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  while block:=f.read(1024*1024):h.update(block)
 return h.hexdigest()
for capture in plan['captures']:
 label=capture['label'];d=root/label;entries=[];trace=d/'record.trace'
 for path in sorted(trace.rglob('*')):
  relative=str(path.relative_to(trace))
  if path.is_symlink():entries.append(dict(path=relative,type='symlink',target=str(path.readlink())))
  elif path.is_file():entries.append(dict(path=relative,type='file',bytes=path.stat().st_size,sha256=sha(path)))
 manifest=json.dumps(entries,sort_keys=True,separators=(',',':')).encode()
 (d/'private-bundle-inventory.json').write_bytes(manifest+b'\n')
 raw={}
 for path in sorted(d.iterdir()):
  if path.is_file() and (path.name.endswith(('.xml','.log','.stderr','.stdout','.txt')) or path.name=='receipt.json'):
   raw[path.name]=dict(bytes=path.stat().st_size,sha256=sha(path))
 for path in (d/'frame-logs').glob('*.jsonl'):raw['frame-logs/'+path.name]=dict(bytes=path.stat().st_size,sha256=sha(path))
 log=(d/'test.log').read_text();found=collections.defaultdict(list)
 for name,status in re.findall(r'^test (.+?) \.\.\. (ok|FAILED|ignored[^\n]*)\s*$',log,re.M):
  if name in names:found[name].append(status)
 assert not set(found)-names
 statuses={n:('UNKNOWN' if not found[n] else 'AMBIGUOUS' if len(found[n])!=1 else 'PASS' if found[n][0]=='ok' else 'FAIL' if found[n][0]=='FAILED' else 'IGNORED') for n in sorted(names)}
 suite=next(r['suite'] for r in json.loads((root/'capture-ledger.json').read_text()) if r['label']==label)
 counts0=collections.Counter(statuses.values())
 assert counts0['PASS']<=suite['passed'] and counts0['FAIL']==suite['failed'] and counts0['IGNORED']<=suite['ignored']
 unresolved=dict(passed=suite['passed']-counts0['PASS'],ignored=suite['ignored']-counts0['IGNORED'])
 # Parallel stdout can interrupt individual lines. Never reconstruct them as PASS.

 counts=dict(collections.Counter(statuses.values()));(d/'test-outcomes.json').write_text(json.dumps(dict(counts=counts,authoritative_suite=suite,unresolved_summary_counts=unresolved,tests=statuses,limits=['UNKNOWN/AMBIGUOUS are retained individual stdout gaps; no missing result promoted to PASS']),indent=2)+'\n')
 results[label]=dict(raw_files=raw,bundle_file_tree_digest_sha256=hashlib.sha256(manifest).hexdigest(),bundle_entries=len(entries),bundle_bytes=sum(e.get('bytes',0) for e in entries),test_counts=counts)
 print(label,'hashes and1679 outcomes retained',flush=True)
(root/'raw-inventory.json').write_text(json.dumps(results,indent=2)+'\n')
