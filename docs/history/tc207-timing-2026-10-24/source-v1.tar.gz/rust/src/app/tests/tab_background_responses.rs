use super::*;

#[test]
fn tc_207_promoted_handoff_preserves_active_warm_active_mailbox_order() {
    use crate::app::index_response_effects::{IndexResponseApplicationOwner, RoutedIndexResponse};
    let settings = test_settings_scope("tc-207-handoff-order");
    let root = test_root("tc-207-handoff-order-root");
    fs::create_dir(&root).unwrap();
    fs::write(root.join("FileList.txt"), "").unwrap();
    let mut app = settings.app(root.clone(), 50, String::new());
    app.shell.ui.show_preview = false;
    app.filelist_auto_check_enabled = false;
    app.create_new_tab();
    reset_index_request_state_for_test(&mut app);
    let (index_tx, index_rx) = bounded_request_channel::<IndexRequest>(2);
    app.shell.indexing.tx = index_tx;
    for tab in &mut app.shell.tabs {
        tab.index_state
            .set_lifecycle_for_test(TabResourceLifecycle::Ready);
    }
    app.shell
        .indexing
        .apply_resource_transition(crate::app::tab_state::TabResourceTransition::Success);
    app.switch_to_tab_index(0);
    let tab_id = app.current_tab_id().unwrap();
    let request_id = app.shell.indexing.allocate_request_id(Some(tab_id));
    app.shell.indexing.pending_request_id = Some(request_id);
    app.shell.indexing.in_progress = true;
    app.shell.indexing.inflight_requests.insert(request_id);
    let mailbox = app.shell.indexing.response_mailboxes.lock().unwrap()[&request_id].clone();
    let source = IndexSource::FileList(root.join("FileList.txt"));
    let batch = |range: std::ops::Range<usize>| IndexResponse::Batch {
        request_id,
        entries: range
            .map(|i| IndexEntry {
                path: root.join(format!("e{i}.txt")),
                kind: EntryKind::file(),
                kind_known: true,
            })
            .collect(),
    };
    mailbox
        .try_publish(IndexResponse::Started {
            request_id,
            source: source.clone(),
        })
        .unwrap();
    mailbox.try_publish(batch(0..2)).unwrap();
    app.poll_index_response();
    assert_eq!(app.shell.indexing.build.index.entries.len(), 2);
    // Consume the next real mailbox batch but leave its active drain pending.
    mailbox.try_publish(batch(2..3)).unwrap();
    let response = mailbox.try_recv().unwrap();
    IndexResponseApplicationOwner::new(&mut app).apply(RoutedIndexResponse {
        route: IndexResponseRoute::Active,
        response,
        active_mailbox_blocked: false,
        from_shared_response_queue: false,
    });
    let next_request_id = app.shell.indexing.next_request_id;
    app.switch_to_tab_index(1);
    assert_eq!(app.shell.indexing.warm_tab_id, Some(tab_id));
    mailbox.try_publish(batch(3..5)).unwrap();
    app.poll_index_response();
    assert_eq!(
        app.shell.indexing.background_states[&request_id]
            .entries
            .len(),
        2
    );
    app.switch_to_tab_index(0);
    assert_eq!(app.current_tab_id(), Some(tab_id));
    assert_eq!(app.shell.indexing.pending_request_id, Some(request_id));
    assert!(app.shell.indexing.in_progress);
    assert_eq!(
        app.shell
            .indexing
            .latest_request_ids
            .lock()
            .unwrap()
            .get(&tab_id),
        Some(&request_id)
    );

    assert_eq!(app.shell.indexing.next_request_id, next_request_id);
    assert_eq!(app.shell.indexing.build.index.source, source);
    assert_eq!(
        app.shell
            .indexing
            .build
            .index
            .entries
            .iter()
            .map(|e| e.path.clone())
            .collect::<Vec<_>>(),
        (0..2)
            .map(|i| root.join(format!("e{i}.txt")))
            .collect::<Vec<_>>()
    );
    mailbox.try_publish(batch(5..7)).unwrap();
    mailbox
        .try_publish(IndexResponse::Finished {
            request_id,
            source: source.clone(),
        })
        .unwrap();
    poll_background_index_until(&mut app, "ordered promoted terminal", |app| {
        app.shell.indexing.pending_request_id.is_none()
            && !app
                .shell
                .indexing
                .background_states
                .contains_key(&request_id)
            && !app
                .shell
                .indexing
                .background_finalizations
                .contains_key(&request_id)
    });
    let expected = (0..7)
        .map(|i| root.join(format!("e{i}.txt")))
        .collect::<Vec<_>>();
    assert_eq!(
        app.shell
            .runtime
            .all_entries
            .iter()
            .map(|e| e.path.clone())
            .collect::<Vec<_>>(),
        expected
    );
    assert_eq!(
        app.shell
            .runtime
            .entries
            .iter()
            .map(|e| e.path.clone())
            .collect::<Vec<_>>(),
        expected
    );
    assert_eq!(
        app.shell
            .runtime
            .results
            .iter()
            .map(|(p, _)| p.clone())
            .collect::<Vec<_>>(),
        expected
    );
    assert_eq!(app.shell.indexing.next_request_id, next_request_id);
    assert!(
        matches!(
            index_rx.try_recv(),
            Err(std::sync::mpsc::TryRecvError::Empty)
        ),
        "same-generation Warm restoration must not dispatch another request"
    );
    let freshness = app.shell.runtime.freshness.as_ref().unwrap();
    assert_eq!(freshness.request_id, request_id);
    assert_eq!(freshness.root, root);
    assert_eq!(app.shell.indexing.build.index.source, source);
    assert!(!app.shell.indexing.request_tabs.contains_key(&request_id));
    assert!(!app.shell.indexing.inflight_requests.contains(&request_id));
    drop(app);
    fs::remove_dir_all(root).unwrap();
}

fn handoff_test_batch(
    root: &Path,
    request_id: u64,
    range: std::ops::Range<usize>,
) -> IndexResponse {
    IndexResponse::Batch {
        request_id,
        entries: range
            .map(|i| IndexEntry {
                path: root.join(format!("e{i}.txt")),
                kind: EntryKind::file(),
                kind_known: true,
            })
            .collect(),
    }
}

fn handoff_fixture_name() -> String {
    static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
    format!(
        "tc-207-handoff-guards-{}-{}",
        std::process::id(),
        NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed)
    )
}

#[test]
fn tc_207_parallel_handoff_fixtures_have_distinct_names() {
    let names = std::thread::scope(|scope| {
        (0..16)
            .map(|_| scope.spawn(handoff_fixture_name))
            .collect::<Vec<_>>()
            .into_iter()
            .map(|thread| thread.join().unwrap())
            .collect::<std::collections::HashSet<_>>()
    });
    assert_eq!(
        names.len(),
        16,
        "a clock tick cannot share fixture ownership"
    );
}

fn handoff_test_app(
    started_active: bool,
) -> (
    super::support::TestSettingsScope,
    PathBuf,
    FlistWalkerApp,
    u64,
    Arc<crate::app::index_mailbox::IndexResponseMailbox>,
) {
    use crate::app::index_response_effects::{IndexResponseApplicationOwner, RoutedIndexResponse};
    let name = handoff_fixture_name();
    let settings = test_settings_scope(&name);
    let root = test_root(&format!("{name}-root"));
    fs::create_dir(&root).unwrap();
    fs::write(root.join("FileList.txt"), "").unwrap();
    let mut app = settings.app(root.clone(), 50, String::new());
    app.shell.ui.show_preview = false;
    app.filelist_auto_check_enabled = false;
    app.create_new_tab();
    reset_index_request_state_for_test(&mut app);
    for tab in &mut app.shell.tabs {
        tab.index_state
            .set_lifecycle_for_test(TabResourceLifecycle::Ready);
    }
    app.shell
        .indexing
        .apply_resource_transition(crate::app::tab_state::TabResourceTransition::Success);
    app.switch_to_tab_index(0);
    app.shell.runtime.use_filelist = true;
    app.shell.runtime.include_files = true;
    app.shell.runtime.include_dirs = true;
    app.shell.ui.ignore_list_enabled = false;
    let tab_id = app.current_tab_id().unwrap();
    let id = app.shell.indexing.allocate_request_id(Some(tab_id));
    app.shell.indexing.pending_request_id = Some(id);
    app.shell.indexing.in_progress = true;
    app.shell.indexing.inflight_requests.insert(id);
    app.shell.indexing.build.index.source = IndexSource::None;
    let mailbox = app.shell.indexing.response_mailboxes.lock().unwrap()[&id].clone();
    if started_active {
        mailbox
            .try_publish(IndexResponse::Started {
                request_id: id,
                source: IndexSource::FileList(root.join("FileList.txt")),
            })
            .unwrap();
    }
    mailbox
        .try_publish(handoff_test_batch(&root, id, 0..2))
        .unwrap();
    app.poll_index_response();
    mailbox
        .try_publish(handoff_test_batch(&root, id, 2..3))
        .unwrap();
    IndexResponseApplicationOwner::new(&mut app).apply(RoutedIndexResponse {
        route: IndexResponseRoute::Active,
        response: mailbox.try_recv().unwrap(),
        active_mailbox_blocked: false,
        from_shared_response_queue: false,
    });
    app.switch_to_tab_index(1);
    if !started_active {
        mailbox
            .try_publish(IndexResponse::Started {
                request_id: id,
                source: IndexSource::FileList(root.join("FileList.txt")),
            })
            .unwrap();
    }
    mailbox
        .try_publish(handoff_test_batch(&root, id, 3..7))
        .unwrap();
    app.poll_index_response();
    assert_eq!(
        app.shell.indexing.background_states[&id].source.is_none(),
        started_active
    );
    app.switch_to_tab_index(0);
    (settings, root, app, id, mailbox)
}

fn handoff_fill_reclaimer(app: &mut FlistWalkerApp, root: &Path) {
    app.shell.tabs.pause_resource_reclaimer();
    for i in 0..TAB_RESOURCE_RECLAIMER_CAPACITY {
        let mut resources = RetiredIndexBuildResources::empty();
        resources.set_stale_index_entries(vec![IndexEntry {
            path: root.join(format!("held{i}")),
            kind: EntryKind::file(),
            kind_known: true,
        }]);
        app.shell
            .tabs
            .try_retire_index_build_resources(resources)
            .unwrap_or_else(|_| panic!("fill paused reclaimer"));
    }
}

fn handoff_assert_paths(entries: &[Entry], root: &Path, count: usize) {
    assert_eq!(
        entries.iter().map(|e| e.path.clone()).collect::<Vec<_>>(),
        (0..count)
            .map(|i| root.join(format!("e{i}.txt")))
            .collect::<Vec<_>>()
    );
    assert_eq!(
        entries
            .iter()
            .map(|e| &e.path)
            .collect::<HashSet<_>>()
            .len(),
        count
    );
    assert!(entries.iter().all(|e| e.kind == Some(EntryKind::file())));
}

#[test]
fn tc_207_promoted_handoff_multiple_partial_switches_preserve_both_terminal_routes() {
    for started_active in [false, true] {
        for terminal_active in [false, true] {
            let (_settings, root, mut app, id, mailbox) = handoff_test_app(started_active);
            assert!(app.drain_queued_index_entries(id, 1));
            assert_eq!(app.shell.indexing.build.index.entries.len(), 3);
            assert_eq!(app.shell.indexing.background_states[&id].entries.len(), 4);
            assert!(app.drain_queued_index_entries(id, 1));
            assert_eq!(app.shell.indexing.build.index.entries.len(), 4);
            assert_eq!(
                app.shell.indexing.background_states[&id]
                    .entries
                    .front()
                    .unwrap()
                    .path,
                root.join("e4.txt")
            );
            app.switch_to_tab_index(1);
            mailbox
                .try_publish(handoff_test_batch(&root, id, 7..9))
                .unwrap();
            app.poll_index_response();
            assert_eq!(app.shell.indexing.background_states[&id].entries.len(), 5);
            app.switch_to_tab_index(0);
            assert!(app.drain_queued_index_entries(id, 1));
            assert_eq!(app.shell.indexing.build.index.entries.len(), 5);
            assert_eq!(app.shell.indexing.background_states.len(), 1);
            if !terminal_active {
                app.switch_to_tab_index(1);
            }
            mailbox
                .try_publish(handoff_test_batch(&root, id, 9..11))
                .unwrap();
            mailbox
                .try_publish(IndexResponse::Finished {
                    request_id: id,
                    source: IndexSource::FileList(root.join("FileList.txt")),
                })
                .unwrap();
            poll_background_index_until(&mut app, "repeated handoff finish", |app| {
                !app.shell.indexing.request_tabs.contains_key(&id)
            });
            let snapshot = if terminal_active {
                &app.shell.runtime.all_entries
            } else {
                &app.shell
                    .tabs
                    .get(0)
                    .unwrap()
                    .result_state
                    .committed
                    .all_entries
            };
            handoff_assert_paths(snapshot, &root, 11);
            let visible = if terminal_active {
                &app.shell.runtime.entries
            } else {
                &app.shell
                    .tabs
                    .get(0)
                    .unwrap()
                    .result_state
                    .committed
                    .entries
            };
            handoff_assert_paths(visible, &root, 11);
            assert!(!app.shell.indexing.background_states.contains_key(&id));
            assert!(!app.shell.indexing.inflight_requests.contains(&id));
            drop(app);
            fs::remove_dir_all(root).unwrap();
        }
    }
}

#[test]
fn tc_207_promoted_handoff_full_restores_empty_owner_and_bounds_new_mailbox_data() {
    use crate::app::index_mailbox::INDEX_MAILBOX_DATA_CAPACITY;
    for started_active in [false, true] {
        let (_settings, root, mut app, id, mailbox) = handoff_test_app(started_active);
        let original_capacity = app.shell.indexing.background_states[&id].entries.capacity();
        let original_source = app.shell.indexing.background_states[&id].source.clone();
        handoff_fill_reclaimer(&mut app, &root);
        assert!(app.drain_queued_index_entries(id, 100));
        let state = &app.shell.indexing.background_states[&id];
        assert!(state.entries.is_empty());
        assert_eq!(state.entries.capacity(), original_capacity);
        assert_eq!(state.source, original_source);
        assert!(!state.replaced);
        let owner = (
            state.entries.as_slices().0.as_ptr(),
            state.entries.capacity(),
        );
        assert!(!app.drain_queued_index_entries(id, 1));
        let state = &app.shell.indexing.background_states[&id];
        assert_eq!(
            (
                state.entries.as_slices().0.as_ptr(),
                state.entries.capacity()
            ),
            owner
        );
        for i in 0..INDEX_MAILBOX_DATA_CAPACITY {
            mailbox
                .try_publish(handoff_test_batch(&root, id, 7 + i..8 + i))
                .unwrap();
        }
        assert!(mailbox
            .try_publish(handoff_test_batch(&root, id, 99..100))
            .is_err());
        mailbox
            .try_publish(IndexResponse::Finished {
                request_id: id,
                source: IndexSource::FileList(root.join("FileList.txt")),
            })
            .unwrap();
        app.poll_index_response();
        assert_eq!(app.shell.indexing.build.index.entries.len(), 7);
        assert!(mailbox.has_terminal_response());
        // Publishing a terminal releases the producer's capacity slot; the UI
        // request/owner/terminal must still remain pending behind the handoff.
        assert!(!app.shell.indexing.inflight_requests.contains(&id));
        assert_eq!(app.shell.indexing.pending_request_id, Some(id));
        assert!(app.shell.indexing.request_tabs.contains_key(&id));
        assert!(app.shell.indexing.pending_finish.is_none());
        assert!(app
            .shell
            .runtime
            .freshness
            .as_ref()
            .is_none_or(|f| f.request_id != id));
        assert_eq!(
            app.shell.indexing.background_states[&id].source,
            original_source
        );
        app.shell.tabs.resume_resource_reclaimer();
        poll_background_index_until(&mut app, "Full handoff resume", |app| {
            !app.shell.indexing.request_tabs.contains_key(&id)
        });
        handoff_assert_paths(
            &app.shell.runtime.all_entries,
            &root,
            7 + INDEX_MAILBOX_DATA_CAPACITY,
        );
        handoff_assert_paths(
            &app.shell.runtime.entries,
            &root,
            7 + INDEX_MAILBOX_DATA_CAPACITY,
        );
        assert_eq!(
            app.shell.indexing.build.index.source,
            IndexSource::FileList(root.join("FileList.txt"))
        );
        drop(app);
        fs::remove_dir_all(root).unwrap();
    }
}

#[test]
fn tc_207_promoted_handoff_deferred_all_categories_wait_before_terminal_mutation() {
    for category in 0..7 {
        let (_settings, root, mut app, id, _mailbox) = handoff_test_app(true);
        handoff_fill_reclaimer(&mut app, &root);
        app.drain_queued_index_entries(id, 100);
        let response = match category {
            0 => IndexResponse::Started {
                request_id: id,
                source: IndexSource::FileList(root.join("FileList.txt")),
            },
            1 => IndexResponse::Truncated {
                request_id: id,
                limit: 7,
            },
            2 => handoff_test_batch(&root, id, 7..8),
            3 => IndexResponse::ReplaceAll {
                request_id: id,
                entries: vec![IndexEntry {
                    path: root.join("new.txt"),
                    kind: EntryKind::file(),
                    kind_known: true,
                }],
            },
            4 => IndexResponse::Finished {
                request_id: id,
                source: IndexSource::FileList(root.join("FileList.txt")),
            },
            5 => IndexResponse::Failed {
                request_id: id,
                error: "controlled failure".into(),
            },
            _ => IndexResponse::Canceled { request_id: id },
        };
        app.shell.indexing.deferred_response = Some(response);
        for _ in 0..2 {
            app.poll_index_response();
            assert!(
                app.shell.indexing.deferred_response.is_some(),
                "category{category}"
            );
            assert!(app.shell.indexing.inflight_requests.contains(&id));
            assert_eq!(app.shell.indexing.pending_request_id, Some(id));
            assert!(app.shell.indexing.pending_finish.is_none());
            assert!(app.shell.indexing.request_tabs.contains_key(&id));
            assert_eq!(app.shell.indexing.build.index.entries.len(), 7);
        }
        app.shell.tabs.resume_resource_reclaimer();
        poll_background_index_until(
            &mut app,
            "deferred category admitted after owner release",
            |app| app.shell.indexing.deferred_response.is_none(),
        );
        if matches!(category, 4..=6) {
            poll_background_index_until(&mut app, "deferred terminal settled", |app| {
                !app.shell.indexing.request_tabs.contains_key(&id)
            });
        }
        drop(app);
        fs::remove_dir_all(root).unwrap();
    }
}

#[test]
fn tc_207_promoted_handoff_combines_pending_and_remainder_in_fallback_budget() {
    let (_settings, root, mut app, id, mailbox) = handoff_test_app(true);
    app.switch_to_tab_index(1);
    mailbox
        .try_publish(handoff_test_batch(&root, id, 7..100))
        .unwrap();
    app.poll_index_response();
    app.switch_to_tab_index(0);
    assert!(!app.drain_queued_index_entries_with_budget(
        id,
        Instant::now(),
        Duration::ZERO,
        32_000
    ));
    assert_eq!(app.shell.indexing.build.index.entries.len(), 2);
    app.poll_index_response_with_budget_for_test(Duration::ZERO);
    assert_eq!(app.shell.indexing.build.index.entries.len(), 34);
    assert!(app.shell.indexing.build.pending_entries.is_empty());
    assert_eq!(app.shell.indexing.background_states[&id].entries.len(), 66);
    handoff_assert_paths(&app.shell.indexing.build.index.entries, &root, 34);
    app.poll_index_response_with_budget_for_test(Duration::ZERO);
    assert_eq!(app.shell.indexing.build.index.entries.len(), 66);
    assert_eq!(app.shell.indexing.background_states[&id].entries.len(), 34);
    handoff_assert_paths(&app.shell.indexing.build.index.entries, &root, 66);
    mailbox
        .try_publish(IndexResponse::Finished {
            request_id: id,
            source: IndexSource::FileList(root.join("FileList.txt")),
        })
        .unwrap();
    poll_background_index_until(&mut app, "fallback handoff terminal", |app| {
        !app.shell.indexing.request_tabs.contains_key(&id)
    });
    handoff_assert_paths(&app.shell.runtime.all_entries, &root, 100);
    drop(app);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn tc_207_promoted_handoff_full_preserves_real_warm_quota_and_stale_cleanup() {
    use crate::app::{
        index_mailbox::INDEX_MAILBOX_DATA_CAPACITY, index_response_arbitration::WARM_MAILBOX_QUOTA,
    };
    let (_settings, root, mut app, id, active_mailbox) = handoff_test_app(true);
    handoff_fill_reclaimer(&mut app, &root);
    app.drain_queued_index_entries(id, 100);
    active_mailbox
        .try_publish(handoff_test_batch(&root, id, 7..8))
        .unwrap();
    let tab_id = app.shell.tabs.get(1).unwrap().id;
    let stale_id = app.shell.indexing.allocate_request_id(Some(tab_id));
    let warm_id = app.shell.indexing.allocate_request_id(Some(tab_id));
    app.shell.indexing.inflight_requests.insert(warm_id);
    app.shell.indexing.warm_tab_id = Some(tab_id);
    {
        let tab = app.shell.tabs.get_mut(1).unwrap();
        tab.index_state.pending_index_request_id = Some(warm_id);
        tab.index_state.index_in_progress = true;
    }
    let warm_mailbox = app.shell.indexing.response_mailboxes.lock().unwrap()[&warm_id].clone();
    warm_mailbox
        .try_publish(IndexResponse::Started {
            request_id: warm_id,
            source: IndexSource::Walker,
        })
        .unwrap();
    for i in 0..INDEX_MAILBOX_DATA_CAPACITY {
        warm_mailbox
            .try_publish(handoff_test_batch(&root, warm_id, i..i + 1))
            .unwrap();
    }
    app.poll_index_response_with_budget_for_test(Duration::from_secs(1));
    assert_eq!(
        app.shell.indexing.background_states[&warm_id].entries.len(),
        WARM_MAILBOX_QUOTA - 1
    );
    assert!(warm_mailbox.has_payload());
    assert!(active_mailbox.has_payload());
    assert_eq!(app.shell.indexing.build.index.entries.len(), 7);
    assert_eq!(app.shell.indexing.pending_request_id, Some(id));
    // An actual superseded request is selected independently of both active
    // and Warm owners; its terminal must retain cleanup ownership on Full.
    app.shell.indexing.superseded_request_ids.insert(stale_id);
    app.shell.indexing.inflight_requests.insert(stale_id);
    let stale_mailbox = app.shell.indexing.response_mailboxes.lock().unwrap()[&stale_id].clone();
    stale_mailbox
        .try_publish(handoff_test_batch(&root, stale_id, 90..91))
        .unwrap();
    stale_mailbox
        .try_publish(IndexResponse::Canceled {
            request_id: stale_id,
        })
        .unwrap();
    app.poll_index_response_with_budget_for_test(Duration::from_secs(1));
    assert!(stale_mailbox.has_terminal_response());
    assert!(app.shell.indexing.pending_stale_build_reclaim.is_some());
    assert!(app.shell.indexing.request_tabs.contains_key(&stale_id));
    assert!(!app.shell.indexing.inflight_requests.contains(&stale_id));
    assert_eq!(app.shell.indexing.pending_request_id, Some(id));
    assert!(active_mailbox.has_payload());
    app.shell.tabs.resume_resource_reclaimer();
    active_mailbox
        .try_publish(IndexResponse::Finished {
            request_id: id,
            source: IndexSource::FileList(root.join("FileList.txt")),
        })
        .unwrap();
    warm_mailbox
        .try_publish(IndexResponse::Finished {
            request_id: warm_id,
            source: IndexSource::Walker,
        })
        .unwrap();
    poll_background_index_until(&mut app, "Warm and stale handoff settlement", |app| {
        [id, warm_id, stale_id]
            .iter()
            .all(|id| !app.shell.indexing.request_tabs.contains_key(id))
    });
    handoff_assert_paths(&app.shell.runtime.all_entries, &root, 8);
    handoff_assert_paths(
        &app.shell
            .tabs
            .get(1)
            .unwrap()
            .result_state
            .committed
            .all_entries,
        &root,
        INDEX_MAILBOX_DATA_CAPACITY,
    );
    assert!(!app.shell.indexing.background_states.contains_key(&stale_id));
    assert!(!app
        .shell
        .indexing
        .superseded_request_ids
        .contains(&stale_id));
    drop(app);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn tc_207_promoted_handoff_replace_all_full_restores_old_owner_then_exact_new_order() {
    let (_settings, root, mut app, id, mailbox) = handoff_test_app(true);
    app.drain_queued_index_entries(id, 100);
    let deadline = Instant::now() + Duration::from_secs(5);
    while app.shell.tabs.reclaimer_pending() != 0 {
        assert!(Instant::now() < deadline);
        thread::yield_now();
    }
    handoff_fill_reclaimer(&mut app, &root);
    let old_owner = (
        app.shell.indexing.build.index.entries.as_ptr(),
        app.shell.indexing.build.index.entries.capacity(),
    );
    let entries = match handoff_test_batch(&root, id, 100..102) {
        IndexResponse::Batch { entries, .. } => entries,
        _ => unreachable!(),
    };
    mailbox
        .try_publish(IndexResponse::ReplaceAll {
            request_id: id,
            entries,
        })
        .unwrap();
    mailbox
        .try_publish(handoff_test_batch(&root, id, 102..103))
        .unwrap();
    mailbox
        .try_publish(IndexResponse::Finished {
            request_id: id,
            source: IndexSource::FileList(root.join("FileList.txt")),
        })
        .unwrap();
    app.poll_index_response();
    assert!(app.shell.indexing.pending_replace_all.is_some());
    assert_eq!(
        (
            app.shell.indexing.build.index.entries.as_ptr(),
            app.shell.indexing.build.index.entries.capacity()
        ),
        old_owner
    );
    handoff_assert_paths(&app.shell.indexing.build.index.entries, &root, 7);
    assert!(app
        .shell
        .runtime
        .freshness
        .as_ref()
        .is_none_or(|f| f.request_id != id));
    app.shell.tabs.resume_resource_reclaimer();
    poll_background_index_until(&mut app, "replacement Full settlement", |app| {
        !app.shell.indexing.request_tabs.contains_key(&id)
    });
    let expected = (100..103)
        .map(|i| root.join(format!("e{i}.txt")))
        .collect::<Vec<_>>();
    assert_eq!(
        app.shell
            .runtime
            .all_entries
            .iter()
            .map(|e| e.path.clone())
            .collect::<Vec<_>>(),
        expected
    );
    assert_eq!(
        app.shell
            .runtime
            .entries
            .iter()
            .map(|e| e.path.clone())
            .collect::<Vec<_>>(),
        expected
    );
    assert!(app.shell.runtime.all_entries.iter().all(|e| !e
        .path
        .file_name()
        .unwrap()
        .to_string_lossy()
        .starts_with("e0.")));
    drop(app);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn tc_207_promoted_handoff_background_replace_all_marker_survives_repeated_switches() {
    for started_active in [false, true] {
        let (_settings, root, mut app, id, mailbox) = handoff_test_app(started_active);
        app.drain_queued_index_entries(id, 1);
        app.switch_to_tab_index(1);
        let entries = match handoff_test_batch(&root, id, 100..102) {
            IndexResponse::Batch { entries, .. } => entries,
            _ => unreachable!(),
        };
        mailbox
            .try_publish(IndexResponse::ReplaceAll {
                request_id: id,
                entries,
            })
            .unwrap();
        app.poll_index_response();
        assert!(app.shell.indexing.background_states[&id].replaced);
        app.switch_to_tab_index(0);
        assert!(app.drain_queued_index_entries(id, 1));
        assert!(!app.shell.indexing.background_states[&id].replaced);
        assert_eq!(app.shell.indexing.build.index.entries.len(), 1);
        assert_eq!(
            app.shell.indexing.build.index.entries[0].path,
            root.join("e100.txt")
        );
        app.switch_to_tab_index(1);
        mailbox
            .try_publish(handoff_test_batch(&root, id, 102..103))
            .unwrap();
        app.poll_index_response();
        app.switch_to_tab_index(0);
        assert!(app.drain_queued_index_entries(id, 1));
        assert_eq!(
            app.shell.indexing.build.index.entries[1].path,
            root.join("e101.txt")
        );
        mailbox
            .try_publish(IndexResponse::Finished {
                request_id: id,
                source: IndexSource::FileList(root.join("FileList.txt")),
            })
            .unwrap();
        poll_background_index_until(&mut app, "background replacement handoff", |app| {
            !app.shell.indexing.request_tabs.contains_key(&id)
        });
        let expected = (100..103)
            .map(|i| root.join(format!("e{i}.txt")))
            .collect::<Vec<_>>();
        assert_eq!(
            app.shell
                .runtime
                .all_entries
                .iter()
                .map(|e| e.path.clone())
                .collect::<Vec<_>>(),
            expected
        );
        assert_eq!(
            app.shell
                .runtime
                .entries
                .iter()
                .map(|e| e.path.clone())
                .collect::<Vec<_>>(),
            expected
        );
        drop(app);
        fs::remove_dir_all(root).unwrap();
    }
}

#[test]
fn tc_207_promoted_handoff_restored_replace_marker_full_is_transactional() {
    let (_settings, root, mut app, id, mailbox) = handoff_test_app(true);
    // Model a restored replacement owner coexisting with the old active build
    // and pending prefix. Admission must retire both before the first new entry.
    let state = app.shell.indexing.background_states.get_mut(&id).unwrap();
    state.entries = (100..102)
        .map(|i| file_entry(root.join(format!("e{i}.txt"))))
        .collect();
    state.replaced = true;
    let replacement_owner = (
        state.entries.as_slices().0.as_ptr(),
        state.entries.capacity(),
        state.source.clone(),
    );
    let build_owner = (
        app.shell.indexing.build.index.entries.as_ptr(),
        app.shell.indexing.build.index.entries.capacity(),
    );
    let pending_owner = (
        app.shell
            .indexing
            .build
            .pending_entries
            .as_slices()
            .0
            .as_ptr(),
        app.shell.indexing.build.pending_entries.capacity(),
    );
    let source = app.shell.indexing.build.index.source.clone();
    handoff_fill_reclaimer(&mut app, &root);
    assert!(!app.drain_queued_index_entries(id, 1));
    assert_eq!(
        (
            app.shell.indexing.build.index.entries.as_ptr(),
            app.shell.indexing.build.index.entries.capacity()
        ),
        build_owner
    );
    assert_eq!(
        (
            app.shell
                .indexing
                .build
                .pending_entries
                .as_slices()
                .0
                .as_ptr(),
            app.shell.indexing.build.pending_entries.capacity()
        ),
        pending_owner
    );
    assert_eq!(app.shell.indexing.pending_entries_request_id, Some(id));
    handoff_assert_paths(&app.shell.indexing.build.index.entries, &root, 2);
    assert_eq!(
        app.shell
            .indexing
            .build
            .pending_entries
            .front()
            .unwrap()
            .path,
        root.join("e2.txt")
    );
    let state = &app.shell.indexing.background_states[&id];
    assert_eq!(
        (
            state.entries.as_slices().0.as_ptr(),
            state.entries.capacity(),
            state.source.clone()
        ),
        replacement_owner
    );
    assert!(state.replaced);
    assert_eq!(state.entries.front().unwrap().path, root.join("e100.txt"));
    assert_eq!(app.shell.indexing.build.index.source, source);
    app.shell.tabs.resume_resource_reclaimer();
    poll_background_index_until(&mut app, "replacement marker first ordered entry", |app| {
        app.shell
            .indexing
            .build
            .index
            .entries
            .first()
            .is_some_and(|e| e.path == root.join("e100.txt"))
    });
    mailbox
        .try_publish(handoff_test_batch(&root, id, 102..103))
        .unwrap();
    mailbox
        .try_publish(IndexResponse::Finished {
            request_id: id,
            source: IndexSource::FileList(root.join("FileList.txt")),
        })
        .unwrap();
    poll_background_index_until(&mut app, "restored replacement marker finish", |app| {
        !app.shell.indexing.request_tabs.contains_key(&id)
    });
    let expected = (100..103)
        .map(|i| root.join(format!("e{i}.txt")))
        .collect::<Vec<_>>();
    assert_eq!(
        app.shell
            .runtime
            .all_entries
            .iter()
            .map(|e| e.path.clone())
            .collect::<Vec<_>>(),
        expected
    );
    assert_eq!(
        app.shell
            .runtime
            .entries
            .iter()
            .map(|e| e.path.clone())
            .collect::<Vec<_>>(),
        expected
    );
    assert_eq!(app.shell.indexing.build.index.source, source);
    drop(app);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn tc_207_promoted_handoff_real_refresh_full_restores_then_retires_old_request() {
    let (_settings, root, mut app, id, mailbox) = handoff_test_app(true);
    let state = &app.shell.indexing.background_states[&id];
    let owner = (
        state.entries.as_slices().0.as_ptr(),
        state.entries.capacity(),
        state.source.clone(),
    );
    let build_owner = (
        app.shell.indexing.build.index.entries.as_ptr(),
        app.shell.indexing.build.index.entries.capacity(),
    );
    handoff_fill_reclaimer(&mut app, &root);
    app.request_index_refresh();
    assert_eq!(app.shell.indexing.pending_request_id, Some(id));
    assert!(!app.shell.indexing.is_superseded_request(id));
    assert!(app.shell.indexing.build_reclaim_pending);
    assert_eq!(app.shell.indexing.build_reclaim_request_id, Some(id));
    assert!(app.shell.indexing.refresh_after_pending_finish.is_some());
    assert_eq!(
        (
            app.shell.indexing.build.index.entries.as_ptr(),
            app.shell.indexing.build.index.entries.capacity()
        ),
        build_owner
    );
    let state = &app.shell.indexing.background_states[&id];
    assert_eq!(
        (
            state.entries.as_slices().0.as_ptr(),
            state.entries.capacity(),
            state.source.clone()
        ),
        owner
    );
    assert_eq!(
        state
            .entries
            .iter()
            .map(|e| e.path.clone())
            .collect::<Vec<_>>(),
        (3..7)
            .map(|i| root.join(format!("e{i}.txt")))
            .collect::<Vec<_>>()
    );
    let replacement_id = app.shell.indexing.next_request_id;
    app.shell.tabs.resume_resource_reclaimer();
    poll_background_index_until(&mut app, "real replacement request committed", |app| {
        let committed = app
            .shell
            .runtime
            .freshness
            .as_ref()
            .is_some_and(|f| f.request_id == replacement_id)
            && app.shell.indexing.pending_request_id.is_none();
        if !committed {
            // Real FileList I/O needs elapsed scheduling time, not just busy yields.
            // The shared five-second deadline and 4096-frame cap remain in force.
            thread::sleep(Duration::from_millis(1));
        }
        committed
    });
    assert_eq!(app.shell.indexing.next_request_id, replacement_id + 1);
    let freshness = app.shell.runtime.freshness.as_ref().unwrap();
    assert_eq!(freshness.root, root);
    assert_eq!(
        app.shell.indexing.build.index.source,
        IndexSource::FileList(root.join("FileList.txt").canonicalize().unwrap())
    );
    assert!(!app.shell.indexing.request_tabs.contains_key(&id));
    assert!(!app.shell.indexing.background_states.contains_key(&id));
    assert!(!app.shell.indexing.inflight_requests.contains(&id));
    assert!(app.shell.runtime.all_entries.is_empty());
    assert!(mailbox
        .try_publish(IndexResponse::Canceled { request_id: id })
        .is_err());
    drop(app);
    fs::remove_dir_all(root).unwrap();
}

fn collect_drop_threads_until(
    drop_rx: &mpsc::Receiver<String>,
    expected: &str,
    timeout: Duration,
) -> Vec<String> {
    let deadline = Instant::now() + timeout;
    let mut threads = drop_rx.try_iter().collect::<Vec<_>>();
    while !threads.iter().any(|name| name == expected) {
        let remaining = deadline.saturating_duration_since(Instant::now());
        if remaining.is_zero() {
            break;
        }
        match drop_rx.recv_timeout(remaining) {
            Ok(name) => threads.push(name),
            Err(_) => break,
        }
    }
    threads
}

pub(super) fn poll_background_index_until(
    app: &mut FlistWalkerApp,
    description: &str,
    mut settled: impl FnMut(&FlistWalkerApp) -> bool,
) {
    const MAX_FRAMES: usize = 4_096;
    let deadline = Instant::now() + Duration::from_secs(5);
    for _ in 0..MAX_FRAMES {
        if settled(app) {
            return;
        }
        assert!(
            Instant::now() < deadline,
            "background index did not reach {description} within five seconds"
        );
        app.poll_index_response();
        thread::yield_now();
    }
    assert!(
        settled(app),
        "background index did not reach {description} within {MAX_FRAMES} frames"
    );
}

fn receive_after_background_index_progress<T>(
    app: &mut FlistWalkerApp,
    receiver: &mpsc::Receiver<T>,
    description: &str,
) -> T {
    let mut received = None;
    poll_background_index_until(app, description, |_| match receiver.try_recv() {
        Ok(request) => {
            received = Some(request);
            true
        }
        Err(mpsc::TryRecvError::Empty) => false,
        Err(mpsc::TryRecvError::Disconnected) => {
            panic!("{description}: request channel disconnected")
        }
    });
    received.expect("background index request was received")
}

const BACKGROUND_FINALIZATION_FRAME_LIMIT: usize = 2_000;
const BACKGROUND_FINALIZATION_STALL_LIMIT: usize = 32;

#[derive(Clone, Copy, Debug, Eq, PartialEq, serde::Serialize)]
struct BackgroundFinalizationProgress {
    initial_remaining: usize,
    pending_remaining: usize,
    continuation_remaining: usize,
    completed: usize,
    filter_cursor: usize,
    filtered: usize,
    kind_cursor: usize,
    unresolved_kinds: usize,
    scratch_reclaimed: bool,
}

#[derive(Clone, Debug)]
struct BackgroundFinalizationFrame {
    elapsed: Duration,
    cpu: Option<Duration>,
    measurement_overhead: Duration,
    before: Option<BackgroundFinalizationProgress>,
    after: Option<BackgroundFinalizationProgress>,
}

impl BackgroundFinalizationFrame {
    fn timing(&self) -> super::finalization_timing::FrameTiming {
        super::finalization_timing::FrameTiming {
            wall: self.elapsed,
            cpu: self.cpu,
            measurement_overhead: self.measurement_overhead,
        }
    }
}

fn assert_finalization_frame_budget(
    request_id: u64,
    ordinal: usize,
    frame: &BackgroundFinalizationFrame,
) {
    assert!(frame.elapsed < Duration::from_millis(100),
        "background finalization frame exceeded 100ms: request_id={request_id}, frame={ordinal}, wall={:?}, thread_cpu={:?}, off_cpu_lower_bound={:?}, measurement_overhead={:?}, before={:?}, after={:?}",
        frame.elapsed, frame.cpu, frame.timing().off_cpu_lower_bound(), frame.measurement_overhead, frame.before, frame.after);
}

#[test]
fn tc_207_wall_budget_remains_enforced_when_thread_cpu_is_low() {
    let frame = BackgroundFinalizationFrame {
        elapsed: Duration::from_millis(101),
        cpu: Some(Duration::from_millis(1)),
        measurement_overhead: Duration::from_micros(2),
        before: None,
        after: None,
    };
    let failure = std::panic::catch_unwind(|| assert_finalization_frame_budget(77, 3, &frame));
    let error = failure.expect_err("scheduling delay must not bypass the wall-clock gate");
    let message = error.downcast_ref::<String>().unwrap();
    for diagnostic in [
        "request_id=77",
        "frame=3",
        "wall=",
        "thread_cpu=",
        "off_cpu_lower_bound=",
        "measurement_overhead=",
        "before=",
        "after=",
    ] {
        assert!(
            message.contains(diagnostic),
            "missing {diagnostic}: {message}"
        );
    }
}

#[derive(Clone, Copy)]
enum BackgroundFinalizationTarget {
    Removed,
    FilterCursorAtLeast(usize),
    TabFinishSettled,
}

fn background_finalization_progress(
    app: &FlistWalkerApp,
    request_id: u64,
) -> Option<BackgroundFinalizationProgress> {
    app.shell
        .indexing
        .background_finalizations
        .get(&request_id)
        .map(|state| BackgroundFinalizationProgress {
            initial_remaining: state.initial_entries.len(),
            pending_remaining: state.pending_entries.len(),
            continuation_remaining: state.continuation_entries.len(),
            completed: state.completed_entries.len(),
            filter_cursor: state.filter_cursor,
            filtered: state.filtered_entries.as_ref().map_or(0, Vec::len),
            kind_cursor: state.kind_cursor,
            unresolved_kinds: state.unresolved_kind_paths.len(),
            scratch_reclaimed: state.scratch_reclaimed,
        })
}

fn background_finalization_target_reached(
    app: &FlistWalkerApp,
    tab_index: usize,
    request_id: u64,
    target: BackgroundFinalizationTarget,
) -> bool {
    match target {
        BackgroundFinalizationTarget::Removed => !app
            .shell
            .indexing
            .background_finalizations
            .contains_key(&request_id),
        BackgroundFinalizationTarget::FilterCursorAtLeast(minimum) => app
            .shell
            .indexing
            .background_finalizations
            .get(&request_id)
            .is_some_and(|state| state.filter_cursor >= minimum),
        BackgroundFinalizationTarget::TabFinishSettled => app
            .shell
            .tabs
            .get(tab_index)
            .is_some_and(|tab| tab.index_state.pending_index_finish.is_none()),
    }
}

fn assert_background_finalization_progress(
    request_id: u64,
    frame: usize,
    consecutive_stalled_frames: usize,
    before: Option<BackgroundFinalizationProgress>,
) {
    assert!(
        consecutive_stalled_frames <= BACKGROUND_FINALIZATION_STALL_LIMIT,
        "background finalization stalled: request_id={request_id}, frame={frame}, consecutive_stalled_frames={consecutive_stalled_frames}, progress={before:?}"
    );
}

fn emit_finalization_frames(
    request_id: u64,
    frames: &[BackgroundFinalizationFrame],
    trace: bool,
    control: Option<&str>,
) {
    let worst_wall = frames
        .iter()
        .enumerate()
        .max_by_key(|(_, f)| f.elapsed)
        .map(|(i, _)| i);
    let worst_cpu = frames
        .iter()
        .enumerate()
        .max_by_key(|(_, f)| f.cpu)
        .map(|(i, _)| i);
    let worst_off_cpu = frames
        .iter()
        .enumerate()
        .max_by_key(|(_, f)| f.timing().off_cpu_lower_bound())
        .map(|(i, _)| i);
    for (ordinal, frame) in frames.iter().enumerate() {
        if trace
            || Some(ordinal) == worst_wall
            || Some(ordinal) == worst_cpu
            || Some(ordinal) == worst_off_cpu
        {
            let timing = frame.timing();
            eprintln!(
                "TC207_FRAME {}",
                serde_json::json!({
                    "schema": 1, "pid": std::process::id(),
                    "test": thread::current().name(), "request_id": request_id,
                    "frame": ordinal, "frames_observed": frames.len(),
                    "wall_ns": frame.elapsed.as_nanos(),
                    "cpu_upper_ns": frame.cpu.map(|d| d.as_nanos()),
                    "cpu_lower_ns": timing.cpu_lower_bound().map(|d| d.as_nanos()),
                    "off_cpu_lower_ns": timing.off_cpu_lower_bound().map(|d| d.as_nanos()),
                    "measurement_overhead_ns": frame.measurement_overhead.as_nanos(),
                    "wall_under_100ms": frame.elapsed < Duration::from_millis(100),
                    "before": frame.before, "after": frame.after,
                    "control": if ordinal == 0 { control } else { None },
                })
            );
        }
    }
}

fn drive_background_finalization_with_frame_budget(
    app: &mut FlistWalkerApp,
    tab_index: usize,
    request_id: u64,
    source: IndexSource,
    target: BackgroundFinalizationTarget,
) -> Vec<BackgroundFinalizationFrame> {
    let mut frames = Vec::new();
    let mut consecutive_stalled_frames = 0usize;
    let trace = std::env::var_os("FLISTWALKER_TEST_TC207_TRACE").is_some();
    let control = std::env::var("FLISTWALKER_TEST_TC207_CONTROL").ok();
    assert!(
        control.is_none() || trace,
        "diagnostic controls require raw tracing"
    );
    for frame in 0..BACKGROUND_FINALIZATION_FRAME_LIMIT {
        if background_finalization_target_reached(app, tab_index, request_id, target) {
            emit_finalization_frames(request_id, &frames, trace, control.as_deref());
            return frames;
        }
        let before = background_finalization_progress(app, request_id);
        let timing = super::finalization_timing::measure(|| {
            if frame == 0 {
                if let Some(control) = control.as_deref() {
                    super::finalization_timing::diagnostic_control(control);
                }
            }
            app.handle_background_index_response(
                tab_index,
                IndexResponse::Finished {
                    request_id,
                    source: source.clone(),
                },
            );
        });
        let after = background_finalization_progress(app, request_id);
        let observation = BackgroundFinalizationFrame {
            elapsed: timing.wall,
            cpu: timing.cpu,
            measurement_overhead: timing.measurement_overhead,
            before,
            after,
        };
        frames.push(observation);
        let observation = frames.last().unwrap();
        if observation.elapsed >= Duration::from_millis(100) {
            emit_finalization_frames(request_id, &frames, trace, control.as_deref());
        }
        assert_finalization_frame_budget(request_id, frame, observation);
        if !background_finalization_target_reached(app, tab_index, request_id, target) {
            consecutive_stalled_frames = if before == after {
                consecutive_stalled_frames.saturating_add(1)
            } else {
                0
            };
            assert_background_finalization_progress(
                request_id,
                frame,
                consecutive_stalled_frames,
                before,
            );
        }
    }
    panic!(
        "background finalization exceeded frame bound: request_id={request_id}, tab_index={tab_index}, frames={BACKGROUND_FINALIZATION_FRAME_LIMIT}, progress={:?}",
        background_finalization_progress(app, request_id)
    );
}

fn settle_background_finish_with_frame_budget(
    app: &mut FlistWalkerApp,
    tab_index: usize,
    request_id: u64,
    source: IndexSource,
) -> Vec<Duration> {
    drive_background_finalization_with_frame_budget(
        app,
        tab_index,
        request_id,
        source,
        BackgroundFinalizationTarget::TabFinishSettled,
    )
    .into_iter()
    .map(|frame| frame.elapsed)
    .collect()
}

#[test]
fn tc_207_stalled_background_finalization_guard_fails_deterministically_regression() {
    let stalled = BackgroundFinalizationProgress {
        initial_remaining: 10,
        pending_remaining: 0,
        continuation_remaining: 0,
        completed: 0,
        filter_cursor: 0,
        filtered: 0,
        kind_cursor: 0,
        unresolved_kinds: 0,
        scratch_reclaimed: false,
    };
    let failure = std::panic::catch_unwind(|| {
        assert_background_finalization_progress(
            207,
            BACKGROUND_FINALIZATION_STALL_LIMIT,
            BACKGROUND_FINALIZATION_STALL_LIMIT + 1,
            Some(stalled),
        );
    });
    assert!(failure.is_err());
}

#[test]
fn background_tab_search_and_preview_responses_are_retained() {
    let root = test_root("background-tab-search-preview");
    fs::create_dir_all(&root).expect("create dir");
    let selected = root.join("picked.txt");
    fs::write(&selected, "hello").expect("write file");
    let mut app = FlistWalkerApp::new(root.clone(), 50, "picked".to_string());
    app.shell.indexing.in_progress = false;
    app.shell.indexing.pending_request_id = None;
    app.shell.runtime.committed_for_test_mut().entries =
        Arc::new(vec![file_entry(selected.clone())]);
    app.shell.runtime.committed_for_test_mut().results = vec![(selected.clone(), 0.0)];
    app.shell.runtime.committed_for_test_mut().current_row = Some(0);
    app.set_entry_kind(&selected, EntryKind::file());

    let (search_tx_req, _search_rx_req) = mpsc::channel::<SearchRequest>();
    let (search_tx_res, search_rx_res) = mpsc::channel::<SearchResponse>();
    app.shell.search.tx = search_tx_req;
    app.shell.search.rx = search_rx_res;
    app.enqueue_search_request();
    let search_request_id = app
        .shell
        .search
        .pending_request_id()
        .expect("search request id");
    let first_tab_id = app.shell.tabs.get(0).expect("tab 0").id;

    let (preview_tx_req, _preview_rx_req) = mpsc::channel::<PreviewRequest>();
    let (preview_tx_res, preview_rx_res) = mpsc::channel::<PreviewResponse>();
    app.shell.worker_bus.preview.tx = preview_tx_req;
    app.shell.worker_bus.preview.worker_inflight_request_id = None;
    app.shell.worker_bus.preview.rx = preview_rx_res;
    app.request_preview_for_current();
    let preview_request_id = app
        .shell
        .worker_bus
        .preview
        .pending_request_id
        .expect("preview request id");

    app.create_new_tab();
    assert_eq!(app.shell.tabs.active_tab, 1);

    search_tx_res
        .send(SearchResponse {
            request_id: search_request_id,
            results: vec![(selected.clone(), 9.0)],
            total_match_count: 1,
            sort_mode: ResultSortMode::Score,
            sort_scope: ResultSortScope::ShownResults,
            error: None,
        })
        .expect("send search response");
    preview_tx_res
        .send(PreviewResponse {
            canceled: false,
            request_id: preview_request_id,
            path: selected.clone(),
            preview: "preview-body".to_string(),
            document: None,
            page_error: None,
            is_more: false,
        })
        .expect("send preview response");
    app.poll_search_response();
    app.poll_preview_response();

    let first_tab = app
        .shell
        .tabs
        .iter()
        .find(|tab| tab.id == first_tab_id)
        .expect("first tab");
    assert_eq!(first_tab.result_state.committed.results.len(), 1);
    assert!(!first_tab.result_state.results_compacted);
    assert_eq!(first_tab.result_state.committed.base_results.len(), 1);
    assert_eq!(first_tab.result_state.committed.base_results[0].0, selected);
    assert_eq!(first_tab.result_state.committed.preview, "preview-body");
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn background_search_selection_change_invalidates_old_preview_and_reloads_on_activation_regression()
{
    let root = test_root("background-search-preview-ownership");
    fs::create_dir_all(&root).expect("create dir");
    let old_path = root.join("old.txt");
    let new_path = root.join("new.txt");
    fs::write(&old_path, "old").expect("write old");
    fs::write(&new_path, "new").expect("write new");
    let mut app = FlistWalkerApp::new(root.clone(), 50, "new".to_string());
    app.shell.indexing.in_progress = false;
    app.shell.indexing.pending_request_id = None;
    app.shell.runtime.committed_for_test_mut().entries = Arc::new(vec![
        file_entry(old_path.clone()),
        file_entry(new_path.clone()),
    ]);
    app.shell.runtime.committed_for_test_mut().results = vec![(old_path.clone(), 1.0)];
    app.shell.runtime.committed_for_test_mut().base_results = app.shell.runtime.results.clone();
    app.shell.runtime.committed_for_test_mut().current_row = Some(0);
    app.set_entry_kind(&old_path, EntryKind::file());
    app.set_entry_kind(&new_path, EntryKind::file());
    let (preview_tx, preview_rx) = mpsc::channel::<PreviewRequest>();
    app.shell.worker_bus.preview.tx = preview_tx;
    app.shell.worker_bus.preview.worker_inflight_request_id = None;
    app.request_preview_for_current();
    let old_request = preview_rx.try_recv().expect("old preview request");
    let background_tab_id = app.current_tab_id().expect("background tab id");

    app.create_new_tab();
    while preview_rx.try_recv().is_ok() {}
    app.apply_background_search_response(
        background_tab_id,
        SearchResponse {
            request_id: 91,
            results: vec![(new_path.clone(), 9.0)],
            total_match_count: 1,
            sort_mode: ResultSortMode::Score,
            sort_scope: ResultSortScope::ShownResults,
            error: None,
        },
    );

    let background = app.shell.tabs.get(0).expect("background tab");
    assert!(background.result_state.committed.preview.is_empty());
    assert!(background.pending_preview_request_id.is_none());
    assert!(background.preview_reload_pending);
    assert_eq!(app.preview_request_tab(old_request.request_id), None);
    app.apply_background_preview_response(PreviewResponse {
        canceled: false,
        request_id: old_request.request_id,
        path: old_path,
        preview: "late old preview".to_string(),
        document: None,
        page_error: None,
        is_more: false,
    });
    app.shell
        .tabs
        .get_mut(0)
        .expect("background tab")
        .index_state
        .build
        .entry_kind_cache
        .set(new_path.clone(), EntryKind::file());

    app.switch_to_tab_index(0);
    let activated_requests = preview_rx.try_iter().collect::<Vec<_>>();
    assert!(
        activated_requests
            .iter()
            .any(|request| request.path == new_path),
        "activation must request the background tab's new selected path; results={:?}, preview={}",
        app.shell.runtime.results,
        app.shell.runtime.preview
    );
    assert_eq!(app.shell.runtime.preview, "Loading preview...");
    assert!(
        !app.shell
            .tabs
            .get(0)
            .expect("activated tab slot")
            .preview_reload_pending
    );

    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tab_activation_without_background_selection_change_does_not_request_preview_regression() {
    let root = test_root("tab-activation-preview-noop");
    fs::create_dir_all(&root).expect("create dir");
    let selected = root.join("selected.txt");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.shell.indexing.in_progress = false;
    app.shell.indexing.pending_request_id = None;
    app.shell.runtime.committed_for_test_mut().entries =
        Arc::new(vec![file_entry(selected.clone())]);
    app.shell.runtime.committed_for_test_mut().results = vec![(selected.clone(), 1.0)];
    app.shell.runtime.committed_for_test_mut().base_results = app.shell.runtime.results.clone();
    app.shell.runtime.committed_for_test_mut().current_row = Some(0);
    app.set_entry_kind(&selected, EntryKind::file());
    // Keep this fixture non-compacting so it isolates activation from the
    // separate result-restoration path, which intentionally refreshes preview.
    app.shell.search.set_pending_request_id(Some(801));
    app.shell.search.set_in_progress(true);
    let (preview_tx, preview_rx) = mpsc::channel::<PreviewRequest>();
    app.shell.worker_bus.preview.tx = preview_tx;
    app.shell.worker_bus.preview.worker_inflight_request_id = None;

    app.create_new_tab();
    let create_requests = preview_rx
        .try_iter()
        .map(|request| request.path)
        .collect::<Vec<_>>();
    assert!(
        create_requests.is_empty(),
        "ordinary tab creation must not request preview: {create_requests:?}"
    );
    assert!(
        !app.shell
            .tabs
            .get(0)
            .expect("ordinary background tab")
            .preview_reload_pending
    );
    app.switch_to_tab_index(0);

    let unexpected = preview_rx
        .try_iter()
        .map(|request| request.path)
        .collect::<Vec<_>>();
    assert!(
        unexpected.is_empty(),
        "ordinary activation must not request preview: {unexpected:?}"
    );
    assert!(app.shell.runtime.preview.is_empty());
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn sizedesc_inactive_completed_preview_roundtrips_via_explicit_reload_regression() {
    let root = test_root("sizedesc-preview-roundtrip");
    fs::create_dir_all(&root).expect("create dir");
    let selected = root.join("selected.txt");
    fs::write(&selected, "selected").expect("write fixture");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.shell.indexing.in_progress = false;
    app.shell.indexing.pending_request_id = None;
    app.shell.runtime.committed_for_test_mut().entries =
        Arc::new(vec![file_entry(selected.clone())]);
    app.shell.runtime.committed_for_test_mut().base_results = vec![(selected.clone(), 1.0)];
    app.shell.runtime.committed_for_test_mut().results = app.shell.runtime.base_results.clone();
    app.shell.runtime.committed_for_test_mut().current_row = Some(0);
    app.shell.runtime.result_sort_mode = ResultSortMode::SizeDesc;
    app.shell.runtime.committed_for_test_mut().preview = "completed preview".to_string();
    app.set_entry_kind(&selected, EntryKind::file());
    let (preview_tx, preview_rx) = mpsc::channel::<PreviewRequest>();
    app.shell.worker_bus.preview.tx = preview_tx;
    app.shell.worker_bus.preview.worker_inflight_request_id = None;

    app.create_new_tab();
    let background = app.shell.tabs.get(0).expect("background tab");
    assert!(!background.result_state.results_compacted);
    assert!(background.result_state.committed.preview.is_empty());
    assert!(background.preview_reload_pending);
    while preview_rx.try_recv().is_ok() {}

    app.switch_to_tab_index(0);
    assert_eq!(
        preview_rx
            .try_recv()
            .expect("activation preview reload")
            .path,
        selected
    );
    assert!(
        !app.shell
            .tabs
            .get(0)
            .expect("active tab")
            .preview_reload_pending
    );
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn background_none_to_some_selection_rejects_late_preview_and_reloads_regression() {
    let root = test_root("background-none-some-preview");
    fs::create_dir_all(&root).expect("create dir");
    let selected = root.join("selected.txt");
    fs::write(&selected, "selected").expect("write fixture");
    let mut app = FlistWalkerApp::new(root.clone(), 50, "selected".to_string());
    app.shell.indexing.in_progress = false;
    app.shell.indexing.pending_request_id = None;
    app.shell.runtime.committed_for_test_mut().entries =
        Arc::new(vec![file_entry(selected.clone())]);
    app.shell.runtime.committed_for_test_mut().results.clear();
    app.shell
        .runtime
        .committed_for_test_mut()
        .base_results
        .clear();
    app.shell.runtime.committed_for_test_mut().current_row = None;
    let background_tab_id = app.current_tab_id().expect("background tab id");
    app.shell.worker_bus.preview.pending_request_id = Some(711);
    app.shell.worker_bus.preview.in_progress = true;
    app.bind_preview_request_to_tab(711, background_tab_id);

    app.create_new_tab();
    app.apply_background_search_response(
        background_tab_id,
        SearchResponse {
            request_id: 712,
            results: vec![(selected.clone(), 9.0)],
            total_match_count: 1,
            sort_mode: ResultSortMode::Score,
            sort_scope: ResultSortScope::ShownResults,
            error: None,
        },
    );
    let background = app.shell.tabs.get(0).expect("background tab");
    assert!(background.preview_reload_pending);
    assert!(background.pending_preview_request_id.is_none());
    assert_eq!(app.preview_request_tab(711), None);
    app.apply_background_preview_response(PreviewResponse {
        canceled: false,
        request_id: 711,
        path: selected.clone(),
        preview: "late preview".to_string(),
        document: None,
        page_error: None,
        is_more: false,
    });
    assert!(app
        .shell
        .tabs
        .get(0)
        .expect("background tab")
        .result_state
        .committed
        .preview
        .is_empty());

    app.shell
        .tabs
        .get_mut(0)
        .expect("background tab")
        .index_state
        .build
        .entry_kind_cache
        .set(selected.clone(), EntryKind::file());
    let (preview_tx, preview_rx) = mpsc::channel::<PreviewRequest>();
    app.shell.worker_bus.preview.tx = preview_tx;
    app.shell.worker_bus.preview.worker_inflight_request_id = None;
    app.switch_to_tab_index(0);
    assert_eq!(
        preview_rx
            .try_recv()
            .expect("activation preview request")
            .path,
        selected
    );
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn background_sort_reorder_invalidates_old_preview_request_regression() {
    let root = test_root("background-sort-preview-ownership");
    fs::create_dir_all(&root).expect("create dir");
    let old_path = root.join("old.txt");
    let new_path = root.join("new.txt");
    let mut app = FlistWalkerApp::new(root.clone(), 50, "item".to_string());
    app.shell.indexing.in_progress = false;
    app.shell.indexing.pending_request_id = None;
    app.shell.runtime.committed_for_test_mut().base_results =
        vec![(old_path.clone(), 2.0), (new_path.clone(), 1.0)];
    app.shell.runtime.committed_for_test_mut().results = app.shell.runtime.base_results.clone();
    app.shell.runtime.committed_for_test_mut().current_row = Some(0);
    app.shell.runtime.committed_for_test_mut().preview = "old preview".to_string();
    app.shell.runtime.result_sort_mode = ResultSortMode::SizeDesc;
    app.shell.worker_bus.sort.pending_request_id = Some(93);
    app.shell.worker_bus.sort.in_progress = true;
    app.shell.worker_bus.preview.pending_request_id = Some(94);
    app.shell.worker_bus.preview.in_progress = true;
    let background_tab_id = app.current_tab_id().expect("background tab id");
    app.bind_sort_request_to_tab(93, background_tab_id);
    app.bind_preview_request_to_tab(94, background_tab_id);
    app.cache_sort_metadata(
        old_path.clone(),
        SortMetadata {
            size_bytes: Some(1),
            ..SortMetadata::default()
        },
    );
    app.cache_sort_metadata(
        new_path.clone(),
        SortMetadata {
            size_bytes: Some(2),
            ..SortMetadata::default()
        },
    );

    app.create_new_tab();
    app.apply_background_sort_response(SortMetadataResponse {
        request_id: 93,
        entries: Vec::new(),
        mode: ResultSortMode::SizeDesc,
    });

    let background = app.shell.tabs.get(0).expect("background tab");
    assert_eq!(
        background.result_state.committed.base_results[0].0,
        old_path
    );
    assert_eq!(background.result_state.committed.results[0].0, new_path);
    assert!(background.result_state.committed.preview.is_empty());
    assert!(background.pending_preview_request_id.is_none());
    assert!(background.preview_reload_pending);
    assert_eq!(app.preview_request_tab(94), None);

    app.shell
        .tabs
        .get_mut(0)
        .expect("background tab")
        .index_state
        .build
        .entry_kind_cache
        .set(new_path.clone(), EntryKind::file());
    let (preview_tx, preview_rx) = mpsc::channel::<PreviewRequest>();
    app.shell.worker_bus.preview.tx = preview_tx;
    app.shell.worker_bus.preview.worker_inflight_request_id = None;
    app.switch_to_tab_index(0);
    assert_eq!(
        preview_rx.try_recv().expect("sort activation preview").path,
        new_path
    );
    assert!(
        !app.shell
            .tabs
            .get(0)
            .expect("activated tab slot")
            .preview_reload_pending
    );

    let _ = fs::remove_dir_all(&root);
}

#[test]
fn background_tab_switch_does_not_stop_indexing_progress() {
    let root = test_root("background-tab-indexing-progress");
    fs::create_dir_all(&root).expect("create dir");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.shell.indexing.in_progress = true;
    app.create_new_tab();

    run_shortcuts_frame(
        &mut app,
        false,
        vec![egui::Event::Key {
            key: egui::Key::Tab,
            physical_key: None,
            pressed: true,
            repeat: false,
            modifiers: tab_switch_shortcut_modifiers(true),
        }],
    );

    assert!(app.shell.indexing.in_progress);
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn background_tab_index_batches_do_not_override_active_tab_entries() {
    let root = test_root("background-tab-index-isolation");
    fs::create_dir_all(&root).expect("create dir");
    let active_file = root.join("active.txt");
    let indexed_file = root.join("indexed.txt");
    fs::write(&active_file, "a").expect("write active");
    fs::write(&indexed_file, "b").expect("write indexed");

    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    let (index_req_tx, index_req_rx) = bounded_request_channel::<IndexRequest>(2);
    app.shell.indexing.tx = index_req_tx;
    let (index_res_tx, index_res_rx) = mpsc::channel::<IndexResponse>();
    app.shell.indexing.rx = index_res_rx;
    reset_index_request_state_for_test(&mut app);

    app.request_index_refresh();
    let index_req = index_req_rx.try_recv().expect("index request");
    app.shell.runtime.committed_for_test_mut().entries =
        Arc::new(vec![unknown_entry(active_file.clone())]);
    app.shell.runtime.committed_for_test_mut().all_entries =
        Arc::new(vec![unknown_entry(active_file.clone())]);
    app.sync_active_tab_state();

    app.create_new_tab();
    assert_eq!(app.shell.tabs.active_tab, 1);
    app.shell.runtime.committed_for_test_mut().entries =
        Arc::new(vec![unknown_entry(active_file.clone())]);
    app.shell.runtime.committed_for_test_mut().all_entries =
        Arc::new(vec![unknown_entry(active_file.clone())]);
    app.sync_active_tab_state();

    index_res_tx
        .send(IndexResponse::Batch {
            request_id: index_req.request_id,
            entries: vec![IndexEntry {
                path: indexed_file.clone(),
                kind: EntryKind::file(),
                kind_known: true,
            }],
        })
        .expect("send batch");
    index_res_tx
        .send(IndexResponse::Finished {
            request_id: index_req.request_id,
            source: IndexSource::Walker,
        })
        .expect("send finished");

    app.poll_index_response();

    assert_eq!(app.shell.runtime.entries.len(), 1);
    assert_eq!(app.shell.runtime.entries[0], active_file);

    app.switch_to_tab_index(0);
    assert_eq!(app.shell.runtime.entries.len(), 1);
    assert_eq!(app.shell.runtime.entries[0], indexed_file);
    assert!(!app.shell.indexing.in_progress);

    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_110_background_index_finish_preserves_sort_and_rejects_stale_sort_response() {
    let root = test_root("background-index-invalidates-sort");
    fs::create_dir_all(&root).expect("create dir");
    let stale = root.join("stale.txt");
    let current_a = root.join("current-a.txt");
    let current_z = root.join("current-z.txt");
    fs::write(&stale, "stale").expect("write stale");
    fs::write(&current_a, "a").expect("write current a");
    fs::write(&current_z, "zz").expect("write current z");

    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    let (index_req_tx, index_req_rx) = bounded_request_channel::<IndexRequest>(2);
    let (index_res_tx, index_res_rx) = mpsc::channel::<IndexResponse>();
    app.shell.indexing.tx = index_req_tx;
    app.shell.indexing.rx = index_res_rx;
    reset_index_request_state_for_test(&mut app);
    app.request_index_refresh();
    let index_req = index_req_rx.try_recv().expect("index request");

    app.shell.runtime.committed_for_test_mut().entries = Arc::new(vec![file_entry(stale.clone())]);
    app.shell.runtime.committed_for_test_mut().all_entries = Arc::clone(&app.shell.runtime.entries);
    app.shell.runtime.committed_for_test_mut().base_results = vec![(stale.clone(), 1.0)];
    app.shell.runtime.committed_for_test_mut().results = app.shell.runtime.base_results.clone();
    app.shell.runtime.committed_for_test_mut().total_match_count = 7;
    app.shell.runtime.committed_for_test_mut().current_row = Some(0);
    let (sort_req_tx, sort_req_rx) = mpsc::channel::<SortMetadataRequest>();
    let (sort_res_tx, sort_res_rx) = mpsc::channel::<SortMetadataResponse>();
    app.shell.worker_bus.sort.tx = sort_req_tx;
    app.shell.worker_bus.sort.rx = sort_res_rx;
    app.set_result_sort_mode(ResultSortMode::SizeDesc);
    let sort_req = sort_req_rx.try_recv().expect("sort request");

    app.create_new_tab();
    index_res_tx
        .send(IndexResponse::ReplaceAll {
            request_id: index_req.request_id,
            entries: vec![
                IndexEntry {
                    path: current_a.clone(),
                    kind: EntryKind::file(),
                    kind_known: true,
                },
                IndexEntry {
                    path: current_z.clone(),
                    kind: EntryKind::file(),
                    kind_known: true,
                },
            ],
        })
        .expect("send replace");
    index_res_tx
        .send(IndexResponse::Finished {
            request_id: index_req.request_id,
            source: IndexSource::Walker,
        })
        .expect("send finish");
    let replacement_sort_req =
        receive_after_background_index_progress(&mut app, &sort_req_rx, "replacement sort request");
    assert_ne!(replacement_sort_req.request_id, sort_req.request_id);
    assert_eq!(replacement_sort_req.mode, ResultSortMode::SizeDesc);

    sort_res_tx
        .send(SortMetadataResponse {
            request_id: sort_req.request_id,
            entries: vec![(
                stale.clone(),
                SortMetadata {
                    size_bytes: Some(5),
                    ..SortMetadata::default()
                },
            )],
            mode: ResultSortMode::SizeDesc,
        })
        .expect("send stale sort");
    app.poll_sort_response();

    let background = app.shell.tabs.get(0).expect("background tab");
    assert_eq!(
        background.result_state.result_sort_mode,
        ResultSortMode::SizeDesc
    );
    assert_eq!(background.result_state.committed.total_match_count, 7);
    assert_eq!(
        background.result_state.committed.base_results,
        vec![(current_a.clone(), 0.0), (current_z.clone(), 0.0)]
    );
    assert_eq!(
        background.result_state.committed.results,
        vec![(stale, 1.0)]
    );
    assert_eq!(
        background.result_state.pending_sort_request_id,
        Some(replacement_sort_req.request_id)
    );
    assert!(background.result_state.sort_in_progress);

    sort_res_tx
        .send(SortMetadataResponse {
            request_id: replacement_sort_req.request_id,
            entries: vec![
                (
                    current_a.clone(),
                    SortMetadata {
                        size_bytes: Some(1),
                        ..SortMetadata::default()
                    },
                ),
                (
                    current_z.clone(),
                    SortMetadata {
                        size_bytes: Some(2),
                        ..SortMetadata::default()
                    },
                ),
            ],
            mode: ResultSortMode::SizeDesc,
        })
        .expect("send replacement sort");
    app.poll_sort_response();

    let background = app.shell.tabs.get(0).expect("background tab");
    assert_eq!(background.result_state.committed.total_match_count, 2);
    assert_eq!(
        background.result_state.committed.results,
        vec![(current_z.clone(), 0.0), (current_a.clone(), 0.0)]
    );
    assert!(background.result_state.pending_sort_request_id.is_none());
    assert!(!background.result_state.sort_in_progress);

    app.switch_to_tab_index(0);
    assert_eq!(app.shell.runtime.result_sort_mode, ResultSortMode::SizeDesc);
    assert_eq!(app.shell.runtime.total_match_count, 2);
    assert_eq!(
        app.shell.runtime.results,
        vec![(current_z, 0.0), (current_a, 0.0)]
    );
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn active_index_progress_before_tab_switch_is_preserved_on_background_finish() {
    let root = test_root("active-index-progress-before-tab-switch");
    fs::create_dir_all(&root).expect("create dir");
    let first_file = root.join("first.txt");
    let second_file = root.join("second.txt");
    fs::write(&first_file, "first").expect("write first");
    fs::write(&second_file, "second").expect("write second");

    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    let (index_req_tx, index_req_rx) = bounded_request_channel::<IndexRequest>(2);
    app.shell.indexing.tx = index_req_tx;
    let (index_res_tx, index_res_rx) = mpsc::channel::<IndexResponse>();
    app.shell.indexing.rx = index_res_rx;
    reset_index_request_state_for_test(&mut app);

    app.request_index_refresh();
    let index_req = index_req_rx.try_recv().expect("index request");

    index_res_tx
        .send(IndexResponse::Batch {
            request_id: index_req.request_id,
            entries: vec![IndexEntry {
                path: first_file.clone(),
                kind: EntryKind::file(),
                kind_known: true,
            }],
        })
        .expect("send active batch");
    app.poll_index_response();
    assert_eq!(app.shell.indexing.build.index.entries.len(), 1);

    app.create_new_tab();
    assert_eq!(app.shell.tabs.active_tab, 1);

    index_res_tx
        .send(IndexResponse::Batch {
            request_id: index_req.request_id,
            entries: vec![IndexEntry {
                path: second_file.clone(),
                kind: EntryKind::file(),
                kind_known: true,
            }],
        })
        .expect("send background batch");
    index_res_tx
        .send(IndexResponse::Finished {
            request_id: index_req.request_id,
            source: IndexSource::Walker,
        })
        .expect("send background finished");

    app.poll_index_response();
    app.switch_to_tab_index(0);

    assert_eq!(app.shell.runtime.entries.len(), 2);
    assert!(app
        .shell
        .runtime
        .entries
        .iter()
        .any(|entry| entry.path == first_file));
    assert!(app
        .shell
        .runtime
        .entries
        .iter()
        .any(|entry| entry.path == second_file));
    assert!(!app.shell.indexing.in_progress);

    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_110_background_non_empty_refresh_keeps_last_good_until_sorted_search_response() {
    let root = test_root("ignore-refresh-background-non-empty-sort");
    fs::create_dir_all(&root).expect("create dir");
    let old = root.join("old-match.txt");
    let new_a = root.join("a-match.txt");
    let new_z = root.join("z-match.txt");
    let mut app = FlistWalkerApp::new(root.clone(), 50, "match".to_string());
    let (index_req_tx, index_req_rx) = bounded_request_channel::<IndexRequest>(2);
    let (index_res_tx, index_res_rx) = mpsc::channel::<IndexResponse>();
    app.shell.indexing.tx = index_req_tx;
    app.shell.indexing.rx = index_res_rx;
    let (search_req_tx, search_req_rx) = mpsc::channel::<SearchRequest>();
    let (search_res_tx, search_res_rx) = mpsc::channel::<SearchResponse>();
    app.shell.search.tx = search_req_tx;
    app.shell.search.rx = search_res_rx;
    reset_index_request_state_for_test(&mut app);
    app.shell.runtime.committed_for_test_mut().all_entries =
        Arc::new(vec![file_entry(old.clone())]);
    app.shell.runtime.committed_for_test_mut().entries = Arc::clone(&app.shell.runtime.all_entries);
    app.replace_results_snapshot(vec![(old.clone(), 1.0)], false);
    app.shell.runtime.set_total_match_count(1);
    app.shell.runtime.result_sort_mode = ResultSortMode::NameAsc;
    app.shell.runtime.result_sort_scope = ResultSortScope::AllMatches;

    app.maybe_reindex_from_filter_toggles(false, false, false, true);
    let index_request = index_req_rx.try_recv().expect("index request");
    app.create_new_tab();
    index_res_tx
        .send(IndexResponse::ReplaceAll {
            request_id: index_request.request_id,
            entries: vec![
                IndexEntry {
                    path: new_z.clone(),
                    kind: EntryKind::file(),
                    kind_known: true,
                },
                IndexEntry {
                    path: new_a.clone(),
                    kind: EntryKind::file(),
                    kind_known: true,
                },
            ],
        })
        .expect("send replacement index");
    index_res_tx
        .send(IndexResponse::Finished {
            request_id: index_request.request_id,
            source: IndexSource::Walker,
        })
        .expect("send background terminal");
    let search_request = receive_after_background_index_progress(
        &mut app,
        &search_req_rx,
        "background search request",
    );
    assert_eq!(search_request.sort_mode, ResultSortMode::NameAsc);
    assert_eq!(search_request.sort_scope, ResultSortScope::AllMatches);
    let background = app.shell.tabs.get(0).expect("background tab");
    assert_eq!(
        background.result_state.committed.results,
        vec![(old.clone(), 1.0)]
    );
    assert_eq!(background.result_state.committed.total_match_count, 1);

    search_res_tx
        .send(SearchResponse {
            request_id: search_request.request_id + 1_000,
            results: vec![(new_z.clone(), 99.0)],
            total_match_count: 99,
            sort_mode: ResultSortMode::NameAsc,
            sort_scope: ResultSortScope::AllMatches,
            error: None,
        })
        .expect("send stale background search");
    app.poll_search_response();
    let background = app.shell.tabs.get(0).expect("background tab");
    assert_eq!(background.result_state.committed.results, vec![(old, 1.0)]);
    assert_eq!(background.result_state.committed.total_match_count, 1);

    search_res_tx
        .send(SearchResponse {
            request_id: search_request.request_id,
            results: vec![(new_a.clone(), 2.0), (new_z.clone(), 1.0)],
            total_match_count: 2,
            sort_mode: ResultSortMode::NameAsc,
            sort_scope: ResultSortScope::AllMatches,
            error: None,
        })
        .expect("send sorted background search");
    app.poll_search_response();

    let background = app.shell.tabs.get(0).expect("background tab");
    assert_eq!(
        background.result_state.committed.results,
        vec![(new_a.clone(), 2.0), (new_z.clone(), 1.0)]
    );
    assert_eq!(background.result_state.committed.total_match_count, 2);
    app.switch_to_tab_index(0);
    assert_eq!(app.shell.runtime.result_sort_mode, ResultSortMode::NameAsc);
    assert_eq!(
        app.shell.runtime.result_sort_scope,
        ResultSortScope::AllMatches
    );
    assert_eq!(app.shell.runtime.results, vec![(new_a, 2.0), (new_z, 1.0)]);
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_110_background_empty_all_matches_refresh_sorts_full_replacement_before_limit() {
    let root = test_root("ignore-refresh-background-empty-all-matches");
    fs::create_dir_all(&root).expect("create dir");
    let old = root.join("old.txt");
    let new_a = root.join("a.txt");
    let new_m = root.join("m.txt");
    let new_z = root.join("z.txt");
    let mut app = FlistWalkerApp::new(root.clone(), 1, String::new());
    let (index_req_tx, index_req_rx) = bounded_request_channel::<IndexRequest>(2);
    let (index_res_tx, index_res_rx) = mpsc::channel::<IndexResponse>();
    app.shell.indexing.tx = index_req_tx;
    app.shell.indexing.rx = index_res_rx;
    let (search_req_tx, search_req_rx) = mpsc::channel::<SearchRequest>();
    let (search_res_tx, search_res_rx) = mpsc::channel::<SearchResponse>();
    app.shell.search.tx = search_req_tx;
    app.shell.search.rx = search_res_rx;
    reset_index_request_state_for_test(&mut app);
    app.shell.runtime.committed_for_test_mut().all_entries =
        Arc::new(vec![file_entry(old.clone())]);
    app.shell.runtime.committed_for_test_mut().entries = Arc::clone(&app.shell.runtime.all_entries);
    app.replace_results_snapshot(vec![(old.clone(), 1.0)], false);
    app.shell.runtime.set_total_match_count(1);
    app.shell.runtime.result_sort_mode = ResultSortMode::NameAsc;
    app.shell.runtime.result_sort_scope = ResultSortScope::AllMatches;

    app.maybe_reindex_from_filter_toggles(false, false, false, true);
    let index_request = index_req_rx.try_recv().expect("index request");
    app.create_new_tab();
    index_res_tx
        .send(IndexResponse::ReplaceAll {
            request_id: index_request.request_id,
            entries: vec![
                IndexEntry {
                    path: new_z.clone(),
                    kind: EntryKind::file(),
                    kind_known: true,
                },
                IndexEntry {
                    path: new_m.clone(),
                    kind: EntryKind::file(),
                    kind_known: true,
                },
                IndexEntry {
                    path: new_a.clone(),
                    kind: EntryKind::file(),
                    kind_known: true,
                },
            ],
        })
        .expect("send replacement index");
    index_res_tx
        .send(IndexResponse::Finished {
            request_id: index_request.request_id,
            source: IndexSource::Walker,
        })
        .expect("send background terminal");
    let search_request = receive_after_background_index_progress(
        &mut app,
        &search_req_rx,
        "background search request",
    );
    assert!(search_request.query.is_empty());
    assert_eq!(search_request.limit, 1);
    assert_eq!(search_request.entries.len(), 3);
    assert!(search_request
        .entries
        .iter()
        .any(|entry| entry.path == new_a));
    assert_eq!(search_request.sort_mode, ResultSortMode::NameAsc);
    assert_eq!(search_request.sort_scope, ResultSortScope::AllMatches);
    let background = app.shell.tabs.get(0).expect("background tab");
    assert_eq!(background.result_state.committed.results, vec![(old, 1.0)]);
    assert_eq!(background.result_state.committed.total_match_count, 1);

    search_res_tx
        .send(SearchResponse {
            request_id: search_request.request_id,
            results: vec![(new_a.clone(), 3.0)],
            total_match_count: 3,
            sort_mode: ResultSortMode::NameAsc,
            sort_scope: ResultSortScope::AllMatches,
            error: None,
        })
        .expect("send sorted background search");
    app.poll_search_response();

    let background = app.shell.tabs.get(0).expect("background tab");
    assert_eq!(
        background.result_state.committed.results,
        vec![(new_a.clone(), 3.0)]
    );
    assert_eq!(background.result_state.committed.total_match_count, 3);
    app.switch_to_tab_index(0);
    assert_eq!(app.shell.runtime.results, vec![(new_a, 3.0)]);
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_110_background_empty_all_matches_metadata_worker_failure_keeps_last_good() {
    let root = test_root("ignore-refresh-background-empty-metadata-worker-failure");
    fs::create_dir_all(&root).expect("create dir");
    let old = root.join("old.txt");
    let replacement = root.join("replacement.txt");
    let mut app = FlistWalkerApp::new(root.clone(), 1, String::new());
    let (index_req_tx, index_req_rx) = bounded_request_channel::<IndexRequest>(2);
    let (index_res_tx, index_res_rx) = mpsc::channel::<IndexResponse>();
    app.shell.indexing.tx = index_req_tx;
    app.shell.indexing.rx = index_res_rx;
    let (search_req_tx, search_req_rx) = mpsc::channel::<SearchRequest>();
    app.shell.search.tx = search_req_tx;
    drop(search_req_rx);
    reset_index_request_state_for_test(&mut app);
    app.shell.runtime.committed_for_test_mut().all_entries =
        Arc::new(vec![file_entry(old.clone())]);
    app.shell.runtime.committed_for_test_mut().entries = Arc::clone(&app.shell.runtime.all_entries);
    app.replace_results_snapshot(vec![(old.clone(), 1.0)], false);
    app.shell.runtime.set_total_match_count(1);
    app.shell.runtime.result_sort_mode = ResultSortMode::SizeDesc;
    app.shell.runtime.result_sort_scope = ResultSortScope::AllMatches;

    app.maybe_reindex_from_filter_toggles(false, false, false, true);
    let index_request = index_req_rx.try_recv().expect("index request");
    app.create_new_tab();
    index_res_tx
        .send(IndexResponse::ReplaceAll {
            request_id: index_request.request_id,
            entries: vec![IndexEntry {
                path: replacement,
                kind: EntryKind::file(),
                kind_known: true,
            }],
        })
        .expect("send replacement index");
    index_res_tx
        .send(IndexResponse::Finished {
            request_id: index_request.request_id,
            source: IndexSource::Walker,
        })
        .expect("send background terminal");
    poll_background_index_until(&mut app, "failed background search settlement", |app| {
        app.shell.tabs.get(0).is_some_and(|tab| {
            tab.notice == "Search worker is unavailable" && !tab.search_in_progress
        })
    });

    let background = app.shell.tabs.get(0).expect("background tab");
    assert_eq!(background.result_state.committed.results, vec![(old, 1.0)]);
    assert_eq!(background.result_state.committed.total_match_count, 1);
    assert_eq!(
        background.result_state.result_sort_mode,
        ResultSortMode::SizeDesc
    );
    assert_eq!(
        background.result_state.result_sort_scope,
        ResultSortScope::AllMatches
    );
    assert_eq!(background.notice, "Search worker is unavailable");
    assert!(!background.search_in_progress);
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn active_index_handoff_preserves_pending_and_background_batches() {
    let root = test_root("active-index-handoff-pending-background");
    fs::create_dir_all(&root).expect("create dir");
    let drained_file = root.join("drained.txt");
    let pending_file = root.join("pending.txt");
    let background_file = root.join("background.txt");
    fs::write(&drained_file, "drained").expect("write drained");
    fs::write(&pending_file, "pending").expect("write pending");
    fs::write(&background_file, "background").expect("write background");

    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    let (index_req_tx, index_req_rx) = bounded_request_channel::<IndexRequest>(2);
    app.shell.indexing.tx = index_req_tx;
    let (index_res_tx, index_res_rx) = mpsc::channel::<IndexResponse>();
    app.shell.indexing.rx = index_res_rx;
    reset_index_request_state_for_test(&mut app);

    app.request_index_refresh();
    let index_req = index_req_rx.try_recv().expect("index request");
    app.shell.indexing.build.index.entries = vec![file_entry(drained_file.clone())];
    app.shell.indexing.pending_entries_request_id = Some(index_req.request_id);
    app.shell
        .indexing
        .build
        .pending_entries
        .push_back(IndexEntry {
            path: pending_file.clone(),
            kind: EntryKind::file(),
            kind_known: true,
        });

    app.create_new_tab();
    assert_eq!(app.shell.tabs.active_tab, 1);

    index_res_tx
        .send(IndexResponse::Batch {
            request_id: index_req.request_id,
            entries: vec![IndexEntry {
                path: background_file.clone(),
                kind: EntryKind::file(),
                kind_known: true,
            }],
        })
        .expect("send background batch");
    index_res_tx
        .send(IndexResponse::Finished {
            request_id: index_req.request_id,
            source: IndexSource::Walker,
        })
        .expect("send background finished");

    app.poll_index_response();
    app.switch_to_tab_index(0);

    assert_eq!(app.shell.runtime.entries.len(), 3);
    assert!(app
        .shell
        .runtime
        .entries
        .iter()
        .any(|entry| entry.path == drained_file));
    assert!(app
        .shell
        .runtime
        .entries
        .iter()
        .any(|entry| entry.path == pending_file));
    assert!(app
        .shell
        .runtime
        .entries
        .iter()
        .any(|entry| entry.path == background_file));
    assert!(!app.shell.indexing.in_progress);
    assert!(app.shell.indexing.build.pending_entries.is_empty());

    let _ = fs::remove_dir_all(&root);
}

#[test]
fn background_replace_all_after_active_handoff_discards_prior_partial_index() {
    let root = test_root("background-replace-all-discards-partial");
    fs::create_dir_all(&root).expect("create dir");
    let stale_file = root.join("stale.txt");
    let replacement_file = root.join("replacement.txt");
    fs::write(&stale_file, "stale").expect("write stale");
    fs::write(&replacement_file, "replacement").expect("write replacement");

    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    let (index_req_tx, index_req_rx) = bounded_request_channel::<IndexRequest>(2);
    app.shell.indexing.tx = index_req_tx;
    let (index_res_tx, index_res_rx) = mpsc::channel::<IndexResponse>();
    app.shell.indexing.rx = index_res_rx;
    reset_index_request_state_for_test(&mut app);

    app.request_index_refresh();
    let index_req = index_req_rx.try_recv().expect("index request");
    app.shell.indexing.build.index.entries = vec![file_entry(stale_file.clone())];
    app.shell.indexing.pending_entries_request_id = Some(index_req.request_id);
    app.shell
        .indexing
        .build
        .pending_entries
        .push_back(IndexEntry {
            path: stale_file.clone(),
            kind: EntryKind::file(),
            kind_known: true,
        });

    app.create_new_tab();

    index_res_tx
        .send(IndexResponse::ReplaceAll {
            request_id: index_req.request_id,
            entries: vec![IndexEntry {
                path: replacement_file.clone(),
                kind: EntryKind::file(),
                kind_known: true,
            }],
        })
        .expect("send replace all");
    index_res_tx
        .send(IndexResponse::Finished {
            request_id: index_req.request_id,
            source: IndexSource::FileList(root.join("FileList.txt")),
        })
        .expect("send finished");

    poll_background_index_until(&mut app, "background replacement index finish", |app| {
        app.shell.tabs.get(0).is_some_and(|tab| {
            tab.index_state.pending_index_request_id.is_none()
                && tab.index_state.pending_index_finish.is_none()
        })
    });
    app.switch_to_tab_index(0);

    assert_eq!(app.shell.runtime.entries.len(), 1);
    assert_eq!(app.shell.runtime.entries[0], replacement_file);
    assert!(!app
        .shell
        .runtime
        .entries
        .iter()
        .any(|entry| entry.path == stale_file));

    let _ = fs::remove_dir_all(&root);
}

#[test]
fn background_empty_query_index_finish_updates_total_match_count() {
    let root = test_root("background-empty-query-total-count");
    fs::create_dir_all(&root).expect("create dir");
    let active_file = root.join("active.txt");
    let indexed_a = root.join("indexed-a.txt");
    let indexed_b = root.join("indexed-b.txt");
    fs::write(&active_file, "a").expect("write active");
    fs::write(&indexed_a, "a").expect("write indexed a");
    fs::write(&indexed_b, "b").expect("write indexed b");

    let mut app = FlistWalkerApp::new(root.clone(), 1, String::new());
    let (index_res_tx, index_res_rx) = mpsc::channel::<IndexResponse>();
    app.shell.indexing.rx = index_res_rx;
    app.shell.runtime.committed_for_test_mut().entries =
        Arc::new(vec![file_entry(active_file.clone())]);
    app.shell.runtime.committed_for_test_mut().all_entries =
        Arc::new(vec![file_entry(active_file.clone())]);
    app.shell.runtime.committed_for_test_mut().results = vec![(active_file.clone(), 0.0)];
    app.shell.runtime.committed_for_test_mut().base_results = app.shell.runtime.results.clone();
    app.shell.runtime.committed_for_test_mut().total_match_count = 99;
    app.sync_active_tab_state();

    app.create_new_tab();
    let background_tab_id = app.shell.tabs.get(0).expect("tab 0").id;
    app.shell
        .indexing
        .request_tabs
        .insert(77, background_tab_id);
    app.shell
        .indexing
        .latest_request_ids
        .lock()
        .expect("latest index requests")
        .insert(background_tab_id, 77);
    app.shell
        .tabs
        .get_mut(0)
        .expect("tab 0")
        .index_state
        .pending_index_request_id = Some(77);
    app.shell
        .tabs
        .get_mut(0)
        .expect("tab 0")
        .index_state
        .index_in_progress = true;

    index_res_tx
        .send(IndexResponse::Batch {
            request_id: 77,
            entries: vec![
                IndexEntry {
                    path: indexed_a.clone(),
                    kind: EntryKind::file(),
                    kind_known: true,
                },
                IndexEntry {
                    path: indexed_b.clone(),
                    kind: EntryKind::file(),
                    kind_known: true,
                },
            ],
        })
        .expect("send background batch");
    index_res_tx
        .send(IndexResponse::Finished {
            request_id: 77,
            source: IndexSource::Walker,
        })
        .expect("send background finished");

    poll_background_index_until(&mut app, "background total-match count update", |app| {
        app.shell.tabs.get(0).is_some_and(|tab| {
            tab.index_state.pending_index_request_id.is_none()
                && tab.index_state.pending_index_finish.is_none()
                && tab.result_state.committed.total_match_count == 2
        })
    });

    let background_tab = app.shell.tabs.get(0).expect("tab 0");
    assert_eq!(background_tab.result_state.committed.results.len(), 1);
    assert_eq!(background_tab.result_state.committed.total_match_count, 2);

    app.switch_to_tab_index(0);
    assert_eq!(app.shell.runtime.results.len(), 1);
    assert_eq!(app.shell.runtime.total_match_count, 2);
    assert!(app.status_line_text().contains("Results: 1 of 2 shown"));

    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_background_empty_terminal_clears_absent_evicted_selection_intent_regression() {
    let root = test_root("tc-207-background-empty-clears-selection-intent");
    fs::create_dir_all(&root).expect("create dir");
    let first = root.join("first.txt");
    let previously_selected = root.join("previously-selected.txt");
    fs::write(&first, "first").expect("write first");
    fs::write(&previously_selected, "selected").expect("write selected");

    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    let (index_res_tx, index_res_rx) = mpsc::channel::<IndexResponse>();
    app.shell.indexing.rx = index_res_rx;
    app.create_new_tab();
    let background_tab_id = app.shell.tabs.get(0).expect("background tab").id;
    {
        let tab = app.shell.tabs.get_mut(0).expect("background tab");
        tab.result_state.evicted_selected_path = Some(previously_selected.clone());
        tab.index_state.pending_index_request_id = Some(807);
        tab.index_state.index_in_progress = true;
    }
    app.shell
        .indexing
        .request_tabs
        .insert(807, background_tab_id);
    app.shell
        .indexing
        .latest_request_ids
        .lock()
        .expect("latest index requests")
        .insert(background_tab_id, 807);

    index_res_tx
        .send(IndexResponse::Finished {
            request_id: 807,
            source: IndexSource::Walker,
        })
        .expect("send empty terminal");
    app.poll_index_response();

    let background = app.shell.tabs.get(0).expect("background tab");
    assert!(background.result_state.committed.results.is_empty());
    assert!(background.result_state.evicted_selected_path.is_none());

    {
        let tab = app.shell.tabs.get_mut(0).expect("background tab");
        tab.index_state.pending_index_request_id = Some(808);
        tab.index_state.index_in_progress = true;
    }
    app.shell
        .indexing
        .request_tabs
        .insert(808, background_tab_id);
    app.shell
        .indexing
        .latest_request_ids
        .lock()
        .expect("latest index requests")
        .insert(background_tab_id, 808);
    index_res_tx
        .send(IndexResponse::Batch {
            request_id: 808,
            entries: vec![
                IndexEntry {
                    path: first.clone(),
                    kind: EntryKind::file(),
                    kind_known: true,
                },
                IndexEntry {
                    path: previously_selected.clone(),
                    kind: EntryKind::file(),
                    kind_known: true,
                },
            ],
        })
        .expect("send later batch");
    index_res_tx
        .send(IndexResponse::Finished {
            request_id: 808,
            source: IndexSource::Walker,
        })
        .expect("send later terminal");
    app.poll_index_response();

    let background = app.shell.tabs.get(0).expect("background tab");
    assert_eq!(background.result_state.committed.current_row, Some(0));
    assert_eq!(background.result_state.committed.results[0].0, first);
    assert!(background.result_state.evicted_selected_path.is_none());
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn background_tab_search_and_index_responses_do_not_override_active_results() {
    let root = test_root("background-tab-response-isolation");
    fs::create_dir_all(&root).expect("create dir");
    let active_file = root.join("active.txt");
    let background_file = root.join("background.txt");
    fs::write(&active_file, "active").expect("write active");
    fs::write(&background_file, "background").expect("write background");

    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    let (index_req_tx, index_req_rx) = bounded_request_channel::<IndexRequest>(2);
    let (index_res_tx, index_res_rx) = mpsc::channel::<IndexResponse>();
    app.shell.indexing.tx = index_req_tx;
    app.shell.indexing.rx = index_res_rx;
    reset_index_request_state_for_test(&mut app);
    let (search_tx_req, search_rx_req) = mpsc::channel::<SearchRequest>();
    let (search_tx_res, search_rx_res) = mpsc::channel::<SearchResponse>();
    app.shell.search.tx = search_tx_req;
    app.shell.search.rx = search_rx_res;

    app.shell.runtime.committed_for_test_mut().entries =
        Arc::new(vec![file_entry(active_file.clone())]);
    app.shell.runtime.committed_for_test_mut().all_entries =
        Arc::new(vec![file_entry(active_file.clone())]);
    app.shell.runtime.committed_for_test_mut().results = vec![(active_file.clone(), 0.0)];
    app.shell.runtime.committed_for_test_mut().base_results = app.shell.runtime.results.clone();
    app.shell.runtime.committed_for_test_mut().current_row = Some(0);
    app.shell
        .indexing
        .set_lifecycle_for_test(TabResourceLifecycle::Ready);
    app.shell
        .indexing
        .set_committed_snapshot_present_for_test(true);
    app.sync_active_tab_state();

    app.create_new_tab();
    assert_eq!(app.shell.tabs.active_tab, 1);
    app.shell.runtime.committed_for_test_mut().entries =
        Arc::new(vec![file_entry(active_file.clone())]);
    app.shell.runtime.committed_for_test_mut().all_entries =
        Arc::new(vec![file_entry(active_file.clone())]);
    app.shell.runtime.committed_for_test_mut().results = vec![(active_file.clone(), 0.0)];
    app.shell.runtime.committed_for_test_mut().base_results = app.shell.runtime.results.clone();
    app.shell.runtime.committed_for_test_mut().current_row = Some(0);
    app.shell
        .indexing
        .set_lifecycle_for_test(TabResourceLifecycle::Ready);
    app.shell
        .indexing
        .set_committed_snapshot_present_for_test(true);
    app.sync_active_tab_state();

    app.switch_to_tab_index(0);
    app.shell.runtime.query_state.query = "background".to_string();
    app.sync_active_tab_state();
    app.switch_to_tab_index(1);

    let background_tab_id = app.shell.tabs.get(0).expect("tab 0").id;
    let background_index_request = IndexRequest {
        request_id: 88,
        tab_id: background_tab_id,
        root: root.clone(),
        use_filelist: true,
        include_files: true,
        include_dirs: true,
        max_depth: crate::indexer::MaxDepth::unlimited(),
        follow_links: false,
        complete_walker_snapshot: false,
    };
    app.shell
        .indexing
        .request_tabs
        .insert(88, background_tab_id);
    app.shell
        .indexing
        .latest_request_ids
        .lock()
        .expect("latest index requests")
        .insert(background_tab_id, 88);
    app.shell
        .tabs
        .get_mut(0)
        .expect("tab 0")
        .index_state
        .pending_index_request_id = Some(88);
    app.shell
        .tabs
        .get_mut(0)
        .expect("tab 0")
        .index_state
        .index_in_progress = true;
    app.shell.search.bind_request_tab(89, background_tab_id);
    app.shell.tabs.get_mut(0).expect("tab 0").pending_request_id = Some(89);
    app.shell.tabs.get_mut(0).expect("tab 0").search_in_progress = true;

    let active_results = app.shell.runtime.results.clone();
    let active_base_results = app.shell.runtime.base_results.clone();
    let active_current_row = app.shell.runtime.current_row;

    search_tx_res
        .send(SearchResponse {
            request_id: 89,
            results: vec![(background_file.clone(), 9.0)],
            total_match_count: 1,
            sort_mode: ResultSortMode::Score,
            sort_scope: ResultSortScope::ShownResults,
            error: None,
        })
        .expect("send background search response");
    index_res_tx
        .send(IndexResponse::Batch {
            request_id: background_index_request.request_id,
            entries: vec![IndexEntry {
                path: background_file.clone(),
                kind: EntryKind::file(),
                kind_known: true,
            }],
        })
        .expect("send background batch");
    index_res_tx
        .send(IndexResponse::Finished {
            request_id: background_index_request.request_id,
            source: IndexSource::Walker,
        })
        .expect("send background finished");

    app.poll_search_response();
    app.poll_index_response();

    assert_eq!(app.shell.runtime.results, active_results);
    assert_eq!(app.shell.runtime.base_results, active_base_results);
    assert_eq!(app.shell.runtime.current_row, active_current_row);
    assert!(app
        .shell
        .tabs
        .get(0)
        .expect("tab 0")
        .result_state
        .committed
        .base_results
        .is_empty());
    assert!(
        search_rx_req.try_recv().is_ok(),
        "the committed background snapshot must be searched again"
    );
    assert_eq!(
        app.shell
            .tabs
            .get(0)
            .expect("tab 0")
            .result_state
            .committed
            .entries
            .len(),
        1
    );
    assert_eq!(
        app.shell
            .tabs
            .get(0)
            .expect("tab 0")
            .result_state
            .committed
            .entries[0],
        background_file
    );
    assert!(index_req_rx.try_recv().is_err());

    let _ = fs::remove_dir_all(&root);
}

#[test]
fn background_walker_truncated_notice_points_to_config_file_setting() {
    let root = test_root("background-walker-truncated-config-notice");
    fs::create_dir_all(&root).expect("create dir");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    let (_index_req_tx, _index_req_rx) = bounded_request_channel::<IndexRequest>(2);
    let (index_res_tx, index_res_rx) = mpsc::channel::<IndexResponse>();
    app.shell.indexing.rx = index_res_rx;

    app.create_new_tab();
    assert_eq!(app.shell.tabs.active_tab, 1);
    let background_tab_id = app.shell.tabs.get(0).expect("tab 0").id;
    app.shell
        .indexing
        .request_tabs
        .insert(92, background_tab_id);
    app.shell
        .indexing
        .latest_request_ids
        .lock()
        .expect("latest index requests")
        .insert(background_tab_id, 92);
    app.shell
        .tabs
        .get_mut(0)
        .expect("tab 0")
        .index_state
        .pending_index_request_id = Some(92);

    index_res_tx
        .send(IndexResponse::Truncated {
            request_id: 92,
            limit: 500_000,
        })
        .expect("send background truncated response");

    app.poll_index_response();

    let notice = &app.shell.tabs.get(0).expect("tab 0").notice;
    assert_eq!(
        notice,
        "Walker capped at 500000 entries (set walker_max_entries in the config file to adjust)"
    );
    assert!(!notice.contains("FLISTWALKER_WALKER_MAX_ENTRIES"));

    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_background_finish_waits_for_reclaimer_without_dropping_old_snapshot() {
    let root = test_root("tc-207-background-finish-reclaimer-debt");
    fs::create_dir_all(&root).expect("create root");
    let old = file_entry(root.join("old.txt"));
    let new = file_entry(root.join("new.txt"));
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    let background_tab_id = app.shell.tabs.get(0).expect("background tab").id;
    {
        let tab = app.shell.tabs.get_mut(0).expect("background tab");
        tab.index_state
            .set_lifecycle_for_test(TabResourceLifecycle::Refreshing);
        tab.index_state
            .set_committed_snapshot_present_for_test(true);
        tab.result_state.committed.all_entries = Arc::new(vec![old.clone()]);
        tab.result_state.committed.entries = Arc::new(vec![old.clone()]);
        tab.result_state.committed.base_results = vec![(old.path.clone(), 0.0)];
        tab.result_state.committed.results = vec![(old.path.clone(), 0.0)];
        tab.result_state.committed.total_match_count = 7;
        tab.result_state.committed.current_row = Some(0);
        tab.result_state.result_sort_mode = ResultSortMode::NameAsc;
        tab.result_state.result_sort_scope = ResultSortScope::ShownResults;
        tab.result_state.pending_sort_request_id = Some(406);
        tab.result_state.sort_in_progress = true;
        tab.index_state.pending_index_request_id = Some(407);
        tab.index_state.index_in_progress = true;
    }
    app.bind_sort_request_to_tab(406, background_tab_id);
    app.shell
        .indexing
        .request_tabs
        .insert(407, background_tab_id);
    app.shell.indexing.warm_tab_id = Some(background_tab_id);
    app.shell.indexing.background_states.insert(
        407,
        BackgroundIndexState {
            source: Some(IndexSource::Walker),
            entries: vec![new.clone()].into(),
            replaced: true,
        },
    );
    app.shell.tabs.pause_resource_reclaimer();
    for index in 0..TAB_RESOURCE_RECLAIMER_CAPACITY {
        let mut tab = app.capture_active_tab_state(1_400 + index as u64);
        tab.result_state.committed.all_entries =
            Arc::new(vec![file_entry(root.join(format!("held-{index}.txt")))]);
        tab.index_state
            .set_committed_snapshot_present_for_test(true);
        app.shell
            .tabs
            .retire_tab_resources_for_test(tab.take_heavy_resources())
            .expect("fill reclaimer");
    }

    let effect = app.apply_background_index_response(
        0,
        IndexResponse::Finished {
            request_id: 407,
            source: IndexSource::Walker,
        },
    );

    assert!(effect.cleanup_request_id.is_none());
    let waiting = app.shell.tabs.get(0).expect("background tab");
    assert_eq!(waiting.result_state.committed.all_entries.as_ref(), &[old]);
    assert_eq!(
        waiting.result_state.result_sort_mode,
        ResultSortMode::NameAsc
    );
    assert_eq!(waiting.result_state.committed.total_match_count, 7);
    assert_eq!(waiting.result_state.committed.results.len(), 1);
    assert_eq!(waiting.result_state.pending_sort_request_id, Some(406));
    assert!(waiting.result_state.sort_in_progress);
    assert_eq!(app.sort_request_tab(406), Some(background_tab_id));
    assert!(waiting.index_state.pending_index_finish.is_some());
    assert!(waiting
        .notice
        .contains("Waiting for background tab resource"));

    app.shell.tabs.resume_resource_reclaimer();
    let frame_times =
        settle_background_finish_with_frame_budget(&mut app, 0, 407, IndexSource::Walker);
    assert!(
        frame_times
            .iter()
            .all(|elapsed| *elapsed < Duration::from_millis(100)),
        "frame times: {frame_times:?}"
    );

    let completed = app.shell.tabs.get(0).expect("background tab");
    assert_eq!(
        completed.result_state.committed.all_entries.as_ref(),
        std::slice::from_ref(&new)
    );
    assert!(completed.index_state.pending_index_finish.is_none());
    assert_eq!(
        completed.index_state.lifecycle(),
        TabResourceLifecycle::Ready
    );
    assert_eq!(
        completed.result_state.result_sort_mode,
        ResultSortMode::NameAsc
    );
    assert_eq!(completed.result_state.committed.total_match_count, 1);
    assert_eq!(
        completed.result_state.committed.results,
        vec![(new.path.clone(), 0.0)]
    );
    assert!(completed.result_state.pending_sort_request_id.is_none());
    assert!(!completed.result_state.sort_in_progress);
    assert_eq!(app.sort_request_tab(406), None);
    assert!(!app.shell.indexing.request_tabs.contains_key(&407));
    assert_eq!(app.shell.indexing.warm_tab_id, Some(background_tab_id));
    app.switch_to_tab_index(0);
    assert_eq!(app.shell.runtime.result_sort_mode, ResultSortMode::NameAsc);
    assert_eq!(app.shell.runtime.results, vec![(new.path, 0.0)]);
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_background_finished_commits_100k_default_snapshot_within_ui_budget() {
    let root = test_root("tc-207-background-finish-100k");
    fs::create_dir_all(&root).expect("create root");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    let background_tab_id = app.shell.tabs.get(0).expect("background tab").id;
    let request_id = app
        .shell
        .indexing
        .allocate_request_id(Some(background_tab_id));
    {
        let tab = app.shell.tabs.get_mut(0).expect("background tab");
        tab.include_files = true;
        tab.include_dirs = true;
        tab.index_state
            .set_lifecycle_for_test(TabResourceLifecycle::Loading);
        tab.index_state.pending_index_request_id = Some(request_id);
        tab.index_state.index_in_progress = true;
    }
    app.shell.indexing.background_states.insert(
        request_id,
        BackgroundIndexState {
            source: Some(IndexSource::FileList(root.join("FileList.txt"))),
            entries: (0..100_000)
                .map(|index| file_entry(root.join(format!("entry-{index}.txt"))))
                .collect(),
            replaced: true,
        },
    );

    let started = Instant::now();
    app.handle_background_index_response(
        0,
        IndexResponse::Finished {
            request_id,
            source: IndexSource::FileList(root.join("FileList.txt")),
        },
    );
    let elapsed = started.elapsed();

    assert!(
        elapsed < Duration::from_millis(100),
        "100k background finish admission took {elapsed:?}"
    );
    let staged = app
        .shell
        .indexing
        .background_finalizations
        .get(&request_id)
        .expect("100k finalization remains pending after admission");
    assert!((1..=2_048).contains(&staged.completed_entries.len()));
    assert!(app
        .shell
        .tabs
        .get(0)
        .expect("background tab")
        .index_state
        .pending_index_finish
        .is_some());
    let frames = drive_background_finalization_with_frame_budget(
        &mut app,
        0,
        request_id,
        IndexSource::FileList(root.join("FileList.txt")),
        BackgroundFinalizationTarget::Removed,
    );
    for frame in &frames {
        if let (Some(before), Some(after)) = (frame.before, frame.after) {
            let added = after.completed.saturating_sub(before.completed);
            assert!(added <= 2_048, "one frame assembled {added} entries");
        }
    }
    assert!(
        frames.len() > 1,
        "100k finalization must span multiple frames"
    );
    let tab = app.shell.tabs.get(0).expect("completed background tab");
    assert_eq!(tab.result_state.committed.all_entries.len(), 100_000);
    assert_eq!(tab.index_state.lifecycle(), TabResourceLifecycle::Ready);
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_background_finished_mixed_owners_settles_incrementally() {
    let root = test_root("tc-207-background-finish-mixed-100k");
    fs::create_dir_all(&root).expect("create root");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    let tab_id = app.shell.tabs.get(0).expect("background tab").id;
    let request_id = app.shell.indexing.allocate_request_id(Some(tab_id));
    {
        let tab = app.shell.tabs.get_mut(0).expect("background tab");
        tab.index_state.pending_index_request_id = Some(request_id);
        tab.index_state.index_in_progress = true;
        tab.index_state.build.index.entries = (0..40_000)
            .map(|index| file_entry(root.join(format!("base-{index}.txt"))))
            .collect();
        tab.index_state.pending_index_entries_request_id = Some(request_id);
        tab.index_state.build.pending_entries = (0..30_000)
            .map(|index| IndexEntry {
                path: root.join(format!("pending-{index}.txt")),
                kind: EntryKind::file(),
                kind_known: true,
            })
            .collect();
    }
    app.shell.indexing.background_states.insert(
        request_id,
        BackgroundIndexState {
            source: Some(IndexSource::FileList(root.join("FileList.txt"))),
            entries: (0..30_000)
                .map(|index| file_entry(root.join(format!("tail-{index}.txt"))))
                .collect(),
            replaced: false,
        },
    );

    let started = Instant::now();
    app.handle_background_index_response(
        0,
        IndexResponse::Finished {
            request_id,
            source: IndexSource::FileList(root.join("FileList.txt")),
        },
    );
    assert!(started.elapsed() < Duration::from_millis(100));
    let frames = settle_background_finish_with_frame_budget(
        &mut app,
        0,
        request_id,
        IndexSource::FileList(root.join("FileList.txt")),
    );
    assert!(frames
        .iter()
        .all(|elapsed| *elapsed < Duration::from_millis(100)));
    let tab = app.shell.tabs.get(0).expect("background tab");
    assert_eq!(tab.result_state.committed.all_entries.len(), 100_000);
    assert!(tab.result_state.committed.all_entries[0]
        .path
        .ends_with("base-0.txt"));
    assert!(tab.result_state.committed.all_entries[40_000]
        .path
        .ends_with("pending-0.txt"));
    assert!(tab.result_state.committed.all_entries[70_000]
        .path
        .ends_with("tail-0.txt"));
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_background_finished_file_filter_settles_incrementally() {
    let root = test_root("tc-207-background-finish-filter-100k");
    fs::create_dir_all(&root).expect("create root");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    app.shell.ui.ignore_list_enabled = true;
    app.shell.runtime.ignore_list_terms = Arc::new(vec!["ignored".to_string()]);
    let tab_id = app.shell.tabs.get(0).expect("background tab").id;
    let request_id = app.shell.indexing.allocate_request_id(Some(tab_id));
    {
        let tab = app.shell.tabs.get_mut(0).expect("background tab");
        tab.include_files = true;
        tab.include_dirs = false;
        tab.index_state.pending_index_request_id = Some(request_id);
        tab.index_state.index_in_progress = true;
    }
    app.shell.indexing.background_states.insert(
        request_id,
        BackgroundIndexState {
            source: Some(IndexSource::FileList(root.join("FileList.txt"))),
            entries: (0..100_000)
                .map(|index| {
                    let name = if index % 4 == 0 {
                        format!("ignored-{index}")
                    } else {
                        format!("entry-{index}")
                    };
                    let path = root.join(name);
                    if index % 2 == 0 {
                        file_entry(path)
                    } else {
                        dir_entry(path)
                    }
                })
                .collect(),
            replaced: true,
        },
    );

    app.handle_background_index_response(
        0,
        IndexResponse::Finished {
            request_id,
            source: IndexSource::FileList(root.join("FileList.txt")),
        },
    );
    let frames = settle_background_finish_with_frame_budget(
        &mut app,
        0,
        request_id,
        IndexSource::FileList(root.join("FileList.txt")),
    );
    assert!(frames
        .iter()
        .all(|elapsed| *elapsed < Duration::from_millis(100)));
    let tab = app.shell.tabs.get(0).expect("background tab");
    assert_eq!(tab.result_state.committed.all_entries.len(), 100_000);
    assert_eq!(tab.result_state.committed.entries.len(), 25_000);
    assert!(tab
        .result_state
        .committed
        .entries
        .iter()
        .all(|entry| entry.kind == Some(EntryKind::file())));
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_background_finalization_tracks_ignore_policy_changes_both_directions() {
    for (starts_enabled, expected_len) in [(false, 50_000), (true, 100_000)] {
        let case = if starts_enabled { "on-off" } else { "off-on" };
        let root = test_root(&format!("tc-207-finalize-ignore-{case}"));
        fs::create_dir_all(&root).expect("create root");
        let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
        app.create_new_tab();
        app.shell.ui.ignore_list_enabled = starts_enabled;
        app.shell.runtime.ignore_list_terms = Arc::new(vec!["ignored".to_string()]);
        let tab_id = app.shell.tabs.get(0).expect("background tab").id;
        let request_id = app.shell.indexing.allocate_request_id(Some(tab_id));
        {
            let tab = app.shell.tabs.get_mut(0).expect("background tab");
            tab.include_files = true;
            tab.include_dirs = true;
            tab.index_state.pending_index_request_id = Some(request_id);
            tab.index_state.index_in_progress = true;
        }
        app.shell.indexing.background_states.insert(
            request_id,
            BackgroundIndexState {
                source: Some(IndexSource::FileList(root.join("FileList.txt"))),
                entries: (0..100_000)
                    .map(|index| {
                        let prefix = if index % 2 == 0 { "ignored" } else { "kept" };
                        file_entry(root.join(format!("{prefix}-{index}.txt")))
                    })
                    .collect(),
                replaced: true,
            },
        );

        app.handle_background_index_response(
            0,
            IndexResponse::Finished {
                request_id,
                source: IndexSource::FileList(root.join("FileList.txt")),
            },
        );
        assert!(app
            .shell
            .indexing
            .background_finalizations
            .contains_key(&request_id));
        app.shell.ui.ignore_list_enabled = !starts_enabled;
        let frames = settle_background_finish_with_frame_budget(
            &mut app,
            0,
            request_id,
            IndexSource::FileList(root.join("FileList.txt")),
        );
        assert!(frames.len() > 1);
        assert!(frames
            .iter()
            .all(|elapsed| *elapsed < Duration::from_millis(100)));
        let entries = &app
            .shell
            .tabs
            .get(0)
            .expect("background tab")
            .result_state
            .committed
            .entries;
        assert_eq!(entries.len(), expected_len);
        if !starts_enabled {
            assert!(entries
                .iter()
                .all(|entry| !entry.path.to_string_lossy().contains("ignored")));
        }
        let _ = fs::remove_dir_all(&root);
    }
}

#[test]
fn tc_207_late_filter_policy_change_reclaims_old_output_off_ui() {
    let root = test_root("tc-207-late-filter-policy-reclaim");
    fs::create_dir_all(&root).expect("create root");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    app.shell.ui.ignore_list_enabled = true;
    app.shell.runtime.ignore_list_terms = Arc::new(vec!["ignored".to_string()]);
    let tab_id = app.shell.tabs.get(0).expect("background tab").id;
    let request_id = app.shell.indexing.allocate_request_id(Some(tab_id));
    {
        let tab = app.shell.tabs.get_mut(0).expect("background tab");
        tab.include_files = true;
        tab.include_dirs = true;
        tab.index_state.pending_index_request_id = Some(request_id);
        tab.index_state.index_in_progress = true;
    }
    app.shell.indexing.background_states.insert(
        request_id,
        BackgroundIndexState {
            source: Some(IndexSource::FileList(root.join("FileList.txt"))),
            entries: (0..100_000)
                .map(|index| {
                    let prefix = if index % 2 == 0 { "ignored" } else { "kept" };
                    file_entry(root.join(format!("{prefix}-{index}.txt")))
                })
                .collect(),
            replaced: true,
        },
    );
    app.handle_background_index_response(
        0,
        IndexResponse::Finished {
            request_id,
            source: IndexSource::FileList(root.join("FileList.txt")),
        },
    );
    let frames = drive_background_finalization_with_frame_budget(
        &mut app,
        0,
        request_id,
        IndexSource::FileList(root.join("FileList.txt")),
        BackgroundFinalizationTarget::FilterCursorAtLeast(50_000),
    );
    let filter_frames = frames
        .iter()
        .filter(|frame| {
            if let (Some(before), Some(after)) = (frame.before, frame.after) {
                let advanced = after.filter_cursor.saturating_sub(before.filter_cursor);
                assert!(advanced <= 2_048, "one frame filtered {advanced} entries");
                advanced > 0
            } else {
                false
            }
        })
        .count();
    assert!(filter_frames > 1);
    assert!(app
        .shell
        .indexing
        .background_finalizations
        .get(&request_id)
        .is_some_and(|state| {
            state
                .filtered_entries
                .as_ref()
                .is_some_and(|entries| entries.len() >= 20_000)
        }));

    let _observer_guard = lock_reclaim_drop_observer_for_test();
    let (drop_tx, drop_rx) = mpsc::channel();
    set_reclaim_drop_observer(Some(drop_tx));
    app.shell.ui.ignore_list_enabled = false;
    let started = Instant::now();
    app.handle_background_index_response(
        0,
        IndexResponse::Finished {
            request_id,
            source: IndexSource::FileList(root.join("FileList.txt")),
        },
    );
    assert!(started.elapsed() < Duration::from_millis(100));
    set_reclaim_drop_observer(None);
    let drop_threads = collect_drop_threads_until(
        &drop_rx,
        "flistwalker-tab-reclaimer",
        Duration::from_millis(250),
    );
    assert!(
        drop_threads
            .iter()
            .any(|name| name == "flistwalker-tab-reclaimer"),
        "drop threads: {drop_threads:?}"
    );
    let _ = settle_background_finish_with_frame_budget(
        &mut app,
        0,
        request_id,
        IndexSource::FileList(root.join("FileList.txt")),
    );
    assert_eq!(
        app.shell
            .tabs
            .get(0)
            .expect("background tab")
            .result_state
            .committed
            .entries
            .len(),
        100_000
    );
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_late_filter_policy_change_rolls_back_while_reclaimer_is_full() {
    let root = test_root("tc-207-late-filter-policy-full");
    fs::create_dir_all(&root).expect("create root");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    app.shell.ui.ignore_list_enabled = true;
    app.shell.runtime.ignore_list_terms = Arc::new(vec!["ignored".to_string()]);
    let tab_id = app.shell.tabs.get(0).expect("background tab").id;
    let request_id = app.shell.indexing.allocate_request_id(Some(tab_id));
    {
        let tab = app.shell.tabs.get_mut(0).expect("background tab");
        tab.index_state.pending_index_request_id = Some(request_id);
        tab.index_state.index_in_progress = true;
    }
    app.shell.indexing.background_states.insert(
        request_id,
        BackgroundIndexState {
            source: Some(IndexSource::FileList(root.join("FileList.txt"))),
            entries: (0..100_000)
                .map(|index| file_entry(root.join(format!("entry-{index}.txt"))))
                .collect(),
            replaced: true,
        },
    );
    app.handle_background_index_response(
        0,
        IndexResponse::Finished {
            request_id,
            source: IndexSource::FileList(root.join("FileList.txt")),
        },
    );
    let _ = drive_background_finalization_with_frame_budget(
        &mut app,
        0,
        request_id,
        IndexSource::FileList(root.join("FileList.txt")),
        BackgroundFinalizationTarget::FilterCursorAtLeast(50_000),
    );
    let (cursor_before, output_before) = app
        .shell
        .indexing
        .background_finalizations
        .get(&request_id)
        .map(|state| {
            (
                state.filter_cursor,
                state.filtered_entries.as_ref().map_or(0, Vec::len),
            )
        })
        .expect("late filter phase");
    app.shell.tabs.pause_resource_reclaimer();
    for index in 0..TAB_RESOURCE_RECLAIMER_CAPACITY {
        let mut held = app.capture_active_tab_state(9_500 + index as u64);
        held.result_state.committed.all_entries =
            Arc::new(vec![file_entry(root.join(format!("held-{index}.txt")))]);
        held.index_state
            .set_committed_snapshot_present_for_test(true);
        app.shell
            .tabs
            .retire_tab_resources_for_test(held.take_heavy_resources())
            .expect("fill reclaimer");
    }
    app.shell.ui.ignore_list_enabled = false;
    let started = Instant::now();
    app.handle_background_index_response(
        0,
        IndexResponse::Finished {
            request_id,
            source: IndexSource::FileList(root.join("FileList.txt")),
        },
    );
    assert!(started.elapsed() < Duration::from_millis(100));
    let state = app
        .shell
        .indexing
        .background_finalizations
        .get(&request_id)
        .expect("policy retry remains pending");
    assert_eq!(state.filter_cursor, cursor_before);
    assert_eq!(
        state.filtered_entries.as_ref().map_or(0, Vec::len),
        output_before
    );
    assert!(state.ignore_list_enabled);

    app.shell.tabs.resume_resource_reclaimer();
    let frames = settle_background_finish_with_frame_budget(
        &mut app,
        0,
        request_id,
        IndexSource::FileList(root.join("FileList.txt")),
    );
    assert!(frames
        .iter()
        .all(|elapsed| *elapsed < Duration::from_millis(100)));
    assert_eq!(
        app.shell
            .tabs
            .get(0)
            .expect("background tab")
            .result_state
            .committed
            .entries
            .len(),
        100_000
    );
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_background_finished_walker_kind_queue_settles_incrementally() {
    let root = test_root("tc-207-background-finish-walker-kind-100k");
    fs::create_dir_all(&root).expect("create root");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    let tab_id = app.shell.tabs.get(0).expect("background tab").id;
    let request_id = app.shell.indexing.allocate_request_id(Some(tab_id));
    {
        let tab = app.shell.tabs.get_mut(0).expect("background tab");
        tab.include_files = true;
        tab.include_dirs = false;
        tab.index_state.pending_index_request_id = Some(request_id);
        tab.index_state.index_in_progress = true;
    }
    app.shell.indexing.background_states.insert(
        request_id,
        BackgroundIndexState {
            source: Some(IndexSource::Walker),
            entries: (0..100_000)
                .map(|index| Entry::unknown(root.join(format!("entry-{index}"))))
                .collect(),
            replaced: true,
        },
    );

    app.handle_background_index_response(
        0,
        IndexResponse::Finished {
            request_id,
            source: IndexSource::Walker,
        },
    );
    let frames = drive_background_finalization_with_frame_budget(
        &mut app,
        0,
        request_id,
        IndexSource::Walker,
        BackgroundFinalizationTarget::Removed,
    );
    let kind_frames = frames
        .iter()
        .filter(|frame| {
            assert!(frame.elapsed < Duration::from_millis(100));
            if let (Some(before), Some(after)) = (frame.before, frame.after) {
                let advanced = after.kind_cursor.saturating_sub(before.kind_cursor);
                assert!(advanced <= 2_048, "one frame scanned {advanced} kinds");
                advanced > 0
            } else {
                false
            }
        })
        .count();
    assert!(kind_frames > 1);
    let tab = app.shell.tabs.get(0).expect("background tab");
    assert_eq!(tab.result_state.committed.all_entries.len(), 100_000);
    assert!(tab.result_state.committed.entries.is_empty());
    assert_eq!(tab.index_state.build.pending_kind_paths.len(), 100_000);
    assert_eq!(tab.index_state.build.pending_kind_paths_set.len(), 100_000);
    assert!(tab.index_state.kind_resolution_in_progress);
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_background_finalization_survives_promotion_to_active() {
    let root = test_root("tc-207-background-finalize-promote-active");
    fs::create_dir_all(&root).expect("create root");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    let tab_id = app.shell.tabs.get(0).expect("background tab").id;
    let request_id = app.shell.indexing.allocate_request_id(Some(tab_id));
    {
        let tab = app.shell.tabs.get_mut(0).expect("background tab");
        tab.include_files = true;
        tab.include_dirs = true;
        tab.index_state.pending_index_request_id = Some(request_id);
        tab.index_state.index_in_progress = true;
    }
    app.shell.indexing.background_states.insert(
        request_id,
        BackgroundIndexState {
            source: Some(IndexSource::Walker),
            entries: (0..100_000)
                .map(|index| {
                    let prefix = if index % 4 == 0 || index % 4 == 3 {
                        "ignored"
                    } else {
                        "kept"
                    };
                    let path = root.join(format!("{prefix}-{index}"));
                    if index % 2 == 0 {
                        file_entry(path)
                    } else {
                        dir_entry(path)
                    }
                })
                .collect(),
            replaced: true,
        },
    );
    app.handle_background_index_response(
        0,
        IndexResponse::Finished {
            request_id,
            source: IndexSource::Walker,
        },
    );
    assert!(app
        .shell
        .indexing
        .background_finalizations
        .contains_key(&request_id));
    assert!(app
        .shell
        .tabs
        .get(0)
        .expect("background tab")
        .index_state
        .pending_index_finish
        .is_some());

    app.switch_to_tab_index(0);
    assert_eq!(app.current_tab_id(), Some(tab_id));
    assert!(app.shell.indexing.pending_finish.is_some());
    app.shell.runtime.include_files = false;
    app.shell.runtime.include_dirs = true;
    app.shell.ui.ignore_list_enabled = true;
    app.shell.runtime.ignore_list_terms = Arc::new(vec!["ignored".to_string()]);
    let mut settled = false;
    for _ in 0..2_000 {
        let started = Instant::now();
        app.poll_index_response_with_budget_for_test(Duration::from_millis(4));
        assert!(
            started.elapsed() < Duration::from_millis(100),
            "promotion finalization frame exceeded budget"
        );
        if app.shell.indexing.pending_finish.is_none() {
            settled = true;
            break;
        }
    }

    assert!(settled, "promoted finalization did not settle");
    assert_eq!(app.shell.runtime.all_entries.len(), 100_000);
    assert_eq!(app.shell.runtime.entries.len(), 25_000);
    assert!(app.shell.runtime.entries.iter().all(|entry| {
        entry.kind == Some(EntryKind::dir()) && !entry.path.to_string_lossy().contains("ignored")
    }));
    assert_eq!(app.shell.indexing.lifecycle(), TabResourceLifecycle::Ready);
    assert!(!app
        .shell
        .indexing
        .background_finalizations
        .contains_key(&request_id));
    assert!(!app.shell.indexing.request_tabs.contains_key(&request_id));
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_terminal_finalizers_do_not_block_a_new_active_request_when_reclaimer_is_full() {
    let root = test_root("tc-207-finalizer-slots-active-priority");
    fs::create_dir_all(&root).expect("create root");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    app.create_new_tab();
    let (index_tx, index_rx) = bounded_request_channel::<IndexRequest>(2);
    app.shell.indexing.tx = index_tx;
    reset_index_request_state_for_test(&mut app);

    app.shell.tabs.pause_resource_reclaimer();
    for index in 0..TAB_RESOURCE_RECLAIMER_CAPACITY {
        let mut held = app.capture_active_tab_state(8_000 + index as u64);
        held.result_state.committed.all_entries =
            Arc::new(vec![file_entry(root.join(format!("held-{index}.txt")))]);
        held.index_state
            .set_committed_snapshot_present_for_test(true);
        app.shell
            .tabs
            .retire_tab_resources_for_test(held.take_heavy_resources())
            .expect("fill reclaimer");
    }

    for tab_index in 0..2 {
        let tab_id = app.shell.tabs.get(tab_index).expect("inactive tab").id;
        let request_id = app.shell.indexing.allocate_request_id(Some(tab_id));
        {
            let tab = app.shell.tabs.get_mut(tab_index).expect("inactive tab");
            tab.index_state.pending_index_request_id = Some(request_id);
            tab.index_state.index_in_progress = true;
        }
        app.shell.indexing.background_states.insert(
            request_id,
            BackgroundIndexState {
                source: Some(IndexSource::FileList(root.join("FileList.txt"))),
                entries: (0..100_000)
                    .map(|index| {
                        file_entry(root.join(format!("tab-{tab_index}-entry-{index}.txt")))
                    })
                    .collect(),
                replaced: true,
            },
        );
        app.shell.indexing.inflight_requests.insert(request_id);

        app.handle_background_index_response(
            tab_index,
            IndexResponse::Finished {
                request_id,
                source: IndexSource::FileList(root.join("FileList.txt")),
            },
        );
        assert!(!app.shell.indexing.inflight_requests.contains(&request_id));
    }

    assert!(app.shell.indexing.background_finalizations.is_full());
    assert_eq!(
        app.shell.indexing.background_finalizations.keys().count(),
        2
    );
    let active_tab_id = app.current_tab_id().expect("active tab");
    app.request_index_refresh();
    let request = index_rx
        .try_recv()
        .expect("active request must bypass occupied finalization slots");
    assert_eq!(request.tab_id, active_tab_id);

    app.shell.tabs.resume_resource_reclaimer();
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_terminal_waits_in_mailbox_and_activation_commits_complete_snapshot() {
    let root = test_root("tc-207-terminal-mailbox-activation-barrier");
    fs::create_dir_all(&root).expect("create root");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    app.create_new_tab();
    app.create_new_tab();
    reset_index_request_state_for_test(&mut app);
    let original_active_id = app.current_tab_id().expect("active tab");

    for tab_index in 0..2 {
        let tab_id = app.shell.tabs.get(tab_index).expect("inactive tab").id;
        let request_id = app.shell.indexing.allocate_request_id(Some(tab_id));
        {
            let tab = app.shell.tabs.get_mut(tab_index).expect("inactive tab");
            tab.index_state.pending_index_request_id = Some(request_id);
            tab.index_state.index_in_progress = true;
        }
        app.shell.indexing.background_states.insert(
            request_id,
            BackgroundIndexState {
                source: Some(IndexSource::FileList(root.join("FileList.txt"))),
                entries: (0..100_000)
                    .map(|index| {
                        file_entry(root.join(format!("slot-{tab_index}-entry-{index}.txt")))
                    })
                    .collect(),
                replaced: true,
            },
        );
        app.handle_background_index_response(
            tab_index,
            IndexResponse::Finished {
                request_id,
                source: IndexSource::FileList(root.join("FileList.txt")),
            },
        );
    }
    assert!(app.shell.indexing.background_finalizations.is_full());

    let waiting_tab_index = 2;
    let waiting_tab_id = app
        .shell
        .tabs
        .get(waiting_tab_index)
        .expect("waiting tab")
        .id;
    let waiting_request_id = app.shell.indexing.allocate_request_id(Some(waiting_tab_id));
    {
        let tab = app
            .shell
            .tabs
            .get_mut(waiting_tab_index)
            .expect("waiting tab");
        tab.index_state.pending_index_request_id = Some(waiting_request_id);
        tab.index_state.index_in_progress = true;
        tab.index_state.build.index.entries = (0..20_000)
            .map(|index| file_entry(root.join(format!("partial-{index}.txt"))))
            .collect();
        tab.index_state.pending_index_entries_request_id = Some(waiting_request_id);
        tab.index_state.build.pending_entries = (0..20_000)
            .map(|index| IndexEntry {
                path: root.join(format!("pending-{index}.txt")),
                kind: EntryKind::file(),
                kind_known: true,
            })
            .collect();
    }
    app.shell.indexing.background_states.insert(
        waiting_request_id,
        BackgroundIndexState {
            source: Some(IndexSource::FileList(root.join("FileList.txt"))),
            entries: (0..60_000)
                .map(|index| file_entry(root.join(format!("continuation-{index}.txt"))))
                .collect(),
            replaced: false,
        },
    );
    let waiting_mailbox = app
        .shell
        .indexing
        .response_mailboxes
        .lock()
        .expect("mailboxes")
        .get(&waiting_request_id)
        .cloned()
        .expect("waiting mailbox");
    waiting_mailbox
        .try_publish(IndexResponse::Finished {
            request_id: waiting_request_id,
            source: IndexSource::FileList(root.join("FileList.txt")),
        })
        .expect("publish terminal");
    app.shell
        .indexing
        .inflight_requests
        .insert(waiting_request_id);

    app.switch_to_tab_index(waiting_tab_index);
    assert_eq!(app.current_tab_id(), Some(original_active_id));
    assert_eq!(
        app.shell.tabs.pending_activation_tab_id,
        Some(waiting_tab_id)
    );
    let current_tab_index = app.shell.tabs.active_tab_index();
    app.switch_to_tab_index(current_tab_index);
    assert_eq!(
        app.shell.tabs.pending_activation_tab_id, None,
        "reselecting the current tab must cancel a deferred activation intent"
    );
    app.switch_to_tab_index(waiting_tab_index);
    assert_eq!(
        app.shell.tabs.pending_activation_tab_id,
        Some(waiting_tab_id)
    );
    assert!(waiting_mailbox.has_terminal_response());
    assert!(app
        .shell
        .tabs
        .get(waiting_tab_index)
        .expect("waiting tab")
        .index_state
        .pending_index_finish
        .is_none());

    let admitted_request_id = *app
        .shell
        .indexing
        .background_finalizations
        .keys()
        .next()
        .expect("occupied finalizer");
    let admitted_tab_id = *app
        .shell
        .indexing
        .request_tabs
        .get(&admitted_request_id)
        .expect("finalizer owner");
    let admitted_tab_index = app
        .find_tab_index_by_id(admitted_tab_id)
        .expect("finalizer tab");
    let source = IndexSource::FileList(root.join("FileList.txt"));
    let _ = settle_background_finish_with_frame_budget(
        &mut app,
        admitted_tab_index,
        admitted_request_id,
        source,
    );

    let mut settled = false;
    for _ in 0..2_000 {
        app.poll_index_response_with_budget_for_test(Duration::from_millis(4));
        if app.current_tab_id() == Some(waiting_tab_id)
            && app.shell.indexing.pending_finish.is_none()
        {
            settled = true;
            break;
        }
    }
    assert!(settled, "deferred activation did not settle");
    assert_eq!(app.shell.runtime.all_entries.len(), 100_000);
    assert!(app
        .shell
        .runtime
        .all_entries
        .iter()
        .any(|entry| entry.path.ends_with("partial-0.txt")));
    assert!(app
        .shell
        .runtime
        .all_entries
        .iter()
        .any(|entry| entry.path.ends_with("pending-0.txt")));
    assert!(app
        .shell
        .runtime
        .all_entries
        .iter()
        .any(|entry| entry.path.ends_with("continuation-0.txt")));
    assert!(!app
        .shell
        .indexing
        .background_states
        .contains_key(&waiting_request_id));
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_promotion_before_terminal_uses_active_finalization_barrier() {
    let root = test_root("tc-207-promotion-before-terminal-barrier");
    fs::create_dir_all(&root).expect("create root");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    app.create_new_tab();
    app.create_new_tab();
    reset_index_request_state_for_test(&mut app);

    for tab_index in 0..2 {
        let tab_id = app.shell.tabs.get(tab_index).expect("inactive tab").id;
        let request_id = app.shell.indexing.allocate_request_id(Some(tab_id));
        {
            let tab = app.shell.tabs.get_mut(tab_index).expect("inactive tab");
            tab.index_state.pending_index_request_id = Some(request_id);
            tab.index_state.index_in_progress = true;
        }
        app.shell.indexing.background_states.insert(
            request_id,
            BackgroundIndexState {
                source: Some(IndexSource::FileList(root.join("FileList.txt"))),
                entries: (0..100_000)
                    .map(|index| file_entry(root.join(format!("occupied-{tab_index}-{index}.txt"))))
                    .collect(),
                replaced: true,
            },
        );
        app.handle_background_index_response(
            tab_index,
            IndexResponse::Finished {
                request_id,
                source: IndexSource::FileList(root.join("FileList.txt")),
            },
        );
    }
    assert!(app.shell.indexing.background_finalizations.is_full());

    let promoted_index = 2;
    let promoted_tab_id = app.shell.tabs.get(promoted_index).expect("promoted tab").id;
    let request_id = app
        .shell
        .indexing
        .allocate_request_id(Some(promoted_tab_id));
    {
        let tab = app
            .shell
            .tabs
            .get_mut(promoted_index)
            .expect("promoted tab");
        tab.index_state.pending_index_request_id = Some(request_id);
        tab.index_state.index_in_progress = true;
        tab.index_state.build.index.entries = (0..20_000)
            .map(|index| file_entry(root.join(format!("partial-{index}.txt"))))
            .collect();
        tab.index_state.pending_index_entries_request_id = Some(request_id);
        tab.index_state.build.pending_entries = (0..20_000)
            .map(|index| IndexEntry {
                path: root.join(format!("pending-{index}.txt")),
                kind: EntryKind::file(),
                kind_known: true,
            })
            .collect();
    }
    app.shell.indexing.background_states.insert(
        request_id,
        BackgroundIndexState {
            source: Some(IndexSource::FileList(root.join("FileList.txt"))),
            entries: (0..60_000)
                .map(|index| file_entry(root.join(format!("continuation-{index}.txt"))))
                .collect(),
            replaced: false,
        },
    );

    app.switch_to_tab_index(promoted_index);
    assert_eq!(app.current_tab_id(), Some(promoted_tab_id));
    let mailbox = app
        .shell
        .indexing
        .response_mailboxes
        .lock()
        .expect("mailboxes")
        .get(&request_id)
        .cloned()
        .expect("promoted mailbox");
    mailbox
        .try_publish(IndexResponse::Finished {
            request_id,
            source: IndexSource::FileList(root.join("FileList.txt")),
        })
        .expect("publish promoted terminal");
    app.shell.indexing.inflight_requests.insert(request_id);
    app.poll_index_response_with_budget_for_test(Duration::from_millis(4));
    assert!(mailbox.has_terminal_response());
    assert!(!app.shell.indexing.inflight_requests.contains(&request_id));
    assert!(app.shell.indexing.pending_finish.is_none());
    assert!(app
        .shell
        .indexing
        .background_states
        .contains_key(&request_id));

    let admitted_request_id = *app
        .shell
        .indexing
        .background_finalizations
        .keys()
        .next()
        .expect("occupied finalizer");
    let admitted_tab_id = *app
        .shell
        .indexing
        .request_tabs
        .get(&admitted_request_id)
        .expect("finalizer owner");
    let admitted_tab_index = app
        .find_tab_index_by_id(admitted_tab_id)
        .expect("finalizer tab");
    let _ = settle_background_finish_with_frame_budget(
        &mut app,
        admitted_tab_index,
        admitted_request_id,
        IndexSource::FileList(root.join("FileList.txt")),
    );

    let mut settled = false;
    for _ in 0..2_000 {
        app.poll_index_response_with_budget_for_test(Duration::from_millis(4));
        if app.shell.indexing.pending_finish.is_none()
            && !app
                .shell
                .indexing
                .background_states
                .contains_key(&request_id)
            && !app
                .shell
                .indexing
                .background_finalizations
                .contains_key(&request_id)
            && app.shell.indexing.pending_request_id != Some(request_id)
            && !app.shell.indexing.request_tabs.contains_key(&request_id)
        {
            settled = true;
            break;
        }
    }
    assert!(settled, "promoted terminal barrier did not settle");
    assert_eq!(app.shell.runtime.all_entries.len(), 100_000);
    assert!(app
        .shell
        .runtime
        .all_entries
        .iter()
        .any(|entry| entry.path.ends_with("partial-0.txt")));
    assert!(app
        .shell
        .runtime
        .all_entries
        .iter()
        .any(|entry| entry.path.ends_with("pending-0.txt")));
    assert!(app
        .shell
        .runtime
        .all_entries
        .iter()
        .any(|entry| entry.path.ends_with("continuation-0.txt")));
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_replace_all_discarded_build_moves_to_reclaimer_without_ui_drop() {
    let root = test_root("tc-207-replace-all-discard-reclaimer");
    fs::create_dir_all(&root).expect("create root");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    let tab_id = app.shell.tabs.get(0).expect("background tab").id;
    let request_id = app.shell.indexing.allocate_request_id(Some(tab_id));
    {
        let tab = app.shell.tabs.get_mut(0).expect("background tab");
        tab.index_state.pending_index_request_id = Some(request_id);
        tab.index_state.pending_index_entries_request_id = Some(request_id);
        tab.index_state.index_in_progress = true;
        tab.index_state.build.index.entries = (0..50_000)
            .map(|index| file_entry(root.join(format!("old-{index}.txt"))))
            .collect();
        tab.index_state.build.pending_entries = (0..50_000)
            .map(|index| IndexEntry {
                path: root.join(format!("pending-{index}.txt")),
                kind: EntryKind::file(),
                kind_known: true,
            })
            .collect();
    }
    app.shell.indexing.background_states.insert(
        request_id,
        BackgroundIndexState {
            source: Some(IndexSource::FileList(root.join("FileList.txt"))),
            entries: vec![file_entry(root.join("replacement.txt"))].into(),
            replaced: true,
        },
    );
    let _observer_guard = lock_reclaim_drop_observer_for_test();
    let (drop_tx, drop_rx) = mpsc::channel();
    set_reclaim_drop_observer(Some(drop_tx));

    let started = Instant::now();
    app.handle_background_index_response(
        0,
        IndexResponse::Finished {
            request_id,
            source: IndexSource::FileList(root.join("FileList.txt")),
        },
    );
    assert!(started.elapsed() < Duration::from_millis(100));

    set_reclaim_drop_observer(None);
    let tab = app.shell.tabs.get(0).expect("background tab");
    assert_eq!(tab.result_state.committed.all_entries.len(), 1);
    assert_eq!(
        tab.result_state.committed.all_entries[0].path,
        root.join("replacement.txt")
    );
    let drop_threads = collect_drop_threads_until(
        &drop_rx,
        "flistwalker-tab-reclaimer",
        Duration::from_millis(250),
    );
    assert!(
        drop_threads
            .iter()
            .any(|name| name == "flistwalker-tab-reclaimer"),
        "drop threads: {drop_threads:?}"
    );
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_background_failure_reclaims_tab_and_coordinator_building_off_ui() {
    let root = test_root("tc-207-background-failure-reclaim");
    fs::create_dir_all(&root).expect("create root");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    let background_tab_id = app.shell.tabs.get(0).expect("background tab").id;
    {
        let tab = app.shell.tabs.get_mut(0).expect("background tab");
        tab.index_state
            .set_lifecycle_for_test(TabResourceLifecycle::Loading);
        tab.index_state.pending_index_request_id = Some(1_207);
        tab.index_state.index_in_progress = true;
        tab.index_state.build.index.entries = (0..1_000)
            .map(|index| file_entry(root.join(format!("tab-building-{index}.txt"))))
            .collect();
    }
    app.shell
        .indexing
        .request_tabs
        .insert(1_207, background_tab_id);
    app.shell.indexing.background_states.insert(
        1_207,
        BackgroundIndexState {
            source: Some(IndexSource::Walker),
            entries: (0..1_000)
                .map(|index| file_entry(root.join(format!("coordinator-{index}.txt"))))
                .collect(),
            replaced: true,
        },
    );
    let _observer_guard = lock_reclaim_drop_observer_for_test();
    let (drop_tx, drop_rx) = mpsc::channel();
    set_reclaim_drop_observer(Some(drop_tx));

    app.handle_background_index_response(
        0,
        IndexResponse::Failed {
            request_id: 1_207,
            error: "fixture failure".to_string(),
        },
    );

    set_reclaim_drop_observer(None);
    let tab = app.shell.tabs.get(0).expect("background tab");
    assert!(!tab.index_state.build_reclaim_pending);
    assert!(tab.index_state.pending_index_request_id.is_none());
    assert_eq!(tab.index_state.build.index.entries.capacity(), 0);
    assert!(!app.shell.indexing.background_states.contains_key(&1_207));
    let drop_threads = collect_drop_threads_until(
        &drop_rx,
        "flistwalker-tab-reclaimer",
        Duration::from_millis(250),
    );
    assert!(
        drop_threads
            .iter()
            .any(|name| name == "flistwalker-tab-reclaimer"),
        "drop threads: {drop_threads:?}"
    );
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_background_replace_all_waits_for_reclaimer_and_preserves_old_build() {
    let root = test_root("tc-207-background-replace-all-full");
    fs::create_dir_all(&root).expect("create root");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    let background_tab_id = app.shell.tabs.get(0).expect("background tab").id;
    let request_id = app
        .shell
        .indexing
        .allocate_request_id(Some(background_tab_id));
    {
        let tab = app.shell.tabs.get_mut(0).expect("background tab");
        tab.index_state.pending_index_request_id = Some(request_id);
        tab.index_state.index_in_progress = true;
    }
    app.shell.indexing.background_states.insert(
        request_id,
        BackgroundIndexState {
            source: Some(IndexSource::FileList(root.join("FileList.txt"))),
            entries: (0..2_000)
                .map(|index| file_entry(root.join(format!("old-{index}.txt"))))
                .collect(),
            replaced: false,
        },
    );
    app.shell.tabs.pause_resource_reclaimer();
    for index in 0..TAB_RESOURCE_RECLAIMER_CAPACITY {
        let mut tab = app.capture_active_tab_state(3_200 + index as u64);
        tab.result_state.committed.all_entries =
            Arc::new(vec![file_entry(root.join(format!("held-{index}.txt")))]);
        app.shell
            .tabs
            .retire_tab_resources_for_test(tab.take_heavy_resources())
            .expect("fill reclaimer");
    }

    assert!(
        !app.try_apply_replace_all_response(IndexResponse::ReplaceAll {
            request_id,
            entries: vec![IndexEntry {
                path: root.join("replacement.txt"),
                kind: EntryKind::file(),
                kind_known: true,
            }],
        })
    );

    assert!(app.shell.indexing.pending_replace_all.is_some());
    assert_eq!(
        app.shell
            .indexing
            .background_states
            .get(&request_id)
            .expect("old state restored")
            .entries
            .len(),
        2_000
    );

    app.shell.tabs.resume_resource_reclaimer();
    app.poll_index_response();

    let replacement = app
        .shell
        .indexing
        .background_states
        .get(&request_id)
        .expect("replacement state");
    assert!(app.shell.indexing.pending_replace_all.is_none());
    assert!(replacement.replaced);
    assert_eq!(replacement.entries.len(), 1);
    assert_eq!(replacement.entries[0].path, root.join("replacement.txt"));
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_background_failure_debt_switches_active_and_cleans_routing() {
    let root = test_root("tc-207-background-debt-switch-active");
    fs::create_dir_all(&root).expect("create root");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    let background_tab_id = app.shell.tabs.get(0).expect("background tab").id;
    let request_id = app
        .shell
        .indexing
        .allocate_request_id(Some(background_tab_id));
    {
        let tab = app.shell.tabs.get_mut(0).expect("background tab");
        tab.index_state.pending_index_request_id = Some(request_id);
        tab.index_state.index_in_progress = true;
        tab.index_state.build.index.entries = (0..2_000)
            .map(|index| file_entry(root.join(format!("building-{index}.txt"))))
            .collect();
    }
    app.shell.tabs.pause_resource_reclaimer();
    for index in 0..TAB_RESOURCE_RECLAIMER_CAPACITY {
        let mut tab = app.capture_active_tab_state(3_300 + index as u64);
        tab.result_state.committed.all_entries =
            Arc::new(vec![file_entry(root.join(format!("held-{index}.txt")))]);
        app.shell
            .tabs
            .retire_tab_resources_for_test(tab.take_heavy_resources())
            .expect("fill reclaimer");
    }

    app.handle_background_index_response(
        0,
        IndexResponse::Failed {
            request_id,
            error: "fixture failure".to_string(),
        },
    );
    assert!(
        app.shell
            .tabs
            .get(0)
            .unwrap()
            .index_state
            .build_reclaim_pending
    );

    app.switch_to_tab_index(0);
    assert_eq!(app.current_tab_id(), Some(background_tab_id));
    assert!(app.shell.indexing.build_reclaim_pending);

    app.shell.tabs.resume_resource_reclaimer();
    app.poll_index_response();

    assert!(!app.shell.indexing.build_reclaim_pending);
    assert!(app.shell.indexing.build_reclaim_request_id.is_none());
    assert!(!app.shell.indexing.request_tabs.contains_key(&request_id));
    assert!(!app
        .shell
        .indexing
        .response_mailboxes
        .lock()
        .expect("mailboxes")
        .contains_key(&request_id));
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_midflight_background_close_reclaims_coordinator_and_mailbox_off_ui() {
    let root = test_root("tc-207-midflight-background-close");
    fs::create_dir_all(&root).expect("create root");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    assert_eq!(app.shell.tabs.active_tab_index(), 1);
    let closing_tab_id = app.shell.tabs.get(0).expect("closing tab").id;
    let request_id = app.shell.indexing.allocate_request_id(Some(closing_tab_id));
    {
        let tab = app.shell.tabs.get_mut(0).expect("closing tab");
        tab.index_state.pending_index_request_id = Some(request_id);
        tab.index_state.index_in_progress = true;
    }
    app.shell.indexing.background_states.insert(
        request_id,
        BackgroundIndexState {
            source: Some(IndexSource::Walker),
            entries: (0..1_000)
                .map(|index| file_entry(root.join(format!("state-{index}.txt"))))
                .collect(),
            replaced: false,
        },
    );
    let mailbox = app
        .shell
        .indexing
        .response_mailboxes
        .lock()
        .expect("mailboxes")
        .get(&request_id)
        .cloned()
        .expect("request mailbox");
    mailbox
        .try_publish(IndexResponse::Batch {
            request_id,
            entries: (0..1_000)
                .map(|index| IndexEntry {
                    path: root.join(format!("mailbox-{index}.txt")),
                    kind: EntryKind::file(),
                    kind_known: true,
                })
                .collect(),
        })
        .expect("seed mailbox payload");
    drop(mailbox);
    let _observer_guard = lock_reclaim_drop_observer_for_test();
    let (drop_tx, drop_rx) = mpsc::channel();
    set_reclaim_drop_observer(Some(drop_tx));
    assert!(app.shell.tabs.get(0).unwrap().index_state.index_in_progress);
    assert_eq!(
        app.shell
            .tabs
            .get(0)
            .unwrap()
            .index_state
            .pending_index_request_id,
        Some(request_id)
    );

    app.close_tab_index(0);

    set_reclaim_drop_observer(None);
    assert_eq!(app.shell.tabs.len(), 1);
    assert_eq!(app.shell.tabs.closed_tab_count(), 1);
    assert!(!app.shell.indexing.request_tabs.contains_key(&request_id));
    assert!(!app
        .shell
        .indexing
        .background_states
        .contains_key(&request_id));
    assert!(!app
        .shell
        .indexing
        .response_mailboxes
        .lock()
        .expect("mailboxes")
        .contains_key(&request_id));
    let drop_threads = collect_drop_threads_until(
        &drop_rx,
        "flistwalker-tab-reclaimer",
        Duration::from_millis(250),
    );
    assert!(
        drop_threads
            .iter()
            .any(|name| name == "flistwalker-tab-reclaimer"),
        "drop threads: {drop_threads:?}"
    );
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_multigeneration_background_close_reclaims_every_request_owner() {
    let root = test_root("tc-207-multigeneration-background-close");
    fs::create_dir_all(&root).expect("create root");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    let tab_id = app.shell.tabs.get(0).expect("closing tab").id;
    let superseded_request_id = app.shell.indexing.allocate_request_id(Some(tab_id));
    let current_request_id = app.shell.indexing.allocate_request_id(Some(tab_id));
    {
        let tab = app.shell.tabs.get_mut(0).expect("closing tab");
        tab.index_state.pending_index_request_id = Some(current_request_id);
        tab.index_state.index_in_progress = true;
    }
    for request_id in [superseded_request_id, current_request_id] {
        app.shell.indexing.background_states.insert(
            request_id,
            BackgroundIndexState {
                source: Some(IndexSource::Walker),
                entries: (0..1_000)
                    .map(|index| file_entry(root.join(format!("state-{request_id}-{index}.txt"))))
                    .collect(),
                replaced: false,
            },
        );
        let mailbox = app
            .shell
            .indexing
            .response_mailboxes
            .lock()
            .expect("mailboxes")
            .get(&request_id)
            .cloned()
            .expect("mailbox");
        mailbox
            .try_publish(IndexResponse::Batch {
                request_id,
                entries: vec![IndexEntry {
                    path: root.join(format!("mailbox-{request_id}.txt")),
                    kind: EntryKind::file(),
                    kind_known: true,
                }],
            })
            .expect("seed mailbox");
    }
    let _observer_guard = lock_reclaim_drop_observer_for_test();
    let (drop_tx, drop_rx) = mpsc::channel();
    set_reclaim_drop_observer(Some(drop_tx));

    app.close_tab_index(0);

    set_reclaim_drop_observer(None);
    assert_eq!(app.shell.tabs.len(), 1);
    assert_eq!(app.shell.tabs.closed_tab_count(), 1);
    for request_id in [superseded_request_id, current_request_id] {
        assert!(!app.shell.indexing.request_tabs.contains_key(&request_id));
        assert!(!app
            .shell
            .indexing
            .background_states
            .contains_key(&request_id));
        assert!(!app
            .shell
            .indexing
            .response_mailboxes
            .lock()
            .expect("mailboxes")
            .contains_key(&request_id));
    }
    let drop_threads = collect_drop_threads_until(
        &drop_rx,
        "flistwalker-tab-reclaimer",
        Duration::from_millis(250),
    );
    assert!(
        drop_threads
            .iter()
            .any(|name| name == "flistwalker-tab-reclaimer"),
        "drop threads: {drop_threads:?}"
    );
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_multigeneration_background_close_rolls_back_every_owner_when_full() {
    let root = test_root("tc-207-multigeneration-background-close-full");
    fs::create_dir_all(&root).expect("create root");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    let tab_id = app.shell.tabs.get(0).expect("closing tab").id;
    let superseded_request_id = app.shell.indexing.allocate_request_id(Some(tab_id));
    let current_request_id = app.shell.indexing.allocate_request_id(Some(tab_id));
    {
        let tab = app.shell.tabs.get_mut(0).expect("closing tab");
        tab.index_state.pending_index_request_id = Some(current_request_id);
        tab.index_state.index_in_progress = true;
    }
    for request_id in [superseded_request_id, current_request_id] {
        app.shell.indexing.background_states.insert(
            request_id,
            BackgroundIndexState {
                source: Some(IndexSource::Walker),
                entries: vec![file_entry(root.join(format!("state-{request_id}.txt")))].into(),
                replaced: false,
            },
        );
        let mailbox = app
            .shell
            .indexing
            .response_mailboxes
            .lock()
            .expect("mailboxes")
            .get(&request_id)
            .cloned()
            .expect("mailbox");
        mailbox
            .try_publish(IndexResponse::Batch {
                request_id,
                entries: vec![IndexEntry {
                    path: root.join(format!("mailbox-{request_id}.txt")),
                    kind: EntryKind::file(),
                    kind_known: true,
                }],
            })
            .expect("seed mailbox");
    }
    app.shell.tabs.pause_resource_reclaimer();
    for index in 0..TAB_RESOURCE_RECLAIMER_CAPACITY {
        let mut held = app.capture_active_tab_state(7_000 + index as u64);
        held.result_state.committed.all_entries =
            Arc::new(vec![file_entry(root.join(format!("held-{index}.txt")))]);
        app.shell
            .tabs
            .retire_tab_resources_for_test(held.take_heavy_resources())
            .expect("fill reclaimer");
    }

    app.close_tab_index(0);

    assert_eq!(app.shell.tabs.len(), 2);
    assert_eq!(app.shell.tabs.closed_tab_count(), 0);
    assert_eq!(
        app.shell
            .tabs
            .get(0)
            .expect("closing tab retained")
            .index_state
            .pending_index_request_id,
        Some(current_request_id)
    );
    for request_id in [superseded_request_id, current_request_id] {
        assert_eq!(
            app.shell.indexing.request_tabs.get(&request_id),
            Some(&tab_id)
        );
        assert!(app
            .shell
            .indexing
            .background_states
            .contains_key(&request_id));
        let mailbox = app
            .shell
            .indexing
            .response_mailboxes
            .lock()
            .expect("mailboxes")
            .get(&request_id)
            .cloned()
            .expect("mailbox restored");
        assert!(mailbox.has_payload());
    }
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_background_terminal_debt_coalesces_refresh_to_one_follow_up() {
    let root = test_root("tc-207-background-terminal-follow-up");
    fs::create_dir_all(&root).expect("create root");
    let old = file_entry(root.join("old.txt"));
    let new = file_entry(root.join("new.txt"));
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    let background_tab_id = app.shell.tabs.get(0).expect("background tab").id;
    let (request_tx, request_rx) = bounded_request_channel::<IndexRequest>(2);
    app.shell.indexing.tx = request_tx;
    app.shell.indexing.pending_queue.clear();
    app.shell.indexing.inflight_requests.clear();
    app.shell.indexing.request_tabs.clear();
    {
        let tab = app.shell.tabs.get_mut(0).expect("background tab");
        tab.index_state
            .set_lifecycle_for_test(TabResourceLifecycle::Refreshing);
        tab.index_state
            .set_committed_snapshot_present_for_test(true);
        tab.result_state.committed.all_entries = Arc::new(vec![old.clone()]);
        tab.result_state.committed.entries = Arc::new(vec![old]);
        tab.index_state.build.index.entries = vec![new];
        tab.index_state.pending_index_request_id = Some(607);
        tab.index_state.pending_index_finish = Some(PendingActiveIndexFinish {
            request_id: 607,
            source: IndexSource::Walker,
        });
    }
    app.shell
        .indexing
        .request_tabs
        .insert(607, background_tab_id);
    app.shell.tabs.pause_resource_reclaimer();
    for index in 0..TAB_RESOURCE_RECLAIMER_CAPACITY {
        let mut tab = app.capture_active_tab_state(1_700 + index as u64);
        tab.result_state.committed.all_entries =
            Arc::new(vec![file_entry(root.join(format!("held-{index}.txt")))]);
        app.shell
            .tabs
            .retire_tab_resources_for_test(tab.take_heavy_resources())
            .expect("fill reclaimer");
    }
    let next_request_id = app.shell.indexing.next_request_id;

    app.request_background_index_refresh_for_tab(0);
    app.request_background_index_refresh_for_tab(0);

    let waiting = app.shell.tabs.get(0).expect("background tab");
    assert_eq!(waiting.index_state.pending_index_request_id, Some(607));
    assert_eq!(waiting.index_state.build.index.entries.len(), 1);
    assert_eq!(app.shell.indexing.next_request_id, next_request_id);
    assert!(request_rx.try_recv().is_err());

    app.shell.tabs.resume_resource_reclaimer();
    app.poll_index_response();

    let replay = request_rx
        .try_recv()
        .expect("one coalesced background refresh");
    assert_eq!(replay.tab_id, background_tab_id);
    assert!(request_rx.try_recv().is_err());
    assert_eq!(app.shell.indexing.next_request_id, next_request_id + 1);
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tc_207_background_search_restores_evicted_selected_path() {
    let root = test_root("tc-207-background-selected-path");
    fs::create_dir_all(&root).expect("create root");
    let first = root.join("first.txt");
    let selected = root.join("selected.txt");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    let background_tab_id = app.shell.tabs.get(0).expect("background tab").id;
    {
        let tab = app.shell.tabs.get_mut(0).expect("background tab");
        tab.query_state.query = "selected".to_string();
        tab.result_state.evicted_selected_path = Some(selected.clone());
        tab.index_state.index_in_progress = true;
        tab.pending_request_id = Some(707);
        tab.search_in_progress = true;
    }

    app.apply_background_search_response(
        background_tab_id,
        SearchResponse {
            request_id: 706,
            results: vec![(first.clone(), 2.0)],
            total_match_count: 1,
            sort_mode: ResultSortMode::Score,
            sort_scope: ResultSortScope::ShownResults,
            error: None,
        },
    );
    assert_eq!(
        app.shell
            .tabs
            .get(0)
            .expect("background tab")
            .result_state
            .evicted_selected_path
            .as_ref(),
        Some(&selected),
        "background partial search must retain the restore intent"
    );
    app.shell
        .tabs
        .get_mut(0)
        .expect("background tab")
        .index_state
        .index_in_progress = false;

    app.apply_background_search_response(
        background_tab_id,
        SearchResponse {
            request_id: 707,
            results: vec![(first, 2.0), (selected.clone(), 1.0)],
            total_match_count: 2,
            sort_mode: ResultSortMode::Score,
            sort_scope: ResultSortScope::ShownResults,
            error: None,
        },
    );

    let tab = app.shell.tabs.get(0).expect("background tab");
    assert_eq!(tab.result_state.committed.current_row, Some(1));
    assert_eq!(tab.result_state.committed.results[1].0, selected);
    assert!(tab.result_state.evicted_selected_path.is_none());
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn canceled_background_preview_settles_and_reloads_on_activation() {
    let root = test_root("preview-cancel-owner");
    fs::create_dir_all(&root).unwrap();
    let path = root.join("sample.txt");
    fs::write(&path, "sample").unwrap();
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.shell.runtime.committed_for_test_mut().entries = Arc::new(vec![file_entry(path.clone())]);
    app.shell.runtime.committed_for_test_mut().results = vec![(path.clone(), 1.0)];
    app.shell.runtime.committed_for_test_mut().base_results = app.shell.runtime.results.clone();
    app.shell.runtime.committed_for_test_mut().current_row = Some(0);
    app.set_entry_kind(&path, EntryKind::file());
    let (tx, rx) = mpsc::channel();
    app.shell.worker_bus.preview.tx = tx;
    app.shell.worker_bus.preview.worker_inflight_request_id = None;
    app.request_preview_for_current();
    let obsolete = rx.try_recv().unwrap();
    app.request_preview_for_current();
    assert!(rx.try_recv().is_err(), "only one request may be in flight");
    app.create_new_tab();
    while rx.try_recv().is_ok() {}
    app.apply_background_preview_response(PreviewResponse {
        request_id: obsolete.request_id,
        path: path.clone(),
        preview: String::new(),
        canceled: true,
        document: None,
        page_error: None,
        is_more: false,
    });
    let request = rx
        .try_recv()
        .expect("queued latest preview is dispatched after cancellation");
    assert_eq!(
        app.shell.tabs.get(0).unwrap().pending_preview_request_id,
        Some(request.request_id)
    );
    app.apply_background_preview_response(PreviewResponse {
        request_id: request.request_id,
        path: path.clone(),
        preview: String::new(),
        canceled: true,
        document: None,
        page_error: None,
        is_more: false,
    });
    let tab = app.shell.tabs.get(0).unwrap();
    assert!(!tab.preview_in_progress);
    assert!(tab.pending_preview_request_id.is_none());
    assert!(tab.preview_reload_pending);
    assert_eq!(app.preview_request_tab(request.request_id), None);
    app.switch_to_tab_index(0);
    assert!(rx.try_iter().any(|request| request.path == path));
    let _ = fs::remove_dir_all(root);
}
