#![allow(unused_imports)]

pub(super) use crate::app::index_coordinator::IndexResponseRoute;
pub(super) use crate::app::search_coordinator::SearchResponseRoute;
pub(super) use crate::app::session::UiState;
pub(super) use crate::app::state::{
    BackgroundIndexState, PendingActiveIndexFinish, PendingFileListAfterIndex,
    PendingFileListAncestorConfirmation, PendingFileListConfirmation,
    PendingFileListIndexCompletionNotice, PendingFileListUseWalkerConfirmation,
    PendingIndexRefreshMode, SortMetadata, UpdateCheckFailureState, UpdateInstallFailureState,
    UpdateManager, UpdatePromptState, UpdateState,
};
pub(super) use crate::app::tab_resources::{
    lock_reclaim_drop_observer_for_test, set_reclaim_drop_observer, RetiredIndexBuildResources,
    TabResourceReclaimer, TAB_RECENT_INACTIVE_ENGAGEMENT_THRESHOLD, TAB_RECENT_INACTIVE_GRACE,
    TAB_RESOURCE_CACHE_HARD_MAX_COUNT, TAB_RESOURCE_CACHE_HARD_MAX_WEIGHT,
    TAB_RESOURCE_CACHE_MAX_COUNT, TAB_RESOURCE_CACHE_MAX_WEIGHT, TAB_RESOURCE_RECLAIMER_CAPACITY,
};
pub(super) use crate::app::worker::channel::bounded_request_channel;
pub(super) use crate::app::worker::protocol::{
    KindResolveRequest, KindResolveResponse, UpdateRequestKind,
};
pub(super) use crate::app::{clear_process_shutdown_request, process_shutdown_requested};
pub(super) use crate::app::{
    egui, ActionRequest, ActionResponse, AppRuntimeState, AppShellState, CacheStateBundle,
    EntryKind, FileListDialogKind, FileListManager, FileListRequest, FileListRequestPhase,
    FileListResponse, FlistWalkerApp, HighlightCacheKey, HighlightCacheState,
    IgnoreMatcherCacheState, IndexBuildResult, IndexEntry, IndexRequest, IndexResponse,
    IndexSource, LaunchSettings, PreviewRequest, PreviewResponse, QueryState, ResultSortMode,
    ResultSortScope, RootBrowserState, RuntimeUiState, SavedTabState, SavedWindowGeometry,
    SearchCoordinator, SearchRequest, SearchResponse, SortMetadataCacheState, SortMetadataRequest,
    SortMetadataResponse, TabAccentColor, TabAccentPalette, TabDragState, TabResourceLifecycle,
    TabSessionState, UpdateRequest, UpdateResponse, WorkerBus, WorkerRuntime,
};
pub(super) use crate::app::{render_tabs, request_process_shutdown, spawn_kind_resolver_worker};
pub(super) use crate::entry::Entry;
pub(super) use crate::path_utils::{normalize_windows_path_buf, path_key};
pub(super) use crate::search::SearchPrefixCache;
pub(super) use crate::ui_model::normalize_path_for_display;
pub(super) use crate::updater::{UpdateCandidate, UpdateSupport};
pub(super) use std::collections::{HashMap, HashSet, VecDeque};
pub(super) use std::fs;
pub(super) use std::path::{Path, PathBuf};
pub(super) use std::sync::atomic::{AtomicBool, Ordering};
pub(super) use std::sync::mpsc;
pub(super) use std::sync::Arc;
pub(super) use std::thread;
pub(super) use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

mod support;
pub(super) use support::{
    commit_query_history_for_test, emacs_shortcut_modifiers, entries_count_from_status,
    gui_shortcut_modifiers, is_action_notice, reset_index_request_state_for_test,
    run_shortcuts_frame, run_shortcuts_frame_with_modifiers, settle_root_browse,
    tab_switch_shortcut_modifiers, test_root, test_settings_scope,
};

pub(super) fn unknown_entry(path: PathBuf) -> Entry {
    Entry::unknown(path)
}

pub(super) fn file_entry(path: PathBuf) -> Entry {
    Entry::file(path)
}

pub(super) fn dir_entry(path: PathBuf) -> Entry {
    Entry::dir(path)
}

mod action_commands;
mod activation_contract;
mod app_core;
mod autosave;
mod cache_tests;
mod empty_query_progress;
mod finalization_timing;
mod index_pipeline;
mod indexing_perf;
mod paged_preview;
mod pipeline_tests;
mod preset_picker;
mod query_history;
mod render_tests;
mod result_parity;
mod root_list_manager;
mod search_failure;
mod session_restore;
mod settings_dialog;
mod shortcut_action;
mod shortcut_help;
mod shortcut_navigation;
mod shortcut_pin_focus;
mod shortcut_root_history;
mod shutdown;
mod stateful_endurance;
mod tab_background_responses;
mod tab_contract;
mod tab_drag;
mod tab_lifecycle;
mod tab_ownership;
mod tab_result_cache;
mod update_commands;
mod ux_contracts;
mod window_ime;

mod freshness;
mod freshness_refresh;

mod index_recovery;
