#!/usr/bin/env python3
"""Decode actual Xcode27.1 TOC/XML, retaining target-only state/stack records."""
from collections import defaultdict
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as E


def resolve(element, ids):
    seen=set()
    while element.get('ref'):
        key=element.get('ref')
        if key in seen or key not in ids:raise ValueError('missing/cyclic XML reference '+key)
        seen.add(key);element=ids[key]
    return element


def calibrate(anchors,tick=1000):
    if len(anchors)!=2:raise ValueError('both process clock anchors required')
    intervals=[[a['mono_before_ns']-a['trace_ns']-tick,a['mono_after_ns']-a['trace_ns']+tick] for a in anchors]
    lo=max(x[0] for x in intervals);hi=min(x[1] for x in intervals)
    if hi<lo:raise ValueError('inconsistent clock offsets; no average/interpolation')
    return [lo,hi]


def frame_window(frame,offset):
    lo,hi=frame['monotonic_window_ns'];margin=frame['measurement_overhead_ns']
    return [lo+margin-offset[0],hi-margin-offset[1]]


def integrate(rows,lo,hi):
    if hi<lo:raise ValueError('uncertainty exceeds frame window')
    totals=defaultdict(int);last=None
    for r in sorted(rows,key=lambda r:r['start']):
        if r['end']<r['start'] or last is not None and r['start']<last:raise ValueError('overlapping/retrograde state rows')
        last=r['end'];n=max(0,min(hi,r['end'])-max(lo,r['start']))
        if n:totals[r['state']]+=n
    missing=hi-lo-sum(totals.values())
    if missing:totals['UNKNOWN']=missing
    return dict(totals)


def decode(root):
    receipt=json.loads((root/'receipt.json').read_text());pid=receipt['pid'];nonce=receipt['nonce']
    toc=E.parse(root/'toc.xml');tables=list(toc.find('.//data'))
    tree=E.parse(root/'events.xml');ids={}
    for e in tree.iter():
        if e.get('id'):
            if e.get('id') in ids:raise ValueError('duplicate XML identity')
            ids[e.get('id')]=e
    def res(e):return resolve(e,ids)
    def num(e):return int(res(e).text)
    def text(e):return res(e).text or res(e).get('fmt') or ''
    def process(e):return num(res(e).find('pid'))
    def thread(e):return num(res(e).find('tid'))
    def stack(e):
        if e.tag=='sentinel':return []
        return [res(f).get('name','UNKNOWN') for f in res(e).findall('frame')]
    states=[];switches=[];calls=[];samples=[];signposts={}
    for node in tree.getroot():
        match=re.search(r'table\[(\d+)\]$',node.get('xpath',''))
        if not match:raise ValueError('unmapped table identity')
        schema=tables[int(match.group(1))-1].get('schema')
        for row in node.findall('row'):
            c=list(row)
            if schema=='os-signpost-arg' and len(c)==10 and process(c[5])==pid and text(c[3])=='TC207Clock':
                key=(num(c[0]),thread(c[6]));g=signposts.setdefault(key,{})
                name=text(c[4])
                if name in g:raise ValueError('duplicate signpost argument')
                g[name]=text(c[9])
            elif schema=='thread-state' and len(c)>=5 and process(c[4])==pid:
                states.append(dict(pid=pid,tid=thread(c[1]),start=num(c[0]),end=num(c[0])+num(c[3]),state=text(c[2])))
            elif schema=='context-switch' and len(c)>=4 and process(c[3])==pid:
                switches.append(dict(pid=pid,tid=thread(c[1]),time=num(c[0]),event=text(c[2])))
            elif schema=='syscall' and len(c)>=14 and process(c[4])==pid:
                calls.append(dict(pid=pid,tid=thread(c[1]),start=num(c[0]),end=num(c[0])+num(c[3]),name=text(c[2]),stack=stack(c[13])))
            elif schema=='time-profile' and len(c)==7 and process(c[2])==pid:
                samples.append(dict(pid=pid,tid=thread(c[1]),time=num(c[0]),state=text(c[4]),stack=stack(c[6])))
    raw=(root/'test.log').read_text()
    anchors=[json.loads(m.group(1)) for m in re.finditer(r'TC207_CLOCK (\{[^\n]*\})',raw)]
    if {a['label'] for a in anchors}!={'process-start','process-exit'} or len(anchors)!=2:raise ValueError('missing/extra process anchors')
    for a in anchors:
        if a['pid']!=pid or a['nonce']!=nonce or not a['signpost_enabled']:raise ValueError('foreign/inactive process anchor')
        matches=[(time,tid) for (time,tid),args in signposts.items() if args.get('arg0')==a['label'] and args.get('arg1')==nonce and args.get('arg2')==str(a['mono_before_ns'])]
        if len(matches)!=1 or matches[0][1]!=a['native_thread_id']:raise ValueError('missing/ambiguous native signpost anchor')
        a['trace_ns']=matches[0][0]
    offset=calibrate(anchors)
    frames=[json.loads(m.group(1)) for m in re.finditer(r'TC207_FRAME (\{[^\n]*\})',raw)]
    normalized=dict(receipt=receipt,anchors=anchors,clock_resolution_ns=1000,offset_interval_ns=offset,
                    states=states,switches=switches,syscalls=calls,cpu_samples=samples,frames=frames,
                    limits=['constant offset admitted only if both bracket intervals agree; clock/sleep error beyond admission remains a limit',
                            'Interrupted is separate; no inference that every non-Running interval is scheduling wait',
                            'only owned PID state/call/sample records retained; other process narratives/device identifiers excluded'])
    frame_results=[]
    for f in frames:
        if f['pid']!=pid:raise ValueError('foreign measured frame')
        lo,hi=frame_window(f,offset)
        if hi<lo:
            frame_results.append(dict(frame=f,reason='bracket/clock uncertainty exceeds short frame',states_ns=None));continue
        tid=f['native_thread_id'];rows=[r for r in states if r['tid']==tid]
        totals=integrate(rows,lo,hi)
        frame_results.append(dict(frame=f,conservative_trace_window_ns=[lo,hi],states_ns=totals,
                                  syscalls=[c for c in calls if c['tid']==tid and c['start']<hi and c['end']>lo],
                                  cpu_samples=[s for s in samples if s['tid']==tid and lo<=s['time']<=hi]))
    normalized['frame_results']=frame_results
    return normalized


if __name__=='__main__':print(json.dumps(decode(Path(sys.argv[1])),indent=2))
