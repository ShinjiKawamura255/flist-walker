import gzip,hashlib,io,json,pathlib,re,shutil,tarfile,sys
raw=pathlib.Path('/private/tmp/tc207-xcode-20261024')
out=raw/'public-evidence';out.mkdir(exist_ok=False)
src=pathlib.Path('/Users/shinji/work/flist-walker/docs/history/tc207-timing-2026-10-24/system-trace')
sys.path.insert(0,str(src));from replay import replay
manifest={'raw_material':'private local only; trace, TOC, XML are not published','projection':'allowlisted target-only normalized fields, numeric frames/states and target stack symbols; raw env/device/neighbor identifiers excluded','captures':{}}
for name in ['campaign-plan.json','campaign-plan-v2.json','campaign-plan-v3.json','campaign-plan-v4.json','campaign-v1-stop.json','campaign-v2-capture-failure.json','campaign-v3-partial-correlation.json','campaign-v4-parser-rejection.json','analysis-repair-provenance.json','parser-regression-red.txt','parser-regression-green.txt','parser-strict-lines-red.txt','scheduling-options.json','retention-preflight.json','python-tests.txt','validation-plan.txt','validation-quick.txt']:
 shutil.copy2(raw/name,out/name)
for d in raw.glob('method-v*'):shutil.copytree(d,out/d.name)
shutil.copy2(raw/'retain.py',out/'projection.py')
summary={}
for d in sorted(raw.iterdir()):
 if not d.is_dir() or not (d/'receipt.json').is_file():continue
 dest=out/d.name;dest.mkdir()
 receipt=json.loads((d/'receipt.json').read_text());(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 inventory={}
 for name in ['receipt.json','test.log','test.stderr','tracer.stdout','tracer.stderr','toc.xml','events.xml','analysis-repaired.stderr']:
  p=d/name
  if p.is_file():
   h=hashlib.sha256()
   with p.open('rb') as f:
    while chunk:=f.read(1024*1024):h.update(chunk)
   inventory[name]={'bytes':p.stat().st_size,'sha256':h.hexdigest()}
 for p in (d/'frame-logs').glob('*.jsonl'):
  inventory['frame-logs/'+p.name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 # Keep only clock records and runner summaries from stdout, not arbitrary application output.
 log=(d/'test.log').read_text(errors='replace');(dest/'runner-summary.txt').write_text('\n'.join(line for line in log.splitlines() if line.startswith(('TC207_CLOCK ','test result:','running ')))+'\n')
 # Controlled panics are bounded to the exact assertion and timing evidence.
 err=(d/'test.stderr').read_text(errors='replace') if (d/'test.stderr').exists() else log
 (dest/'assertion-summary.txt').write_text('\n'.join(line for line in err.splitlines() if 'background finalization frame exceeded 100ms' in line)+'\n')
 manifest['captures'][d.name]={'raw_files':inventory,'status':receipt['status'],'test_exit':receipt.get('test_exit'),'tracer_exit':receipt.get('tracer_exit')}
 if d.name.startswith('v4-'):
  j=json.loads((d/('normalized-repaired.json' if d.name=='v4-natural-full-lib' else 'normalized.json')).read_text())
  allowed=['receipt','anchors','clock_resolution_ns','monotonic_clock_resolution_ns','offset_interval_ns','calibration_clock','calibration_status','calibration_error','states','switches','cpu_samples','supplemental_samples','transition_stacks','frames','limits']
  data={k:j[k] for k in allowed}
  # Retain whole state rows intersecting the measured threads' outer windows.
  bounds={}
  for f in data['frames']:
   tid=f['native_thread_id'];lo=f['mach_absolute_window_ns'][0]-j['offset_interval_ns'][1];hi=f['mach_absolute_window_ns'][1]-j['offset_interval_ns'][0]
   old=bounds.get(tid,(lo,hi));bounds[tid]=(min(lo,old[0]),max(hi,old[1]))
  data['states']=[r for r in data['states'] if r['tid'] in bounds and r['start']<bounds[r['tid']][1] and r['end']>bounds[r['tid']][0]]
  for key in ['switches','cpu_samples','supplemental_samples','transition_stacks']:
   data[key]=[r for r in data[key] if r['tid'] in bounds and bounds[r['tid']][0]<=r['time']<=bounds[r['tid']][1]]
  (dest/'inputs.json').write_text(json.dumps(data,separators=(',',':'))+'\n')
  result=replay(data);summary[d.name]=result
  assert result['offset_interval_ns']==j['offset_interval_ns']
  recomputed=[]
  from analyze import frame_window,integrate
  for f in data['frames']:
   lo,hi=frame_window(f,j['offset_interval_ns'],j['calibration_clock']);recomputed.append(None if hi<lo else integrate([r for r in data['states'] if r['tid']==f['native_thread_id']],lo,hi))
  assert recomputed==[r['states_ns'] for r in j['frame_results']]
  (dest/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
manifest['v4_summary']=summary
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Exact captured test-source delta and helper sources make uncommitted-source identities replayable.
shutil.copytree(src,out/'method-v4',ignore=shutil.ignore_patterns('__pycache__','*.tar.gz','README.md'))
for name in ['finalization_timing.rs','tab_background_responses.rs']:
 shutil.copy2(pathlib.Path('/Users/shinji/work/flist-walker/rust/src/app/tests')/name,out/'method-v4'/name)
for name in ['cargo-test-final.log','clippy-final.log']:
 lines=(raw/name).read_text().splitlines();(out/name).write_text('\n'.join(line for line in lines if line.startswith(('test result:','    Finished','error:','warning:')))+'\n')
checks={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.rglob('*')) if p.is_file()}
(out/'sha256.json').write_text(json.dumps(checks,indent=2)+'\n')
archive=src/'evidence.tar.gz'
with archive.open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for p in sorted(out.rglob('*')):
  if p.is_file():
   info=tar.gettarinfo(str(p),arcname=str(p.relative_to(out)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
   with p.open('rb') as f2:tar.addfile(info,f2)
print(json.dumps({'archive_bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'summary':summary},indent=2))
