"""Offline controller regressions; synthetic bytes never calibrate performance."""
import ast,copy,datetime,json,pathlib,re,subprocess,sys,tempfile,time,unittest
from types import SimpleNamespace
sys.path.insert(0,str(pathlib.Path.cwd()))
from scripts import indexing_perf_gate as gate,indexing_perf_contract as contract,indexing_perf as collector
from scripts.tests.test_indexing_perf_gate import write_fixture
SCRIPT=pathlib.Path(sys.argv.pop(1))
class ControllerControls(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.folder=pathlib.Path(self.temp.name);self.addCleanup(self.temp.cleanup)
  tree=ast.parse(SCRIPT.read_text());self.tree=tree
  self.env={'datetime':datetime,'json':json,'pathlib':pathlib,'subprocess':subprocess,'sys':sys,'time':time,'ROOT':pathlib.Path.cwd(),'OUT':self.folder,'HEAD':'a'*40,'REPO':'synthetic','DEADLINE':time.monotonic()+60,'gate':gate,'contract':contract,'COMPONENT_IDS':set(),'PROTOCOL':{'synthetic':True},'re':re}
  exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(SCRIPT),'exec'),self.env)
 def prepare(self):
  arts=self.folder/'artifacts';arts.mkdir();sources={}
  for group in contract.GROUPS:
   p=arts/group;p.mkdir();write_fixture(p,group,enforced=False)
   r=json.loads((p/'receipt.json').read_text());comparison=r['comparison']
   for role in gate.ROLES:
    q=p/(role+'-receipt.log');comp=json.loads(q.read_text());comp['run_id']=group+'-'+role;q.write_text(json.dumps(comp));comparison['legs'][role]['receipt_sha256']=collector.sha(q)
    sources[comp['source_before']['head']]=comp['source_before']
    if role=='candidate':r={**comp,'comparison':comparison}
   (p/'receipt.json').write_text(json.dumps(r))
  jobs=[{'name':f'Indexing Contention ({g})','conclusion':'success','startedAt':'2026-10-05T00:00:00Z','completedAt':'2026-10-05T00:00:10Z'} for g in contract.GROUPS]
  (self.folder/'state-final.json').write_text(json.dumps({'jobs':jobs}))
  self.env['command']=lambda *a,**k:'';self.env['git_identity']=lambda rev:copy.deepcopy(sources[rev]);return sources
 def test_admission_keeps_full_source_revision_and_partition(self):
  self.prepare();v=self.env['download_and_admit']('123','a'*40,self.folder)
  self.assertEqual(v['source'],'a'*40);self.assertEqual((v['decision_count'],v['enforced_count'],v['diagnostic_count']),(136,68,68))
 def test_stop_during_command_cannot_return_for_dispatch(self):
  marker=self.folder/'STOP_REQUESTED';calls=[]
  def run(*a,**k):calls.append(k);marker.touch();return SimpleNamespace(returncode=0,stdout='remote-read',stderr='')
  old=self.env['subprocess'];self.env['subprocess']=SimpleNamespace(run=run)
  with self.assertRaisesRegex(RuntimeError,'stop marker'):self.env['command'](['synthetic','read'])
  self.assertEqual(len(calls),1);self.env['subprocess']=old
 def test_blocking_command_is_limited_by_remaining_campaign_time(self):
  self.env['DEADLINE']=time.monotonic()+.5;limits=[]
  def run(*a,**k):limits.append(k['timeout']);return SimpleNamespace(returncode=0,stdout='',stderr='')
  self.env['subprocess']=SimpleNamespace(run=run);self.env['command'](['synthetic','read'],timeout=45)
  self.assertTrue(0<limits[0]<=.5)
 def test_expiry_during_whole_validation_prevents_admission(self):
  self.prepare();real=gate.load_comparison;calls=[]
  def load(*a,**k):r=real(*a,**k);calls.append(1);self.env['DEADLINE']=time.monotonic()-1;return r
  self.env['gate']=SimpleNamespace(ROLES=gate.ROLES,REFERENCE=gate.REFERENCE,POLICY=gate.POLICY,load_comparison=load)
  with self.assertRaisesRegex(RuntimeError,'finite6h'):self.env['download_and_admit']('123','a'*40,self.folder)
  self.assertEqual(len(calls),3)
 def test_expiry_during_remote_identity_read_prevents_new_dispatch(self):
  self.env['PROTOCOL']={'sessions':[{'index':1,'role':'exploratory'}]};self.env['BRANCH']='synthetic';self.env['REPO']='synthetic';dispatched=[]
  def api(*args):self.env['DEADLINE']=time.monotonic()-1;return {'object':{'sha':'a'*40}}
  self.env['api']=api;self.env['command']=lambda argv,*a,**k:dispatched.append(argv) or 'https://example.invalid/actions/runs/123';self.env['wait']=lambda *a,**k: (_ for _ in ()).throw(RuntimeError('unexpected-dispatch'))
  outer=next(n for n in self.tree.body if isinstance(n,ast.Try));loop=next(n for n in outer.body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='reserved')
  with self.assertRaisesRegex(RuntimeError,'finite6h'):exec(compile(ast.Module(body=[loop],type_ignores=[]),str(SCRIPT),'exec'),self.env)
  self.assertEqual(dispatched,[])
if __name__=='__main__':unittest.main()
