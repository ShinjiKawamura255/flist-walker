# Goal verification and closure

- Execution Profile: strict
- Risk Tier: medium
- Planning Depth: roadmap+slice
- Review Pattern: staged-subagents
- Review Requiredness: required-before-implementation-and-final
- Review Placement: before-and-final
- Plan Readiness: ready-for-implementation
- Before-Implementation Review: 初期、sampling および observer repair レビュー済み (/root/plan_review PASS; rust/target/indexing-speed-gate/observer-repair-before-review.md)
- Final Review: 未レビュー
- Ownership: main owns plans, manifest, implementation, Git/external changes, and closure; reviewers are read-only.
- Parent: roadmap; filesystem ownership inherited.
- Dependency: slice A actual implementation, frozen rule, null/held-out and fail-path evidence, selected checks and final review complete.
- Scope: verify requested numeric regression rejection is enabled, protected PR merge identity, durable docs/results, source/worktree ownership and temporary cleanup.
- Acceptance: no observational-only fallback presented as completion; exact run identities/raw source preserved; remaining unimplemented coverage explicitly disclosed; task-owned durable changes committed; original GUI worktree unchanged; controls removed only after verified goal.
- Validation: live PR/check readback, source patch/tree/commit identity, required policy unchanged, selected validation/review evidence, clean owned checkout. Full settings snapshot only if task mutates settings.
- Continuation: if goal remains unmet, add targeted repair/implementation phase and keep controls; do not close because observation succeeded.
- Cleanup: preserve existing AGENTS except owned temporary section; archive required durable decisions; mark cleanup in_progress then prove deletion/commit/clean status externally.

## Closure Capsule
- Goal achieved: no
- Final review: 未レビュー
- Commit evidence: none
- Close decision: do not close

## Material measurement repair
The first exact-source null session37245833397 has f1 reference-condition median drift1.276521>1.25 and cannot calibrate the gate. No unchanged retry. Slice A proposes all f1 cells21pairs, other groups7, full median/max samples and unchanged100k/RCR/1.50/1.25/finite budgets. The entire five-session reservation must restart after focused independent BEFORE review and validated tooling. Prior raw/receipts remain original7-pair rejected evidence, revalidated by original source contract. Final review/activation/merge/closure requirements are unchanged.

## Observer repair boundary
Revised21-pair campaign fails on session3 reference MAX drift; sessions4/5 NOT RUN. Slice A now proposes a focused observer-only repair and immutable healthy reference evolution with full production-byte equivalence. Required focused independent BEFORE review precedes edits; thresholds/tails/sample inclusion and FINAL/activation/closure requirements stay unchanged. No unchanged perf retry or acceptance of earlier PASS subset.

## Proposed v4 common completion ceiling — independent BEFORE decision pending
The fresh ee/f108 v3 campaign has exploratory1 wholePASS, while exploratory2 matched has MAX reference drift1.263339169>1.25 with every median and candidate predicate PASS; other groups are being retained before the finite controller stops. No v3 outcome is adopted as v4 calibration. No unchanged retry or threshold widening follows.

Main-owned specification proposal: policy rcr-median-ceiling-v2, protocol same-job-RCR-f1-21-observer-v4. For each cell/source/arm/endpoint, M=max(R1 median,R2 median), L=1.50*M. Both reference medians must be finite positive with symmetric drift<=1.25. Both reference maxima must be<=L, otherwise the family is indeterminate. Candidate median and all-sample maximum each must be<=L, equality passing. Reference maximum cross-bracket drift remains diagnostic, no longer an admission criterion. Keep all136 decisions; both candidate predicates share admission; any indeterminate makes whole result nonpassing while candidate threshold diagnostics remain retained. This is an explicit reference-admission change, not simple strengthening: stable reference maxima180 with medians100 were admitted by v3 but rejected here. Candidate maximum ceiling is stricter than the old1.50*max(reference MAX). All raw observations,21/7 cadence,100k fixture,17 cells, all source/work/context/oracles/physical receipt checks and finite1800/2700/5400s remain unchanged. No production or test Rust edits, new fixed reference, workflow/settings change, percentile substitution, sample removal, wait subtraction or pooling.

Rationale: user's requirement is detecting substantial indexing completion slowdown including concurrent non-search work; user did not specify MAX bracket drift1.25 or a statistical tail-repeatability guarantee. Those numeric design choices were delegated in the accepted implementation plan. Preserve1.50 practical slowdown and1.25 median host-drift tolerances while using a common typical-reference ceiling to require every reference/candidate observed completion to meet the stated tolerance. This goes beyond a false-positive patch: adversarial reference tail admission tightens and candidate outlier sensitivity increases. Independent feasibility agrees this is a finite engineering check, not confidence/p95 guarantee. No unchanged further v3 run is justified. Main owns adoption after concrete required integrated BEFORE review; no repeated task approval for the delegated numeric design is needed. If contrary evidence of an explicit user MAX-drift contract appears, stop that decision for user input.

Focused gate-2d: preserve v3 original stopped campaign and original-source CLI replay, then implement only Python policy/comparator/receipt contract and owning SDD/ops/status docs. TDD must first fail max151/reference median100+max140, one-row MAX-only excess, uniform both-predicate excess, reference-tail indeterminate, reference-median drift, reciprocal brackets, exact equality, all136 keys, invalid receipt/source and unknown old-policy/protocol. Median FAIL implies MAX FAIL under common ceiling; remove no tests simply for green, disposition the prior impossible independent-median expectation explicitly. New calibrated source is independently complete with ENFORCE_TIMING=False; commit only after all selected checks PASS. Existing exact Rust/reference bytes reuse pinned Rust/VM checks, ordinary exact new source CI/required checks must PASS before dispatch.

After gate-2d: fresh five-session reservation declared before any outcomes, same3exploratory+2heldout order, source-bound newv4 comparator, unchanged immutable f108 reference/measurement/sample/budgets. Freeze only first3 wholePASS before slots4/5; require allfive wholePASS. Earlier v3/v2/7pair outcomes remain original rejected historical evidence. Finite controller collects all three sibling groups even after numeric rejection, stops on any invalid/indeterminate/FAIL, does not retry unchanged source, does not activate or merge. Whole original archive/roundtrip/15 originalCLI replays and actual resource admission precede activation.

Activation remains a separate validated unit: default enforcement unmocked RED/GREEN, synthetic CLI numeric-only FAIL exit1 distinct from receipt-invalid, actual active hosted normal-CLI 17cell/1386row/136predicate/source-bound PASS, exact-source required CI, selected regressions, independent FINAL, protected rebase auto-merge and safe owner-worktree closure. No prior contract or native-axis result is relabelled. Existing closure slice and external authority stay unchanged.

Evidence: rust/target/indexing-speed-gate/v4-design/feasibility-before.md and counterfactual-not-calibration.json; latter marked calibration_eligible=false and hashed original inputs. Exact immutable source ee1673a4452c51a7db0cf3c12227cdc9080dc14b, healthy Rust reference f1089f63be32cfe0b1d14d9f49ab1832bd287982. V4 not implemented or activated at proposal checkpoint.

V4 BEFORE decision: /root/plan_review integrated PASS0 at exactee/ref f108 (packet ee23e9d9), independent feasibility confirmed. Main adopts the delegated common-ceiling design with explicit changed admission and unchanged practical ratios. Product implementation begins only after complete originalv3 archive/replay; no user-specified MAX1.25 requirement exists in supplied history. Numerical activation, fresh5 acceptance and closure remain pending.


V4 fresh campaign rejection: sourcef9/ref f108, exploratory1/2wholePASS, exploratory3 run37284416662 indeterminate in f1. F1-ignore-list/FileList/condition referenceMAX526.986631ms exceeds484.4958765ms common ceiling; F1-mid-ignore/FileList/condition581.640258ms exceeds557.090526ms. Allcandidatepredicates and medianreferenceadmission pass; matched/stablePASS. Whole3isrejected,4/5NOTRUN, nofreeze/activation/retry. Threewholeoriginalpackets retain4158rows408decisions27uniquecomponents, originalsourceCLI nine replays reproduce failure; allshared1800/2700/5400budgetsPASS. Main pauses numeric adoption and requests focused independent read-only measurement diagnosis; no newdesign or thresholdchange adopted. Originalv4 archive278files/10880307bytes roundtripPASS. Task remains open; requiredFINAL/merge/closure pending.

Focused gate-3a: preserve rejectedv4 archive/9originalCLIreplays/independentdiagnosis as a complete docs/evidence unit; fix the unchanged f1table count to336rawrowsperleg. TDD is inapplicable to original-byte archival and count documentation; actual roundtrip/sourceCLI/rawinventory/references are alternative validation. No numeric policy/default/Rust/workflow change is part of this unit. User clarification now distinguishes sustained median performance from every-sample tail guarantee before dependent changed requirements; no answer assumed.

Independentv4 diagnosis completed with no established observer defect. Archived3c7f33f unit committed/pushed; current exactheadCI37290334727inprogress and Guardian37290332286PASS. Required user requirement choice is pending: median1.50 substantial sustained slowdown gate retainingMAXdiagnostics without single-event guarantee, versus existing every-sample tail ceiling with further diagnosis. This is a material protection-scope choice, not repeated implementation approval. No preselected/elapsed answer, changedpolicy, furtherperfdispatch, activation, merge or closure is assumed.

Focused gate-3b proposal: exact3c archival CI Windows fails unrelated-writer physicalstop1s atsupport.rs224; startup/IOcause unmeasured. No unchangedretry. Independent BEFORE evaluates existing WriteGate readiness handshake while preserving1s stop/1ms original timeout/2s cleanup/allphysicalguards, with real-controlled-order RED/GREEN before any source edits. No numeric/pipeline/timeout change, user performance-scope answer still pending; any source change requires exact nativeCI and new actual null reference equivalence before a future campaign.

Focusednormaltest BEFORE PASSc98eeb45 requires bothgatesrelease/rootretention onfailure. Existing scope joinsprimaryonly although unrelatedwriter sharesroot; minimalboundedOptionauxiliary ownership/shareddeadline cleanup is proposed for focusedBEFORE beforeedits, with realparked-auxiliary deletionRED/GREEN and alloriginalboundsretained. Sourceunchanged; actualWindowsstartup/IOcauseunproven.

Focused owned-root BEFORE accepted /root/plan_review, exact3c subjects42f3e452; gate3b complete. gate3c real-worker TDD: onlysupport.rs, one same-base auxiliary path, shared totaldeadline, bothjoins beforedelete, no timeoutincrease. Actual3c CIcompletedFAIL; no unchangedretry. Numeric scope userchoice remainspending.

CI sequencing clarification: exact remote sourceCI requires a pushed commit. gate3c is the independently complete local real-worker repair+fullpinnedchecks+focusedreview checkpoint; gate3d records mandatory postcommit actualnativeCI before futureperf or merge. No nativePASS claimed beforethat. AuxiliaryRED exit101(actualoldcleanupOk); auxiliaryGREEN1PASS; controlled unreleasedstoporderRED exit101 (notoriginalWindowscause); corrected threecleanup testsGREEN3PASS.

Gate3c independentlycomplete local repair: fullpinnedRust1570lib/main/integrations and43persistence/fmt/clippyPASS; focusedimplementationreviewPASS0 exact3c+supportoverlayc7a2c5ac. Gate3d ready: actualnewsourceCI afterselectivesupport-onlycheckpoint/push. Numericunit/v4rejection unchanged; no overallFINAL/closure.

Gate3d complete: actual81075f9 nativeCI37294829577attempt1 andGuardian37294825488 SUCCESS. Linux1579/mac1570/Windows1602lib/allnativeintegrations+build/GNUE2E PASS. No source retry; originalWindowsfailretained. Read-onlyproof: newcheckpoint differs fromF108 onlysupport.rs, originalAFDD onlysupport+extensions/driver.rs (bothcfg(test)); all otherproduction/Cargo/buildbytes match. Currentfixedref stillF108; newreference NOTADOPTED/hostednullNOTRUN. Numericchoice questionstillpending; latestPR remainsDRAFT/noautoMerge, ENFORCEFalse, gate3failed/gate4–7pending. No finalclosure or controls removal.

## Authorized sustained slowdown continuation (v5)

User「変更を許可します。」 accepts recommended68mandatorymedian/68MAXdiagnostic scope. No userchoice pending now. Concrete v5 plan/TDD/oldMAXscenario disposition/ref810/fresh5/activation/FINAL/closure contract: `rust/target/indexing-speed-gate/v5-design/integrated-before.md`. Required focusedintegratedBEFORE pending before product edits; humanapproval is authority, not completedreview. Priorv4 rejection/history remains original. gate3e BEFORE→gate3f toolingTDD/referencepin/validation/checkpoint+actualCI→gate3g freshprospective5/archive→gate4activation→gate5FINAL→gate6protectedmerge/masterproof→gate7ownercleanup. Claim68enforced+68MAXdiagnostic/136observations; currentENFORCEFalse/PRDRAFT. Allphysical/source/work/budgets unchanged.
