﻿# Quality, Constraints, and Risks

### Non-functional (NFR)
- NFR-001: 10万件候補での検索処理は、固定 fixture と release mode の代表的な cold/warm query で median 100ms 未満を目標（SHOULD）とする。hosted CI の weekly regression gate は環境差を吸収するため、全定義 shape の各測定 sample と maximum が 250ms 未満であることを MUST とし、候補数、評価件数、match 件数、compile 時間、median、maximum を記録する。加えて、100万件の固定候補に対する代表 query の p50/p95/p99 と RSS lifecycle を同じ weekly signal で観測可能にし、安定した hosted baseline が蓄積するまでは RSS を hard gate にしてはならない。
- NFR-002: 例外時はユーザ向けに原因を表示し、非ゼロ終了コードを返すこと。
- NFR-003: モジュールはテスト可能に分離され、主要機能に unit test を持つこと。query の operator truth、score、visibility、highlight span は共有 evaluator で検証可能とし、公開 adapter 間の互換性を characterization test で固定する。
- NFR-004: GUI の主要フロー（検索、選択、アクション、再読込）は回帰手順を定義すること。
- NFR-005: セキュリティ衛生と再現性のため、required CI は version-addressed な runner 世代・Rust・Action・CI tool で release 対象 OS を継続検証し、Cargo 関連変更の依存脆弱性検査を merge gate に含めなければならない。時間経過で変化する advisory と latest 環境互換性は別の定期 workflow で観測し、失敗を追跡可能にしなければならない。protected `master` は linear history とし、machine PR は意味ある複数commitの境界・順序・message・authorを保持してrebase mergeされなければならない。
- NFR-006: ソート追加後もインデクシング速度は既存実装より劣化させないこと。検索・フィルタ・ソート・複数タブ・旧 snapshot の回収との併走時も indexing の候補・最新結果の正しさを維持し、FileList / Walker 別の固定10万件・release profileで完了時間と停止区間を測定できなければならない。比較は同じ候補、設定、有限の操作列で行い、検索要求の送信だけで併走成立としてはならない。ケース別の時間閾値は正常版との実測と対象環境のばらつきで校正し、未校正の倍率を性能保証として採用してはならない。 同一jobの正常参照を前後に計測する数値判定は、cell/source/arm/t2・t3別の遅い参照medianの1.50倍をcandidate medianと全sample maximumの共通上限とする。参照medianの対称driftは1.25以下かつ両参照maximumも共通上限以下を必須とし、違反は判定不能として合格にしない。参照maximum間driftは診断として保持する。全17cell・136判定を維持し、新基準の事前予約した正常版・held-out検証が完了するまで数値enforcementは有効化しない。
- NFR-007: 更新確認・ダウンロードは UI スレッドをブロックせず、失敗時も通常検索操作を継続可能でなければならない。
- NFR-008: GUI の action、kind resolution、indexing、および保存済み root の path 検証は UI スレッドをブロックせず、request identity により過負荷・切断・stale・shutdown の各経路で要求を終端状態へ収束させなければならない。action、kind resolution、indexing の同時実行数と待機件数は固定上限を持たなければならない。
- NFR-009: GUI の通常・session restore・closed-tab restore のタブ遷移は、active tab の大規模な index、building queue、kind resolution、incremental result、search result を要素単位で複製・同期破棄・capacity 縮小・再構築せず所有権移動で遷移し、候補件数に比例する同期処理によって UI 入力応答性を損なってはならない。tab は lifecycle と committed snapshot の有無を別々に所有し、refresh 中または失敗後も last-good snapshot を表示できなければならない。直前に十分利用された open-inactive tab は短い往復操作で committed snapshot を再利用でき、偶発的な瞬間表示がその保護対象を置換してはならない。lazy load が必要な tab は同じ遷移処理内で `Indexing...` と最新 generation を確立し、Ready tab の activation は無条件 reindex してはならない。固定 10 万件の release-mode coordinator fixture ではタブ切替 p95 16ms を目標、50ms を hard ceiling とし、非同期 index 完了時間と resource reclamation はこの閾値から分離する。
- NFR-010: 自己更新の release metadata、署名済み manifest、署名、binary、sidecar は接続・無通信・要求・全体時間と decoded byte 数に固定上限を持ち、署名済み manifest を信頼する前に配布 asset を取得してはならない。失敗時はこの要求が作成した partial staging だけを削除し、既存 path や別 transaction の証跡を変更してはならない。
- NFR-011: interactive CLI の index/search は入力ループをブロックせず、同一 query を含む古い応答を request identity で破棄し、結果更新中も利用者の選択を可能な限り維持しなければならない。worker 応答の反映は iteration ごとの固定件数上限を持ち、増分候補の追加で既存候補 path 全件を入力ループ上で複製してはならない。端末描画はフレーム途中の全画面消去状態を利用者へ表示してはならない。正常終了、cancel、setup 途中失敗、描画/入力エラー、unwind の各経路で terminal mode・alternate screen・cursor・bracketed paste を開始前相当へ復旧しなければならない。
- NFR-012: FileList transaction、history/UI-state/saved-root persistence、および opt-in window trace は UI frame / terminal event loop をブロックしてはならない。利用者が確定を要求する設定保存は成功または失敗を request identity とともに UI へ返し、失敗時に未保存値を確定済みとして表示してはならない。FileList の未 settle な worker は selection 出力・root 切替・terminal 終了より先に完了または失敗として確定しなければならない。
- NFR-013: GUI coordinator の非同期状態遷移は、決定論的に再生できる長い操作列で継続検証しなければならない。各操作後は tab identity、request routing、result/selection、bounded queue の安全不変条件を満たし、入力停止後は pending / in-flight / routing / progress state が有限 step で終端状態へ収束しなければならない。失敗証跡は seed、step、event、意味論的 state digest を含み、同じ revision で再生可能でなければならない。
- NFR-014: Windows の固定 shallow 200-file fixture では、同一 release build・同一 host で 5 warmup 後に標準出力を破棄して 25 回測定した `fw` batch 検索の median が、universal の direct-process `flistwalker --cli` baseline median の 70% 以下でなければならない。この baseline は Windows universal の shell-synchronous CLI サポートを意味しない。1 回だけ全測定を再実行でき、再度未達なら release を停止する。
- NFR-015: GUI index resource は active 1件と warm background 1件を scheduler owner として pinned にし、それと直交する Recent Inactive 最大1件およびその他の open-inactive/closed heavy snapshot を、soft/hard の件数・deterministic weight 上限で管理しなければならない。Recent Inactive の猶予は通常の cache pressure だけを延期し、hard pressure は猶予中でも回収できなければならない。index response は request-scoped の bounded mailbox と順序付き control/terminal slot を使い、UI 側に無制限 queue を作ってはならない。heavy payload の最終 drop は固定 reclaimer worker が担当し、queue Full、cancel、failure、shutdown のいずれでも UI thread の同期 drop、terminal 消失、上限外の side queue を生じさせてはならない。これは cacheable history の上限であり、単一 active FileList snapshot の hard byte cap ではない。

### Constraints (CON)
- CON-001: 本実装は Rust で行う。
- CON-002: 外部コマンド実行は配列引数で呼び出し、シェル展開依存を避ける。
- CON-003: root 配下判定はインデクシング経路へ導入せず、実行/オープン直前に行う。
- CON-004: 自己更新は universal の `FlistWalker-<version>-<platform>-<arch>`、CLI 専用の `fw-<version>-<platform>-<arch>`、共有 sidecar と `SHA256SUMS` を前提とし、追加の常駐 updater 事前配置を要求してはならない。

## Risks
- R-001: OS ごとのオープン/実行差異により挙動不一致が発生する。軽減策: 実行/オープン分岐を抽象化しテストで検証する。
- R-002: 大規模ディレクトリで走査コストが増大する。軽減策: FileList 優先、非同期処理、バッチ更新を維持する。
- R-003: FileList に root 外パスが含まれると、意図しない実行対象が一覧へ混入する。軽減策: 表示は許容しつつ、実行/オープン直前に root 配下判定で拒否する。
- R-004: query history の平文永続化は、運用によっては機微な検索語を残す。軽減策: 永続化無効化設定と注意書きを提供する。
- R-005: mutable runner/toolchain/security database、重い cache、重複実行、PR自身によるrequired workflow弱体化により、CI failureや誤ったgreen判定がmergeを不安定にする。軽減策: required環境のversion-addressing、cache制限、concurrency/timeout、Cargo変更時audit、scheduled audit、non-required latest canary、集約`CI Gate`、default branch版policyだけを実行する`CI Policy Guardian`を適用する。
- R-006: 日付ソートのために全候補へ `metadata()` を導入すると index/search の体感が悪化する。軽減策: 結果スナップショット限定の遅延解決と上限付きキャッシュを採用する。
- R-007: GitHub API 一時障害やネットワーク不通で起動時更新確認が失敗する。軽減策: 非同期確認として失敗を notice に閉じ込め、検索機能は継続する。
- R-008: 実行中バイナリの置換に失敗すると更新後再起動できない。軽減策: Windows は別 updater、Linux は一時スクリプト経由で置換し、署名済み checksum manifest と整合する staged binary のみ使用する。
- R-009: ignore list の解釈が query とずれると、検索結果と UI 表示が不一致になる。軽減策: 除外判定は query の `!` と同じ非 fuzzy の比較ルールに寄せ、既定有効/切替状態を session に保持する。
- R-010: runtime config file の自動生成や seed-only 挙動が不明瞭だと、環境変数での一時的な変更が効かず、起動時設定の期待が外れる。軽減策: 初回生成と既存ファイル優先、Windows での `%LocalAppData%\flistwalker\` と Linux/macOS の `~/.flistwalker/` を README / release README / SPEC に明記し、起動時に file が source of truth であることを固定する。UI state、saved roots、window trace も同じ保存先ルールに揃える。旧保存先からの移行は transition period に限って維持し、後続版で削除できるようにする。
- R-011: sample ignore list を release asset にのみ依存させると、自己更新時や特殊な配布形態で sample が欠落しうる。軽減策: sample を埋め込み、起動時に local 実体を自動生成し、既存 ignore list は上書きしない。
- R-012: updater helper または本体が置換途中で停止すると binary と sidecar の版が分離しうる。軽減策: 同一ディレクトリの create-new 準備、固定 lock、per-target write-ahead marker、backup、binary-last commit、hash 検証付き recovery を用い、曖昧な状態では自動 cleanup/再更新を停止する。
- R-013: 個別の非同期回帰テストだけでは、tab 操作、root/query 変更、stale completion、cancel が長い順序で重なった場合の orphan state や別 tab 汚染を見逃しうる。軽減策: production transition API と controlled response channel を使う決定論的 state-sequence test を required PR test とし、実 worker と一時 root を使う長時間 profile を non-required scheduled workflow で補完する。
