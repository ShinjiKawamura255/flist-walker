"""Design-only re-calculation; never creates or changes campaign admission."""
import hashlib,json,sys
from pathlib import Path
results=[]
for name in sys.argv[1:]:
 path=Path(name); original=json.loads(path.read_text()); decisions=original['decisions']
 keyed={(d['case'],d['source'],d['arm'],d['endpoint'],d['statistic']):d for d in decisions}
 rows=[]
 for d in decisions:
  key=(d['case'],d['source'],d['arm'],d['endpoint'])
  median=keyed[key+('median',)];maximum=keyed[key+('max',)]
  denominator=max(median['reference_before'],median['reference_after']);limit=1.5*denominator
  drift=denominator/min(median['reference_before'],median['reference_after'])
  admitted=drift<=1.25 and max(maximum['reference_before'],maximum['reference_after'])<=limit
  rows.append(dict(key=list(key)+( [d['statistic']] ),original_status=d['status'],
   design_status='indeterminate' if not admitted else 'timing-fail' if d['candidate']>limit else 'pass',
   median_denominator=denominator,limit_ms=limit,candidate_ratio=d['candidate']/denominator,
   reference_median_drift=drift,reference_max_ceiling_ratio=max(maximum['reference_before'],maximum['reference_after'])/denominator))
 results.append(dict(input=str(path),input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
  original_protocol=original['protocol'],original_status=original['status'],group=original['group'],
  decision_count=len(rows),design_status='indeterminate' if any(d['design_status']=='indeterminate' for d in rows) else 'timing-fail' if any(d['design_status']=='timing-fail' for d in rows) else 'pass',
  decisions=rows))
print(json.dumps(dict(purpose='unadopted-design-counterfactual-only',calibration_eligible=False,
 original_outcomes_unchanged=True,reports=results),indent=2,allow_nan=False))
