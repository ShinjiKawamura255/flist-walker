﻿# Non-functional Runtime Design

## Non-functional design
- DES-007 / DES-009: active filter の大量候補は `active_filter.rs` の request-owned continuation として `TabBuildPayload` に保持し、1回のpollは4msを主予算、最大32,768候補を件数上限として候補cloneとincremental snapshot構築を進める。unknown-kind収集は1poll最大512件、backlog最大4096件を維持する。small-input同期処理と小規模scratchの同期退役の閾値も各512件に固定し、known候補の上限と連動させない。source/tab/root/index/kind/filterの同一性を確認してから公開し、完了までは旧表示を維持する。有効な増分membershipがあるlive filterでは、raw prefix長とfiltered subset長を別々に記録し、毎poll/公開再試行でidentityを検証する。subsetだけを検索snapshotへcloneし、除外再評価とincremental ownerの二重copy/swapを省く。kind/case/policyの失効時は再判定へ戻し、取消時は既存incremental allocationを保持する。処理中は対象indexの取込みを止め、supersessionとtab/root破棄を含むscratch/旧payloadは既存reclaimerへ移す。Full時は所有権を保持して再試行する。
- DES-006 Performance
- directory previewは共有cancelable builderで4096件sample＋1 lookaheadまで列挙し、bounded sampleだけをsortする。新requestを受けたGUI/TUI workerはfilesystem呼出し間で旧要求を中断し、本文を返す前にもcancelを確認する。
- Indexer と search を分離し、GUI ではワーカースレッドで非同期処理する。
- action executor は固定 2 worker と待機 queue 8 件で構成し、受理済み要求の総量を running 2 + queued 8 = 10 件に制限する。要求ごとの detached thread は生成しない。
- kind resolver は固定 1 worker と待機 queue 256 件で構成し、受理済み要求の総量を running 1 + queued 256 = 257 件に制限する。
- index executor は固定 2 worker と待機 queue 2 件で構成し、stale だが未 settle の要求も含めて running 2 + queued 2 = 4 件に制限する。index coordinator が同時に dispatch 済みとして追跡する要求は 2 件以下、app 側の再試行用 pending request は全体 4 件以下かつ tab ごとに最新 1 件とする。worker channel へ受理された request は stale 化や replacement 投入後も terminal response まで dispatch 済みとして数え、送信前 request を inflight に含めない。
- UI から各 bounded queue への送信は non-blocking `try_send` とし、`Full` では action を未受理として扱い、kind は queue 先頭、index は tab ごとの latest-only pending slot へ戻す。いずれも UI thread で capacity 解放を待たない。
- kind worker は tab identity / epoch の最新性を metadata I/O より前に検証し、stale、tab 消失、共有状態の poison は metadata call 0 件の `kind=None` terminal response にする。index worker は supersede/cancel を root canonicalize より前に検証し、stale request は filesystem I/O 0 件の `Canceled` response にする。
- 検索要求は入力ごとに発行しつつ、ワーカーでキューを集約して最新要求のみ処理する。同一 GUI tab または TUI current request の新要求は旧要求の token を cancel し、検索 collect loop は 256 候補ごとに停止判定して partial result を publish しない。
- interactive CLI の候補 snapshot は immutable path batch を共有し、増分 append で既存 path 全件を複製しない。同じ batch identity と root/ignore scope の検索では worker-local の projected `Arc<Vec<Entry>>` を再利用し、prefix cache の source identity を維持する。
- interactive CLI の event loop は worker 応答を 1 iteration 最大 64 件だけ反映する。backlog 中は次回 poll timeout を 0 にするが、各 iteration の key polling は省略しない。
- 検索要求は query を1回だけ `CompiledQuery` に変換し、各 path を1回だけ `PreparedCandidate` に変換する。rank-only 評価は match/score だけを返し、UI は query/options scope に保持した同じ compiled representation から可視行だけ span 付き評価する。
- prefix cache は raw query の単調延長だけでなく、`ignore_case`、`prefer_relative`、正規化 root、live snapshot identity が一致する場合だけ候補 index を再利用する。
- unknown-kind の `ext:` query は candidate を file/directory projection の両方で評価し、match/score が異なる候補だけ `is_dir` を解決する。同値の候補では filesystem probe を行わない。
- 10万件検索は TC-156 の fixed fixture、release mode、5回以上の sample で compile/cold/warm/query-shape/unknown-kind-ext/evaluated-candidate を分離計測し、100ms median target と weekly CI の 250ms hard ceiling を別々に扱う。
- 100万件検索は TC-185 として TC-156 の weekly release-mode entrypoint 内で続けて実行する。fixture は計測外で構築し、selective/dense の2 shapeを空 cacheで各7回測定して nearest-rank p50/p95/p99 と deterministic result signature を出力する。RSS は fixture 前後、検索中 peak、候補・結果・cache drop 後の最大1秒 quiescence後に samplingし、stable labelの観測値として保持するが閾値判定には使わない。
- インデックス再読込開始時は保留中の検索 request_id を破棄し、旧スナップショット由来の検索応答が UI 結果を上書きしないようにする。
- 非空クエリ時は再読込後の最初のインデックスバッチで検索を即時再開し、中断後の復帰遅延を最小化する。
- 非空クエリで indexing 中の自動再検索は、差分件数と時間の両閾値（既定: 2048件・1500ms）を満たす場合のみ実行し、indexing スループット低下を抑える。
- 検索は絞り込み後にスコア計算し、上位 `limit` を返す。
- prefix cache 用の候補集合は query 延長時だけ再利用し、cache 対象件数を超える大規模マッチでは全件ランキングを保存しない。
- 検索ランキングは score 降順 + 元の候補順序で決定し、`limit` が小さい場合は partial selection で top-N のみを整列する。
- 並列検索は候補数が閾値以上の場合だけ有効化し、`FLISTWALKER_SEARCH_THREADS` で worker 内の検索スレッド数を調整できる。
- 非アクティブタブは `results` と preview のような表示キャッシュを compact し、再表示時は `base_results` と現在の sort mode から復元する。`all_entries` / `entries` / index 本体は保持してタブ復帰で再インデックスを避ける。
- tab 保存状態は query/history、index 状態、result/selection を別 struct で保持し、tab 切替や復元時に必要な束だけ同期する。
- GUI の逐次反映は2系統とする: 空クエリはインデックス蓄積分を即時表示、非空クエリは一定件数/時間の閾値を満たしたときだけ検索用スナップショットを更新する。
- Active indexing の terminal drain は wall-clock frame budget を主な応答性ガードとする。探索中は表示更新の tail 短縮のため大きめの件数上限を許容し、`Finished` 後の内部後処理では小さい件数上限に切り替えて入力応答性を優先する。
- Active indexing の受信側は未反映 queue が 32,768 entry に達した frame では次の active data batch を queue へ展開せず ownership のまま 1 message 保留し、既存 backlog を先に drain する。これにより巨大な UI-owned `VecDeque` の capacity growth による全要素 relocation を避けつつ、`Finished` / `Failed` / `Canceled` の通常処理は維持する。nested FileList の hierarchy replacement は最初の `ReplaceAll` と後続 `Batch` をそれぞれ最大 1,024 entry に分け、単一 message の処理が wall-clock budget を迂回しないようにする。
- 空クエリかつ FILE/DIR/Ignore List のフィルタが不要な active indexing では、表示結果を `runtime.index.entries` の先頭 `limit` 件から直接作り、`runtime.entries` / `incremental_filtered_entries` の全件複製を terminal state まで遅延する。フィルタ切替で同じ状態へ戻った場合も、表示更新のためだけに `runtime.entries` へ全件 clone しない。
- FILE/DIR/Ignore List のフィルタが必要な active indexing では、ingest 時に更新している `incremental_filtered_entries` を terminal state の `runtime.entries` へ移し、`Finished` 後に `all_entries` 全体を再走査しない。
- 空クエリ・Score順のactive indexingでは、tab/root/request、処理済みprefix長、FILE/DIR/Ignore List/case/path投影、kind epoch/revisionが一致する増分フィルタ集合から先頭`limit`件だけを表示する。条件が変わらなければ追加batchごとに既存prefixのfilter/copyを繰り返さず、全件除外された空集合も処理済みとして終端へ昇格する。Ignore Listの同一性はWeak参照で保持し、古い除外語の大量payloadを追加所有しない。
- Esc/Ctrl+Gまたは編集で空クエリになった場合、旧search requestを取消し、再利用可能な増分集合があれば不要な候補準備をreclaimerへ移す。Full時はscratchと旧一覧を保持して次frameで再試行する。初回batch前はlast-good候補を用い、index途中の空集合と未取得を混同しない。空クエリ表示だけで検索用全候補を公開していないことはtab-owned `live_results_only`で記録し、再入力やAllMatches sortでは現行候補の準備を完了してから検索要求を送る。
- Ignore Caseのcheckboxと検索支援・undoは共通のcase変更処理を通す。Ignore Listが有効で除外語がある場合は候補membershipを再準備し、追加batchを待たずにlive/completed・空/非空queryへ反映する。
- terminalで不要になるincremental候補scratch（Create File List finalizationで置き換わるscratchを含む）は、committed-resource退役・pending_finish解除・runtime公開より前にreclaimerへ渡す。Full/Disconnectedでは元のallocationとpending terminal、last-good一覧/count/rowを維持してnoticeを出す。恒久disconnect時もUI側で破棄しない。
- kind filter 用の unknown path queue は、対象 entries を走査しながら entry 自体の kind / entry kind cache / pending set / in-flight set を直接参照して積む。全 path の中間 `Vec<PathBuf>` は作らず、queue へ入れる path だけ clone する。
- `Finished` 受信後に pending entries が残る場合、`pending_finish` を内部後処理 marker として保持し、status line の indexing 表示は解除する。repaint は `pending_finish` でも継続要求し、drain / terminal snapshot 確定 / request cleanup は後続 frame で完了させる。
- Active indexing の terminal cleanup は `pending_entries.clear()` に留め、直前まで大きかった queue の `shrink_to_fit()` を同じ UI frame で呼ばない。容量解放より入力応答性を優先し、必要な小規模 checkpoint shrink は失敗/キャンセルなど別経路に限定する。
- Status line 更新は cached memory text を使う通常経路と、`schedule_frame_repaint` から呼ぶ明示的な memory sampling 経路に分ける。notice clear / terminal cleanup / navigation のような頻繁な UI 状態更新では OS メモリ取得を同期実行しない。
- FileList 解析はストリーミングで処理し、`Started` を先行通知した後にバッチ反映する。大規模 FileList でも `Source: None` 固定を避け、新しい request_id で中断可能にする。
- FileList の `\` / `/` 混在は候補生成順でプラットフォーム優先の字句選択へ寄せ、初期ストリームで `exists()` / `try_exists()` を各行へ追加しない。line-only fast path を metadata-probe baseline より優先し、そのスループットを維持する。
- 非 Windows の dual-filter fast path では、Windows/WSL で生成された `\` 区切り FileList の実用性を優先して slash 正規化候補を先に流す。literal `\` を含む POSIX filename の厳密判定は初期ストリームでは扱わず、曖昧性解消のための per-line probe も入れない。
- Walker 解析は adaptive walker が `read_dir` から得た `file_type` を通常ファイル/ディレクトリの即時分類に使い、リンクや Windows shortcut のような追加確認が必要な項目だけを後続の kind resolver へ遅延させる。初期 `Finished` は後処理完了を待たないが、`Finished`/`Truncated` 後は unknown kind を自動で kind resolver キューへ積み、バックグラウンドで収束させる。
- Walker backend は adaptive のみを使う。jwalk fallback と runtime config の `developer.walker_backend` 切替口は廃止し、既存 config に残る `walker_backend` は読み込み時に削除する。
- adaptive backend では、developer-only の `developer.walker_adaptive_initial_limit` と `developer.walker_adaptive_max_limit` で初期同時 read_dir 数と最大同時 read_dir 数を別々に指定できる。未指定時の最大値は論理コア数の半分（端数切り上げ、最低 1、既定上限 8）とし、初期値は最大値の半分（端数切り上げ、最低 1）とする。既存 config に残る `walker_threads` は読み込み時に削除し、adaptive の最大 worker 数へは反映しない。
- adaptive backend の limit 調整は、短いサンプル窓の throughput を前回サンプルと比較し、直前の探索方向（increase/decrease）を保持して行う。方向未確定時は改善で増加、悪化で減少、微小変動で維持する。方向確定後は改善または微小変動で同方向へ進み、悪化で方向を反転する。これにより、低速 I/O で減らした結果の改善を次窓で増加へ誤反転することを避け、高速 I/O では小さな改善幅でも上限まで探索できる。
- Walker metrics summary は `adaptive_limit_*` に加えて `child_dir_publish_batches`、`max_queued_dirs`、`shared_frontier_soft_limit`、`frontier_saturation_fallbacks`、`frontier_soft_limit_bypasses`、`open_directory_frame_budget`、`max_open_directory_frames` を含む。これにより走行全体の並列度、frontier peak/soft limit、局所処理、完全性優先 bypass、open frame budget/peak を比較できる。`adaptive_limit_avg` は停止・join の尾を少し含みうる時間加重平均として扱う。
- adaptive worker 上限が 1 の場合、adaptive backend は serial fast path を使い、channel / condvar / worker pool の制御 overhead を避ける。
- adaptive traversal は GUI/TUI request の `include_files` / `include_dirs` を producer まで伝播する。単一種別モードでは対象外の通常 entry を entry channel 送信前に除外し、再帰にも不要な対象外 entry は path materialization も省く。file-only で対象外となる通常ディレクトリは再帰 frontier 用の path を生成する。symlink / Windows shortcut は target kind が未確定なら downstream classification へ残す。両種別モードは compile-time に filter 分岐を除去した worker / serial fast path を使う。
- 並列 worker は発見した child directory を 32 件単位で共有 FIFO frontier へ公開する。共有 frontier soft limit は最大 worker 数 × 64 directory とする。32 件分の空きがない場合は待たず、親の `ReadDir` と未公開 child を明示的な frame stack に保持して pending child を同じ worker で局所処理する。worker ごとの frame limit は `max(1, floor(64 / max_workers))`、全 worker の `open_directory_frame_budget` はその積とし、深さに比例した directory handle 増加を防ぐ。frame limit 到達時も共有 frontier が飽和していれば、候補欠落を避けるため pending child を soft limit より先へ公開し、`frontier_soft_limit_bypasses` を増やす。soft limit は通常の shallow-wide workload のメモリ圧抑制値であり、完全性を犠牲にする hard cap ではない。親 directory entry は frontier 公開または局所処理より先に送信して parent-before-child を維持し、global task の active count は局所 subtree 処理中も保持して frame stack 全体の終了後だけ decrement する。
- `developer.walker_adaptive_initial_limit` と `developer.walker_adaptive_max_limit` は developer-only tuning 項目として扱う。公開向け設定として拡張しない。
- adaptive backend は Windows 互換用の `Hidden + System + ReparsePoint` junction を候補から除外する。通常の directory symlink / junction は既定では再帰せず、`WalkOptions.follow_links` 有効時だけ worker 内で directory 判定後に再帰する。directory open 前に解決済み path を branch-local の共有祖先 chain と比較し、祖先循環だけを除外して別名を維持する。chain は最終所有者でも反復的にdropし、深い階層の再帰dropを避ける。既定falseでは祖先chainもdirectory単位のcanonicalizeも生成しない。
- GUI index worker と TUI index worker は `walker_runtime/` の adaptive traversal、runtime settings、entry classification、truncation notice を crate 内で共有する。TUI は設定済み上限へ到達したら残 batch、request identity 付き truncation、finished の順で応答し、最新 request の上限 notice を検索結果 status に合成して次の index 開始まで保持する。FileList 作成経路は表示 index から独立した完全 snapshot を維持する。
- `developer.walker_metrics = true` の場合だけ、GUI index worker は Walker request の terminal point で summary metrics を 1 件出力する。per-entry/per-directory log は出さず、Indexing 完了・キャンセル・失敗後に継続ロギングしない。
- `developer.walker_metrics_log_path` が空でない場合、上記 summary metrics を指定ファイルへ append する。これは Windows release GUI build のように stderr が取得しにくい環境での開発者向け計測導線とする。
- 階層 FileList 展開は全ディレクトリ走査ではなく、読み込み済み候補から `FileList.txt` / `filelist.txt` の完全一致エントリを抽出して判定する。
- 階層 FileList 展開で子 FileList を解析する経路も `should_cancel` を伝播し、supersede 時に中断できるようにする。
- include_files/include_dirs が両方有効な FileList 解析では、初期ロード時の `metadata` 依存を避けて候補パスの投入を優先し、FILE/DIR/LINK 表示種別は別ワーカーで遅延解決する。
- regex モードは include term をクエリ単位で事前コンパイルし、候補ごとの再コンパイルを禁止する。
- regex モードでも plain token は既存の literal/fuzzy matcher を流用し、regex 構文を含む token だけを事前コンパイル済み regex matcher へ振り分ける。
- プレビューキャッシュは固定上限（FIFO）で運用し、長時間セッションでのメモリ増加を抑制する。
- preview/highlight/sort metadata cache は app coordinator 直下の flat field ではなく専用 state struct へ束ね、root 変更や index refresh 開始時にまとめて破棄できるようにする。
- 結果ソートは `base_results` に検索エンジンの元順位を保持し、表示用 `results` だけを並び替えることで `Score` 復帰を O(n) で実現する。
- `Name` / `Path` ソートは UI スレッド上で `base_results` の clone を即時ソートし、追加 I/O を行わない。`Name` は最終componentを主キー、正規化済みfull pathを副キーとし、`Path` は正規化済みfull pathを主キーとする。
- `Modified` / `Created` / `Size` は結果スナップショット中の未キャッシュ path だけを sort worker へ送り、属性解決後に表示リストを更新する。`Size` は通常ファイルの `metadata.len()` だけを使い、フォルダは再帰計算せず `None` として末尾へ送る。
- 検索 worker は `results` とは別に limit 前の `total_match_count` を返し、GUI は `results.len()` と全マッチ件数を区別して status / result header に表示する。
- 結果ソートは `Shown results` / `All matches` の scope を持つ。`Shown results` は既存の `base_results` だけを並び替える既定動作とし、`All matches` の非 `Score` ソートは検索 worker で現在条件を満たす全マッチ集合を再評価して、選択 sort key の上位 `limit` 件だけを materialize する。
- `All matches` scope でも通常検索の prefix cache は全マッチ配列を恒久保持せず、count と表示上限分の結果だけを UI state へ返す。
- sort worker は index/search worker とは分離し、query 編集中や indexing 中でも UI フレームを塞がない。
- sort metadata cache は上限件数を持つ FIFO/LRU 風管理とし、root 変更や index refresh 開始時に破棄できるようにする。

- DES-007 Reliability / Error
- 失敗は `anyhow::Result` に集約し、CLI/GUI で表示責務を分離する。
- 外部コマンドは引数配列で起動し、シェル解釈を避ける。
- GUI 検索はワーカーからエラー文字列を受け取り、notice に反映する。
- GUI ワーカーは shutdown フラグを共有し、`Drop` 時に停止要求 + channel 切断 + `join` で終了待機する。
- `Drop` 時の worker `join` は短いタイムアウト付き（既定 250ms）で待機し、超過時はタイムアウト件数を記録して UI 終了の無限待ちと体感遅延を同時に避ける。
- bounded worker の queue depth / in-flight count は受理成功時だけ増加させ、queue からの取り出し、正常完了、error、cancel、stale、channel 切断、panic unwind のすべてで RAII load guard が必ず減算する。`Full` または `Disconnected` では guard を生成せず、負数化、二重解放、負荷枠のリークを許さない。
- scheduling lock は queue、load counter、accepting/closed flag の更新だけに限定し、filesystem metadata、canonicalize、walker/FileList 読み込み、OS action、response send、trace 出力を lock 保持中に実行しない。複数 lock が必要な場合は scheduler state から routing/state の順に固定し、I/O 前にすべて解放する。
- `WorkerRuntime` は action 2、kind 1、index 2 の各固定 worker を識別可能な名前付き `JoinHandle` として直接所有し、request ごとの detached thread や join 不能な入れ子 spawn を許可しない。
- shutdown は accepting flag を落として新規 dispatch を止め、request sender を閉じ、queue 内要求を terminal cancel/failed response で drain し、名前付き worker を join してから response endpoint を閉じる。UI thread が待つ shutdown budget は全体 250ms 以下とし、超過 worker は worker_id と timeout 時点の bounded-family 残存負荷を `load_scope=family` とともに記録して無限待ちしない。
- bounded worker の structured trace は worker family、worker_id、request_id、必要な場合の tab_id / epoch、queue_depth、in_flight、outcome（accepted / full / disconnected / completed / canceled / stale / failed / shutdown_timeout）を含める。family 共有 queue/load の値を個別 worker の負荷として偽装せず `load_scope=family` を付ける。path や executor error の詳細は既存の disclosure policy に従い、相関 field を欠いた自由形式ログだけにしない。
- OS シグナル（例: `Ctrl+C`）受信時は shutdown 要求を立て、GUI 側で window close を発行して終了処理へ収束させる。
- FileList 作成応答は request_id と要求 root を照合し、root 変更後に到着した旧 root の完了/失敗応答では再インデックスを行わず通知のみ行う。
- Create File List は app 側で pending confirmation / pending after index / in-flight request を 1 系列の状態として管理し、status panel の `Cancel Create File List` から共通キャンセル処理へ流す。
- Create File List の既存 FileList 検出と祖先追記要否判定は FileList worker の cancellable preflight とし、UI thread では filesystem を走査しない。preflight request が完全 path snapshot の ownership を worker へ移し、worker はその時点の target set、内容、mtime、権限、file object identity、親ディレクトリ identity を含む write plan を prepared request ID に結び付けて保持する。確認後の write は同じ plan だけを実行し、読取り前後と各 atomic replace 直前に target selection と fingerprint を再検証して、同一内容での差替えや metadata/親 identity の変化も最初の write 前に fail closed とする。path-based revalidation と atomic replace の間に外部プロセスが介入できる残余 TOCTOU は OS の compare-and-replace primitive を採用しない限り残る。正常 write、利用者 cancel、root/tab 変更、stale response、worker shutdown の全経路で、snapshot と plan は同じ固定 worker 上で消費または破棄する。
- God Object 解消の第一段として、Create File List は `app/filelist/` 内の FileList 専用 reducer/manager 境界へ寄せ、FileList worker request/response の lifecycle と stale/cancel 判定だけを manager 側で所有する。
- FileList 系の副作用は `UiCommand`、`WorkerCommand`、`FileListAppCommand` のようなカテゴリ化した戻り値で表現し、単一巨大 enum や `&mut FlistWalkerApp` への直接依存を増やさない。
- `pending_after_index`、tab/root 切替時の再インデックス判断、active/background tab への反映は orchestration として `FlistWalkerApp` 側に残し、manager は必要な app command を返すだけに留める。
- FileList 作成は各 target と同一 directory の create-new 一時ファイルへ出力し、bytes、既存 permissions、祖先の accessed/modified time を適用して file sync 後に atomic replace する。祖先 target は root に近い位置から上位へ処理し、root target を最後の commit point とする。replace 後の directory sync failure は destination が変化済みであることを型付き error で上位へ伝え、current target を含めて rollback しながら durability failure を保持する。通常の failure/cancel/panic は従来どおり rollback を試み、root commit 前の process abort は旧 root と append-only の祖先参照だけを残すため、再実行時の重複除去で収束する。untrusted root 内に新たな transaction marker は置かない。
- Create File List の worker request は cancel flag を持ち、テキスト生成、root 直下への最終置換、祖先 FileList 追記の各境界で中断確認する。キャンセル後は `Canceled` 応答を返し、UI は notice 更新だけ行う。
- FileList 作成後は root の親から filesystem root まで順に辿り、祖先ディレクトリ直下の既存 `FileList.txt` / `filelist.txt` へ子 FileList 参照を相対表現で追記する。既に同一参照がある場合は追記しない。
- 祖先 FileList を追記した場合でも、その FileList の mtime は更新前の値へ復元し、階層 FileList の新旧判定を崩さない。
- 祖先探索や親 FileList 読込/書込/mtime 復元で失敗した場合は、その時点で祖先追記だけを静かに打ち切り、root 自身の FileList 作成結果は成功扱いのまま維持する。
- Root 変更時は旧 root 由来の選択状態（current row / pinned / preview）を即時クリアし、旧パスの実行/コピー誤操作を防ぐ。
- Root 変更時は旧 root 向けの FileList 上書き確認ダイアログを破棄し、誤上書きを防ぐ。
- root 配下判定はアクション実行直前にのみ行い、FileList 読み込みや walker indexing のスループットへ影響させない。
- UI の root precheck は path component だけを評価する純粋な `Reject` / `Defer` 判定とし、canonicalize、metadata、存在確認を行わない。証明可能な字句的 escape だけを `Reject` とし、曖昧な形式は worker へ `Defer` する。
- Action worker は request が保持する trusted root を 1 回解決し、各 raw effective target について、component 正規化後の字句 path が trusted root 配下にあるか、解決済み target が解決済み root 配下にあるかを `Path` component の `starts_with` で確認し、どちらか一方を満たす場合だけ許可する。`to_string_lossy`、separator rewrite、manual case folding、単純な文字列 prefix は認可に使わない。
- direct action では選択 path、open-containing-folder では通常ファイル/file link の字句的な親または directory/directory link/junction 自身を raw effective target とする。表示用 path と execution path は別に保持する。
- 複数選択は全 target を事前認可してから dispatch を開始し、解決失敗、root 外、mixed valid/invalid のいずれも backend call 0 件で fail closed とする。解決済み execution path の重複は display 情報を維持したまま除く。
- Action worker は各 backend call の直前に raw effective target を再解決し、字句的 root または解決済み root のいずれかに対する containment を再確認して、最後に認可した解決済み execution path だけを OS leaf へ渡す。途中の再検証失敗では残件を停止し、完了件数を含む partial completion を notice と trace に残す。
- open-containing-folder の対象種別は worker で `symlink_metadata` と追跡 metadata を使って明示判定し、broken link、metadata error、特殊種別を fail closed とする。deduplicate された target も対応する全 source path から effective target を直前に再導出し、種別変更または解決先変更を検出する。
- rejected notice は選択時の display path または effective display path を用い、root 外の canonical destination を漏らさない。trusted root または target の解決失敗も同じく action error とする。
- executor error の詳細は内部 trace に限定し、利用者向け notice は display path と結果区分だけから構築する。trace は `request_id`、`result`（success / blocked / failed / partial）、`completed`、`total`、失敗段階を構造化 field として残す。
- UNC root も字句的 root または解決済み root の component containment を使い、いずれかの同一 root 配下だけを許可する。Windows の junction、symlink、case、extended prefix と実 UNC は自動または manual evidence で確認する。
- Regression guard: root 自体が link/junction の場合と、字句的 root 配下の link/junction が物理的な root 外へ解決される場合は、字句または解決済み scope の片方を満たすため許可する。両 scope の外側は拒否し、この lexical-or-resolved 契約を TC-050 / TC-051 で維持する。
- 最終再検証と OS 利用の間の link/object 差し替えを完全に排除できないため、handle-relative launch がない platform では residual TOCTOU として扱う。解決済み path を直ちに dispatch して窓を縮小するが、外部 action の原子性や rollback は保証しない。
- Create File List は root 直下の FileList 作成と祖先追記を分離し、祖先追記がありうる場合のみ GUI 側の確認ダイアログを通す。
- 祖先追記確認は write plan と同じ deterministic root target selector を使い、既存 `FileList.txt` / `filelist.txt` / case variant のうち実際に置換する path を祖先参照と比較する。
- 利用者が祖先追記を拒否した場合、root 直下の FileList 作成は成功扱いのまま維持し、祖先追記経路だけをスキップする。
- Source が FileList のアクティブタブで Create File List を要求した場合は、新規タブを作らずに同一タブへ `use_filelist = false` の一時 index request を発行する。完了後はその Walker snapshot で FileList を作成し、FileList 作成完了応答で同一タブを通常の FileList 再インデックスへ戻す。
- Source が Walker であっても Create File List は表示用 committed snapshot を UI frame 内で全件 clone せず、通常表示用 request を supersede する request-owned fresh Walker indexing と frame-budget finalization により完全 path snapshot を構築してから worker preflight へ ownership transfer する。この専用 request は `walker_max_entries` を適用せず、root 全体を対象にする。固定2 finalizer が満杯なら active terminal state と未移送 entries を保持したまま capacity を待ち、slot 上限を迂回しない。filter policy が finalization 中に変わった場合は FileList path accumulation も先頭から作り直す。タブ切替・cancel・worker send failure では request ID 単位で stale 化し、未移送 snapshot は固定 reclaimer の admission/debt 経路へ渡して UI thread で大量破棄しない。
- FileList 作成完了時の再インデックス対象は request に紐づく tab_id/root で判定し、元タブが background 化していてもその tab へ再インデックス request を投げる。完了時点で元タブの root が変わっていた場合は旧 root 応答として notice のみ更新し、tab 状態は戻さない。
- `Ctrl+Shift+C`（macOS では `Cmd+Shift+C`）は TextEdit の既定コピー処理より後段で実行し、検索窓フォーカス中でも選択パスコピーを優先する。`egui-winit` が clipboard chord を `Event::Copy` に正規化して `Key::C` を出さない場合も、Shift 付き primary modifier のときだけ選択パスコピーへ流す。
- Windows のプレビュー抑止判定は属性ビットだけに依存せず、`FileAttributeTagInfo` と `CfGetPlaceholderStateFromAttributeTag` を使って Cloud Files API 準拠 placeholder を検出する。属性/タグ取得に失敗した場合のみ既存の属性ビット判定へフォールバックする。
- プレビューデコーダは拡張子を見ず、先頭 64KiB を対象に UTF-8、BOM 付き UTF-16、その後に主要レガシー文字コードを順に試す。候補ごとに decode error と制御文字比率を評価し、妥当なテキストだけを preview に採用する。
- query 履歴はアプリ共通 state として保持し、全タブから同じ履歴集合を参照できるようにする。同一 query の再登録は exact duplicate を除去して最新位置へ移動し、GUI/TUI は同じ pure policy を使う。
- query 履歴保存は入力経路から独立して管理し、TextEdit / IME フォールバック / Emacs 風編集のどの入力経路でも「一定時間の無入力」または `Results` 移動開始時に最終 query だけを記録する。
- Emacs 風 keybindings は runtime config の `emacs_keybindings_enabled` で制御する。既定は `true` で既存操作を維持し、`false` のときは `consume_emacs_shortcut` と検索欄編集の Emacs 風処理を入口で無効化する。GUI の `ctrl_w_deletes_word_in_query` は既定 `false` とし、両設定が有効な検索欄・履歴検索フィルターだけで `Ctrl+W` をタブ終了より先に共有 text editing reducer へ渡す。reducer は空白と単語componentを後退し、直前が非空白・非単語separatorなら1 Unicode scalarを削除して停止を防ぐ。描画前 owner が key event の消費、TextEdit cursor 更新、query/history 再評価までを一度で完了し、後段 TextEdit との二重削除を防ぐ。IME 合成中の `Ctrl+W` は削除にも Windows/Linux のタブ終了にも流さない。macOS は `Ctrl+W` の編集と primary `Cmd+W` のタブ終了を分離する。TUI は競合がないため新設定に依存しない。
- IME 合成中は履歴確定を抑止し、`CompositionEnd` 後に反映された確定文字列のみが履歴候補になるようにする。
- `Ctrl+R` は履歴検索モードを開始し、同じ検索欄を履歴検索入力へ切り替える。履歴検索中は `Enter` / `Ctrl+J` / `Ctrl+M` で選択中履歴を query へ展開し、`Esc` / `Ctrl+G` で開始前 query を復元してキャンセルする。
- query 履歴は通常終了時の UI state に最大 100 件まで永続化し、次回起動時に後方互換を保って復元する。
- runtime config の `history_persist_disabled` が有効なときは、UI state 読み書き時に query history フィールドを空として扱い、履歴の永続化だけを無効にする。
- runtime config の migration、初回 seed、GUI 設定 open による不足 file 生成は同じ sidecar lock と in-lock current recheck を共有する。設定 open は現在プロセスの実効 config を候補にするが、待機中に別の協調 writer が current を作成した場合はその winner を保持し、process env を再適用しない。
- 結果ソート状態と sort scope はタブ単位で保持するが、query 変更や結果スナップショット更新時には `Score` / `Shown results` へ戻し、保留中の sort request_id を無効化する。
- 結果ペイン上部に `Sort` ドロップダウンを配置し、`Score` / `Name (A-Z)` / `Name (Z-A)` / `Path (A-Z)` / `Path (Z-A)` / `Modified (New)` / `Modified (Old)` / `Created (New)` / `Created (Old)` / `Size (Large)` / `Size (Small)` を選択可能にする。併せて `Scope` ドロップダウンを配置し、`Shown results` / `All matches` を選択可能にする。
- `Created` 属性は取得失敗を正常系として扱い、notice ではなく並び順の末尾送りだけで吸収する。
- `Size` 属性は通常ファイルだけを値ありとして扱い、フォルダや取得不可項目は notice ではなく並び順の末尾送りだけで吸収する。
- タブ復元は runtime config の `restore_tabs_enabled` が有効で、root/query/depth の明示起動値がないときだけ有効化する。永続化対象は `root/query/use_filelist/use_regex/ignore_case/include_files/include_dirs/max_depth/tab_accent/active_tab` の intent に限定し、entry/result snapshot と closed-tab history は保存しない。
- 起動優先順位は、明示 root >（明示 query/depth を含む session 抑止時）`Set as default` > last root > 通常 root、有効 session restore 時は saved active root > last root > default > 通常 root、Restore Tabs 有効だが有効 session がない場合は last root > default > 通常 root とする。
- runtime config の `restore_tabs_enabled` が有効な間は root 行の `Set as default` を disabled + logic no-op とする。tooltip は `Unavailable while Restore Tabs is enabled. The last session takes priority at startup, so the default root is not used.`、notice は `Set as default is unavailable while Restore Tabs is enabled because the last session takes priority at startup.` とする。
- tab model は intent、lifecycle（Dormant/Loading/Ready/Refreshing/Failed/Evicted）、optional committed snapshot、building snapshot、最終 activation sequence を所有する。request_id は generation token とし、一致する Finished だけが building を committed へ ownership swap する。refresh failure は committed を保持し、scheduler cancel は committed 有りなら Ready、無しなら Dormant へ戻す。
- Evicted tab の selected path は再構築中の復元 intent として保持する。empty-query の incremental index snapshot と non-empty query の indexing-time search response は partial なので、path が未出現でも intent を消費しない。path match で復元した時点、または同 generation の成功した terminal index / authoritative search snapshot にも存在しないと確定した時点で破棄する。search failure は不存在の確定に使わない。
- index scheduler は2 workerを Active 1件 + Warm 最大1件として運用する。Warm の activation は同 generation を promote し、旧 Active を残す場合は唯一の Warm へ demote する。両 slot 使用中に別 tab を activate した場合は role/activation sequence で決めた Warm 1件だけを cancel し、一括 preempt や unordered container による victim 選択を行わない。
- `TabSessionState` は scheduler role と別に active tenure（tab id、activation time、meaningful-interaction bit）と Recent Inactive 最大1件（tab id、protected-until）を所有する。deactivation 時に2秒以上の tenure または query/programmatic query replacement/root/source/filter/depth/selection/PIN/sort/明示refreshの操作があり、committed snapshot が存在する場合だけ transition candidate を作る。deactivated engagement、candidate、hard 回収対象は明示的な transition token に束ねる。通常候補だけで hard 上限を満たせない場合、token は固定 reclaimer queue の1枠を atomic に予約し、既存 Recent Inactive、次いでcandidateの順に必要な snapshot をUI上でdropせず退避する。commit は退避分を1件のbatch messageとして予約枠へ渡してから未回収candidateだけをRecent Inactiveへ確定し、予約/送信失敗は全snapshotと従前engagementを復元する。active close 成功時はcandidateを確定せず、active index の並べ替えだけでは tenure をリセットしない。
- meaningful-interaction bit は操作イベントの発生だけでは立てず、各 state mutation owner が保護対象状態の before/after を比較して実変更時だけ立てる。非空 PIN の全解除は meaningful とし、空 Results の clear、clamp 境界で動かない navigation、選択済み history row の再選択は no-op とする。
- 各 request は data 8 batch と fixed Started/Truncated/terminal slot を持つ request-scoped mailbox を所有する。publication は mailbox-local sequence で merge し、terminal は final sequence と preceding-data count を固定する。producer は Full 時も cancel/close/shutdown を観測でき、coordinator は Active、Warm fixed quota、stale terminal の順で drain する。refresh、root change、tab close に伴う mailbox close は request の通常終了境界であり、publish failure はその request だけを終了して resident index worker を維持する。worker loop は shutdown または request receiver 切断で終了する。production では shared unbounded response channel と deferred non-active queue を使用しない。
- background tab の search/index 応答は active tab の結果スナップショットへ直接触れず、tab-local state へ適用してから activation 時の restore 経路で前面へ戻す。
- active indexing 中のタブ切替では、切替時点の `index.entries` と同じ request_id の `pending_index_entries` を tab snapshot に保持し、background 完了時に `background_states` の batches と合流して terminal `all_entries` を確定する。background 側で `ReplaceAll` を受けた request は replacement snapshot を正とし、切替前の partial snapshot は破棄する。
- closed history は25件の lightweight intent を LIFO で保持し、元 index、sort/PIN/selection intent を含める。closed heavy snapshot と通常の open-inactive heavy snapshot は共通 LRU soft cache（count 2、weight 1,000,000 entry-unit）で保持する。active committed/building と sole Warm は scheduler owner として soft/hard 集計外、猶予中の Recent Inactive は30秒間だけ soft 集計外とする。inactive/closed 全体は count 3、weight 4,000,000 entry-unit の hard 上限を持ち、通常候補を LRU 順に回収しても超過する場合は Recent Inactive も回収する。猶予満了は専用 timer を持たず、次の budget enforcement で通常 LRU 候補へ戻す。Evicted closed intent は新 tab id と generation で Loading し、旧 routing を継承しない。
- heavy snapshot は固定 reclaimer workerへ ownership transfer して UI thread 外で drop する。reclaimer queue は4件で、通常送信とtab transition予約が同じatomic slot semaphoreを共有する。予約済みslotは通常retirementが消費できず、複数の保護snapshotは単一batch messageで送る。Full/disconnect/rollbackでは予約slotを解放し、payloadをcache/transition ownerへ戻す。retirement を必要とする terminal commit は固定 terminal-pending slot で保留し、debt 解消まで同 tab の次 generation と新規 heavy admissionを止める。worker runtime は admission停止、generation無効化、mailbox close/wake、request endpoint切断、bounded cleanup、named index/reclaimer join、残endpoint closeの順でshutdownする。
- Active/Warm handoff の未反映候補は既存の request-scoped background owner の deque に保持する。Active の old pending を先に、続いて deque の先頭を、既存の単一 frame drain の合計件数・時間 budget 内で取り込む。owner が残る間は同 request mailbox の後続応答を取り出さず、別 Warm mailbox の固定 quota は維持する。空になった allocation と source owner の reclaim admission が成功するまで barrier を保ち、Full では owner を完全に復元する。再 demotion の新候補は残りの末尾へ加え、ReplaceAll は従来の request-owned retirement 成功後だけ新世代へ進める。TC-207 の ordered handoff と TC-229 の実 worker promotion がこの境界を検証する。
- background terminal の snapshot 組み立ては `request_id` 所有の `PendingBackgroundIndexFinalize` へ移し、1 frame あたり最大2,048件かつ1msで partial/pending/continuation の結合、filter、Walker kind queue、FileList path snapshot を進める。finalization slot は index worker と同数の固定2件とし、mailbox の terminal publish を観測した時点で `inflight_requests` から外して worker admission と UI finalization ownership を分離する。slot Full 時は Finished を mailbox の固定 terminal slot に残し、同 request の `background_states` と合わせた request owner のままにする。新しい Active request は先に dispatch できるが、terminal 待ち tab の activation は `pending_activation_tab_id: Option<u64>` へ latest-only で保留し、slot admission 後に自動再開する。terminal publish 前に Warm を Active へ昇格した場合は、上記の ordered handoff が old pending と background remainder を先に取り込み、owner の退役後に Active Finished を適用する。既に background finalization を開始した request の promotion は、同じ request-owned finalization barrier の完了を待つ。Active promotion を含む最終化の各 frame で tab/runtime の Files、Folders、Ignore Case と global Ignore List generation を同期し、変更時は旧 filtered entries と kind queue/set を単一 reclaimer payload へ移してから最新 policy で paced rebuild する。reclaimer Full では旧 policy/output/cursor をそのまま rollback し、次 frame に最新設定を再評価する。入力 container の残容量も完了前に reclaimer へ移し、close/root boundary は current と superseded generation の finalization/background state/mailbox を単一 rollback 単位として扱い、shutdown drain は未完了および scratch-reclaim 待ち finalization も所有する。
- タブ並び替えは `render_tab_bar` がドラッグ開始/ホバー/ドロップを扱い、実際の `Vec<AppTabState>` 更新は `move_tab(from, to)` に集約する。
- `move_tab` は並び替え前に `sync_active_tab_state()` を実行し、active tab の `tab.id` を基準に移動後 index を再解決することで UI 状態の取り違えを防ぐ。
- タブ accent は `DropSendTo` の Slot Color palette を参照し、light/dark theme ごとに background/border/foreground を切り替える。
- `render_tab_bar` は active tab の accent を full-fill、inactive tab の accent を下辺の glow/line 装飾として描画し、右クリックメニューから accent の設定/解除を行う。
- タブ close ボタンは固定サイズの押下領域として描画し、hover 時はタブ accent または clear outline と同系色の背景・細い枠・カーソルを切り替えて close hit area を明示する。タブ本体の click/drag 領域とは別 response として扱う。
- Root 変更時は query 自体を維持しつつ、履歴参照位置と draft query のみ破棄して root 跨ぎの戻り操作を防ぐ。
- 検索窓フォーカス中でも `ArrowUp` / `ArrowDown` / `Ctrl+I` / `Ctrl+J` / `Ctrl+M` はアプリ側ショートカットを優先処理し、結果移動・PIN トグル・実行を抑止しない。
- GUI/TUI は `tab_pin_moves_to_next_row=true` のとき `Tab` / `Shift+Tab` と、`emacs_keybindings_enabled=true` の `Ctrl+I` による PIN トグル後に次行へ移動する。既定の `false` では current row を維持する。TUI event-loop state は process runtime config の両値を起動時に取り込む。
- GUI/TUI は `emacs_keybindings_enabled=false` のときも `ArrowUp` / `ArrowDown` / `Enter` / `Tab` / `Shift+Tab` など非 Emacs 風の操作を維持し、無効化対象を `Ctrl+N` / `Ctrl+P` / `Ctrl+V` / `Alt+V` / `Ctrl+G` / `Ctrl+R` / `Ctrl+I` / `Ctrl+J` / `Ctrl+M` と検索欄編集の Emacs 風 chord に限定する。
- GUI/TUI は Unicode character index と Emacs 風 text editing reducer を共有し、各 adapter は widget/terminal 固有の key event と selection の橋渡しだけを持つ。TUI は normal query と history filter に同じ reducer を適用し、runtime config が無効なら両方を処理しない。help と history/options/sort/root/FileList overlay renderer にも有効状態を渡し、無効な chord を操作案内へ表示しない。
- Windows の一般 `.ps1` は検索結果からの既定操作では直接実行せず、既定アプリでオープンする。自己更新用の内部 PowerShell script は updater モジュールからのみ起動する。
- 自己更新は release metadata、manifest、署名、binary、sidecar ごとの decoded-byte 上限と、接続 10 秒・無通信 30 秒・request 5 分・全体 10 分の deadline を transport/streaming reader の両層で強制する。
- redirect は 3 hop まで手動追跡し、各 hop で scheme/host を検証する。production は HTTPS の GitHub 配布 origin だけを許可し、test transport だけが loopback HTTP を許可する。
- `SHA256SUMS` / `SHA256SUMS.sig` を asset より先に取得し、strict line parser が必須 filename ごとに一意な SHA-256 を構築して署名検証を通過するまで binary/sidecar request を送らない。
- binary/sidecar は private create-new file へ streaming 書き込みし、decoded byte 数と SHA-256 を同じ pass で検証する。`Content-Length` は早期拒否の補助にだけ使い、欠落または虚偽でも reader 上限を迂回できない。
- staging ownership guard は main process が作成した file/directory だけを記録し、download/flush/hash/helper-spawn 前の失敗で partial を cleanup する。既存 path または ownership 未確認 path は削除しない。
- activation preparation は canonical executable parent 内に target ごとの `.new`、非衝突 backup、transaction ID と parent PID を同期した固定 transaction lock、versioned marker、acknowledgement を create-new で作り、directory/symlink/reparse point と parent identity 変化を拒否する。marker 作成前に parent が停止した orphan preparation は live owner なら defer する。dead owner で lock 以外の準備物が無い場合だけ lock を削除し、hash を照合できない準備物がある場合は全証跡を保持して operator recovery を要求する。
- marker は transaction ID、parent/helper PID と start/executable identity、global phase `prepared_parent_owned|helper_registered|applying_sidecars|binary_intent|binary_committed|rolling_back|rolled_back`、各 target の存在・旧新 hash・`prepared|intent|applied|rolled_back` を保持する。marker 更新は temporary state の同期と atomic replace を使い、各 filesystem mutation の直前に `intent`、hash 検証後に `applied` を永続化する。rollback は最初の復元より前に `rolling_back` を永続化し、中断後も旧 bundle への収束を再開する。
- parent は `prepared_parent_owned` を同期して helper を spawn し、観測した helper identity を `helper_registered` として同期する。helper は marker identity が自身と一致することを確認して acknowledgement を create-new/sync し、それまでは mutation しない。parent は ack を確認するまで ApplyStarted を返さず、本体 close を許可しない。
- helper executable は current executable の検証済み同一ディレクトリ create-new copy とし、hidden transaction ID/start token の完全一致時だけ通常起動より前に helper mode へ入る。marker は helper path/hash/PID/token を保持し、helper は自身の path/hash/PID/token を再検証する。
- acknowledgement 後、helper は parent 終了を最大 30 秒待つ。Windows の process handle 取得失敗は PID 不存在が確認できた場合以外 fail closed とする。pre-registration parent crash は helper が無変更で終了し、startup recovery は live parent を先に defer する。live helper は process executable path、copied-helper hash、marker token と acknowledgement を照合し、matching identity が確認できる場合だけ defer、mismatch は証跡を保持して ambiguous とする。owner 判定前に marker temporary artifact を変更しない。
- sidecar を先に適用し、binary を最後の commit point とする。各操作直前に prepared new hash と既存 target old hash を marker と再照合する。Windows の既存 target は updater process 内の native `ReplaceFileW(target, new, backup, 0, null, null)`、Linux は create-new backup の file/parent sync 後に same-directory rename と parent sync を用いる。不在 target は destination を上書きしない same-directory hard-link promotion、parent sync、source unlink を用いる。
- precommit/restart-process-creation failure は originally-present target を検証済み backup から atomic restore し、originally-absent target を除去して旧 bundle hash を検証する。binary commit 後は完全な新 bundle を hash 検証して startup cleanup へ渡す。
- startup recovery は phase と旧新 hash を照合して precommit rollback、committed、rolled-back のいずれかへ収束する。marker/lock/ack/helper/new/backup/failed/marker-temporary artifact は削除前に regular-file/type、transaction identity、利用可能な旧新 hash または token を一括検証する。backup 欠落、hash 不一致、不正 transition、path/type/reparse 変化は ambiguous とし、検証前に何も削除せず lock/marker/backup を保持して別 update を拒否する。利用者と運用者には [UPDATER_RECOVERY.md](../UPDATER_RECOVERY.md) の証跡保全と clean parallel install を案内し、generic な artifact 削除を復旧手段として提示しない。
- macOS は最新 version 検知のみ実施し、自動適用は非対応として release URL への案内に留める。

- DES-008 Testability
- Results の仮想描画は egui ScrollArea と同一の salt 変換で保存 state の ID を求め、keyboard 移動先が viewport 外のときだけ offset を補正する。描画 probe は thread-local・1呼出し単位で実際の ScrollArea ID/offset/viewport と行矩形を記録し、SP-010 / TC-212 の上下往復契約を production 計算から独立して検証する。
- indexer/search/actions/ui_model を独立モジュール化。
- query 解釈は `rust/src/query.rs` の immutable compiled representation へ集約し、search と UI highlight は同じ clause matcher と candidate normalization を再利用する。公開 adapter は互換 projection として維持する。
- ignore list は `CompiledIgnoreTerms` を CLI operation または GUI terms/case scope/pass で1回生成し、候補 loop へ再利用する。
- OS 依存処理は抽象境界を薄くして単体テスト可能性を維持。
- app regression tests は monolithic な `FlistWalkerApp` fixture へ集約し続けず、owner/command seam ごとに module を分ける。update lifecycle は `rust/src/app/tests/update_commands.rs`、session restore/startup root は `rust/src/app/tests/session_restore.rs`、tab interaction/background routing は `rust/src/app/tests/tab_lifecycle.rs` / `rust/src/app/tests/tab_drag.rs` / `rust/src/app/tests/tab_background_responses.rs`、tab snapshot contract は `rust/src/app/tests/tab_contract.rs`、index/filelist lifecycle は `rust/src/app/tests/index_pipeline/*` を基準に保守する。
  - `tab_contract.rs` には `tab_state_contract_round_trip_pins_field_layout` を置き、tab snapshot field の増減を compile-time で検出する。

- DES-011 Window Stability / Windows IME
- マルチディスプレイ跨ぎ時の一時的な巨大ウィンドウサイズを永続化しないよう、保存前に monitor 幅/高さでジオメトリをクランプする。
- 起動時はhidden windowを作り、eframe CreationContextの既存winit windowからmonitorごとのphysical rectangleとnative scaleを取得する。保存geometryのoptional pixels_per_pointでphysical positionへ変換し、最も近い実画面へsize/positionをclampして初回表示前に適用する。画面間の隙間を含むunion rectangleは使わない。
- 保存位置なし、scaleのないlegacy record、または無効位置でもmonitor列挙とposition操作が可能なら、現在の実monitor（取得不能なら列挙先頭）中央へ明示配置する。OS/WMの既定位置を安全なfallbackとみなさない。monitor列挙またはposition操作ができない場合だけ有限なbounded sizeを維持して保存位置を破棄する。保存schemaはoptional field追加に留め、旧recordも読める。
- Windows は起動時に System DPI Aware を有効化し、モニタ跨ぎ時の OS 側自動リサイズ揺れを低減する。
- IME 確定文字が TextEdit 側で落ちるフレーム向けに `CompositionEnd` 文字列のフォールバック反映を行う。
- `Space` / `Shift+Space` は IME/バックエンド差異があっても、TextEdit 側で空白未反映なら最低限の半角スペースをフォールバック挿入する。
- IME 関連の分岐は `FLISTWALKER_WINDOW_TRACE=1` で追跡し、`FLISTWALKER_WINDOW_TRACE_PATH` で出力先を明示指定できる。
- デバッグ用トレースは既定無効（`FLISTWALKER_WINDOW_TRACE=1` のときのみ有効）とし、通常運用への影響を避ける。

- CI / Release Hygiene details
- 通常 CI matrix に Linux を追加し、release 対象 OS と同じ観点で `cargo test --locked` を継続実行する。
- heavy PR CIはLinuxのclippy/coverage jobに加えてmacOS/Windows native jobでもlocked clippyを実行し、tag release preflightはLinux/macOS/Windows nativeの各jobでlocked test/clippyを再実行する。OS条件付きwarningをtag作成前とasset build前の両方で停止する。
- 依存脆弱性は `cargo audit` を CI で必須実行し、既知 CVE の流入を早期検知する。
- `x86_64-pc-windows-gnu` では `windres` が生成する `resource.o` を `flistwalker` バイナリへ直接リンクし、ライブラリターゲットだけに閉じた resource link で Explorer アイコンが欠落しないようにする。
- macOS notarization は現段階では手動ゲートとして維持し、draft release 作成後に docs / template で確認手順を明示する。

- Self Update Coordinator details
- GitHub Releases API の latest endpoint から `tag_name` / asset 名 / `browser_download_url` を取得し、現在 version と比較する。
- asset 選択は release asset 命名規則から current platform/arch と一致する standalone binary、対応する `*.README.txt` / `*.LICENSE.txt` / `*.THIRD_PARTY_NOTICES.txt`、`SHA256SUMS` / `SHA256SUMS.sig` を選択する。
- update worker は check/download を担当し、GUI 側は dialog 表示と再起動要求だけを扱う。
- TUI は専用の短命 update-check worker を起動し、candidate だけを channel で event loop へ渡す。event loop は candidate を永続的な英語 status notice に変換するだけで、download/apply を dispatch しない。check error と up-to-date は通常の TUI state を変更しない。
- `--check-update` / `--update` は GUI/TUI dispatch より前の独立 CLI 分岐で処理する。引数正規化は、この2操作がある場合に限り alias 由来の `--cli` を除去し、それ以外の引数は clap の排他検証へ残す。`--update` の明示指定だけが `prepare_and_start_update` を headless restart mode で呼び、manual-only candidate は release URL を返して apply しない。
- 起動時の update check 失敗は worker からエラー文字列つきで返し、GUI 側は通常操作を継続したまま軽量ダイアログで理由を表示する。利用者が「今後この種の起動時エラーを表示しない」を選んだ場合は UI state へ永続化し、次回以降の startup check failure dialog を抑止する。
- 更新署名公開鍵はビルド時環境変数から埋め込み、未設定ビルドでは Windows/Linux でも update candidate を manual-only に落として自動更新不能を明示する。
- restart 時は現在 executable path を置換対象とする。helperが起動する更新後processにはmode別の内部restart flagを渡し、公開CLI引数解析より先にterminal handoff recoveryを完了する。GUI modeはhelper終了とmarker/hash再検証後に内部flagを除いた既定引数で通常GUIを続行し、セッション復元を既存UI stateへ委譲する。Headless modeはdisplay serverへ接続せず回復後に終了する。更新後バイナリの起動失敗でrollbackした場合は、旧バイナリが新しい内部flagを解釈できない可能性があるため引数なしで再起動する。
- copied helper の起動では installation directory を `current_dir` に設定せず、Windows の `CreateProcessW` が child current directory に課す legacy path length 制約から helper executable path を分離する。Windows GUI-subsystem process は利用可能な console handle を通常持たず、launcher/test 由来の無効または stale standard handle も想定するため、helper と更新後/rollback後 process の hidden command は entrypoint subsystem に依存せず stdin/stdout/stderr を `NUL` へ固定する。helper 起動は最大3ラウンド・100ms間隔とし、canonical path が verbatim drive/UNC 形式なら各ラウンドで UTF-16 path identity を保った非 verbatim 表現も試す。全試行の OS error は診断へ残し、保存済みfailure、update state、status noticeを含む利用者向け文字列は共有display normalizationで文中すべてのverbatim prefixを除去する。
- production activation logic に test bypass を置かず、filesystem/restart/clock/failure injection seam へ inert dummy bundle を渡して成功・rollback・中断 recovery を検証する。Windows/Linux の実 filesystem 証跡は同一 filesystem の一時 directory に限定し、FlistWalker 本体または外部 application は起動しない。
- update dialog は `skip until next version` のチェック状態を持ち、Later 選択時に current target version を UI state へ永続化する。
- 起動時の update 応答は保存済み `skipped_update_target_version` と semver 比較し、target version がそれ以下なら dialog を出さず、より新しい version のみ再通知する。
- `FLISTWALKER_DISABLE_SELF_UPDATE` が truthy、または実行中バイナリと同一ディレクトリに同名ファイルがある場合は GUI 側で起動時 update request 自体を送らず、update install 側でも同じ判定で最終ガードする。
- 手動試験用 override として `FLISTWALKER_UPDATE_FEED_URL`, `FLISTWALKER_UPDATE_ALLOW_SAME_VERSION=1`, `FLISTWALKER_UPDATE_ALLOW_DOWNGRADE=1`, `FLISTWALKER_FORCE_UPDATE_CHECK_FAILURE` を読み取り、通常運用の GitHub latest 比較や startup failure dialog を内部検証用に再現できるようにする。

- DES-023 Stateful endurance harness
- `rust/src/app/tests/stateful_endurance/` は production の tab/root/query/index/search transition を呼ぶ test-only harness、論理 event generator、semantic snapshot/invariant checker、quiescence driver を所有する。
- deterministic profile は request channel を test 側で制御し、worker completion の順序、stale、cancel、failure を sleep なしで注入する。generator は repository 内の小さな固定 PRNG を使い、第三者 dependency を追加しない。
- semantic snapshot は実装 container の容量やアドレスではなく、live tab identity、active owner、root/query/result counts、request routing、queue/in-flight/progress state を記録する。ただし NFR-008 の固定 queue 上限は内部 contract として直接検証する。
- quiescence は harness が観測した要求を terminal response へ進め、poll/dispatch を固定回数で反復する。未収束は timeout による flaky 判定ではなく、残存 owner/request と event trace を伴う deterministic failure とする。
- required profile は通常の unit test に含め、scheduled profile は `#[ignore]` entrypoint と専用 workflow で実行する。実 worker profile は一時 root のみを使い、外部 action、updater、network、利用者設定を対象にしない。

## Linked-root candidate projection (DES-009)
GUI index worker は内部の canonical Root を discovery・hierarchy・depth 判定に維持し、応答sinkで Batch/ReplaceAll の候補を requested Root 配下へ字句的に投影する。Root外の候補は維持し、Windowsの通常/verbatim drive・UNC namespaceをfilesystem probeなしで揃える。UI・検索・highlightは同じ投影済みEntry.pathを共有するため、表示時のmetadata取得や解決Root用のUI状態を追加しない。

## DES-006 / DES-009: Indexing contention observations
`app/tests/indexing_perf/` owns fixture, independent oracle,16ms real-worker driver and paired release observations (TC-228, SP-007/SP-010). `index_mailbox` / `index_worker` expose opt-in request-local batch/phase/Full-wait observations only under `cfg(test)`, enabled before dispatch. Full wait covers first observed Full to successful publish or abort, with retry and blocked-batch counts separately retained. Normal builds retain their existing protocol and scheduling.

`search_coordinator` / `pipeline_owner` observe actual dispatch/routing/cancel requests. The test-only `worker/search_perf` weak registry is keyed by cancellation Arc identity and removed on worker take; it records actual start/evaluation/finish/cancel phases without per-candidate locks. A pre-canceled request cannot claim execution. Completion uses request identity and debt, and conservative overlap uses a confirmed-unsettled time before GUI rendering; early coordinator terminal settlement cannot substitute for complete snapshot settlement. Forward cursor high-water marks and actual evaluated work distinguish preparation from ingestion stalls.

The extension driver separates fixture topology and independent metadata/membership oracles from operation traces. Request-owned GUI/background finalization debt gates completion. Test-only successful-response observations for kind/sort/preview are bounded and disabled by default; background request release does not change active terminal settlement semantics. Stable Active/Warm setup cannot inherit a populated snapshot into the measured tab. Controlled reclaimer pressure and truncation profiles remain isolated from ordinary parallel tests and production settings. TC-229/230/231/232 cover these extensions.

For the fixed TabChain trace, `index_coordinator` also records bounded, default-disabled scalar observations of real routed Warm-request removal at the latest-map mutex. The driver binds these to the declared switch and actual tab/root acknowledgement before selecting the completion owner. Optional `pipeline` preemption markers are validated separately; a marker with no prior live ID requires the earlier removal witness. Standalone removal can be sufficient, but request selection never proves worker return. Typed terminal roles preserve required latest-generation success and the independently verified retained seed. No observer holds entry payloads or snapshots, and the fixed-switch acknowledgement does not establish Active-at-removal for other callers.

The full100k TabChain driver admits a switch only after an old-Warm request with an already-observed data-complete marker, Finished offer or Finished publication has its own committed identity/count and zero own finalization debt. Admission is rechecked next to revocation classification; it uses bounded scalar state, records wait start/end, and advances ordinary16ms production frames within the existing30s constructive deadline. Waiting stays inside t0→t2/t3. Independent final membership/order oracles still determine success. Production Warm replacement/cancellation is unchanged; a later publication/removal race still rejects a missing latest commit. For sub100k correctness runs, including explicitly selected small diagnostic measurements, static old-Warm-own-commit admission removes the small-fixture completion/removal race without adding a product fence or an old-seed Finished exception. This variant may allow outgoing indexing to finish during the wait and thus change which tab becomes Warm; declarations still follow actual ownership. It preserves the three requested switches/refreshes and fresh final identities, and does not prove abort pressure. `tabchain_input_policy` and wait reasons distinguish variants. Earlier trace measurements cannot be silently pooled with these admission policies.

`MailboxResponseSink` keeps its existing Full retry, stale return and worker error classification. A default-disabled test observer captures the actual Full data-send freshness abort with scalar request/tab/response/latest identity and time; a successful latest lock and shutdown=false distinguish a stale request from poison or shutdown. It preserves the freshness decision, records after unlocking, bounds the witness to one and flags duplicates without retaining a response payload. The typed latest-B victim at the second TabChain switch may use this exact witness to distinguish the existing receiver-closed Failed outcome from an arbitrary failure. The cause/abort/offer/publication/body chronology and retained-seed/full-oracle checks remain mandatory; required latest generations still need successful new snapshots.


### DES-006 / DES-009 same-job comparison boundary

`scripts/indexing_perf_gate.py` owns the fixed reference clone, shared process budgets, three-leg identity reconciliation, numeric proposal evaluator and flat artifact reconstruction. `scripts/indexing_perf.py` retains individual source-bound measurement admission; reference receipts keep actual GitHub execution identity with separate measured source and collector provenance. Measurement admission and timing acceptance are distinct: a valid measurement can fail a future numeric gate. Initial comparison-calibration mode has no product timing enforcement. [TC-233](../testplan/indexing-contention.md#same-job-reference-comparison-tooling-tc-233) links the public comparison contract to its executable regressions.

The maintained collector selects21 pairs for every f1 cell and7 for matched/stable through the existing test runner selector. Raw metadata, ABBA inventory and summaries require the exact group cadence; summary reconstruction verifies all pair identities and includes every value. This sampling refinement keeps production runtime, numeric proposal and finite process budgets unchanged; it requires fresh calibration rather than reinterpreting older seven-pair receipts.

The test-only observer prepares invariant fixture cardinality before timing. Its preallocated scalar trace holds at most256 measured-loop frames while tracking total/truncation and maximum start gap across the complete loop; serialization and full oracles remain after tentative t3. The repaired harness is pinned as a distinct immutable healthy measurement reference with exact non-harness Rust/build byte equivalence to the original source. No dirty overlay, production filter budget change or endpoint shift is used. The validator checks this new raw contract and leaves timing limits unchanged; fresh complete null/held-out confirmation still precedes activation.
