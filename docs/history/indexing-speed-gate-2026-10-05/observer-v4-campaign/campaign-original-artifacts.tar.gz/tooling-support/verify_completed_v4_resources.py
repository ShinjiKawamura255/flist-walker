"""Check actual completed campaign resources and early/final byte identity; no dispatch."""
import datetime,hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]);last=int(sys.argv[2]);uuids=set()
head=json.loads((root/'protocol-before-outcomes.json').read_text())['core_source']
for n in range(1,last+1):
 folder=root/f'session-{n}';admission=json.loads((folder/'admission.json').read_text());state=json.loads((folder/'state-final.json').read_text())
 assert admission['whole_null_pass'] is True and admission['source']==head
 assert state['headSha']==head and state['attempt']==1 and state['status']=='completed' and state['conclusion']=='success'
 groups=[]
 for packet in sorted((folder/'artifacts').iterdir()):
  receipt=json.loads((packet/'receipt.json').read_text());group=receipt['group'];build=measurement=0.
  for role in ('reference-before','candidate','reference-after'):
   paths=receipt['comparison']['legs'][role]
   leg=json.loads((packet/paths['receipt']).read_text());assert leg['run_id'] not in uuids;uuids.add(leg['run_id'])
   build+=leg['processes']['build']['elapsed_seconds'];measurement+=leg['processes']['measurement']['elapsed_seconds']
  job=next(j for j in state['jobs'] if j['name']==f'Indexing Contention ({group})');assert job['status']=='completed' and job['conclusion']=='success'
  duration=(datetime.datetime.fromisoformat(job['completedAt'])-datetime.datetime.fromisoformat(job['startedAt'])).total_seconds()
  assert 0<build<=1800 and 0<measurement<=2700 and 0<duration<=5400
  early=root/'tooling-support'/f'early-session-{n}-{group}'/'original-files-sha256.json'
  if early.exists():
   original=json.loads(early.read_text());actual={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in packet.iterdir() if f.is_file()};assert actual==original
  groups.append({'group':group,'build':build,'measurement':measurement,'job':duration})
 assert len(groups)==3
 result={'groups':groups,'unique_component_sessions':9,'unique_campaign_sessions_so_far':len(uuids),'early_original_bytes_equal_final':True}
 path=folder/'resource-admission.json'
 if path.exists():
  existing=json.loads(path.read_text());assert set(existing)<=set(result)
  assert all(result[k]==v for k,v in existing.items() if k!='groups')
  assert {g['group']:g for g in existing['groups']}=={g['group']:g for g in result['groups']}
 else:path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'whole_sessions':last,'unique_component_sessions':len(uuids),'all_shared_budgets':'PASS','early_original_bytes_equal_final':True}))
