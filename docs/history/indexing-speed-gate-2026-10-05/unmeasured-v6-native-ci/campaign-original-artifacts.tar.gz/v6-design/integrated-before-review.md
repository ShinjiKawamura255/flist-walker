**限定 BEFORE PASS。blocking／major／minor の指摘はありません。** matched のみ7→21 pairsへ増やす、未校正の設計候補として受け入れます。

HEAD `83aa173deeb16308c838606313131843247f566c`／reference `5ab325136bbca4d5a94d541b708f2e07c1eb1255` は不変。対象 packet SHA256 `fd50f3ae21a2b6944ab6b8f36492415b62fedfdfc6d837a6deace5538a311ea9` の25 subjects は、レビュー前後とも全 hash 一致しました。

確認した内容は以下です。
- 1638 rows／whole、8190 rows／five、136 observations＝68 mandatory median＋68 MAX diagnostic、45 UUID の件数が整合。
- 追加14 pairsを全役割で保持し、中央値への寄与・21点目のMAX・旧protocol拒否を検証するTDDが具体化されています。
- manifest24 itemsの `3k→3l→3m→4→5→6→7` が、実装・exact CI／controller確認・fresh five・activation・FINAL・merge・cleanupを順に要求しています。
- v5の失敗は非採用で保持。149 archive membersの全 hash 一致を独立確認しました。3,814,927 bytesは圧縮archive容量、展開member合計は35,109,308 bytesです。
- threshold、reference、Rust／runtime、全sample、物理guard、予算を変えず、新予約で最初から検証する方針は承認範囲内です。

21 pairsによるdrift改善、独立性、warmup収束、系統的順序差の解消は保証できません。RCR間隔も広がります。計画はこの限界と、失敗時の停止・変更なし再試行禁止を明示しています。

read-onlyで実装には関与していません。新実装、TDD実行、新source CI、controller確認、fresh five、activation、overall FINALは **NOT RUN**。性能合格や完了の認定ではありません。
