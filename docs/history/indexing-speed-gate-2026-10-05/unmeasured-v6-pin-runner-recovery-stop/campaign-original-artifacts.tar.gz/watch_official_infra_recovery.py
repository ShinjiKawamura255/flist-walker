"""Finite read-only official recovery watch; never reruns or dispatches."""
import datetime,json,pathlib,subprocess,time
out=pathlib.Path(__file__).parent
record=json.loads((out/'native-diagnostic-source-infra-recovery-exception.json').read_text())
end=datetime.datetime.fromisoformat(record['absolute_deadline_utc'])
last=None
while datetime.datetime.now(datetime.timezone.utc)<end:
    left=(end-datetime.datetime.now(datetime.timezone.utc)).total_seconds()
    r=subprocess.run(['curl','--fail','--silent','--show-error','--max-time',str(max(1,min(30,int(left)))),'https://www.githubstatus.com/api/v2/summary.json'],capture_output=True,timeout=max(1,min(35,left)))
    if r.returncode:raise RuntimeError('official status read failed; no recovery or retry inferred')
    s=json.loads(r.stdout);actions=next(c for c in s['components'] if c['name']=='Actions')
    incidents=[i for i in s['incidents'] if i['id']=='3q1yb5m7ltvb']
    recovered=actions['status']=='operational' or any(i['status']=='resolved' for i in incidents)
    now=datetime.datetime.now(datetime.timezone.utc)
    if now>=end:break
    (out/'githubstatus-recovery-watch-latest.json').write_bytes(r.stdout)
    key=(actions['status'],tuple((i['id'],i['status'],i['updated_at']) for i in incidents))
    if key!=last:print(json.dumps({'observed_at':now.isoformat(),'actions':actions['status'],'incident':key[1],'recovery_observed':recovered}),flush=True);last=key
    if recovered:
        (out/'githubstatus-official-recovery-original.json').write_bytes(r.stdout)
        (out/'githubstatus-official-recovery-observation.json').write_text(json.dumps({'observed_at':now.isoformat(),'deadline':end.isoformat(),'recovery':True,'actions':actions['status'],'incident':key[1],'retry_executed':False},indent=2)+'\n')
        raise SystemExit(0)
    time.sleep(min(30,max(0,(end-datetime.datetime.now(datetime.timezone.utc)).total_seconds())))
(out/'githubstatus-recovery-watch-timeout.json').write_text(json.dumps({'deadline':end.isoformat(),'recovery':False,'retry_executed':False,'disposition':'STOP; no deadline reset or inferred recovery'},indent=2)+'\n')
raise SystemExit(2)
