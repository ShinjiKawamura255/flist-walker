"""Read all failed predicates and original frames; never modify/adopt timing rows."""
import argparse,json,pathlib,sys
sys.path.insert(0,str(pathlib.Path.cwd()))
from scripts import indexing_perf_gate as gate,indexing_perf_contract as contract
p=argparse.ArgumentParser();p.add_argument('session',type=pathlib.Path);p.add_argument('output',type=pathlib.Path);a=p.parse_args()
results=[]
for packet in sorted((a.session/'artifacts').iterdir()):
 group=json.loads((packet/'receipt.json').read_text())['group'];report=gate.load_comparison(packet,group,proposal=True)
 failed=[d for d in report['decisions'] if d['status']!='pass']
 if not failed:continue
 roles={}
 for role in gate.ROLES:
  raw=packet/('measurement.log' if role=='candidate' else role+'-measurement.log')
  roles[role]=contract.validate_log(raw.read_text(),group)['rows']
 for decision in failed:
  samples={}
  for role,rows in roles.items():
   selected=[r for r in rows if r['comparison']==decision['case'] and r['source']==decision['source'] and (r['case']=='B0')==(decision['arm']=='control')]
   assert len(selected)==contract.PAIR_COUNTS[group]
   points=[]
   for row in selected:
    fields=('pair','position','order','index_ready_ms','results_ready_ms','data_publish_end_ms','terminal_publish_ms','bookkeeping_released_ms','last_confirmed_snapshot_unsettled_ms','max_no_work_progress_ms','max_ingest_gap_ms','max_frame_ms','frames','entries_emitted','driver_overhead_ms')
    point={k:row.get(k) for k in fields};point['frame_diagnostics']=row['frame_diagnostics'];points.append(point)
   peak=max(points,key=lambda r:r[decision['endpoint']]);samples[role]={'all_original_samples':points,'maximum_endpoint_sample_pair':peak['pair']}
  results.append({'group':group,'decision':decision,'samples':samples})
with a.output.open('x') as f:json.dump({'source':json.loads((a.session/'admission.json').read_text())['source'],'interpretation':'Original bounded observations only; no sample removal, causal attribution or new acceptance. Truncated frames remain declared; endpoints and all timings intact.','failed_predicates':results},f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps({'failed_predicates':len(results),'output':str(a.output)}))
