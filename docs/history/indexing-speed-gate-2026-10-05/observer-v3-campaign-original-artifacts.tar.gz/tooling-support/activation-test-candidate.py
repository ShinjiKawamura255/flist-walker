"""Default hosted collector controls; all inputs are synthetic, never perf evidence."""
from contextlib import ExitStack
import json
from pathlib import Path
import tempfile
import unittest

from scripts import indexing_perf_contract as contract
from scripts import indexing_perf_gate as gate
from scripts.tests import test_indexing_perf_gate as fixtures


class HostedActivationTests(unittest.TestCase):
    def test_default_hosted_collection_rejects_numeric_only_completion_regression(self):
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            options, calls, patches = fixtures.OrchestrationTests().simulate(folder, slow=True)
            with ExitStack() as stack:
                for patch in patches:
                    stack.enter_context(patch)
                # No enforcement-mode mock: exercise the published hosted default.
                with self.assertRaisesRegex(contract.ValidationError, "timing-fail"):
                    gate.collect_triplet(options)
            receipt = json.loads((Path(options.output)/"receipt.json").read_text())
            self.assertEqual(len(calls), 3)
            self.assertEqual(receipt["status"], "observed-valid")
            self.assertTrue(receipt["comparison"]["enforced"])
            self.assertEqual(gate.load_comparison(options.output, "f1")["status"], "timing-fail")

    def test_default_hosted_collection_accepts_normal_completion_and_records_enforcement(self):
        with tempfile.TemporaryDirectory() as name:
            options, calls, patches = fixtures.OrchestrationTests().simulate(Path(name))
            with ExitStack() as stack:
                for patch in patches:
                    stack.enter_context(patch)
                gate.collect_triplet(options)
            receipt = json.loads((Path(options.output)/"receipt.json").read_text())
            self.assertEqual(len(calls), 3)
            self.assertTrue(receipt["comparison"]["enforced"])
            self.assertEqual(gate.load_comparison(options.output, "f1")["status"], "pass")


if __name__ == "__main__":
    unittest.main()
