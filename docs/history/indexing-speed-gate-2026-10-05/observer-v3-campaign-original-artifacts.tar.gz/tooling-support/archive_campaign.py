#!/usr/bin/env python3
"""Archive original campaign bytes and verify every round-trip; no Git writes."""
import argparse,gzip,hashlib,io,json,pathlib,tarfile
p=argparse.ArgumentParser();p.add_argument('campaign',type=pathlib.Path);p.add_argument('output',type=pathlib.Path);a=p.parse_args()
source=a.campaign.resolve();dest=a.output.resolve();dest.mkdir(exist_ok=False)
files=sorted(x for x in source.rglob('*') if x.is_file())
assert files and not any(x.is_symlink() for x in source.rglob('*'))
entries=[]
archive=dest/'campaign-original-artifacts.tar.gz'
with archive.open('xb') as target,gzip.GzipFile(fileobj=target,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w|') as tar:
 for file in files:
  relative=file.relative_to(source).as_posix();data=file.read_bytes()
  info=tarfile.TarInfo(relative);info.size=len(data);info.mode=0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(data))
  entries.append({'path':relative,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
expected={x['path']:x for x in entries}
with tarfile.open(archive,mode='r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(expected)
 for member in members:
  assert member.isfile() and member.name in expected
  data=tar.extractfile(member).read();entry=expected.pop(member.name)
  assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
assert not expected
manifest={'format':'original-campaign-bytes-v1','archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':entries,'roundtrip_verified':True,'interpretation':'Original source/run/attempt/role and rejected outcomes remain unchanged; archive membership never means numeric PASS.'}
(dest/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'archive_bytes':archive.stat().st_size,'original_files':len(entries),'roundtrip':'PASS'}))
