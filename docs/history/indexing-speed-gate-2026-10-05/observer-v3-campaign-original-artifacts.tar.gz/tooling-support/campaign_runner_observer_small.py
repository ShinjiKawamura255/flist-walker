#!/usr/bin/env python3
"""Owned serial readonly/dispatch campaign. No policy writes or merge registration."""
import datetime,hashlib,json,pathlib,re,subprocess,sys,time
ROOT=pathlib.Path.cwd();sys.path.insert(0,str(ROOT))
from scripts import indexing_perf_gate as gate
from scripts import indexing_perf_contract as contract
REPO='ShinjiKawamura255/flist-walker';BRANCH='codex/indexing-perf-speed-gate'
OUT=ROOT/'rust/target/indexing-speed-gate/campaign-observer-small'
OUT.mkdir(exist_ok=False)
PROTOCOL=json.loads((ROOT/'rust/target/indexing-speed-gate/campaign-protocol-observer-small.json').read_text())
HEAD=PROTOCOL['core_source']
DEADLINE=time.monotonic()+6*3600

def save(path,data):
    path.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')

def command(argv,timeout=45):
    result=subprocess.run(argv,cwd=ROOT,text=True,capture_output=True,timeout=timeout)
    if result.returncode:
        raise RuntimeError(f'command exit{result.returncode}: '+str(argv[:4])+' '+result.stderr[-1000:])
    return result.stdout

def api(endpoint):return json.loads(command(['gh','api',f'repos/{REPO}/'+endpoint]))
def state(run):return json.loads(command(['gh','run','view',run,'--repo',REPO,'--json','status,conclusion,headSha,jobs,createdAt,attempt']))
def ensure_time():
    if (OUT/'STOP_REQUESTED').exists():raise RuntimeError('explicit local stop marker; no further dispatch')
    if time.monotonic()>=DEADLINE:raise RuntimeError('campaign finite6h bound exhausted')
def wait(run,expected,folder):
    old=None
    while True:
        ensure_time();s=state(run);save(folder/'state-latest.json',s)
        if s['headSha']!=expected:raise RuntimeError('run source mismatch')
        key=(s['status'],s['conclusion'],tuple((j['name'],j['status'],j['conclusion']) for j in s['jobs']))
        if key!=old:
            print(json.dumps({'run':run,'status':s['status'],'conclusion':s['conclusion'],
                'jobs':key[2]}),flush=True);old=key
        if s['status']=='completed':save(folder/'state-final.json',s);return s
        time.sleep(30)

def git_identity(revision):
    names=command(['git','ls-tree','-r','--name-only','-z',revision]).split('\0')
    files={}
    for name in names:
        if name.startswith(('rust/','scripts/','.github/workflows/','.cargo/')):
            content=subprocess.run(['git','show',revision+':'+name],cwd=ROOT,capture_output=True,check=True).stdout
            files[name]=hashlib.sha256(content).hexdigest()
    return {'head':revision,'tree':command(['git','rev-parse',revision+'^{tree}']).strip(),
            'files':files,'local_controls':[]}

def download_and_admit(run,expected,folder,required_null=True):
    command(['gh','run','download',run,'--repo',REPO,'--pattern',f'indexing-contention-{run}-1-*',
        '--dir',str(folder/'artifacts')],timeout=180)
    dirs=[p for p in (folder/'artifacts').iterdir() if p.is_dir()]
    if len(dirs)!=3:raise RuntimeError('exactly3artifacts required')
    measured=git_identity(expected);reference=git_identity(gate.REFERENCE)
    reports={};legrows=0;decisions=0;rejected=[]
    for packet in dirs:
        receipt=json.loads((packet/'receipt.json').read_text());group=receipt['group']
        if group in reports:raise RuntimeError('duplicate group')
        if receipt['comparison']['enforced'] is not False:raise RuntimeError('calibration enforcement mismatch')
        if receipt['source_before']!=measured:raise RuntimeError('candidate source/tree/allfiles mismatch')
        proposal=gate.load_comparison(packet,group,proposal=True)
        if required_null and (proposal['status']!='pass' or not proposal['null_rust_sources_equal']):
            save(folder/(group+'-rejected-proposal.json'),proposal)
            rejected.append(group+' '+proposal['status'])
        for role in gate.ROLES:
            component=json.loads((packet/(role+'-receipt.log')).read_text())
            if role!='candidate' and component['source_before']!=reference:
                raise RuntimeError('reference source/tree/allfiles mismatch')
            raw=packet/('measurement.log' if role=='candidate' else role+'-measurement.log')
            admitted=contract.validate_log(raw.read_bytes().decode(),group)
            legrows+=len(admitted['rows'])
        decisions+=proposal['decision_count'];reports[group]=proposal
        save(folder/(group+'-proposal.json'),proposal)
    if set(reports)!=set(contract.GROUPS) or legrows!=1386 or decisions!=136:
        raise RuntimeError('whole17cell/1386row/136predicate coverage incomplete')
    verdict={'run':run,'source':expected,'whole_null_pass':required_null,'leg_rows':legrows,
        'decision_count':decisions,'groups':{k:{'status':v['status'],'null_rust_sources_equal':v['null_rust_sources_equal'],
            'worst_candidate_ratio':max(d['candidate_ratio'] for d in v['decisions']),
            'worst_reference_drift':max(d['reference_drift_ratio'] for d in v['decisions'])} for k,v in reports.items()},
        'policy':gate.POLICY,'protocol':PROTOCOL}
    verdict['whole_null_pass']=required_null and not rejected
    save(folder/'admission.json',verdict)
    if rejected:raise RuntimeError('whole null session rejected: '+', '.join(rejected))
    return verdict

def wait_ci():
    while True:
        ensure_time();pr=json.loads(command(['gh','pr','view','173','--repo',REPO,'--json','headRefOid,statusCheckRollup,isDraft,autoMergeRequest,state']))
        save(OUT/'core-pr-checks.json',pr)
        if pr['headRefOid']!=HEAD or not pr['isDraft'] or pr['autoMergeRequest'] is not None or pr['state']!='OPEN':
            raise RuntimeError('calibration PR source/draft/no-registration identity changed')
        checks={x.get('name',x.get('context')):x for x in pr['statusCheckRollup']}
        bad=[n for n,x in checks.items() if x.get('conclusion') in ('FAILURE','CANCELLED','TIMED_OUT','ACTION_REQUIRED') or x.get('state') in ('ERROR','FAILURE')]
        # This fresh source requires ordinary CI attempt1 before any perf dispatch.
        ci=json.loads(command(['gh','run','view','37264939025','--repo',REPO,'--json','status,conclusion,headSha,attempt,jobs']))
        save(OUT/'source-ci-attempt1-latest.json',ci)
        if ci['headSha']!=HEAD or ci['attempt']!=1:raise RuntimeError('new CI identity changed')
        if ci['status']=='completed':
            if ci['conclusion']!='success':raise RuntimeError('new CI failed; stop and diagnose, no unchanged retry')
            if bad:raise RuntimeError('source PR checks failed: '+','.join(bad))
            if all(checks.get(n,{}).get('conclusion')=='SUCCESS' for n in ('CI Gate','CI Policy Guardian')):return
        time.sleep(30)

try:
    save(OUT/'protocol-before-outcomes.json',PROTOCOL)
    save(OUT/'previous-rejection.json',PROTOCOL['previous_rejection'])
    contracts=OUT/'source-contract/scripts';contracts.mkdir(parents=True)
    for filename in ('indexing_perf.py','indexing_perf_contract.py','indexing_perf_gate.py'):
        content=subprocess.run(['git','show',HEAD+':scripts/'+filename],cwd=ROOT,capture_output=True,check=True).stdout
        (contracts/filename).write_bytes(content)
    save(OUT/'source-contract-identity.json',git_identity(HEAD))
    support=OUT/'tooling-support';support.mkdir()
    for filename in ('campaign_runner_observer_small.py','campaign-protocol-observer-small.json','observer-small-fixture-before-review.md','observer-small-checkpoint.json','observer-small-pinning-checkpoint.json','observer-small-fixture-validation-plan.txt'):
        (support/filename).write_bytes((ROOT/'rust/target/indexing-speed-gate'/filename).read_bytes())
    wait_ci()
    admitted=[]
    for reserved in PROTOCOL['sessions']:
        ensure_time()
        current=api('git/ref/heads/'+BRANCH)['object']['sha']
        if current!=HEAD:raise RuntimeError('remote branch source changed before dispatch')
        folder=OUT/('session-'+str(reserved['index']));folder.mkdir()
        save(folder/'reservation-before-dispatch.json',reserved)
        output=command(['gh','workflow','run','perf-regression.yml','--repo',REPO,'--ref',BRANCH,'-f','indexing_calibration=true'])
        (folder/'dispatch.txt').write_text(output)
        match=re.search(r'/actions/runs/([0-9]+)',output)
        if not match:raise RuntimeError('dispatch returned no unambiguous run ID; do not retry')
        run=match[1];s=wait(run,HEAD,folder)
        if s['attempt']!=1:raise RuntimeError('rerun cannot be silently accepted')
        if s['conclusion']!='success':
            try:command(['gh','run','download',run,'--repo',REPO,'--dir',str(folder/'artifacts')],180)
            finally:raise RuntimeError('whole intended comparison run failed; preserve and diagnose')
        verdict=download_and_admit(run,HEAD,folder)
        verdict['role']=reserved['role'];save(folder/'admission.json',verdict);admitted.append(verdict)
        print(json.dumps({'session':reserved['index'],'role':reserved['role'],'run':run,
            'status':'whole-null-pass','groups':verdict['groups']}),flush=True)
        if reserved['index']==3:
            save(OUT/'frozen-before-held-out.json',{'source':HEAD,'policy':gate.POLICY,'sessions':[a['run'] for a in admitted],
                'held_out_reservations':[x for x in PROTOCOL['sessions'] if x['role']=='held-out'],
                'nothing_refit_from_heldouts':True})
    save(OUT/'complete.json',{'source':HEAD,'reference':gate.REFERENCE,'sessions':admitted,'status':'five-whole-null-sessions-pass',
        'leg_rows':6930,'decisions':680,'enforcement_active':False})
    print('CAMPAIGN_COMPLETE five whole null sessions; numeric activation remains pending',flush=True)
except BaseException as error:
    save(OUT/'stopped.json',{'source':HEAD,'error':type(error).__name__+': '+str(error),
        'enforcement_active':False,'no_unchanged_retry':True})
    print('CAMPAIGN_STOPPED '+type(error).__name__+': '+str(error),flush=True)
    raise
