"""Replay all five reserved calibration sessions from verified original archive bytes."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument("archive", type=Path)
parser.add_argument("manifest", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
manifest = json.loads(args.manifest.read_text())
assert hashlib.sha256(args.archive.read_bytes()).hexdigest() == manifest["archive_sha256"]
expected = {entry["path"]: entry for entry in manifest["files"]}
results = []
with tempfile.TemporaryDirectory(prefix="flistwalker-calibration-replay-") as name:
    root = Path(name)
    with tarfile.open(args.archive, "r:gz") as archive:
        members = archive.getmembers()
        assert len(members) == len(expected)
        for member in members:
            assert member.isfile() and member.name in expected
            relative = Path(member.name)
            assert not relative.is_absolute() and ".." not in relative.parts
            content = archive.extractfile(member).read()
            entry = expected.pop(member.name)
            assert len(content) == entry["bytes"]
            assert hashlib.sha256(content).hexdigest() == entry["sha256"]
            target = root / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(content)
    assert not expected
    complete = json.loads((root / "complete.json").read_text())
    frozen = json.loads((root / "frozen-before-held-out.json").read_text())
    assert complete["status"] == "five-whole-null-sessions-pass"
    assert len(complete["sessions"]) == 5
    assert frozen["sessions"] == [item["run"] for item in complete["sessions"][:3]]
    assert frozen["policy"] == complete["sessions"][0]["policy"]
    script = root / "source-contract/scripts/indexing_perf.py"
    for index, session in enumerate(complete["sessions"], 1):
        assert session["role"] == ("exploratory" if index <= 3 else "held-out")
        packets = sorted((root / f"session-{index}/artifacts").iterdir())
        assert len(packets) == 3
        groups = set()
        for packet in packets:
            receipt = json.loads((packet / "receipt.json").read_text())
            group = receipt["group"]
            assert group not in groups
            groups.add(group)
            assert receipt["source_before"]["head"] == complete["source"]
            validate = subprocess.run([sys.executable, str(script), "validate", "--group", group, str(packet)], capture_output=True, text=True, timeout=60)
            assert validate.returncode == 0, validate.stderr
            normal = json.loads(validate.stdout)
            assert normal["status"] == "comparison-calibration" and normal["timing_gate"] is None
            proposal_path = root / f"replay-{index}-{group}.json"
            proposal = subprocess.run([sys.executable, str(script), "compare-proposal", "--group", group, "--output", str(proposal_path), str(packet)], capture_output=True, text=True, timeout=60)
            assert proposal.returncode == 0, proposal.stderr
            report = json.loads(proposal_path.read_text())
            assert report["status"] == "pass" and report["null_rust_sources_equal"]
            results.append({"session": index, "role": session["role"], "run": session["run"], "group": group, "validate_exit": validate.returncode, "validation_status": normal["status"], "proposal_exit": proposal.returncode, "proposal_status": report["status"], "decisions": report["decision_count"]})
        assert groups == {"f1", "matched", "stable"}
assert len(results) == 15 and sum(item["decisions"] for item in results) == 680
with args.output.open("x") as stream:
    json.dump({"source": complete["source"], "archive_sha256": manifest["archive_sha256"], "original_contract_roundtrip_replay": "PASS", "numeric_enforcement_active_in_calibration": False, "results": results}, stream, indent=2)
    stream.write("\n")
print(json.dumps({"original_contract_replays": 15, "decisions": 680, "status": "PASS"}))
