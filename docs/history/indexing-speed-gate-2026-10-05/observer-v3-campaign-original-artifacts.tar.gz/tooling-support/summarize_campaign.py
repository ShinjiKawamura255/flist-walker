#!/usr/bin/env python3
"""Describe all pre-reserved comparisons; never pool absolute hosted timings."""
import collections,datetime,json,pathlib,sys
sys.path.insert(0,str(pathlib.Path.cwd()))
from scripts import indexing_perf_gate as gate
campaign=pathlib.Path(sys.argv[1]);output=pathlib.Path(sys.argv[2])
complete=json.loads((campaign/'complete.json').read_text())
assert complete['status']=='five-whole-null-sessions-pass' and len(complete['sessions'])==5
frozen=json.loads((campaign/'frozen-before-held-out.json').read_text())
assert frozen['policy']==gate.POLICY and frozen['sessions']==[s['run'] for s in complete['sessions'][:3]]
assert [s['role'] for s in complete['sessions']]==['exploratory']*3+['held-out']*2
cells=collections.defaultdict(list);families=collections.defaultdict(list);run_ids=set();resources=[]
for index,session in enumerate(complete['sessions'],1):
 folder=campaign/f'session-{index}'
 assert session['source']==complete['source']
 for packet in sorted((folder/'artifacts').iterdir()):
  receipt=json.loads((packet/'receipt.json').read_text());group=receipt['group']
  assert receipt['source_before']['head']==complete['source']
  report=gate.load_comparison(packet,group,proposal=True)
  assert report['status']=='pass' and report['null_rust_sources_equal']
  elapsed={'build':0.,'measurement':0.}
  for role,e in receipt['comparison']['legs'].items():
   component=json.loads((packet/e['receipt']).read_text())
   assert component['run_id'] not in run_ids
   run_ids.add(component['run_id'])
   for phase in elapsed:
    elapsed[phase]+=component['processes'][phase]['elapsed_seconds']
  assert elapsed['build']<=1800 and elapsed['measurement']<=2700
  state=json.loads((folder/'state-final.json').read_text())
  job=next(j for j in state['jobs'] if j['name']==f'Indexing Contention ({group})')
  assert state['headSha']==complete['source'] and state['attempt']==1
  assert job['status']=='completed' and job['conclusion']=='success'
  duration=(datetime.datetime.fromisoformat(job['completedAt'])-datetime.datetime.fromisoformat(job['startedAt'])).total_seconds()
  assert 0<duration<=5400
  resources.append({'session':index,'run':session['run'],'group':group,'shared_build_seconds':elapsed['build'],'shared_measurement_seconds':elapsed['measurement'],'job_seconds':duration,'bounds_seconds':{'build':1800,'measurement':2700,'job':5400}})
  for d in report['decisions']:
   point={'session':index,'role':session['role'],'run':session['run'],'candidate_ratio':d['candidate_ratio'],'reference_drift_ratio':d['reference_drift_ratio'],'status':d['status']}
   key=tuple(d[k] for k in ('case','source','arm','endpoint','statistic'))
   families[key].append(point);cells[(group,d['case'],d['source'])].append((d,point))
assert len(families)==136 and all(len(v)==5 for v in families.values()) and len(cells)==17 and len(run_ids)==45
rows=[]
for (group,case,source),points in sorted(cells.items()):
 med=[p['candidate_ratio'] for d,p in points if d['statistic']=='median']
 maximum=[p['candidate_ratio'] for d,p in points if d['statistic']=='max']
 rows.append({'group':group,'case':case,'source':source,'max_candidate_median_ratio':max(med),'max_candidate_maximum_ratio':max(maximum),'max_reference_drift_ratio':max(p['reference_drift_ratio'] for _,p in points)})
result={'source':complete['source'],'reference':complete['reference'],'policy':gate.POLICY,'session_count':5,'unique_component_run_ids':45,'resources':resources,'cells':rows,'families':[{'key':dict(zip(('case','source','arm','endpoint','statistic'),key)),'ratios':values} for key,values in sorted(families.items())],'interpretation':'Descriptive normalized per-comparison ratios only; no pooled absolute timing, fitted threshold, p95 or false-positive guarantee. Every pre-reserved session and numeric family is present.'}
with output.open('x') as stream:json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
print(json.dumps({'cells':17,'families':136,'sessions':5,'unique_components':45,'worst_candidate_ratio':max(x['candidate_ratio'] for v in families.values() for x in v),'worst_reference_drift':max(x['reference_drift_ratio'] for v in families.values() for x in v)}))
