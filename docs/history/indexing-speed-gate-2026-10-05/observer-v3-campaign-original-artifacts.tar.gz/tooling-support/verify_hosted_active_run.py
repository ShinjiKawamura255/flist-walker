"""Read and verify one completed active hosted comparison; never dispatch or retry."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT))
from scripts import indexing_perf_contract as contract
from scripts import indexing_perf_gate as gate

parser = argparse.ArgumentParser()
parser.add_argument("run")
parser.add_argument("head")
parser.add_argument("ref")
parser.add_argument("output", type=Path)
args = parser.parse_args()
REPO = "ShinjiKawamura255/flist-walker"


def command(argv, timeout=60):
    result = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=timeout)
    if result.returncode:
        raise RuntimeError(f"command exit {result.returncode}: {argv[:4]} {result.stderr.decode()[-1000:]}")
    return result.stdout


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def identity(revision):
    names = command(["git", "ls-tree", "-r", "--name-only", "-z", revision]).decode().split("\0")
    files = {}
    for name in names:
        if name.startswith(("rust/", "scripts/", ".github/workflows/", ".cargo/")):
            files[name] = hashlib.sha256(command(["git", "show", f"{revision}:{name}"])).hexdigest()
    return {"head": revision, "tree": command(["git", "rev-parse", revision + "^{tree}"]).decode().strip(), "files": files, "local_controls": []}


assert gate.ENFORCE_TIMING is True, "verifier requires the active published collector"
assert len(args.head) == 40 and args.run.isdecimal()
args.output.mkdir(parents=True, exist_ok=False)
try:
    expected = identity(args.head)
    reference = identity(gate.REFERENCE)
    scripts = args.output / "source-contract/scripts"
    scripts.mkdir(parents=True)
    for name in ("indexing_perf.py", "indexing_perf_contract.py", "indexing_perf_gate.py"):
        path = "scripts/" + name
        data = command(["git", "show", args.head + ":" + path])
        assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == expected["files"][path], "verification contract differs from actual source"
        (scripts / name).write_bytes(data)
    state = json.loads(command(["gh", "run", "view", args.run, "--repo", REPO, "--json", "status,conclusion,headSha,jobs,createdAt,attempt"]))
    save(args.output / "state-final.json", state)
    assert state["headSha"] == args.head and state["attempt"] == 1
    assert state["status"] == "completed" and state["conclusion"] == "success"
    command(["gh", "run", "download", args.run, "--repo", REPO, "--pattern", f"indexing-contention-{args.run}-1-*", "--dir", str(args.output / "artifacts")], 180)
    packets = sorted((args.output / "artifacts").iterdir())
    assert len(packets) == 3 and all(p.is_dir() for p in packets)
    groups = {}
    rows = decisions = 0
    uuids = set()
    for packet in packets:
        receipt = json.loads((packet / "receipt.json").read_text())
        group = receipt["group"]
        assert group not in groups
        assert receipt["comparison"]["enforced"] is True
        assert receipt["source_before"] == expected
        runner = receipt["runner"]
        assert runner["GITHUB_RUN_ID"] == args.run and runner["GITHUB_RUN_ATTEMPT"] == "1"
        assert runner["GITHUB_SHA"] == runner["GITHUB_WORKFLOW_SHA"] == args.head
        assert runner["GITHUB_WORKFLOW_REF"] == f"{REPO}/.github/workflows/perf-regression.yml@refs/heads/{args.ref}"
        report = gate.load_comparison(packet, group)
        assert report["status"] == "pass" and report["policy"] == gate.POLICY
        actual_cli = json.loads(command([sys.executable, str(scripts / "indexing_perf.py"), "validate", "--group", group, str(packet)]))
        assert actual_cli == report
        save(args.output / (group + "-active-cli-validation.json"), actual_cli)
        resource = {"build": 0., "measurement": 0.}
        for role in gate.ROLES:
            component = json.loads((packet / (role + "-receipt.log")).read_text())
            assert component["run_id"] not in uuids
            uuids.add(component["run_id"])
            assert component["source_before"] == (expected if role == "candidate" else reference)
            raw = packet / ("measurement.log" if role == "candidate" else role + "-measurement.log")
            rows += len(contract.validate_log(raw.read_text(), group)["rows"])
            for phase in resource:
                resource[phase] += component["processes"][phase]["elapsed_seconds"]
        assert resource["build"] <= 1800 and resource["measurement"] <= 2700
        job = next(j for j in state["jobs"] if j["name"] == f"Indexing Contention ({group})")
        assert job["status"] == "completed" and job["conclusion"] == "success"
        resource["job"] = (datetime.datetime.fromisoformat(job["completedAt"]) - datetime.datetime.fromisoformat(job["startedAt"])).total_seconds()
        assert 0 < resource["job"] <= 5400
        decisions += report["decision_count"]
        groups[group] = {"status": "pass", "enforced": True, "decision_count": report["decision_count"], "null_rust_sources_equal": report["null_rust_sources_equal"], "worst_candidate_ratio": max(d["candidate_ratio"] for d in report["decisions"]), "worst_reference_drift": max(d["reference_drift_ratio"] for d in report["decisions"]), "shared_resource_seconds": resource}
    assert set(groups) == set(contract.GROUPS) and rows == 1386 and decisions == 136 and len(uuids) == 9
    proof = {"status": "active-hosted-comparison-pass", "source": args.head, "tree": expected["tree"], "ref": args.ref, "run": args.run, "attempt": 1, "reference": gate.REFERENCE, "enforcement_active": True, "leg_rows": rows, "decisions": decisions, "unique_component_run_ids": len(uuids), "groups": groups, "policy": gate.POLICY, "protocol": gate.PROTOCOL}
    save(args.output / "active-proof.json", proof)
    print(json.dumps(proof, indent=2))
except BaseException as error:
    save(args.output / "verification-failed.json", {"source": args.head, "run": args.run, "error": f"{type(error).__name__}: {error}", "no_dispatch_or_retry": True})
    raise
