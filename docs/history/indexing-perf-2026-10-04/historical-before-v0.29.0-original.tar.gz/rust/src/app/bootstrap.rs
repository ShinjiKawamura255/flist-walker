use super::{
    spawn_action_worker, spawn_catalog_worker, spawn_filelist_worker, spawn_index_worker,
    spawn_kind_resolver_worker, spawn_preview_worker, spawn_root_validation_worker,
    spawn_search_worker, spawn_sort_metadata_worker, spawn_update_worker, ActionWorkerBus,
    AppRuntimeState, AppShellState, CacheStateBundle, CatalogWorkerBus, FeatureStateBundle,
    FileListManager, FileListWorkerBus, FlistWalkerApp, HighlightCacheState,
    IgnoreMatcherCacheState, IndexCoordinator, IndexRequest, IndexResponse, KindWorkerBus,
    LaunchSettings, PresetManagerState, PreviewCacheState, PreviewWorkerBus, QueryState, Receiver,
    RootBrowserState, RootValidationWorkerBus, RuntimeUiState, SavedTabState, SearchCoordinator,
    SearchRequest, SearchResponse, Sender, SortMetadataCacheState, SortWorkerBus, TabSessionState,
    UpdateWorkerBus, WorkerBus, WorkerRuntime,
};
use crate::app::state::{UpdateManager, UpdateState};
use crate::app::tab_resources::TabResourceReclaimer;
use crate::app::worker::channel::BoundedSender;
use crate::ignore_list::load_ignore_terms_from_current_exe;
use crate::path_utils::normalize_windows_path_buf;
use crate::runtime_config::current_runtime_config;
use std::collections::{HashMap, VecDeque};
#[cfg(test)]
use std::path::Path;
use std::path::PathBuf;
use std::sync::atomic::AtomicBool;
use std::sync::{Arc, Mutex};

type WorkerBootstrapParts = (
    Sender<SearchRequest>,
    Receiver<SearchResponse>,
    WorkerBus,
    BoundedSender<IndexRequest>,
    Receiver<IndexResponse>,
    Arc<Mutex<HashMap<u64, u64>>>,
    Arc<Mutex<HashMap<u64, Arc<super::index_mailbox::IndexResponseMailbox>>>>,
    Arc<Mutex<HashMap<u64, u64>>>,
    TabResourceReclaimer,
    WorkerRuntime,
);

type LaunchSeedParts = (
    PathBuf,
    usize,
    String,
    VecDeque<String>,
    Vec<PathBuf>,
    Option<PathBuf>,
    bool,
    bool,
    f32,
    Arc<Vec<String>>,
    UpdateState,
);

pub(super) struct AppWorkerBootstrap {
    search_tx: Sender<SearchRequest>,
    search_rx: Receiver<SearchResponse>,
    worker_bus: WorkerBus,
    index_tx: BoundedSender<IndexRequest>,
    index_rx: Receiver<IndexResponse>,
    latest_index_request_ids: Arc<Mutex<HashMap<u64, u64>>>,
    index_response_mailboxes:
        Arc<Mutex<HashMap<u64, Arc<super::index_mailbox::IndexResponseMailbox>>>>,
    latest_kind_epochs: Arc<Mutex<HashMap<u64, u64>>>,
    tab_resource_reclaimer: TabResourceReclaimer,
    worker_runtime: WorkerRuntime,
}

pub(super) struct AppLaunchSeed {
    root: PathBuf,
    limit: usize,
    query: String,
    query_history: VecDeque<String>,
    saved_roots: Vec<PathBuf>,
    default_root: Option<PathBuf>,
    show_preview: bool,
    ignore_list_enabled: bool,
    preview_panel_width: f32,
    ignore_list_terms: Arc<Vec<String>>,
    update_state: UpdateState,
}

impl AppWorkerBootstrap {
    pub(super) fn into_parts(self) -> WorkerBootstrapParts {
        (
            self.search_tx,
            self.search_rx,
            self.worker_bus,
            self.index_tx,
            self.index_rx,
            self.latest_index_request_ids,
            self.index_response_mailboxes,
            self.latest_kind_epochs,
            self.tab_resource_reclaimer,
            self.worker_runtime,
        )
    }
}

impl AppLaunchSeed {
    pub(super) fn into_parts(self) -> LaunchSeedParts {
        (
            self.root,
            self.limit,
            self.query,
            self.query_history,
            self.saved_roots,
            self.default_root,
            self.show_preview,
            self.ignore_list_enabled,
            self.preview_panel_width,
            self.ignore_list_terms,
            self.update_state,
        )
    }
}

impl FlistWalkerApp {
    pub(super) fn build_new(root: PathBuf, limit: usize, query: String) -> Self {
        let launch = LaunchSettings {
            show_preview: true,
            ignore_list_enabled: true,
            preview_panel_width: Self::DEFAULT_PREVIEW_PANEL_WIDTH,
            ..LaunchSettings::default()
        };
        Self::new_with_launch(
            root,
            limit,
            query,
            launch,
            None,
            crate::indexer::MaxDepth::unlimited(),
            false,
        )
    }

    #[cfg(test)]
    pub(super) fn build_new_with_test_settings(
        root: PathBuf,
        limit: usize,
        query: String,
        settings_base: &Path,
    ) -> Self {
        let launch = LaunchSettings {
            show_preview: true,
            ignore_list_enabled: true,
            preview_panel_width: Self::DEFAULT_PREVIEW_PANEL_WIDTH,
            test_settings_paths: Some(super::TestSettingsPaths {
                ui_state: Self::ui_state_file_path_in(settings_base),
                saved_roots: Self::saved_roots_file_path_in(settings_base),
            }),
            ..LaunchSettings::default()
        };
        Self::new_with_launch(
            root,
            limit,
            query,
            launch,
            None,
            crate::indexer::MaxDepth::unlimited(),
            false,
        )
    }

    pub(super) fn build_from_launch(
        root: PathBuf,
        limit: usize,
        query: String,
        root_explicit: bool,
        max_depth: crate::indexer::MaxDepth,
        follow_links: bool,
    ) -> Self {
        let launch = Self::load_launch_settings();
        let restore_tabs_enabled = Self::restore_tabs_enabled();
        let saved_last_root = launch.last_root.clone().map(normalize_windows_path_buf);
        let saved_default = launch.default_root.clone().map(normalize_windows_path_buf);
        let restore_session_allowed = Self::restore_session_allowed(
            restore_tabs_enabled,
            root_explicit,
            &query,
            max_depth,
            follow_links,
        );
        let restore_session = if restore_session_allowed {
            Self::sanitize_saved_tabs(&launch.restore_tabs, launch.restore_active_tab)
        } else {
            None
        };
        let chosen_root = Self::choose_startup_root(
            root,
            root_explicit,
            restore_session_allowed,
            restore_session.as_ref(),
            saved_last_root,
            saved_default,
        );
        let mut app = Self::new_with_launch(
            chosen_root,
            limit,
            query,
            launch,
            restore_session,
            max_depth,
            follow_links,
        );
        app.request_startup_update_check();
        app
    }

    pub(super) fn restore_session_allowed(
        restore_tabs_enabled: bool,
        root_explicit: bool,
        query: &str,
        max_depth: crate::indexer::MaxDepth,
        follow_links: bool,
    ) -> bool {
        restore_tabs_enabled
            && !root_explicit
            && query.trim().is_empty()
            && max_depth.is_unlimited()
            && !follow_links
    }

    pub(super) fn bootstrap_workers() -> AppWorkerBootstrap {
        let worker_shutdown = Arc::new(AtomicBool::new(false));
        let mut worker_runtime = WorkerRuntime::new(Arc::clone(&worker_shutdown));
        let (config_open, config_open_handle) =
            crate::app::worker::config_open::ConfigOpenService::spawn_with(
                Arc::clone(&worker_shutdown),
                Self::prepare_and_open_runtime_config,
            );
        worker_runtime.push("config-open", config_open_handle);
        let (config_settings, config_settings_handle) =
            crate::app::worker::config_settings::ConfigSettingsService::spawn(Arc::clone(
                &worker_shutdown,
            ));
        worker_runtime.push("config-settings", config_settings_handle);
        let (search_tx, search_rx, search_handle) =
            spawn_search_worker(Arc::clone(&worker_shutdown));
        worker_runtime.push("search", search_handle);
        let preview_freshness = Arc::new(std::sync::atomic::AtomicU64::new(0));
        let (preview_tx, preview_rx, preview_handle) =
            spawn_preview_worker(Arc::clone(&worker_shutdown), Arc::clone(&preview_freshness));
        worker_runtime.push("preview", preview_handle);
        let (action_tx, action_rx, action_handles, action_freshness) =
            spawn_action_worker(Arc::clone(&worker_shutdown));
        for (idx, handle) in action_handles.into_iter().enumerate() {
            worker_runtime.push(format!("action-{idx}"), handle);
        }
        let (sort_tx, sort_rx, sort_handle) =
            spawn_sort_metadata_worker(Arc::clone(&worker_shutdown));
        worker_runtime.push("sort-metadata", sort_handle);
        let latest_kind_epochs = Arc::new(Mutex::new(HashMap::new()));
        let (kind_tx, kind_rx, kind_handle) = spawn_kind_resolver_worker(
            Arc::clone(&worker_shutdown),
            Arc::clone(&latest_kind_epochs),
        );
        worker_runtime.push("kind-resolver", kind_handle);
        let (filelist_tx, filelist_rx, filelist_handle) =
            spawn_filelist_worker(Arc::clone(&worker_shutdown));
        worker_runtime.push("filelist", filelist_handle);
        let (update_tx, update_rx, update_handle) =
            spawn_update_worker(Arc::clone(&worker_shutdown));
        worker_runtime.push("update", update_handle);
        let (catalog_tx, catalog_rx, catalog_handle) =
            spawn_catalog_worker(Arc::clone(&worker_shutdown));
        worker_runtime.push("search-catalog", catalog_handle);
        let (root_validation_tx, root_validation_rx, root_validation_handle) =
            spawn_root_validation_worker(Arc::clone(&worker_shutdown));
        worker_runtime.push("root-validation", root_validation_handle);
        let latest_index_request_ids = Arc::new(Mutex::new(HashMap::new()));
        let (index_tx, index_rx, index_response_mailboxes, index_handles) = spawn_index_worker(
            Arc::clone(&worker_shutdown),
            Arc::clone(&latest_index_request_ids),
        );
        for (idx, handle) in index_handles.into_iter().enumerate() {
            worker_runtime.push(format!("index-{idx}"), handle);
        }
        let (tab_resource_reclaimer, tab_resource_reclaimer_handle) =
            TabResourceReclaimer::spawn_managed();
        worker_runtime.push("tab-reclaimer", tab_resource_reclaimer_handle);

        AppWorkerBootstrap {
            search_tx,
            search_rx,
            worker_bus: WorkerBus {
                config_open,
                config_settings,
                preview: PreviewWorkerBus {
                    tx: preview_tx,
                    rx: preview_rx,
                    next_request_id: 1,
                    pending_request_id: None,
                    in_progress: false,
                    freshness: preview_freshness,
                    worker_inflight_request_id: None,
                    worker_input_document_bytes: 0,
                    latest_request: None,
                },
                action: ActionWorkerBus {
                    tx: action_tx,
                    rx: action_rx,
                    next_request_id: 1,
                    pending_request_id: None,
                    in_progress: false,
                    freshness: action_freshness,
                },
                sort: SortWorkerBus {
                    tx: sort_tx,
                    rx: sort_rx,
                    next_request_id: 1,
                    pending_request_id: None,
                    in_progress: false,
                    pending_total_match_count: None,
                },
                kind: KindWorkerBus {
                    tx: kind_tx,
                    rx: kind_rx,
                },
                filelist: FileListWorkerBus {
                    tx: filelist_tx,
                    rx: filelist_rx,
                },
                update: UpdateWorkerBus {
                    tx: update_tx,
                    rx: update_rx,
                },
                catalog: CatalogWorkerBus {
                    tx: catalog_tx,
                    rx: catalog_rx,
                    next_request_id: 1,
                    pending_request_id: None,
                    in_progress: false,
                },
                root_validation: RootValidationWorkerBus {
                    tx: root_validation_tx,
                    rx: root_validation_rx,
                    next_request_id: 1,
                    pending_request_id: None,
                    in_progress: false,
                },
            },
            index_tx,
            index_rx,
            latest_index_request_ids,
            index_response_mailboxes,
            latest_kind_epochs,
            tab_resource_reclaimer,
            worker_runtime,
        }
    }

    pub(super) fn launch_seed(
        root: PathBuf,
        limit: usize,
        query: String,
        launch: &LaunchSettings,
        #[cfg(test)] test_saved_roots_path: Option<&Path>,
    ) -> AppLaunchSeed {
        #[cfg(test)]
        let saved_roots = test_saved_roots_path
            .map(Self::load_saved_roots_from_path)
            .unwrap_or_default();
        #[cfg(not(test))]
        let saved_roots = Self::load_saved_roots();
        AppLaunchSeed {
            root: normalize_windows_path_buf(root),
            limit: limit.clamp(1, 1000),
            query,
            query_history: launch.query_history.iter().cloned().collect(),
            saved_roots,
            default_root: launch.default_root.clone(),
            show_preview: launch.show_preview,
            ignore_list_enabled: launch.ignore_list_enabled,
            preview_panel_width: launch
                .preview_panel_width
                .max(Self::MIN_PREVIEW_PANEL_WIDTH),
            ignore_list_terms: Arc::new(load_ignore_terms_from_current_exe()),
            update_state: UpdateState {
                skipped_target_version: launch.skipped_update_target_version.clone(),
                suppress_check_failure_dialog: launch.suppress_update_check_failure_dialog,
                ..UpdateState::default()
            },
        }
    }

    fn new_with_launch(
        root: PathBuf,
        limit: usize,
        query: String,
        launch: LaunchSettings,
        restore_session: Option<(Vec<SavedTabState>, usize)>,
        max_depth: crate::indexer::MaxDepth,
        follow_links: bool,
    ) -> Self {
        let (
            search_tx,
            search_rx,
            worker_bus,
            index_tx,
            index_rx,
            latest_index_request_ids,
            index_response_mailboxes,
            latest_kind_epochs,
            tab_resource_reclaimer,
            worker_runtime,
        ) = Self::bootstrap_workers().into_parts();
        let (
            root,
            limit,
            query,
            query_history,
            saved_roots,
            default_root,
            show_preview,
            ignore_list_enabled,
            preview_panel_width,
            ignore_list_terms,
            update_state,
        ) = Self::launch_seed(
            root,
            limit,
            query,
            &launch,
            #[cfg(test)]
            launch
                .test_settings_paths
                .as_ref()
                .map(|paths| paths.saved_roots.as_path()),
        )
        .into_parts();
        let runtime_config = current_runtime_config();
        let emacs_keybindings_enabled = runtime_config.emacs_keybindings_enabled;
        let ctrl_w_deletes_word_in_query = runtime_config.ctrl_w_deletes_word_in_query;
        let tab_pin_moves_to_next_row = runtime_config.tab_pin_moves_to_next_row;
        let preview_retirement = tab_resource_reclaimer.preview_handle();
        let mut app = Self {
            settings_dialog: Default::default(),
            paged_preview_view: Default::default(),
            deferred_preview_response: None,
            parked_preview_request: None,
            deferred_latest_preview_request: None,
            deferred_more_intent: None,
            shell: AppShellState {
                runtime: AppRuntimeState::new(
                    root,
                    limit,
                    max_depth,
                    follow_links,
                    QueryState::new(query, query_history),
                    ignore_list_terms,
                    Default::default(),
                    emacs_keybindings_enabled,
                    ctrl_w_deletes_word_in_query,
                    tab_pin_moves_to_next_row,
                ),
                search: SearchCoordinator::new(search_tx, search_rx),
                worker_bus,
                indexing: IndexCoordinator::new(
                    index_tx,
                    index_rx,
                    latest_index_request_ids,
                    index_response_mailboxes,
                    latest_kind_epochs,
                ),
                ui: RuntimeUiState::new(show_preview, ignore_list_enabled, preview_panel_width),
                cache: CacheStateBundle {
                    preview: PreviewCacheState::default(),
                    highlight: HighlightCacheState::with_scope_ignore_case(true),
                    ignore_matcher: IgnoreMatcherCacheState::default(),
                    sort_metadata: SortMetadataCacheState::default(),
                },
                tabs: TabSessionState::with_resource_reclaimer(tab_resource_reclaimer),
                features: FeatureStateBundle {
                    root_browser: RootBrowserState {
                        #[cfg(test)]
                        browse_dialog_result: None,
                        #[cfg(test)]
                        last_browse_dialog_root: None,
                        saved_roots,
                        default_root,
                        manage_list: Default::default(),
                        next_settings_request_id: 1,
                        pending_settings_commit: None,
                    },
                    presets: PresetManagerState::default(),
                    filelist: FileListManager::default(),
                    update: UpdateManager::from_state(update_state),
                },
                worker_runtime: Some(worker_runtime),
            },
            #[cfg(test)]
            test_settings_paths: launch.test_settings_paths.clone(),
        };
        app.shell
            .runtime
            .install_preview_retirement(preview_retirement);
        Self::append_window_trace(
            "launch_query_initialized",
            &Self::query_trace_summary(&app.shell.runtime.query_state.query),
        );
        Self::append_window_trace("app_initialized", "");
        if let Some((tabs, active_tab)) = restore_session {
            app.initialize_tabs_from_saved(tabs, active_tab);
        } else {
            app.initialize_tabs();
            app.request_index_refresh();
        }
        app
    }
}
