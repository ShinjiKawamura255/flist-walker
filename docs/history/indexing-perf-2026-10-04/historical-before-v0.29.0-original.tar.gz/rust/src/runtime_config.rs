use crate::fs_atomic::{
    acquire_sidecar_lock, atomic_write_replaced_destination, write_bytes_atomic,
    write_bytes_atomic_with_metadata, write_text_atomic, AtomicWriteMetadata,
};
use anyhow::{bail, Context, Result};
use serde::{Deserialize, Serialize};
use std::env;
use std::fs;
use std::io::Read;
use std::path::{Path, PathBuf};
use std::sync::{Mutex, OnceLock};
use std::time::Duration;
use tracing::warn;

pub const RUNTIME_CONFIG_FILE_NAME: &str = ".flistwalker_config.json";
pub const DEFAULT_UPDATE_FEED_URL: &str =
    "https://api.github.com/repos/ShinjiKawamura255/flist-walker/releases/latest";

#[cfg(windows)]
const WINDOWS_SETTINGS_DIR_NAME: &str = "flistwalker";
#[cfg(not(windows))]
const UNIX_SETTINGS_DIR_NAME: &str = ".flistwalker";
const SEARCH_PARALLEL_THRESHOLD_DEFAULT: usize = 25_000;
const WALKER_MAX_ENTRIES_DEFAULT: usize = 500_000;
const GUI_EDITABLE_SETTINGS_MAX_BYTES: usize = 64 * 1024;
const WINDOW_TRACE_LOG_NAME: &str = ".flistwalker_window_trace.log";

const SEARCH_PARALLEL_THRESHOLD_ENV: &str = "FLISTWALKER_SEARCH_PARALLEL_THRESHOLD";
const SEARCH_THREADS_ENV: &str = "FLISTWALKER_SEARCH_THREADS";
const WALKER_MAX_ENTRIES_ENV: &str = "FLISTWALKER_WALKER_MAX_ENTRIES";
const WINDOW_TRACE_ENV: &str = "FLISTWALKER_WINDOW_TRACE";
const WINDOW_TRACE_VERBOSE_ENV: &str = "FLISTWALKER_WINDOW_TRACE_VERBOSE";
const WINDOW_TRACE_PATH_ENV: &str = "FLISTWALKER_WINDOW_TRACE_PATH";
const HISTORY_PERSIST_ENV: &str = "FLISTWALKER_DISABLE_HISTORY_PERSIST";
const RESTORE_TABS_ENV: &str = "FLISTWALKER_RESTORE_TABS";
const UPDATE_FEED_URL_ENV: &str = "FLISTWALKER_UPDATE_FEED_URL";
const UPDATE_ALLOW_SAME_VERSION_ENV: &str = "FLISTWALKER_UPDATE_ALLOW_SAME_VERSION";
const UPDATE_ALLOW_DOWNGRADE_ENV: &str = "FLISTWALKER_UPDATE_ALLOW_DOWNGRADE";
const DISABLE_SELF_UPDATE_ENV: &str = "FLISTWALKER_DISABLE_SELF_UPDATE";
const FORCE_UPDATE_CHECK_FAILURE_ENV: &str = "FLISTWALKER_FORCE_UPDATE_CHECK_FAILURE";

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default)]
pub struct RuntimeConfig {
    pub search_parallel_threshold: usize,
    pub search_threads: usize,
    pub walker_max_entries: usize,
    pub window_trace_enabled: bool,
    pub window_trace_verbose: bool,
    pub window_trace_path: String,
    pub history_persist_disabled: bool,
    pub restore_tabs_enabled: bool,
    pub emacs_keybindings_enabled: bool,
    pub ctrl_w_deletes_word_in_query: bool,
    pub tab_pin_moves_to_next_row: bool,
    pub update_feed_url: String,
    pub update_allow_same_version: bool,
    pub update_allow_downgrade: bool,
    pub disable_self_update: bool,
    pub force_update_check_failure: String,
    #[serde(skip_serializing_if = "DeveloperRuntimeConfig::is_default")]
    pub developer: DeveloperRuntimeConfig,
}

/// The public settings edited by the GUI. This does not mutate the effective
/// process configuration until the next application launch.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct EditableSettings {
    pub restore_tabs_enabled: bool,
    pub history_persist_disabled: bool,
    pub emacs_keybindings_enabled: bool,
    pub ctrl_w_deletes_word_in_query: bool,
    pub tab_pin_moves_to_next_row: bool,
    pub walker_max_entries: usize,
}

impl From<&RuntimeConfig> for EditableSettings {
    fn from(config: &RuntimeConfig) -> Self {
        Self {
            restore_tabs_enabled: config.restore_tabs_enabled,
            history_persist_disabled: config.history_persist_disabled,
            emacs_keybindings_enabled: config.emacs_keybindings_enabled,
            ctrl_w_deletes_word_in_query: config.ctrl_w_deletes_word_in_query,
            tab_pin_moves_to_next_row: config.tab_pin_moves_to_next_row,
            walker_max_entries: config.walker_max_entries,
        }
    }
}

impl Default for EditableSettings {
    fn default() -> Self {
        Self::from(&RuntimeConfig::default())
    }
}

#[derive(Clone, Debug)]
pub struct EditableSettingsSnapshot {
    pub values: EditableSettings,
    original_bytes: Vec<u8>,
}

fn read_editable_settings_bytes(path: &Path) -> Result<Vec<u8>> {
    let mut bytes = Vec::new();
    fs::File::open(path)
        .with_context(|| format!("failed to read {}", path.display()))?
        .take((GUI_EDITABLE_SETTINGS_MAX_BYTES + 1) as u64)
        .read_to_end(&mut bytes)
        .with_context(|| format!("failed to read {}", path.display()))?;
    if bytes.len() > GUI_EDITABLE_SETTINGS_MAX_BYTES {
        bail!("GUI settings JSON exceeds the 64 KiB editor limit");
    }
    Ok(bytes)
}

pub fn read_editable_settings(path: &Path) -> Result<EditableSettingsSnapshot> {
    let bytes = read_editable_settings_bytes(path)?;
    let value: serde_json::Value = serde_json::from_slice(&bytes)
        .with_context(|| format!("invalid JSON in {}", path.display()))?;
    if !value.is_object() {
        bail!("runtime config must be a JSON object");
    }
    let config: RuntimeConfig = serde_json::from_slice(&bytes)
        .with_context(|| format!("invalid runtime config in {}", path.display()))?;
    Ok(EditableSettingsSnapshot {
        values: EditableSettings::from(&config),
        original_bytes: bytes,
    })
}

pub fn save_editable_settings(
    path: &Path,
    baseline: &EditableSettingsSnapshot,
    draft: &EditableSettings,
) -> Result<EditableSettingsSnapshot> {
    save_editable_settings_with_writer(path, baseline, draft, write_bytes_atomic_with_metadata)
}

fn save_editable_settings_with_writer(
    path: &Path,
    baseline: &EditableSettingsSnapshot,
    draft: &EditableSettings,
    mut write: impl FnMut(&Path, &[u8], AtomicWriteMetadata) -> std::io::Result<()>,
) -> Result<EditableSettingsSnapshot> {
    if draft.walker_max_entries == 0 {
        bail!("walker entry limit must be at least 1");
    }
    let _lock = acquire_sidecar_lock(path, Duration::from_secs(5))
        .with_context(|| format!("failed to lock {}", path.display()))?;
    let latest = read_editable_settings_bytes(path)
        .with_context(|| format!("failed to reread {}", path.display()))?;
    if latest != baseline.original_bytes {
        bail!("runtime config changed outside the settings dialog");
    }
    let mut value: serde_json::Value = serde_json::from_slice(&latest)?;
    let object = value
        .as_object_mut()
        .context("runtime config must be a JSON object")?;
    object.insert(
        "restore_tabs_enabled".into(),
        serde_json::json!(draft.restore_tabs_enabled),
    );
    object.insert(
        "history_persist_disabled".into(),
        serde_json::json!(draft.history_persist_disabled),
    );
    object.insert(
        "emacs_keybindings_enabled".into(),
        serde_json::json!(draft.emacs_keybindings_enabled),
    );
    object.insert(
        "ctrl_w_deletes_word_in_query".into(),
        serde_json::json!(draft.ctrl_w_deletes_word_in_query),
    );
    object.insert(
        "tab_pin_moves_to_next_row".into(),
        serde_json::json!(draft.tab_pin_moves_to_next_row),
    );
    object.insert(
        "walker_max_entries".into(),
        serde_json::json!(draft.walker_max_entries),
    );
    let bytes = serde_json::to_vec_pretty(&value)?;
    if bytes.len() > GUI_EDITABLE_SETTINGS_MAX_BYTES {
        bail!("saved settings JSON exceeds the 64 KiB editor limit");
    }
    let permissions = fs::metadata(path)?.permissions();
    // A non-cooperating editor can change the file while we hold our sidecar
    // lock. Check again immediately before replacement to narrow that window.
    if read_editable_settings_bytes(path)? != latest {
        bail!("runtime config changed outside the settings dialog");
    }
    if let Err(error) = write(
        path,
        &bytes,
        AtomicWriteMetadata {
            permissions: Some(permissions.clone()),
            ..AtomicWriteMetadata::default()
        },
    ) {
        if atomic_write_replaced_destination(&error) {
            match read_editable_settings_bytes(path) {
                Ok(current) if current == bytes => {
                    if let Err(rollback_error) = write_bytes_atomic_with_metadata(
                        path,
                        &latest,
                        AtomicWriteMetadata {
                            permissions: Some(permissions),
                            ..AtomicWriteMetadata::default()
                        },
                    ) {
                        bail!(
                            "failed to save {}: {error}; rollback failed: {rollback_error}",
                            path.display()
                        );
                    }
                }
                Ok(_) => bail!(
                    "failed to save {}: {error}; file changed after replacement, rollback skipped",
                    path.display()
                ),
                Err(read_error) => bail!(
                    "failed to save {}: {error}; rollback safety check failed: {read_error}",
                    path.display()
                ),
            }
        }
        return Err(error).with_context(|| format!("failed to save {}", path.display()));
    }
    Ok(EditableSettingsSnapshot {
        values: draft.clone(),
        original_bytes: bytes,
    })
}

#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default)]
pub struct DeveloperRuntimeConfig {
    pub walker_metrics: bool,
    pub walker_metrics_log_path: String,
    pub walker_adaptive_initial_limit: Option<usize>,
    pub walker_adaptive_max_limit: Option<usize>,
}

impl DeveloperRuntimeConfig {
    fn is_default(&self) -> bool {
        self == &Self::default()
    }
}

#[derive(Clone, Debug, Default, Serialize)]
struct RuntimeConfigSeed {
    #[serde(skip_serializing_if = "Option::is_none")]
    search_parallel_threshold: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    search_threads: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    walker_max_entries: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    window_trace_enabled: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    window_trace_verbose: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    window_trace_path: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    history_persist_disabled: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    restore_tabs_enabled: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    emacs_keybindings_enabled: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    ctrl_w_deletes_word_in_query: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    tab_pin_moves_to_next_row: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    update_feed_url: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    update_allow_same_version: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    update_allow_downgrade: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    disable_self_update: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    force_update_check_failure: Option<String>,
}

fn process_runtime_config() -> &'static Mutex<RuntimeConfig> {
    static CONFIG: OnceLock<Mutex<RuntimeConfig>> = OnceLock::new();
    CONFIG.get_or_init(|| Mutex::new(RuntimeConfig::default()))
}

pub fn current_runtime_config() -> RuntimeConfig {
    process_runtime_config()
        .lock()
        .map(|config| config.clone())
        .unwrap_or_else(|_| RuntimeConfig::from_current_env())
}

pub fn set_process_runtime_config(config: RuntimeConfig) {
    if let Ok(mut current) = process_runtime_config().lock() {
        *current = config;
    }
}

impl Default for RuntimeConfig {
    fn default() -> Self {
        Self {
            search_parallel_threshold: SEARCH_PARALLEL_THRESHOLD_DEFAULT,
            search_threads: default_search_threads(),
            walker_max_entries: WALKER_MAX_ENTRIES_DEFAULT,
            window_trace_enabled: false,
            window_trace_verbose: false,
            window_trace_path: default_window_trace_path(),
            history_persist_disabled: false,
            restore_tabs_enabled: false,
            emacs_keybindings_enabled: true,
            ctrl_w_deletes_word_in_query: false,
            tab_pin_moves_to_next_row: false,
            update_feed_url: DEFAULT_UPDATE_FEED_URL.to_string(),
            update_allow_same_version: false,
            update_allow_downgrade: false,
            disable_self_update: false,
            force_update_check_failure: String::new(),
            developer: DeveloperRuntimeConfig::default(),
        }
    }
}

impl RuntimeConfig {
    pub fn from_current_env() -> Self {
        Self::seed_from_current_env().0
    }

    pub fn apply_to_process_env(&self) {
        set_env_value(
            SEARCH_PARALLEL_THRESHOLD_ENV,
            self.search_parallel_threshold.to_string(),
        );
        set_env_value(SEARCH_THREADS_ENV, self.search_threads.to_string());
        set_env_value(WALKER_MAX_ENTRIES_ENV, self.walker_max_entries.to_string());
        set_env_bool(WINDOW_TRACE_ENV, self.window_trace_enabled);
        set_env_bool(WINDOW_TRACE_VERBOSE_ENV, self.window_trace_verbose);
        set_env_value(WINDOW_TRACE_PATH_ENV, self.window_trace_path.clone());
        set_env_bool(HISTORY_PERSIST_ENV, self.history_persist_disabled);
        set_env_bool(RESTORE_TABS_ENV, self.restore_tabs_enabled);
        set_env_value(UPDATE_FEED_URL_ENV, self.update_feed_url.clone());
        set_env_bool(
            UPDATE_ALLOW_SAME_VERSION_ENV,
            self.update_allow_same_version,
        );
        set_env_bool(UPDATE_ALLOW_DOWNGRADE_ENV, self.update_allow_downgrade);
        set_env_bool(DISABLE_SELF_UPDATE_ENV, self.disable_self_update);
        if self.force_update_check_failure.trim().is_empty() {
            env::remove_var(FORCE_UPDATE_CHECK_FAILURE_ENV);
        } else {
            set_env_value(
                FORCE_UPDATE_CHECK_FAILURE_ENV,
                self.force_update_check_failure.clone(),
            );
        }
        set_process_runtime_config(self.clone());
    }

    pub fn load_or_seed() -> Self {
        Self::load_or_seed_at(runtime_config_file_path())
    }

    fn load_or_seed_at(path: Option<PathBuf>) -> Self {
        let Some(path) = path else {
            let (config, _) = Self::seed_from_current_env();
            config.apply_to_process_env();
            return config;
        };

        if let Some(config) = load_runtime_config_from_path(&path) {
            config.apply_to_process_env();
            return config;
        }

        let config = match acquire_sidecar_lock(&path, Duration::from_secs(5)) {
            Ok(_lock) => load_migrate_or_seed_runtime_config_locked(&path),
            Err(err) => {
                warn!(
                    "failed to acquire runtime config lock for {}: {}; using current environment values without writing",
                    path.display(),
                    err
                );
                Self::seed_from_current_env().0
            }
        };
        config.apply_to_process_env();
        config
    }

    pub fn save_to_path(&self, path: &Path) -> Result<()> {
        save_runtime_config_to_path(path, self)
    }
}

pub fn ensure_runtime_config_file_at(path: &Path, config: &RuntimeConfig) -> Result<()> {
    if path
        .try_exists()
        .with_context(|| format!("failed to inspect runtime config at {}", path.display()))?
    {
        return Ok(());
    }
    let _lock = acquire_sidecar_lock(path, Duration::from_secs(5))
        .with_context(|| format!("failed to lock runtime config at {}", path.display()))?;
    if path
        .try_exists()
        .with_context(|| format!("failed to recheck runtime config at {}", path.display()))?
    {
        return Ok(());
    }
    save_runtime_config_to_path(path, config)
}

pub fn runtime_config_file_path() -> Option<PathBuf> {
    settings_base_dir().map(|base| runtime_config_file_path_in(&base))
}

pub fn initialize_runtime_config() -> RuntimeConfig {
    RuntimeConfig::load_or_seed()
}

pub fn settings_base_dir() -> Option<PathBuf> {
    #[cfg(windows)]
    {
        local_app_data_dir().map(|base| base.join(WINDOWS_SETTINGS_DIR_NAME))
    }

    #[cfg(not(windows))]
    {
        home_dir().map(|base| base.join(UNIX_SETTINGS_DIR_NAME))
    }
}

pub fn legacy_settings_base_dirs() -> Vec<PathBuf> {
    #[cfg(windows)]
    {
        let mut dirs = Vec::new();
        if let Some(base) = current_exe_dir() {
            dirs.push(base);
        }
        if let Some(base) = home_dir() {
            if dirs.iter().all(|existing| existing != &base) {
                dirs.push(base);
            }
        }
        dirs
    }

    #[cfg(not(windows))]
    {
        home_dir().into_iter().collect()
    }
}

pub fn runtime_config_file_path_in(base: &Path) -> PathBuf {
    base.join(RUNTIME_CONFIG_FILE_NAME)
}

pub fn legacy_runtime_config_file_paths(current_path: &Path) -> Vec<PathBuf> {
    legacy_settings_base_dirs()
        .into_iter()
        .map(|base| runtime_config_file_path_in(&base))
        .filter(|path| path != current_path)
        .collect()
}

pub(crate) fn migrate_file_if_needed(current_path: &Path, legacy_path: &Path) -> bool {
    let Ok(_lock) = acquire_sidecar_lock(current_path, Duration::from_secs(5)) else {
        return false;
    };
    migrate_file_if_needed_locked(current_path, legacy_path)
}

fn migrate_file_if_needed_locked(current_path: &Path, legacy_path: &Path) -> bool {
    migrate_file_if_needed_with(
        current_path,
        legacy_path,
        |source, destination| fs::rename(source, destination),
        write_bytes_atomic,
    )
}

fn migrate_file_if_needed_with<R, W>(
    current_path: &Path,
    legacy_path: &Path,
    mut rename: R,
    mut promote: W,
) -> bool
where
    R: FnMut(&Path, &Path) -> std::io::Result<()>,
    W: FnMut(&Path, &[u8]) -> std::io::Result<()>,
{
    if current_path.exists() || !legacy_path.exists() {
        return false;
    }
    if let Some(parent) = current_path.parent() {
        if let Err(err) = fs::create_dir_all(parent) {
            warn!(
                "failed to prepare destination directory for {}: {}",
                current_path.display(),
                err
            );
            return false;
        }
    }
    match rename(legacy_path, current_path) {
        Ok(_) => true,
        Err(rename_err) => {
            if current_path.exists() {
                return false;
            }
            let bytes = match fs::read(legacy_path) {
                Ok(bytes) => bytes,
                Err(read_err) => {
                    warn!(
                        "failed to migrate legacy file from {} to {}: rename error: {}; read error: {}",
                        legacy_path.display(),
                        current_path.display(),
                        rename_err,
                        read_err
                    );
                    return false;
                }
            };
            if current_path.exists() {
                return false;
            }
            match promote(current_path, &bytes) {
                Ok(()) => {
                    if let Err(remove_err) = remove_file_best_effort(legacy_path) {
                        warn!(
                            "copied legacy file from {} to {}, but failed to remove original: {}",
                            legacy_path.display(),
                            current_path.display(),
                            remove_err
                        );
                    }
                    true
                }
                Err(promote_err) => {
                    warn!(
                        "failed to migrate legacy file from {} to {}: rename error: {}; atomic promotion error: {}",
                        legacy_path.display(),
                        current_path.display(),
                        rename_err,
                        promote_err
                    );
                    false
                }
            }
        }
    }
}

#[allow(clippy::permissions_set_readonly_false)]
fn remove_file_best_effort(path: &Path) -> std::io::Result<()> {
    match fs::remove_file(path) {
        Ok(()) => Ok(()),
        Err(err) => {
            #[cfg(windows)]
            if let Ok(metadata) = fs::metadata(path) {
                let mut permissions = metadata.permissions();
                if permissions.readonly() {
                    permissions.set_readonly(false);
                    let _ = fs::set_permissions(path, permissions);
                    return fs::remove_file(path);
                }
            }
            Err(err)
        }
    }
}

fn read_runtime_config_from_path(path: &Path) -> Option<(String, RuntimeConfig)> {
    let text = fs::read_to_string(path).ok()?;
    let config = serde_json::from_str::<RuntimeConfig>(&text).ok()?;
    Some((text, config))
}

pub fn load_runtime_config_from_path(path: &Path) -> Option<RuntimeConfig> {
    let (text, config) = read_runtime_config_from_path(path)?;
    normalize_runtime_config_file(path, &text, &config);
    Some(config)
}

fn load_runtime_config_from_path_locked(path: &Path) -> Option<RuntimeConfig> {
    let (text, config) = read_runtime_config_from_path(path)?;
    normalize_runtime_config_file_locked(path, &text, &config);
    Some(config)
}

pub fn save_runtime_config_to_path(path: &Path, config: &RuntimeConfig) -> Result<()> {
    let text =
        serde_json::to_string_pretty(config).context("failed to serialize runtime config")?;
    write_text_atomic(path, &text).context("failed to write runtime config")
}

fn save_seeded_runtime_config_to_path(path: &Path, seed: &RuntimeConfigSeed) -> Result<()> {
    let text =
        serde_json::to_string_pretty(seed).context("failed to serialize runtime config seed")?;
    write_text_atomic(path, &text).context("failed to write runtime config")
}

fn load_migrate_or_seed_runtime_config_locked(current_path: &Path) -> RuntimeConfig {
    if let Some(config) = load_runtime_config_from_path_locked(current_path) {
        return config;
    }
    let legacy_paths = legacy_runtime_config_file_paths(current_path);
    if let Some(config) = try_load_or_migrate_runtime_config_locked(current_path, &legacy_paths) {
        return config;
    }
    let (config, seed) = RuntimeConfig::seed_from_current_env();
    if !current_path.exists() {
        if let Err(err) = save_seeded_runtime_config_to_path(current_path, &seed) {
            warn!(
                "failed to create runtime config at {}: {}",
                current_path.display(),
                err
            );
        }
    } else {
        warn!(
            "failed to read runtime config at {}; using current environment values",
            current_path.display()
        );
    }
    config
}

fn try_load_or_migrate_runtime_config_locked(
    current_path: &Path,
    legacy_paths: &[PathBuf],
) -> Option<RuntimeConfig> {
    if current_path.exists() {
        return None;
    }
    for legacy_path in legacy_paths {
        if migrate_file_if_needed_locked(current_path, legacy_path) {
            return load_runtime_config_from_path_locked(current_path);
        }
        if let Some(config) = load_runtime_config_from_path_locked(current_path) {
            return Some(config);
        }
    }
    for legacy_path in legacy_paths {
        if legacy_path.exists() {
            return read_runtime_config_from_path(legacy_path).map(|(_, config)| config);
        }
    }
    None
}

fn default_search_threads() -> usize {
    std::thread::available_parallelism()
        .map(|value| value.get())
        .unwrap_or(1)
        .clamp(1, 32)
}

fn default_window_trace_path() -> String {
    settings_base_dir()
        .map(|base| {
            base.join(WINDOW_TRACE_LOG_NAME)
                .to_string_lossy()
                .to_string()
        })
        .unwrap_or_default()
}

fn env_bool_with_presence(name: &str) -> (bool, bool) {
    match env::var(name) {
        Ok(value) => (
            true,
            matches!(
                value.trim().to_ascii_lowercase().as_str(),
                "1" | "true" | "yes" | "on"
            ),
        ),
        Err(_) => (false, false),
    }
}

fn env_usize_with_presence(name: &str) -> (bool, Option<usize>) {
    match env::var(name) {
        Ok(value) => (true, value.parse::<usize>().ok().filter(|value| *value > 0)),
        Err(_) => (false, None),
    }
}

fn env_string_with_presence(name: &str) -> (bool, Option<String>) {
    match env::var(name) {
        Ok(value) => {
            let trimmed = value.trim().to_string();
            if trimmed.is_empty() {
                (true, None)
            } else {
                (true, Some(trimmed))
            }
        }
        Err(_) => (false, None),
    }
}

fn set_env_value(name: &str, value: String) {
    env::set_var(name, value);
}

fn set_env_bool(name: &str, value: bool) {
    env::set_var(name, if value { "1" } else { "0" });
}

impl RuntimeConfig {
    fn seed_from_current_env() -> (Self, RuntimeConfigSeed) {
        let (_, search_parallel_threshold) = env_usize_with_presence(SEARCH_PARALLEL_THRESHOLD_ENV);
        let (_, search_threads) = env_usize_with_presence(SEARCH_THREADS_ENV);
        let (_, walker_max_entries) = env_usize_with_presence(WALKER_MAX_ENTRIES_ENV);
        let (window_trace_enabled_set, window_trace_enabled) =
            env_bool_with_presence(WINDOW_TRACE_ENV);
        let (window_trace_verbose_set, window_trace_verbose) =
            env_bool_with_presence(WINDOW_TRACE_VERBOSE_ENV);
        let (_, window_trace_path) = env_string_with_presence(WINDOW_TRACE_PATH_ENV);
        let (_, history_persist_disabled) = env_bool_with_presence(HISTORY_PERSIST_ENV);
        let (_, restore_tabs_enabled) = env_bool_with_presence(RESTORE_TABS_ENV);
        let (_, update_feed_url) = env_string_with_presence(UPDATE_FEED_URL_ENV);
        let (update_allow_same_version_set, update_allow_same_version) =
            env_bool_with_presence(UPDATE_ALLOW_SAME_VERSION_ENV);
        let (update_allow_downgrade_set, update_allow_downgrade) =
            env_bool_with_presence(UPDATE_ALLOW_DOWNGRADE_ENV);
        let (disable_self_update_set, disable_self_update) =
            env_bool_with_presence(DISABLE_SELF_UPDATE_ENV);
        let (_, force_update_check_failure) =
            env_string_with_presence(FORCE_UPDATE_CHECK_FAILURE_ENV);

        let config = Self {
            search_parallel_threshold: search_parallel_threshold
                .unwrap_or(SEARCH_PARALLEL_THRESHOLD_DEFAULT),
            search_threads: search_threads.unwrap_or_else(default_search_threads),
            walker_max_entries: walker_max_entries.unwrap_or(WALKER_MAX_ENTRIES_DEFAULT),
            window_trace_enabled,
            window_trace_verbose,
            window_trace_path: window_trace_path
                .as_ref()
                .cloned()
                .unwrap_or_else(default_window_trace_path),
            history_persist_disabled,
            restore_tabs_enabled,
            emacs_keybindings_enabled: true,
            ctrl_w_deletes_word_in_query: false,
            tab_pin_moves_to_next_row: false,
            update_feed_url: update_feed_url
                .as_ref()
                .cloned()
                .unwrap_or_else(|| DEFAULT_UPDATE_FEED_URL.to_string()),
            update_allow_same_version,
            update_allow_downgrade,
            disable_self_update,
            force_update_check_failure: force_update_check_failure
                .as_ref()
                .cloned()
                .unwrap_or_default(),
            developer: DeveloperRuntimeConfig::default(),
        };

        let seed = RuntimeConfigSeed {
            search_parallel_threshold: search_parallel_threshold
                .map(|_| config.search_parallel_threshold),
            search_threads: search_threads.map(|_| config.search_threads),
            walker_max_entries: Some(config.walker_max_entries),
            window_trace_enabled: window_trace_enabled_set.then_some(config.window_trace_enabled),
            window_trace_verbose: window_trace_verbose_set.then_some(config.window_trace_verbose),
            window_trace_path: window_trace_path.map(|_| config.window_trace_path.clone()),
            history_persist_disabled: Some(config.history_persist_disabled),
            restore_tabs_enabled: Some(config.restore_tabs_enabled),
            emacs_keybindings_enabled: Some(config.emacs_keybindings_enabled),
            ctrl_w_deletes_word_in_query: Some(config.ctrl_w_deletes_word_in_query),
            tab_pin_moves_to_next_row: Some(config.tab_pin_moves_to_next_row),
            update_feed_url: update_feed_url.map(|_| config.update_feed_url.clone()),
            update_allow_same_version: update_allow_same_version_set
                .then_some(config.update_allow_same_version),
            update_allow_downgrade: update_allow_downgrade_set
                .then_some(config.update_allow_downgrade),
            disable_self_update: disable_self_update_set.then_some(config.disable_self_update),
            force_update_check_failure: force_update_check_failure
                .map(|_| config.force_update_check_failure.clone()),
        };

        (config, seed)
    }
}

fn normalize_runtime_config_file(path: &Path, text: &str, config: &RuntimeConfig) {
    let _lock = match acquire_sidecar_lock(path, Duration::from_secs(5)) {
        Ok(lock) => lock,
        Err(error) => {
            warn!(
                "failed to lock runtime config for normalization at {}: {}",
                path.display(),
                error
            );
            return;
        }
    };
    let Ok(current_text) = fs::read_to_string(path) else {
        return;
    };
    if current_text == text {
        normalize_runtime_config_file_locked(path, text, config);
    } else if let Ok(current_config) = serde_json::from_str::<RuntimeConfig>(&current_text) {
        normalize_runtime_config_file_locked(path, &current_text, &current_config);
    }
}

fn normalize_runtime_config_file_locked(path: &Path, text: &str, config: &RuntimeConfig) {
    let Ok(mut value) = serde_json::from_str::<serde_json::Value>(text) else {
        return;
    };
    let Some(root) = value.as_object_mut() else {
        return;
    };

    let mut changed = root.remove("walker_threads").is_some();
    changed |= insert_missing_runtime_config_value(
        root,
        "walker_max_entries",
        serde_json::json!(config.walker_max_entries),
    );
    changed |= insert_missing_runtime_config_value(
        root,
        "history_persist_disabled",
        serde_json::json!(config.history_persist_disabled),
    );
    changed |= insert_missing_runtime_config_value(
        root,
        "restore_tabs_enabled",
        serde_json::json!(config.restore_tabs_enabled),
    );
    changed |= insert_missing_runtime_config_value(
        root,
        "emacs_keybindings_enabled",
        serde_json::json!(config.emacs_keybindings_enabled),
    );
    changed |= insert_missing_runtime_config_value(
        root,
        "ctrl_w_deletes_word_in_query",
        serde_json::json!(config.ctrl_w_deletes_word_in_query),
    );
    changed |= insert_missing_runtime_config_value(
        root,
        "tab_pin_moves_to_next_row",
        serde_json::json!(config.tab_pin_moves_to_next_row),
    );
    if let Some(developer) = root
        .get_mut("developer")
        .and_then(|value| value.as_object_mut())
    {
        changed |= developer.remove("walker_backend").is_some();
        if developer.is_empty() {
            root.remove("developer");
        }
    }

    if changed {
        let Ok(cleaned) = serde_json::to_string_pretty(&value) else {
            return;
        };
        // Editors outside the sidecar-lock protocol can still replace the file.
        // Do not normalize bytes that are no longer the bytes we parsed.
        if fs::read_to_string(path).ok().as_deref() != Some(text) {
            return;
        }
        if let Err(err) = write_text_atomic(path, &cleaned) {
            warn!(
                "failed to normalize runtime config at {}: {}",
                path.display(),
                err
            );
        }
    }
}

fn insert_missing_runtime_config_value(
    root: &mut serde_json::Map<String, serde_json::Value>,
    key: &str,
    value: serde_json::Value,
) -> bool {
    if root.contains_key(key) {
        return false;
    }
    root.insert(key.to_string(), value);
    true
}

#[cfg(windows)]
fn current_exe_dir() -> Option<PathBuf> {
    env::current_exe()
        .ok()
        .and_then(|path| path.parent().map(Path::to_path_buf))
}

#[cfg(windows)]
fn local_app_data_dir() -> Option<PathBuf> {
    env::var_os("LOCALAPPDATA")
        .or_else(|| env::var_os("APPDATA"))
        .map(PathBuf::from)
}

fn home_dir() -> Option<PathBuf> {
    #[cfg(windows)]
    {
        if let Some(base) = env::var_os("USERPROFILE") {
            return Some(PathBuf::from(base));
        }
    }
    #[cfg(not(windows))]
    {
        if let Some(base) = env::var_os("HOME") {
            return Some(PathBuf::from(base));
        }
    }
    None
}

#[cfg(test)]
mod tests;
