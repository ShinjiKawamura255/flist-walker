# FlistWalker

`README.md` の英語版は [README.md](README.md) を参照してください。

`fzf --walker` 相当の体験で、ファイル/フォルダを高速にファジー検索し、選択結果を実行またはオープンできる Rust ツールです。

- 表示名: `FlistWalker`
- GitHub リポジトリ名: `flist-walker`
- GUI 実行コマンド: `flistwalker`（Windows 成果物は `FlistWalker.exe`）
- CLI/TUI 実行コマンド: `fw`（Windows 成果物は別配布の `fw.exe`）
- ドキュメント索引: [docs/INDEX.md](docs/INDEX.md)
- 保守者向けの現状入口: [docs/CURRENT_STATUS.md](docs/CURRENT_STATUS.md)

## 主要機能

- マルチタブ
- `FileList.txt` / `filelist.txt` 優先読み込み（ルート直下のみ）
- File / Folder の高速インデックスと検索
- 検索演算子: `'`（完全一致）, `!`（除外）, `^`（先頭）, `$`（末尾）
- 結果ハイライト、非一致非表示、ピン留め複数選択
- プレビュー（オンデマンドファイルは自動スキップ）。テキストは行番号付きで段階的に表示し、本文だけを選択・コピーできます。`Load more` で追加、`Reload preview` で先頭から再読込、`Color: on/off` で当該GUIセッションの色分けを切り替えます。Rust、Python、JavaScript、TypeScript、JSON、TOML、YAML、Markdown、shell、PowerShell、C、C++、HTMLに対応します。
- Root の保存、既定 root 設定
- 検索履歴（全タブ共通）
- `Create File List` で現在Rootから `FileList.txt` を生成
- 実行ファイル横の `flistwalker.ignore.txt` による Ignore List
- Windows では `%LocalAppData%\flistwalker\`、Linux/macOS では `~/.flistwalker/` による runtime config / session files

## クイックスタート（GUI）

```bash
cd rust
source ~/.cargo/env
cargo run -- --root ..
```

1. 検索窓に入力して候補を絞り込み
2. `Enter` で開く/実行
3. `Shift+Enter` で選択項目の格納フォルダを開く（同じフォルダは1回だけ開く）
4. `Tab` / `Shift+Tab` でピン留め複数選択
5. `Ctrl+Shift+C` で選択パスをコピー（macOS は `Cmd+Shift+C`）
6. `Ctrl+R` で検索履歴をファジー検索し、`Enter` / `Ctrl+J` / `Ctrl+M` で検索欄へ展開

### 主なショートカット

- `F1`: キーボードショートカットと query 構文のアプリ内 help を開閉（`Help` からも利用可能）
- `Ctrl+Shift+P`: `Presets...` button と同じ preset picker を開き、preset 名を fuzzy filter して `Enter` で適用、`Add`で現在の検索を追加、`F2`で編集、`Delete`で削除（macOS は `Cmd+Shift+P`）
- `Up` / `Down` または `Ctrl+P` / `Ctrl+N`: 現在行を移動
- `Ctrl+V` / `Alt+V`: ページ移動
- `Enter` / `Ctrl+J` / `Ctrl+M`: 開く / 実行
- `Shift+Enter`: 格納フォルダを開く
- `Tab` / `Shift+Tab` / `Ctrl+I`: 現在行のピン留め切り替え
- `Ctrl+Shift+C`: 選択パスをコピー
- `Esc` / `Ctrl+G`: query とピン留めをクリア
- `Ctrl+L`: 検索欄の focus 切り替え
- `Ctrl+T`: 新規タブ
- `Ctrl+W`: 現在タブを閉じる
- `Ctrl+Tab` / `Ctrl+Shift+Tab`: タブ切り替え
- タブのドラッグ&ドロップ: タブの並び替え

## ショートカット差分（Windows/Linux と macOS）

macOS では次の「主要ショートカット」を `Ctrl` から `Cmd` に切り替えています。

- `Ctrl+T` / `Ctrl+W`
- `Ctrl+L`
- `Ctrl+Shift+C`
- `Ctrl+Shift+P`

タブ切り替えだけはブラウザなどと同様に、macOS でも `Ctrl+Tab` / `Ctrl+Shift+Tab` を使います。

### 入力履歴

- 検索履歴は全タブ共通で最大100件まで保持され、通常終了時の UI state へ永続化されます。
- 永続化先は Windows では `%LocalAppData%\flistwalker\`、Linux/macOS では `~/.flistwalker/` のセッションファイルです。検索語やパスに機微情報を含める運用では注意してください。
- `FLISTWALKER_DISABLE_HISTORY_PERSIST=1` を設定すると、検索履歴の読み込みと保存を無効化できます。
- `Ctrl+R` で履歴検索モードに入り、同じ検索欄で履歴をファジー検索できます。
- 履歴検索中は `Enter` / `Ctrl+J` / `Ctrl+M` で選択中の履歴を検索欄へ展開し、`Esc` / `Ctrl+G` でキャンセルして元の query に戻れます。
- 履歴は打鍵ごとには保存されず、入力が少し止まった時点、または結果移動を始めた時点で確定します。
- IME の未確定文字列は履歴に保存されず、確定後の検索語だけが残ります。

### セッション復元（opt-in）

- `FLISTWALKER_RESTORE_TABS=1` を設定すると、終了時のタブ状態を次回起動時に復元できます。
- 復元対象は `root`、`query`、`Use FileList`、`Regex`、`Files`、`Folders`、active tab です。
- 起動時に `--root` や query を明示した場合は、復元よりそちらを優先します。
- この機能が有効な間は、起動 root がタブ復元で決まるため `Set as default` は無効化されます。

Windows PowerShell でユーザー環境変数として永続設定:

```powershell
[Environment]::SetEnvironmentVariable("FLISTWALKER_RESTORE_TABS", "1", "User")
```

Windows PowerShell で現在セッションだけ有効化:

```powershell
$env:FLISTWALKER_RESTORE_TABS = "1"
```

Windows CMD の現在セッションだけ有効化:

```cmd
set FLISTWALKER_RESTORE_TABS=1
```

macOS の現在セッションだけ有効化:

```bash
export FLISTWALKER_RESTORE_TABS=1
```

macOS で永続設定（zsh）:

```bash
echo 'export FLISTWALKER_RESTORE_TABS=1' >> ~/.zshrc
```

Linux の現在セッションだけ有効化:

```bash
export FLISTWALKER_RESTORE_TABS=1
```

Linux で永続設定（bash）:

```bash
echo 'export FLISTWALKER_RESTORE_TABS=1' >> ~/.bashrc
```

### runtime config

- GUI ではタブバーの歯車から主な設定を編集できます。保存した変更は次回起動から反映され、キャンセルでは JSON を変更しません。設定画面から従来どおり JSON を開け、外部で編集した後は明示的に再読み込みできます。
- runtime settings は Windows では `%LocalAppData%\flistwalker\`、Linux/macOS では `~/.flistwalker/` とその関連ファイルに保存されます。
- 初回起動でファイルが無い場合は、現在の `FLISTWALKER_*` 環境変数を seed にして自動生成します。
- 初回生成時は、一般利用者向けの既定項目を書き込み、詳細項目は実際に環境変数で設定されている値だけを書き込みます。
- いったんファイルができたら、その内容が runtime settings の source of truth になり、同名 env は初期 seed としてのみ使われます。
- この Windows / home の保存先ルールは UI state、saved roots、window trace にも適用されます。
- 旧バージョンから更新した場合は、新しいファイルがまだ無いときに限って、実行ファイル横や home 直下の旧ファイルを新しい platform-specific 保存先へ自動移行します。
- このファイルは JSON なので直接編集できます。
- ここでは一般的に使う項目だけを案内しています。高度な項目は意図的に記載していません。
- ファイルを削除すると、次回起動時に現在の環境変数を seed にして再生成されます。
- `walker_max_entries` は大きい root で効くので、ここでは公開しています。
- `emacs_keybindings_enabled` を `false` にすると、`Ctrl+N`、`Ctrl+P`、`Ctrl+V`、`Alt+V`、`Ctrl+J`、`Ctrl+M`、text-editing chord などの Emacs 風操作を無効化できます。既定は有効で、有効時の移動・確定・キャンセル chord は、対応する矢印キー・`Enter`・`Esc` 操作がある結果一覧、履歴、root 選択、preset/Named Root 画面、overlay、modal 全体へ適用されます。`Ctrl+A/E/B/F/H/D/K/Y/U` は通常検索・履歴だけでなく、preset と root 管理を含む application-owned の全単一行入力へ適用されます。GUI の `Ctrl+W` はタブ終了と競合するため、従来どおり `ctrl_w_deletes_word_in_query` で別途制御します。

例:

```json
{
  "walker_max_entries": 500000,
  "history_persist_disabled": false,
  "restore_tabs_enabled": false,
  "emacs_keybindings_enabled": true
}
```

- boolean 系の値は `true` / `false` で書きます。

### 環境変数の公開区分

- runtime settings は Windows では `%LocalAppData%\flistwalker\` の config file、Linux/macOS では `~/.flistwalker/` と関連する session file に集約され、同名 env は seed 用です。
- signing / release build 用の環境変数は `docs/RELEASE.md` の build/release 用セクションだけで扱います。

## Rust 実装

```bash
cd rust
source ~/.cargo/env
cargo run -- --root ..
```

CLI モード:

```bash
# release の短い CLI 専用コマンド（推奨）
fw "main" --root .. --limit 1000
```

`fw` は GUI 起動経路を含めない CLI 専用 executable で、短い一回検索向けに起動を軽量化しています。Windows では release の `fw-<version>-windows-x86_64.exe` を別途ダウンロードし、必要に応じて `fw.exe` へ rename します。従来の universal ZIP には含まれません。`FlistWalker.exe` は GUI subsystem で起動するため terminal が一瞬表示されず、PowerShell/cmd での同期実行・標準入出力・更新・help/version は `fw.exe` を正式入口とします。Windows universal の旧 CLI 引数は direct process caller 向けの best-effort です。Linux/macOS では `flistwalker --cli ...` も引き続き利用できます。

CLI では:

- query 未指定時は候補一覧を `limit` 件まで表示します。
- query 指定時は一致したパスを1行ずつ表示します。
- `--limit` は内部で 1000 件に丸めず、そのまま上限件数として扱います。
- `--max-depth N` は root 直下を深さ `1` として候補を `N` 階層までに制限します。深さ `N` の folder 自体は候補に含めますが、その配下へは降りません。省略時は無制限で、`0` は拒否します。Walker / FileList、batch CLI、TUI 起動、GUI 起動に共通で適用し、FileList 作成だけは常に完全・無制限です。
- 既定出力は root 相対・改行区切り・スコア/ANSIなしです。スクリプトでは `--absolute` と `--print0` を利用できます。
- 互換性: query 指定時も、旧来の `[score] absolute-path` ではなく空query時と同じpath専用形式になりました。旧出力の絶対pathを利用していた場合は `--absolute` へ移行してください。score文字列は出力しません。
- `--type all|file|folder`、`--regex`、`--case-sensitive` で検索対象と照合方法を指定できます。
- `--source auto|filelist|walker` でインデックス元を指定できます。`filelist` は root FileList がなければ失敗し、`auto` は FileList 優先で walker へフォールバックします。
- `--ignore-file PATH` は実行ファイル横の ignore list を置き換え、`--no-ignore` は ignore を無効化します。両者は同時指定できません。
- ignore fileはUTF-8で、先頭UTF-8 BOMとCRLFを許容します。rule内の `/` と `\\` は同じpath separatorとして扱います。既定sidecarが無ければruleなしで継続し、存在するfileが読めない／UTF-8不正ならCLI/TUIは明示errorにします。
- batch モードの `--progress` は indexing 開始、候補件数と時間、一致/返却件数と時間だけを標準エラー出力へ表示します。`--limit` が一致結果を切り詰めた場合は返却件数と全一致件数をwarningとして明示し、`--progress` なしの既定実行は静かなままです。batch 専用の `--fail-no-match` は一致なしを exit 0 から exit 1 に変更し、interactive モードでは両 option を拒否します。キャンセルは exit 130 です。
- `--sort score|name-asc|name-desc|path-asc|path-desc|modified-desc|modified-asc|created-desc|created-asc|size-desc|size-asc` は `--limit` より先にソートします。nameは末尾のfile/folder名、pathは正規化済みの完全pathをキーにします。`--type` は `all` に加えて `file|files|f` と `folder|folders|directory|directories|dir|d` を受理します。保存済み root は `--use-default-root`、`--saved-root INDEX`、`--list-saved-roots` で明示的に利用でき、一覧は `--print0` に対応します。
- 名前付き root と純粋な検索 preset は CLI/TUI と GUI picker 内で管理・適用できます。作成から適用までの手順は[名前付き root と検索 preset](#名前付き-root-と検索-preset)を参照してください。
- termごとに `name:`、`path:`、`dir:`、`ext:` で対象fieldを限定できます。fieldなしtermは従来どおりvisible path全体を検索します。fieldは `!`、`'`、`^`、`$`、token内 `|`、regex modeと併用できます。shell解釈を安定させるため、1 tokenだけでもQUERY全体を引用してください。対話型Bash/Zshで `!` を含む場合は、履歴展開がFlistWalker起動前に行われるため、QUERY全体をシングルクォートで囲みます（例: `fw '!.git'`）。ダブルクォートではBashの履歴展開を抑止できません。
- `--action print|open|reveal` の既定は `print` です。open/reveal は診断だけを標準エラーへ出し、複数対象には `--action-all` が必要です。これらの action で `--absolute` と `--print0` は使えません。
- `-x` / `--exec` は以後の引数を command template として受け取り、独立した `{}` 引数1個を post-limit の全結果へ展開します。各パスは正規化済み絶対パスの独立 argv とし、実行環境の command-line 上限まで貪欲にまとめて直列実行します。`--exec-max-args N` で1 batch のパス数をさらに制限でき、`--dry-run` は command を起動せず件数だけを表示します。結果0件では command を起動しません。shell は暗黙起動せず、FlistWalker 側の option はすべて `-x` より前に指定します。
- child process は FlistWalker のユーザ権限、環境変数、標準 stream を継承します。Windows では暗黙の shell 起動を防ぐため `.bat` / `.cmd` の直接指定を拒否します。shell interpreter と batch script は独自の引数解釈を持つため、`sh -c`、`cmd.exe /C script.cmd`、PowerShell command string の指定はその解釈への明示的な opt-in です。
- `--create-filelist` は prompt を出さず walker ベースで root の FileList を作成し、標準出力には書き込みません。既存 root FileList の置換には `--overwrite-filelist`、既存 ancestor FileList の更新には `--propagate-ancestors` が必要です。作成時は query/search/output/action の指定を拒否し、成功は exit 0、完全 rollback を伴う clean cancel は 130、read/write/rollback failure は 1 です。

### 名前付き root と検索 preset

名前付き root は検索 root に安定した名前を付けます。preset は名前付き root または root の snapshot と、query、対象種別、source、regex、case、ignore、sort、最大深さ、リンク追跡の設定を保存します。action や外部 command は保存しません。GUI では `Presets...` button または `Ctrl+Shift+P`（macOS は `Cmd+Shift+P`）で同じpickerを開き、preset 名を fuzzy filter して `Up` / `Down` で選択し、`Enter` で現在 tab へ適用するか `Esc` で現在の検索状態を変えず閉じます。preset 適用で変わるのは active tab だけで、深さは2行目の `Depth: All` / `Depth: ≤ N` control または別 preset で変更するまで維持されます。他 tab へは波及せず、新規 tab は `All` で始まり、session 復元でも tab ごとに保持されます。depth control は `Folders` の後、`Preview` の前です。`Add`は現在tabのpure-search stateから新規draftを作ります。選択中に `F2` または `Edit` を使うと draft editor が開き、名前、root/query/type/source/regex/case/ignore/sort/max depth/follow links を編集でき、`Delete`から確認付きで削除できます。`Ctrl+Enter`（macOS は `Cmd+Enter`）または `Save` は catalog だけを更新し、現在 tab へ適用しません。picker 見出しの `Manage named roots...` または preset editor の `Manage...` から名前付き root の一覧、追加、名称・path編集、削除を行えます。名称変更は参照中presetも追従し、削除後は各presetの保存済みpath snapshotを利用します。`Esc` / `Cancel` は未保存 draft または削除確認を破棄します。GUI picker は検索結果を開く／実行せず、メインpanelにはlauncher buttonだけを置いてpresetの選択・管理をmodal内に保ちます。

```bash
# 名前付き root を登録する。path に空白が含まれる場合も NAME=PATH 全体を引用する。
fw --add-named-root "work=./my-project"

# 現在の純粋な検索条件を保存し、検索は実行せず終了する。
fw 'dir:src ext:rs !dir:target' --named-root work --type file --source walker --sort name-asc --save-preset rust-src

# 保存済みの名前を確認する。
fw --list-named-roots
fw --list-presets

# batch モードで適用するか、適用した状態で TUI を起動する。
fw --preset rust-src
fw --interactive --preset rust-src

# 不要になった catalog entry を削除する。
fw --remove-preset rust-src
fw --remove-named-root work
```

query が1 termだけの場合も、query 引数全体を引用してください。Bash/Zshで `!` を含むqueryを直接渡す場合は、ダブルクォートではなくシングルクォートを使用します。`--preset` は値を preset から復元するため、明示 query や root、対象種別、source、regex、case、ignore、sort、`--max-depth`、`--follow-links` の指定とは併用できません。`--limit`、出力形式、明示 action など invocation 固有の option は適用時にも指定できます。

例:

```bash
# 新規 root FileList を作成する。既存ファイルの置換には明示指定が必要。
fw --root . --create-filelist
fw --root . --create-filelist --overwrite-filelist

# post-limit の全一致を明示して開く（標準出力は空）。
fw "report" --root . --limit 10 --action open --action-all

# src配下のRustファイルを検索し、generated directoryを除外する。
fw 'dir:src ext:rs !dir:generated' --root .

# post-limit の全一致を実行環境の上限までまとめて外部 command へ渡す。
fw "report" --root . --exec-max-args 100 -x archive-tool -- {}

# command を起動せず、対象数と batch 数だけを確認する。
fw "report" --root . --dry-run -x archive-tool -- {}
```

PowerShell では placeholder が script block と解釈されないよう、`'{}'` と引用してください。

パスを安全にシェル連携する例:

```bash
fw --root . --type file --print0 | xargs -0 -n1 printf '%s\n'
```

インタラクティブ CLI モード:

```bash
fw --interactive --root ..
```

`--max-depth` は起動時または preset の深さとして TUI session 中固定され、F2 options overlay からは変更しません。

軽量な TUI が起動します。`--root`、`--use-default-root`、`--saved-root` で起動 root を選択でき、`--sort` は初期並び順、`--no-ignore` は Ignore が無効と表示される初期状態へ反映されます。`--color auto|always|never` で CLI の色を制御できます。batch の既定 `auto` は stdout が TTY のときだけ色を出し、空でない `NO_COLOR` 環境変数を尊重するため、pipe/redirect のパス出力はそのままです。`←` / `→` / `Home` / `End` / `Backspace` / `Delete` と貼り付けで query を編集し、`↑` / `↓` / `PageUp` / `PageDown` で移動します。`Tab` は選択項目を出力順に pin し、`Enter` は選択結果を確定します。`F2` は Files、Folders、Regex、Ignore Case、起動時に読み込んだ Ignore terms、Source（`Auto` / `FileList` / `Walker`）を確定/取消できる options overlay を開きます。Source と Files/Folders の変更は再インデックスし、検索だけに関わる変更は現在の snapshot を再利用します。`F3` は Score、名前、更新日時、作成日時、サイズの並び順（該当する昇順/降順）を選択し、Score 以外は limit 適用前に全 match を並べ替えます。`F4` は保存済みrootを開いて強調行へ切り替え、`F5` は現在rootを更新します。`F6` は root のみ／ancestor までの作成範囲を選んで FileList を作成し、root に既存 FileList がある場合は別途上書き確認を要求します。作成はバックグラウンドで行われ、選択・終了・root 切替の要求は commit/cancel/rollback の完了後にだけ反映されます。root切替では旧選択とpinを消去しますが、query・履歴・optionsは維持し、更新時はpinを維持します。`Ctrl+O` は現在行だけを開く/実行し、`Shift+Enter` は現在行の格納フォルダだけを開きます。pin された行がこれらの副作用操作に含まれることはありません。`Ctrl+G` は query と pin をクリアし、`Alt+P` は幅に応じて表示される preview を切り替え、履歴永続化が有効なときの `Ctrl+R` は query 履歴検索を開き、`F1` は文脈に応じた help を開きます。履歴、help、options、sort、root、FileList の overlay 中は、`Enter` / `Esc` / `Ctrl+G` はその overlay だけを確定または閉じ、`Ctrl-C` は常に TUI 全体をキャンセルします。通常状態の `Esc` / `Ctrl-C` は端末を復旧して何も出力せず exit 130 で終了します。標準入力と標準エラー出力には TTY が必要ですが、標準出力はリダイレクトできるため、`fw --interactive > selection.txt` を利用できます。画面・status は標準エラー出力だけを使い、端末復旧後に選択パスを標準出力へ書くか、明示した `-x` command へ渡します。

`F3` の並び順には、上記に加えて正規化済みの完全pathによる昇順・降順も含まれます。

## 挙動

- `FileList.txt` または `filelist.txt` がルート直下にある場合はそれを優先して読み込みます。
- ルート直下の `FileList.txt` / `filelist.txt` に含まれる配下の `FileList.txt` / `filelist.txt` も必要に応じて展開します。
- リストがない場合は walker で再帰走査します。
- ファイル選択時は実行または既定アプリでオープン、フォルダ選択時はファイルマネージャでオープンします。
- `Create File List` は必要に応じて Walker ベースの新規タブへ切り替えて生成します。

### オプションチェックボックス

- `Use FileList`: ONで `FileList.txt` / `filelist.txt` を優先利用
- `Files`: ファイル表示のON/OFF
- `Folders`: フォルダ表示のON/OFF
- `Follow links`: Root配下のdirectory symlink／Windows junctionの先も検索します。既定はOFFで、tab・session・presetごとに保持します。Root外のリンク先もリンク経由の相対パスで表示し、循環は打ち切ります。FileList読込時は追加走査せず、Create File Listの新規走査には適用します。CLIでは `fw --root PATH --source walker --follow-links`、TUIではさらに `--interactive` を指定します。Linux/macOS では universal の `flistwalker --cli` 形式も利用できます。

Root自体がsymlink／junctionの場合も、相対表示のResultsはRootからの相対パスになります。WindowsのHidden＋System属性を持つ互換用junction、`.lnk`、Finder aliasの展開は対象外です。

- `Regex`: 正規表現検索を有効化
- `Preview`: プレビューペインの表示切り替え
- `Use Ignore List`: 実行ファイル横の ignore ルールを有効化/無効化する。既定は ON。

### Ignore List

- `flistwalker.ignore.txt` を `flistwalker` / `FlistWalker.exe` と同じフォルダに置きます。
- 1 行 1 ルールが基本です。空行と `#` で始まる行は無視されます。
- 各トークンは検索の除外条件として扱われます。例えば `old` や `~` は `!old !~` と同じ挙動になります。
- 1 行に複数トークンをスペース区切りで書くこともできます。
- `Use Ignore List` チェックボックスで適用の ON/OFF を切り替えます。既定は ON です。
- サンプルは [flistwalker.ignore.txt.example](flistwalker.ignore.txt.example) を参照してください。
- サンプルが無い場合は、起動時に実行ファイル横へ自動生成します。
- そのファイルを実際の Ignore List として使う場合は、`flistwalker.ignore.txt` にリネームしてください。

### Root 操作

- `Browse...`: Root を変更
- `Set as default`: 次回起動時の既定 root を保存
- `Manage list`: 保存済み root のネイティブ管理ウィンドウを非ブロッキングで開きます。パスを直接入力するか `Browse...` でフォルダを選んで追加し、チェックした項目を draft list から削除できます。反映は `Apply` または `OK` のタイミングで行い、`Cancel` では保存済みリストを変更しません。

## テスト

```bash
cd rust
source ~/.cargo/env
cargo test
```

Windows PowerShell では、配布用 Windows build と同じ GNU target 系を日常開発の第一候補にします:

```powershell
.\scripts\dev-check-windows.ps1
```

このスクリプトは `rustup`、`rustc`、`cargo`、`x86_64-pc-windows-gnu` target、
mingw-w64 tools を確認し、`rust/` で `cargo test --target x86_64-pc-windows-gnu`
を実行します。format check や clippy も確認したい場合は `-IncludeFmt` や
`-IncludeClippy` を指定します。GNU toolchain が未導入の環境で一時的に確認する場合だけ
`-Toolchain msvc` を使います。

初回だけ以下を準備します:

```powershell
rustup target add x86_64-pc-windows-gnu
```

MSYS2 を `C:\msys64` へインストールし、MSYS2 shell から MINGW64 GCC package を入れます:

```bash
pacman -S mingw-w64-x86_64-gcc
```

`scripts/dev-check-windows.ps1` は `C:\msys64\mingw64\bin` が存在する場合、現在のチェック用 PATH に自動追加します。

PowerShell から release 相当の Windows build を行う場合:

```powershell
.\scripts\build-rust-win.ps1
# clean build
.\scripts\build-rust-win-clean.ps1
```

不足している Rustup、GNU Rust target、MSYS2、MinGW tools は内容を表示し、
通常モードでは導入単位ごとに確認してからインストールします。
検出だけ行う場合は `-CheckOnly`、prompt せず手動コマンドを表示して終了する場合は
`-NoInstall`、不足依存の導入を明示的に一括承認する場合は `-InstallMissing` を使います。

## サポート / 不具合報告

不具合報告や機能要望は GitHub Issues のテンプレートを利用してください。報告前に [docs/SUPPORT.md](docs/SUPPORT.md) を確認し、ユーザー名、プロジェクト名、フルパス、トークンなどの機微情報は必ず伏せてください。

## Windows 向けビルド

Windows 上の日常開発は、配布用 Windows 成果物との差分を減らすため GNU target を優先します:

```powershell
cd rust
cargo test --target x86_64-pc-windows-gnu
cargo build --target x86_64-pc-windows-gnu
```

MSVC host target は GNU toolchain が未導入の環境での一時的な確認や Windows UI smoke には使えますが、release-equivalent build ではありません。

Windows PowerShell から:

```powershell
.\scripts\build-rust-win.ps1
```

WSL / Linux シェルから:

```bash
./scripts/build-rust-win.sh
```

どちらの経路も `x86_64-pc-windows-gnu` をビルドし、Explorer アイコンと
`asInvoker` manifest を維持します。PowerShell 版は明示承認後に不足する
Rustup / MSYS2 依存の導入を案内できます。
必要なツール:

- `x86_64-w64-mingw32-gcc`
- `x86_64-w64-mingw32-g++`
- `x86_64-w64-mingw32-ar`
- `x86_64-w64-mingw32-ranlib`
- `x86_64-w64-mingw32-windres`
- `x86_64-w64-mingw32-strip`

Ubuntu / Debian 系では `sudo apt install -y gcc-mingw-w64-x86-64 g++-mingw-w64-x86-64 binutils-mingw-w64-x86-64` で揃います。

release profile では `lto = "thin"`, `codegen-units = 1`, `panic = "abort"`, `strip = "symbols"` を適用し、さらにビルド後に `x86_64-w64-mingw32-strip` を実行して Windows GNU バイナリサイズを抑えます。

クリーンビルド:

```bash
./scripts/build-rust-win-clean.sh
```

PowerShell からは次を実行します:

```powershell
.\scripts\build-rust-win-clean.ps1
```

成果物:

`rust/target/x86_64-pc-windows-gnu/release/FlistWalker.exe`

## macOS 向けビルド

通常ビルド:

```bash
./scripts/build-rust-macos.sh
```

クリーンビルド:

```bash
./scripts/build-rust-macos-clean.sh
```

成果物（ホストターゲット）:

`rust/target/release/flistwalker`

## ライセンスと配布 notices

- `LICENSE`
- `THIRD_PARTY_NOTICES.txt`
- 配布ルール: [docs/RELEASE.md](docs/RELEASE.md)
