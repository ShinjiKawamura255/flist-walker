# REQUIREMENTS

This file is the entry point for FlistWalker requirements. Detailed FR/NFR/CON and AC content is split by topic under `docs/requirements/`.

## Document Map
| Topic | Content |
| --- | --- |
| [Product Scope and Acceptance Criteria](requirements/product-scope.md) | Background / KPI, scope, use cases, acceptance criteria |
| [Functional Requirements](requirements/functional.md) | FR-001 through FR-047 |
| [Quality, Constraints, and Risks](requirements/quality-constraints.md) | NFR, CON, risks |
| [Requirements Traceability](requirements/traceability.md) | FR/NFR to SP/DES/TC traceability excerpt |

## Scope Summary
- Rust CLI/GUI implementation.
- Candidate collection through FileList and walker sources.
- fzf-compatible query handling, result actions, multi-select, and batch actions.
- Startup update check through GitHub Releases and Windows/Linux self-update.
- Prototype feature expansion, network-drive optimization, installer creation, and macOS `.app` bundle auto-update are out of scope.

## ID Ownership
- FR entries live in [Functional Requirements](requirements/functional.md).
- NFR/CON entries and risks live in [Quality, Constraints, and Risks](requirements/quality-constraints.md).
- AC entries live in [Product Scope and Acceptance Criteria](requirements/product-scope.md).

## Traceability (excerpt)
- Full excerpt: [Requirements Traceability](requirements/traceability.md)
- FR-001 -> SP-001 -> DES-001 -> TC-001
- FR-003 -> SP-003 -> DES-003 -> TC-003, TC-155
- FR-007 -> SP-010 -> DES-009 -> TC-010
- FR-007, NFR-008 -> SP-010 -> DES-006, DES-007, DES-009 -> TC-150, TC-151, TC-152, TC-153
- FR-007, NFR-009 -> SP-010 -> DES-009 -> TC-154, TC-203, TC-204, TC-205, TC-208, TC-209, TC-210
- FR-019 -> SP-014 -> DES-014, DES-009 -> TC-074, TC-140
- FR-032 -> SP-018 -> DES-019 -> TC-145, TC-146, TC-147, TC-148
- FR-033 -> SP-014 -> DES-014 -> TC-158, TC-159, TC-160, TC-171, TC-186, TC-187
- NFR-010 -> SP-014 -> DES-014 -> TC-157, TC-159, TC-160, TC-171, TC-186, TC-187
- FR-034 -> SP-001 -> DES-001 -> TC-161
- FR-035 -> SP-006, SP-014 -> DES-005, DES-014 -> TC-169
- FR-036 -> SP-010 -> DES-009 -> TC-173
- FR-007, NFR-008 -> SP-010 -> DES-009 -> TC-192
- NFR-002, NFR-007, FR-033, NFR-010 -> SP-014 -> DES-014 -> TC-188, TC-189
- FR-020, FR-023, CON-004 -> SP-014 -> DES-014 -> TC-190
- NFR-005, FR-020, NFR-010 -> SP-014 -> DES-014 -> TC-191
- FR-037 -> SP-019 -> DES-020 -> TC-174
- FR-038 -> SP-020 -> DES-021 -> TC-175
- FR-039 -> SP-021 -> DES-022 -> TC-180
- FR-040, NFR-014 -> SP-023 -> DES-024 -> TC-193
- FR-032, FR-033, FR-040, NFR-010, NFR-014 -> SP-006, SP-014, SP-018, SP-023 -> DES-005, DES-014, DES-019, DES-024 -> TC-215
- FR-041 -> SP-006, SP-010 -> DES-005, DES-009 -> TC-201
- NFR-015 -> SP-010 -> DES-006, DES-007, DES-009 -> TC-205, TC-206, TC-207, TC-208, TC-209, TC-211
- NFR-001 -> SP-007 -> DES-006 -> TC-007, TC-156, TC-161, TC-185
- FR-009 -> SP-004 -> DES-004, DES-007 -> TC-050, TC-051, TC-164
- FR-006, NFR-011 -> SP-004, SP-006, SP-013 -> DES-004, DES-005, DES-006 -> TC-006, TC-006A, TC-015, TC-057B, TC-162, TC-163, TC-164, TC-172
- FR-010, NFR-012 -> SP-001, SP-006 -> DES-005, DES-007 -> TC-165, TC-166
- FR-011, FR-026, NFR-012 -> SP-016 -> DES-017 -> TC-167, TC-168

- FR-042 -> SP-002 -> DES-002 -> TC-213
- FR-043 -> SP-010 -> DES-009 -> TC-214
- FR-028, FR-044 -> SP-024 -> DES-025 -> TC-216, TC-217, TC-218
- FR-045, NFR-008 -> SP-025 -> DES-026 -> TC-219, TC-220, TC-221, TC-222
