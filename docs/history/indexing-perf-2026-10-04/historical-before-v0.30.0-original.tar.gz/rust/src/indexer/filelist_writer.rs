use crate::fs_atomic::{
    atomic_write_replaced_destination, write_bytes_atomic_with_metadata, AtomicWriteMetadata,
};
use crate::path_utils::path_key;
use anyhow::{Context, Result};
use std::any::Any;
use std::collections::HashSet;
use std::fs;
use std::fs::File;
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::path::{Component, Path, PathBuf};
use std::time::SystemTime;

use super::filelist_reader::{
    compare_filelist_path_precedence, looks_like_windows_absolute_path, read_filelist_text_strict,
    strip_wrapping_quotes,
};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FileListWriteTargetKind {
    Root,
    Ancestor,
}

#[derive(Debug, Clone, Copy)]
pub(super) enum FileListReplacementPhase {
    Commit,
    Rollback,
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct FileListWriteOptions {
    pub allow_root_overwrite: bool,
    pub propagate_to_ancestors: bool,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FileListWriteFailure {
    pub path: PathBuf,
    pub error: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FileListWriteStatus {
    Completed,
    Canceled,
    Failed,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FileListWriteReport {
    pub status: FileListWriteStatus,
    pub root_target: PathBuf,
    pub committed: Vec<PathBuf>,
    pub failed: Vec<FileListWriteFailure>,
    pub rolled_back: Vec<PathBuf>,
    pub rollback_failed: Vec<FileListWriteFailure>,
}

impl FileListWriteReport {
    fn completed(root_target: PathBuf) -> Self {
        Self {
            status: FileListWriteStatus::Completed,
            root_target,
            committed: Vec::new(),
            failed: Vec::new(),
            rolled_back: Vec::new(),
            rollback_failed: Vec::new(),
        }
    }

    fn preflight_failed(root_target: PathBuf, failure_path: PathBuf, error: impl ToString) -> Self {
        Self {
            status: FileListWriteStatus::Failed,
            root_target: root_target.clone(),
            committed: Vec::new(),
            failed: vec![FileListWriteFailure {
                path: failure_path,
                error: error.to_string(),
            }],
            rolled_back: Vec::new(),
            rollback_failed: Vec::new(),
        }
    }

    fn canceled(root_target: PathBuf) -> Self {
        Self {
            status: FileListWriteStatus::Canceled,
            root_target,
            committed: Vec::new(),
            failed: Vec::new(),
            rolled_back: Vec::new(),
            rollback_failed: Vec::new(),
        }
    }

    pub fn exit_code(&self) -> i32 {
        match self.status {
            FileListWriteStatus::Completed => 0,
            FileListWriteStatus::Canceled
                if self.failed.is_empty() && self.rollback_failed.is_empty() =>
            {
                130
            }
            FileListWriteStatus::Canceled | FileListWriteStatus::Failed => 1,
        }
    }

    pub fn summary(&self) -> String {
        let mut parts = Vec::new();
        for failure in self.failed.iter().chain(&self.rollback_failed) {
            parts.push(format!("{}: {}", failure.path.display(), failure.error));
        }
        if parts.is_empty() && self.status == FileListWriteStatus::Canceled {
            "filelist creation canceled".to_string()
        } else if parts.is_empty() {
            "filelist write failed".to_string()
        } else {
            parts.join("; ")
        }
    }
}

#[derive(Debug, Clone)]
struct PriorFileState {
    bytes: Option<Vec<u8>>,
    fingerprint: Option<FileMetadataFingerprint>,
    permissions: Option<fs::Permissions>,
    modified: Option<SystemTime>,
    accessed: Option<SystemTime>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct FileSystemObjectIdentity {
    #[cfg(unix)]
    device: u64,
    #[cfg(unix)]
    inode: u64,
    #[cfg(windows)]
    volume_serial_number: u32,
    #[cfg(windows)]
    file_index: u64,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct FileMetadataFingerprint {
    identity: FileSystemObjectIdentity,
    len: u64,
    modified: SystemTime,
    readonly: bool,
    #[cfg(unix)]
    mode: u32,
    #[cfg(windows)]
    file_attributes: u32,
}

#[derive(Debug, Clone)]
pub struct FileListWriteTarget {
    pub path: PathBuf,
    pub kind: FileListWriteTargetKind,
    content: Vec<u8>,
    prior: PriorFileState,
    parent_identity: FileSystemObjectIdentity,
    preserve_mtime_on_success: bool,
}

#[derive(Debug, Clone)]
pub struct FileListWritePlan {
    root: PathBuf,
    root_target: PathBuf,
    targets: Vec<FileListWriteTarget>,
}

impl FileListWritePlan {
    pub fn root_target(&self) -> &Path {
        &self.root_target
    }

    pub fn targets(&self) -> &[FileListWriteTarget] {
        &self.targets
    }

    pub fn into_root_only(mut self) -> Self {
        self.targets
            .retain(|target| target.kind == FileListWriteTargetKind::Root);
        self
    }
}

pub fn build_filelist_text(entries: &[PathBuf], root: &Path) -> String {
    build_filelist_text_cancellable(entries, root, &|| false)
        .expect("build_filelist_text without cancellation should not fail")
}

pub fn build_filelist_text_cancellable<C>(
    entries: &[PathBuf],
    root: &Path,
    should_cancel: &C,
) -> Result<String>
where
    C: Fn() -> bool,
{
    let root_lexical = root.to_path_buf();
    let root_canonical = root.canonicalize().ok();
    let mut seen = HashSet::new();
    let mut lines = Vec::new();
    for entry in entries {
        if should_cancel() {
            anyhow::bail!("filelist creation canceled");
        }
        let line = filelist_line_for_entry(entry, &root_lexical, root_canonical.as_deref());
        if seen.insert(line.clone()) {
            lines.push(line);
        }
    }
    Ok(if lines.is_empty() {
        String::new()
    } else {
        format!("{}\n", lines.join("\n"))
    })
}

pub(super) fn filelist_line_for_entry(
    entry: &Path,
    root_lexical: &Path,
    root_canonical: Option<&Path>,
) -> String {
    if let Ok(relative) = entry.strip_prefix(root_lexical) {
        return normalize_relative_lexically(relative)
            .to_string_lossy()
            .to_string();
    }
    if let Some(root) = root_canonical {
        if let Ok(relative) = entry.strip_prefix(root) {
            return normalize_relative_lexically(relative)
                .to_string_lossy()
                .to_string();
        }
    }

    if let Some(root) = root_canonical {
        if let Ok(canonical_entry) = entry.canonicalize() {
            if let Ok(relative) = canonical_entry.strip_prefix(root) {
                return relative.to_string_lossy().to_string();
            }
            return canonical_entry.to_string_lossy().to_string();
        }
    }

    entry.to_string_lossy().to_string()
}

fn normalize_relative_lexically(path: &Path) -> PathBuf {
    let mut out = PathBuf::new();
    for component in path.components() {
        match component {
            Component::CurDir => {}
            Component::ParentDir => {
                let popped = out.pop();
                if !popped {
                    out.push(component.as_os_str());
                }
            }
            Component::Normal(segment) => out.push(segment),
            Component::RootDir | Component::Prefix(_) => out.push(component.as_os_str()),
        }
    }
    out
}

pub(crate) fn filelist_modified_time(path: &Path) -> Option<SystemTime> {
    fs::metadata(path)
        .ok()
        .and_then(|meta| meta.modified().ok())
}

#[cfg(test)]
pub(crate) fn annotate_write_target_error(out: &Path, err: std::io::Error) -> anyhow::Error {
    if err.kind() == std::io::ErrorKind::PermissionDenied {
        return anyhow::anyhow!(
            "permission denied while writing {}. destination directory may be protected (for example C:\\ root/UAC), existing FileList.txt may be read-only, or another process may be locking the file. original error: {}",
            out.display(),
            err
        );
    }
    anyhow::Error::new(err)
}

pub(crate) fn visit_ancestor_directories(path: &Path, mut visit: impl FnMut(&Path) -> bool) {
    let mut current = path.parent();
    while let Some(ancestor) = current {
        if !visit(ancestor) {
            break;
        }
        current = ancestor.parent();
    }
}

fn find_all_filelists_in_directory(dir: &Path) -> std::io::Result<Vec<PathBuf>> {
    let mut matches = Vec::new();
    let mut seen = HashSet::new();
    for entry in fs::read_dir(dir)? {
        let entry = entry?;
        let path = entry.path();
        let Some(name) = path.file_name().and_then(|s| s.to_str()) else {
            continue;
        };
        if !name.eq_ignore_ascii_case("filelist.txt") {
            continue;
        }
        if seen.insert(path.clone()) {
            matches.push(path);
        }
    }
    matches.sort_by(|left, right| compare_filelist_path_precedence(left, right));
    Ok(matches)
}

fn preferred_root_filelist_write_target(root: &Path) -> std::io::Result<PathBuf> {
    Ok(find_all_filelists_in_directory(root)?
        .into_iter()
        .next()
        .unwrap_or_else(|| root.join("FileList.txt")))
}

#[derive(Debug)]
pub(crate) struct AncestorFileListDiscovery {
    pub(crate) candidates: Vec<PathBuf>,
    scan_complete: bool,
}

impl AncestorFileListDiscovery {
    pub(crate) fn next_ancestor<'a>(&self, directory: &'a Path) -> Option<&'a Path> {
        self.scan_complete.then(|| directory.parent()).flatten()
    }
}

pub(crate) fn sort_and_deduplicate_filelist_candidates_by<F>(
    candidates: &mut Vec<PathBuf>,
    mut resolve_identity: F,
) where
    F: FnMut(&Path) -> PathBuf,
{
    candidates.sort_by(|left, right| compare_filelist_path_precedence(left, right));
    let mut seen = HashSet::new();
    candidates.retain(|candidate| seen.insert(path_key(&resolve_identity(candidate))));
}

fn filelist_candidate_identity(path: &Path) -> PathBuf {
    // A case-insensitive macOS volume can report both canonical spellings as
    // files even though they address one directory entry. Resolve regular-file
    // aliases before deduplication, but keep symlinks lexical so the later
    // target-safety check can reject them instead of hiding them behind a peer.
    if fs::symlink_metadata(path).is_ok_and(|metadata| metadata.file_type().is_symlink()) {
        return path.to_path_buf();
    }
    path.canonicalize().unwrap_or_else(|_| path.to_path_buf())
}

fn sort_and_deduplicate_filelist_candidates(candidates: &mut Vec<PathBuf>) {
    sort_and_deduplicate_filelist_candidates_by(candidates, filelist_candidate_identity);
}

pub(crate) fn finalize_ancestor_filelist_discovery(
    mut directly_proven: Vec<PathBuf>,
    scan: std::result::Result<Vec<PathBuf>, (Vec<PathBuf>, std::io::Error)>,
) -> AncestorFileListDiscovery {
    let scan_complete = scan.is_ok();
    if let Ok(scanned) = scan {
        directly_proven.extend(scanned);
    }
    // Partial scan results are untrusted after any iterator error. Only
    // canonical paths proven independently may remain eligible.
    sort_and_deduplicate_filelist_candidates(&mut directly_proven);
    AncestorFileListDiscovery {
        candidates: directly_proven,
        scan_complete,
    }
}

fn discover_ancestor_filelists_in_directory(dir: &Path) -> AncestorFileListDiscovery {
    let directly_proven = ["FileList.txt", "filelist.txt"]
        .into_iter()
        .map(|name| dir.join(name))
        .filter(|path| path.is_file())
        .collect::<Vec<_>>();

    let mut scanned = Vec::new();
    let entries = match fs::read_dir(dir) {
        Ok(entries) => entries,
        Err(error) => {
            return finalize_ancestor_filelist_discovery(directly_proven, Err((scanned, error)))
        }
    };
    for entry in entries {
        let entry = match entry {
            Ok(entry) => entry,
            Err(error) => {
                return finalize_ancestor_filelist_discovery(directly_proven, Err((scanned, error)))
            }
        };
        let path = entry.path();
        let Some(name) = path.file_name().and_then(|name| name.to_str()) else {
            continue;
        };
        if name.eq_ignore_ascii_case("filelist.txt") {
            scanned.push(path);
        }
    }
    finalize_ancestor_filelist_discovery(directly_proven, Ok(scanned))
}

pub(crate) fn normalize_filelist_entry_for_text_compare(line: &str) -> Option<String> {
    let trimmed = line.trim();
    if trimmed.is_empty() || trimmed.starts_with('#') {
        return None;
    }

    let raw = strip_wrapping_quotes(trimmed);
    if raw.is_empty() {
        return None;
    }

    let normalized = if looks_like_windows_absolute_path(raw) || raw.starts_with("//") {
        raw.replace('\\', "/").to_ascii_lowercase()
    } else {
        let lexical = normalize_relative_lexically(Path::new(&raw.replace('\\', "/")));
        lexical.to_string_lossy().replace('\\', "/")
    };
    let normalized = normalized.trim_start_matches("./").to_string();
    if normalized.is_empty() {
        None
    } else {
        Some(normalized)
    }
}

fn child_filelist_reference_keys(parent_dir: &Path, child_filelist: &Path) -> HashSet<String> {
    let mut keys = HashSet::new();
    let parent_canonical = parent_dir.canonicalize().ok();
    let relative = filelist_line_for_entry(child_filelist, parent_dir, parent_canonical.as_deref());
    if let Some(key) = normalize_filelist_entry_for_text_compare(&relative) {
        keys.insert(key);
    }
    if let Some(key) =
        normalize_filelist_entry_for_text_compare(child_filelist.to_string_lossy().as_ref())
    {
        keys.insert(key);
    }
    if let Ok(canonical) = child_filelist.canonicalize() {
        if let Some(key) =
            normalize_filelist_entry_for_text_compare(canonical.to_string_lossy().as_ref())
        {
            keys.insert(key);
        }
    }
    keys
}

fn parent_filelist_contains_child_reference(
    parent_filelist: &Path,
    child_filelist: &Path,
) -> std::io::Result<bool> {
    let content = read_filelist_text_strict(parent_filelist)?;
    Ok(parent_filelist_content_contains_child_reference(
        parent_filelist,
        child_filelist,
        &content,
    ))
}

fn parent_filelist_content_contains_child_reference(
    parent_filelist: &Path,
    child_filelist: &Path,
    content: &str,
) -> bool {
    let Some(parent_dir) = parent_filelist.parent() else {
        return false;
    };
    let child_keys = child_filelist_reference_keys(parent_dir, child_filelist);
    content
        .lines()
        .filter_map(normalize_filelist_entry_for_text_compare)
        .any(|line| child_keys.contains(&line))
}

pub fn has_ancestor_filelists(root: &Path) -> bool {
    let mut found = false;
    visit_ancestor_directories(root, |ancestor_dir| {
        let discovery = discover_ancestor_filelists_in_directory(ancestor_dir);
        if discovery.candidates.is_empty() {
            discovery.scan_complete
        } else {
            found = true;
            false
        }
    });
    found
}

pub fn ancestor_filelist_propagation_needed(root: &Path) -> bool {
    let child_filelist =
        preferred_root_filelist_write_target(root).unwrap_or_else(|_| root.join("FileList.txt"));
    let mut needs_confirmation = false;
    visit_ancestor_directories(root, |ancestor_dir| {
        let discovery = discover_ancestor_filelists_in_directory(ancestor_dir);
        for parent_filelist in discovery.candidates {
            match parent_filelist_contains_child_reference(&parent_filelist, &child_filelist) {
                Ok(true) => {}
                Ok(false) => {
                    needs_confirmation = true;
                    return false;
                }
                Err(_) => return false,
            }
        }
        discovery.scan_complete
    });
    needs_confirmation
}

/// Precompute every FileList replacement, including the prior bytes and
/// metadata required to restore already committed targets after a later error.
/// This function performs no writes.
pub fn plan_filelist_write(
    root: &Path,
    entries: &[PathBuf],
    options: FileListWriteOptions,
) -> std::result::Result<FileListWritePlan, Box<FileListWriteReport>> {
    plan_filelist_write_cancellable(root, entries, options, &|| false)
}

/// Build a write plan without mutating the filesystem. Cancellation during
/// entry serialization or ancestor discovery returns a clean cancellation
/// report; no replacement has started at that point.
pub fn plan_filelist_write_cancellable<C>(
    root: &Path,
    entries: &[PathBuf],
    options: FileListWriteOptions,
    should_cancel: &C,
) -> std::result::Result<FileListWritePlan, Box<FileListWriteReport>>
where
    C: Fn() -> bool,
{
    plan_filelist_write_cancellable_inner(root, entries, options, None, should_cancel)
}

#[cfg(test)]
pub(crate) fn plan_filelist_write_cancellable_with_ancestor_boundary<C>(
    root: &Path,
    entries: &[PathBuf],
    options: FileListWriteOptions,
    exclusive_ancestor_boundary: &Path,
    should_cancel: &C,
) -> std::result::Result<FileListWritePlan, Box<FileListWriteReport>>
where
    C: Fn() -> bool,
{
    plan_filelist_write_cancellable_inner(
        root,
        entries,
        options,
        Some(exclusive_ancestor_boundary),
        should_cancel,
    )
}

fn plan_filelist_write_cancellable_inner<C>(
    root: &Path,
    entries: &[PathBuf],
    options: FileListWriteOptions,
    exclusive_ancestor_boundary: Option<&Path>,
    should_cancel: &C,
) -> std::result::Result<FileListWritePlan, Box<FileListWriteReport>>
where
    C: Fn() -> bool,
{
    let fallback_target = root.join("FileList.txt");
    if should_cancel() {
        return Err(Box::new(FileListWriteReport::canceled(fallback_target)));
    }
    validate_filelist_directory(root).map_err(|error| {
        Box::new(FileListWriteReport::preflight_failed(
            fallback_target.clone(),
            root.to_path_buf(),
            error,
        ))
    })?;
    let root_target = preferred_root_filelist_write_target(root).map_err(|error| {
        Box::new(FileListWriteReport::preflight_failed(
            fallback_target.clone(),
            root.to_path_buf(),
            error,
        ))
    })?;
    if fs::symlink_metadata(&root_target).is_ok() && !options.allow_root_overwrite {
        return Err(Box::new(FileListWriteReport::preflight_failed(
            root_target.clone(),
            root_target.clone(),
            format!(
                "refusing to overwrite existing FileList target {} without explicit consent",
                root_target.display()
            ),
        )));
    }

    let root_text =
        build_filelist_text_cancellable(entries, root, should_cancel).map_err(|error| {
            if should_cancel() {
                Box::new(FileListWriteReport::canceled(root_target.clone()))
            } else {
                Box::new(FileListWriteReport::preflight_failed(
                    root_target.clone(),
                    root_target.clone(),
                    error,
                ))
            }
        })?;
    let root_write_target = prepare_filelist_target(
        root_target.clone(),
        FileListWriteTargetKind::Root,
        root_text.into_bytes(),
        false,
    )
    .map_err(|error| {
        Box::new(FileListWriteReport::preflight_failed(
            root_target.clone(),
            root_target.clone(),
            error,
        ))
    })?;
    let mut targets = Vec::new();

    if options.propagate_to_ancestors {
        let mut ancestor = root.parent();
        'ancestors: while let Some(directory) = ancestor {
            // Regression guard: tests inject an exclusive fixture boundary so
            // ancestor discovery cannot observe or mutate a developer's real
            // FileList. Production callers pass no boundary and keep full traversal.
            if exclusive_ancestor_boundary.is_some_and(|boundary| directory == boundary) {
                break;
            }
            if should_cancel() {
                return Err(Box::new(FileListWriteReport::canceled(root_target.clone())));
            }
            let discovery = discover_ancestor_filelists_in_directory(directory);
            for parent_filelist in &discovery.candidates {
                if should_cancel() {
                    return Err(Box::new(FileListWriteReport::canceled(root_target.clone())));
                }
                if inspect_filelist_target(parent_filelist).is_err() {
                    if should_cancel() {
                        return Err(Box::new(FileListWriteReport::canceled(root_target.clone())));
                    }
                    break 'ancestors;
                }
                let mut content = match read_filelist_text_strict(parent_filelist) {
                    Ok(content) => content,
                    Err(_) => {
                        if should_cancel() {
                            return Err(Box::new(FileListWriteReport::canceled(
                                root_target.clone(),
                            )));
                        }
                        break 'ancestors;
                    }
                };
                if should_cancel() {
                    return Err(Box::new(FileListWriteReport::canceled(root_target.clone())));
                }
                if !parent_filelist_content_contains_child_reference(
                    parent_filelist,
                    &root_target,
                    &content,
                ) {
                    if !content.is_empty() && !content.ends_with('\n') {
                        content.push('\n');
                    }
                    content.push_str(&filelist_line_for_entry(&root_target, directory, None));
                    content.push('\n');
                    match prepare_filelist_target(
                        parent_filelist.clone(),
                        FileListWriteTargetKind::Ancestor,
                        content.into_bytes(),
                        true,
                    ) {
                        Ok(target) => targets.push(target),
                        Err(_) => {
                            if should_cancel() {
                                return Err(Box::new(FileListWriteReport::canceled(
                                    root_target.clone(),
                                )));
                            }
                            break 'ancestors;
                        }
                    }
                }
            }
            ancestor = discovery.next_ancestor(directory);
        }
    }
    targets.push(root_write_target);

    Ok(FileListWritePlan {
        root: root.to_path_buf(),
        root_target,
        targets,
    })
}

/// Execute a previously validated plan. Cancellation is sampled immediately
/// before every target replacement; any committed target is then restored in
/// reverse order before the report is returned.
pub fn execute_filelist_write_plan<C>(
    plan: &FileListWritePlan,
    should_cancel: &C,
) -> FileListWriteReport
where
    C: Fn() -> bool,
{
    execute_filelist_write_plan_with(plan, should_cancel, &mut |target, bytes, phase| {
        write_filelist_target_atomically(target, bytes, phase)
    })
}

pub(super) fn execute_filelist_write_plan_with<C, W>(
    plan: &FileListWritePlan,
    should_cancel: &C,
    replace: &mut W,
) -> FileListWriteReport
where
    C: Fn() -> bool,
    W: FnMut(&FileListWriteTarget, &[u8], FileListReplacementPhase) -> std::io::Result<()>,
{
    let mut report = FileListWriteReport::completed(plan.root_target.clone());
    match preferred_root_filelist_write_target(&plan.root) {
        Ok(current_target) if path_key(&current_target) == path_key(&plan.root_target) => {}
        Ok(current_target) => {
            report.status = FileListWriteStatus::Failed;
            report.failed.push(FileListWriteFailure {
                path: current_target,
                error: "preferred FileList target changed after planning".to_string(),
            });
            return report;
        }
        Err(error) => {
            report.status = FileListWriteStatus::Failed;
            report.failed.push(FileListWriteFailure {
                path: plan.root.clone(),
                error: error.to_string(),
            });
            return report;
        }
    }
    let mut committed_indexes = Vec::new();
    for (index, target) in plan.targets.iter().enumerate() {
        if should_cancel() {
            report.status = FileListWriteStatus::Canceled;
            rollback_committed_targets(&plan.targets, &committed_indexes, &mut report, replace);
            return report;
        }
        if let Err(error) = revalidate_filelist_target(target) {
            report.status = FileListWriteStatus::Failed;
            report.failed.push(FileListWriteFailure {
                path: target.path.clone(),
                error: error.to_string(),
            });
            rollback_committed_targets(&plan.targets, &committed_indexes, &mut report, replace);
            return report;
        }
        if should_cancel() {
            report.status = FileListWriteStatus::Canceled;
            rollback_committed_targets(&plan.targets, &committed_indexes, &mut report, replace);
            return report;
        }
        if let Err(error) = revalidate_filelist_target(target) {
            report.status = FileListWriteStatus::Failed;
            report.failed.push(FileListWriteFailure {
                path: target.path.clone(),
                error: error.to_string(),
            });
            rollback_committed_targets(&plan.targets, &committed_indexes, &mut report, replace);
            return report;
        }
        if let Err(error) = replace_filelist_target(
            replace,
            target,
            &target.content,
            FileListReplacementPhase::Commit,
        ) {
            if atomic_write_replaced_destination(&error) {
                report.committed.push(target.path.clone());
                committed_indexes.push(index);
            }
            report.status = FileListWriteStatus::Failed;
            report.failed.push(FileListWriteFailure {
                path: target.path.clone(),
                error: error.to_string(),
            });
            rollback_committed_targets(&plan.targets, &committed_indexes, &mut report, replace);
            return report;
        }
        report.committed.push(target.path.clone());
        committed_indexes.push(index);
        #[cfg(test)]
        abort_after_filelist_commit_if_requested(committed_indexes.len());
        if let Err(error) = restore_success_metadata(target) {
            report.status = FileListWriteStatus::Failed;
            report.failed.push(FileListWriteFailure {
                path: target.path.clone(),
                error: error.to_string(),
            });
            rollback_committed_targets(&plan.targets, &committed_indexes, &mut report, replace);
            return report;
        }
    }
    report
}

fn write_filelist_target_atomically(
    target: &FileListWriteTarget,
    bytes: &[u8],
    phase: FileListReplacementPhase,
) -> std::io::Result<()> {
    let preserve_times =
        matches!(phase, FileListReplacementPhase::Rollback) || target.preserve_mtime_on_success;
    write_bytes_atomic_with_metadata(
        &target.path,
        bytes,
        AtomicWriteMetadata {
            permissions: target.prior.permissions.clone(),
            accessed: preserve_times.then_some(target.prior.accessed).flatten(),
            modified: preserve_times.then_some(target.prior.modified).flatten(),
        },
    )
}

fn replace_filelist_target<W>(
    replace: &mut W,
    target: &FileListWriteTarget,
    bytes: &[u8],
    phase: FileListReplacementPhase,
) -> std::io::Result<()>
where
    W: FnMut(&FileListWriteTarget, &[u8], FileListReplacementPhase) -> std::io::Result<()>,
{
    catch_unwind(AssertUnwindSafe(|| replace(target, bytes, phase)))
        .map_err(replacement_panic_error)?
}

#[cfg(test)]
fn abort_after_filelist_commit_if_requested(committed_count: usize) {
    let requested = std::env::var("FLISTWALKER_TEST_ABORT_AFTER_FILELIST_COMMITS")
        .ok()
        .and_then(|value| value.parse::<usize>().ok());
    if requested == Some(committed_count) {
        std::process::abort();
    }
}

fn replacement_panic_error(payload: Box<dyn Any + Send>) -> std::io::Error {
    let detail = payload
        .downcast_ref::<&str>()
        .copied()
        .or_else(|| payload.downcast_ref::<String>().map(String::as_str))
        .and_then(concise_panic_detail);
    let message = match detail {
        Some(detail) => format!("FileList replacement panicked: {detail}"),
        None => "FileList replacement panicked".to_string(),
    };
    std::io::Error::other(message)
}

fn concise_panic_detail(message: &str) -> Option<String> {
    const MAX_CHARS: usize = 160;

    let normalized = message.split_whitespace().collect::<Vec<_>>().join(" ");
    if normalized.is_empty() {
        return None;
    }
    let mut detail: String = normalized.chars().take(MAX_CHARS).collect();
    if normalized.chars().nth(MAX_CHARS).is_some() {
        detail.push('…');
    }
    Some(detail)
}

fn validate_filelist_directory(directory: &Path) -> Result<()> {
    inspect_filelist_directory(directory).map(|_| ())
}

fn inspect_filelist_directory(directory: &Path) -> Result<fs::Metadata> {
    let metadata = fs::symlink_metadata(directory).with_context(|| {
        format!(
            "failed to inspect FileList directory {}",
            directory.display()
        )
    })?;
    if metadata.file_type().is_symlink() || !metadata.is_dir() {
        anyhow::bail!("refusing unsafe FileList directory {}", directory.display());
    }
    if metadata.permissions().readonly() {
        anyhow::bail!(
            "refusing read-only FileList directory {}",
            directory.display()
        );
    }
    Ok(metadata)
}

fn file_system_object_identity(
    _path: &Path,
    metadata: &fs::Metadata,
) -> Result<FileSystemObjectIdentity> {
    #[cfg(unix)]
    {
        use std::os::unix::fs::MetadataExt;

        Ok(FileSystemObjectIdentity {
            device: metadata.dev(),
            inode: metadata.ino(),
        })
    }
    #[cfg(windows)]
    {
        let _ = metadata;
        windows_file_system_object_identity(_path).map_err(Into::into)
    }
}

#[cfg(windows)]
fn windows_file_system_object_identity(path: &Path) -> std::io::Result<FileSystemObjectIdentity> {
    use std::ffi::c_void;
    use std::os::windows::ffi::OsStrExt;

    #[repr(C)]
    struct FileTime {
        low_date_time: u32,
        high_date_time: u32,
    }

    #[repr(C)]
    struct ByHandleFileInformation {
        file_attributes: u32,
        creation_time: FileTime,
        last_access_time: FileTime,
        last_write_time: FileTime,
        volume_serial_number: u32,
        file_size_high: u32,
        file_size_low: u32,
        number_of_links: u32,
        file_index_high: u32,
        file_index_low: u32,
    }

    #[link(name = "kernel32")]
    extern "system" {
        fn CreateFileW(
            file_name: *const u16,
            desired_access: u32,
            share_mode: u32,
            security_attributes: *mut c_void,
            creation_disposition: u32,
            flags_and_attributes: u32,
            template_file: *mut c_void,
        ) -> *mut c_void;
        fn GetFileInformationByHandle(
            file: *mut c_void,
            information: *mut ByHandleFileInformation,
        ) -> i32;
        fn CloseHandle(object: *mut c_void) -> i32;
    }

    const FILE_SHARE_READ: u32 = 0x0000_0001;
    const FILE_SHARE_WRITE: u32 = 0x0000_0002;
    const FILE_SHARE_DELETE: u32 = 0x0000_0004;
    const OPEN_EXISTING: u32 = 3;
    const FILE_FLAG_BACKUP_SEMANTICS: u32 = 0x0200_0000;
    const INVALID_HANDLE_VALUE: *mut c_void = -1_isize as *mut c_void;

    let wide: Vec<u16> = path
        .as_os_str()
        .encode_wide()
        .chain(std::iter::once(0))
        .collect();
    let handle = unsafe {
        CreateFileW(
            wide.as_ptr(),
            0,
            FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
            std::ptr::null_mut(),
            OPEN_EXISTING,
            FILE_FLAG_BACKUP_SEMANTICS,
            std::ptr::null_mut(),
        )
    };
    if handle == INVALID_HANDLE_VALUE {
        return Err(std::io::Error::last_os_error());
    }
    let mut information = std::mem::MaybeUninit::<ByHandleFileInformation>::uninit();
    let ok = unsafe { GetFileInformationByHandle(handle, information.as_mut_ptr()) };
    let query_error = if ok == 0 {
        Some(std::io::Error::last_os_error())
    } else {
        None
    };
    let close_ok = unsafe { CloseHandle(handle) };
    if let Some(error) = query_error {
        return Err(error);
    }
    if close_ok == 0 {
        return Err(std::io::Error::last_os_error());
    }
    let information = unsafe { information.assume_init() };
    Ok(FileSystemObjectIdentity {
        volume_serial_number: information.volume_serial_number,
        file_index: (u64::from(information.file_index_high) << 32)
            | u64::from(information.file_index_low),
    })
}

fn file_metadata_fingerprint(
    path: &Path,
    metadata: &fs::Metadata,
) -> Result<FileMetadataFingerprint> {
    #[cfg(unix)]
    use std::os::unix::fs::PermissionsExt;
    #[cfg(windows)]
    use std::os::windows::fs::MetadataExt;

    Ok(FileMetadataFingerprint {
        identity: file_system_object_identity(path, metadata)?,
        len: metadata.len(),
        modified: metadata.modified()?,
        readonly: metadata.permissions().readonly(),
        #[cfg(unix)]
        mode: metadata.permissions().mode(),
        #[cfg(windows)]
        file_attributes: metadata.file_attributes(),
    })
}

fn filelist_directory_identity(directory: &Path) -> Result<FileSystemObjectIdentity> {
    file_system_object_identity(directory, &inspect_filelist_directory(directory)?)
}

fn inspect_filelist_target(path: &Path) -> Result<Option<fs::Metadata>> {
    let parent = path
        .parent()
        .ok_or_else(|| anyhow::anyhow!("FileList target has no parent: {}", path.display()))?;
    validate_filelist_directory(parent)?;
    match fs::symlink_metadata(path) {
        Ok(metadata) => {
            if metadata.file_type().is_symlink() || !metadata.is_file() {
                anyhow::bail!("refusing unsafe FileList target {}", path.display());
            }
            if metadata.permissions().readonly() {
                anyhow::bail!("refusing read-only FileList target {}", path.display());
            }
            Ok(Some(metadata))
        }
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(None),
        Err(error) => Err(error.into()),
    }
}

fn revalidate_filelist_target(target: &FileListWriteTarget) -> std::io::Result<()> {
    let changed = || {
        std::io::Error::other(format!(
            "FileList target changed after planning: {}",
            target.path.display()
        ))
    };
    let parent = target.path.parent().ok_or_else(changed)?;
    let parent_before = filelist_directory_identity(parent)
        .map_err(|error| std::io::Error::other(error.to_string()))?;
    if parent_before != target.parent_identity {
        return Err(changed());
    }
    let metadata_before = inspect_filelist_target(&target.path)
        .map_err(|error| std::io::Error::other(error.to_string()))?;
    match (
        &target.prior.bytes,
        &target.prior.fingerprint,
        metadata_before,
    ) {
        (None, None, None) => {
            let parent_after = filelist_directory_identity(parent)
                .map_err(|error| std::io::Error::other(error.to_string()))?;
            if parent_after != target.parent_identity
                || inspect_filelist_target(&target.path)
                    .map_err(|error| std::io::Error::other(error.to_string()))?
                    .is_some()
            {
                Err(changed())
            } else {
                Ok(())
            }
        }
        (Some(expected_bytes), Some(expected_fingerprint), Some(metadata_before)) => {
            if file_metadata_fingerprint(&target.path, &metadata_before)
                .map_err(|error| std::io::Error::other(error.to_string()))?
                != *expected_fingerprint
            {
                return Err(changed());
            }
            let actual = fs::read(&target.path)?;
            let metadata_after = inspect_filelist_target(&target.path)
                .map_err(|error| std::io::Error::other(error.to_string()))?
                .ok_or_else(changed)?;
            let parent_after = filelist_directory_identity(parent)
                .map_err(|error| std::io::Error::other(error.to_string()))?;
            if actual == *expected_bytes
                && file_metadata_fingerprint(&target.path, &metadata_after)
                    .map_err(|error| std::io::Error::other(error.to_string()))?
                    == *expected_fingerprint
                && parent_after == target.parent_identity
            {
                Ok(())
            } else {
                Err(changed())
            }
        }
        (None, None, Some(_)) => Err(std::io::Error::other(format!(
            "FileList target appeared after planning: {}",
            target.path.display()
        ))),
        (Some(_), Some(_), None) => Err(std::io::Error::other(format!(
            "FileList target disappeared after planning: {}",
            target.path.display()
        ))),
        _ => Err(changed()),
    }
}

fn prepare_filelist_target(
    path: PathBuf,
    kind: FileListWriteTargetKind,
    content: Vec<u8>,
    preserve_mtime_on_success: bool,
) -> Result<FileListWriteTarget> {
    let parent = path
        .parent()
        .ok_or_else(|| anyhow::anyhow!("FileList target has no parent: {}", path.display()))?;
    let parent_identity = filelist_directory_identity(parent)?;
    let prior = match inspect_filelist_target(&path)? {
        Some(metadata_before) => {
            let fingerprint = file_metadata_fingerprint(&path, &metadata_before)?;
            let accessed = match metadata_before.accessed() {
                Ok(time) => Some(time),
                Err(error) if error.kind() == std::io::ErrorKind::Unsupported => None,
                Err(error) => return Err(error.into()),
            };
            let bytes = fs::read(&path).with_context(|| {
                format!("failed to read prior FileList target {}", path.display())
            })?;
            let metadata_after = inspect_filelist_target(&path)?.ok_or_else(|| {
                anyhow::anyhow!("FileList target changed while planning: {}", path.display())
            })?;
            if file_metadata_fingerprint(&path, &metadata_after)? != fingerprint
                || filelist_directory_identity(parent)? != parent_identity
            {
                anyhow::bail!("FileList target changed while planning: {}", path.display());
            }
            PriorFileState {
                bytes: Some(bytes),
                fingerprint: Some(fingerprint),
                permissions: Some(metadata_before.permissions()),
                modified: Some(metadata_before.modified()?),
                accessed,
            }
        }
        None => {
            if filelist_directory_identity(parent)? != parent_identity
                || inspect_filelist_target(&path)?.is_some()
            {
                anyhow::bail!("FileList target changed while planning: {}", path.display());
            }
            PriorFileState {
                bytes: None,
                fingerprint: None,
                permissions: None,
                modified: None,
                accessed: None,
            }
        }
    };
    Ok(FileListWriteTarget {
        path,
        kind,
        content,
        prior,
        parent_identity,
        preserve_mtime_on_success,
    })
}

fn restore_success_metadata(target: &FileListWriteTarget) -> std::io::Result<()> {
    if let Some(permissions) = &target.prior.permissions {
        fs::set_permissions(&target.path, permissions.clone())?;
    }
    if target.preserve_mtime_on_success {
        restore_file_metadata(&target.path, &target.prior)?;
    }
    Ok(())
}

fn restore_file_metadata(path: &Path, prior: &PriorFileState) -> std::io::Result<()> {
    if let Some(permissions) = &prior.permissions {
        fs::set_permissions(path, permissions.clone())?;
    }
    let Some(modified) = prior.modified else {
        return Ok(());
    };
    let file = File::options().write(true).open(path)?;
    let times = match prior.accessed {
        Some(accessed) => fs::FileTimes::new()
            .set_accessed(accessed)
            .set_modified(modified),
        None => fs::FileTimes::new().set_modified(modified),
    };
    file.set_times(times)
}

fn rollback_committed_targets<W>(
    targets: &[FileListWriteTarget],
    committed_indexes: &[usize],
    report: &mut FileListWriteReport,
    replace: &mut W,
) where
    W: FnMut(&FileListWriteTarget, &[u8], FileListReplacementPhase) -> std::io::Result<()>,
{
    for index in committed_indexes.iter().rev().copied() {
        let target = &targets[index];
        let result = match &target.prior.bytes {
            Some(bytes) => {
                replace_filelist_target(replace, target, bytes, FileListReplacementPhase::Rollback)
                    .and_then(|_| restore_file_metadata(&target.path, &target.prior))
            }
            None => fs::remove_file(&target.path),
        };
        match result {
            Ok(()) => report.rolled_back.push(target.path.clone()),
            Err(error) => report.rollback_failed.push(FileListWriteFailure {
                path: target.path.clone(),
                error: error.to_string(),
            }),
        }
    }
}

pub fn write_filelist(
    root: &Path,
    entries: &[PathBuf],
    filename: &str,
    propagate_to_ancestors: bool,
) -> Result<PathBuf> {
    write_filelist_cancellable(root, entries, filename, propagate_to_ancestors, &|| false)
}

pub fn write_filelist_cancellable<C>(
    root: &Path,
    entries: &[PathBuf],
    filename: &str,
    propagate_to_ancestors: bool,
    should_cancel: &C,
) -> Result<PathBuf>
where
    C: Fn() -> bool,
{
    write_filelist_cancellable_inner(
        root,
        entries,
        filename,
        propagate_to_ancestors,
        None,
        should_cancel,
    )
}

#[cfg(test)]
pub(crate) fn write_filelist_cancellable_with_ancestor_boundary<C>(
    root: &Path,
    entries: &[PathBuf],
    filename: &str,
    propagate_to_ancestors: bool,
    exclusive_ancestor_boundary: &Path,
    should_cancel: &C,
) -> Result<PathBuf>
where
    C: Fn() -> bool,
{
    write_filelist_cancellable_inner(
        root,
        entries,
        filename,
        propagate_to_ancestors,
        Some(exclusive_ancestor_boundary),
        should_cancel,
    )
}

fn write_filelist_cancellable_inner<C>(
    root: &Path,
    entries: &[PathBuf],
    filename: &str,
    propagate_to_ancestors: bool,
    exclusive_ancestor_boundary: Option<&Path>,
    should_cancel: &C,
) -> Result<PathBuf>
where
    C: Fn() -> bool,
{
    if filename != "FileList.txt" && filename != "filelist.txt" {
        anyhow::bail!("unsupported FileList filename {filename}");
    }
    if should_cancel() {
        anyhow::bail!("filelist creation canceled");
    }
    let plan = plan_filelist_write_cancellable_inner(
        root,
        entries,
        FileListWriteOptions {
            // The legacy GUI reaches this adapter only after its overwrite
            // confirmation. New CLI/TUI callers use the public option model.
            allow_root_overwrite: true,
            propagate_to_ancestors,
        },
        exclusive_ancestor_boundary,
        should_cancel,
    )
    .map_err(|report| anyhow::anyhow!(report.summary()))?;
    let root_target = plan.root_target.clone();
    let report = execute_filelist_write_plan(&plan, should_cancel);
    if report.exit_code() == 0 {
        Ok(root_target)
    } else {
        Err(anyhow::anyhow!(report.summary()))
    }
}
