#[cfg(test)]
use std::fs::File;
use std::fs::Metadata;
#[cfg(test)]
use std::io::Read;
use std::path::Path;
use std::time::{SystemTime, UNIX_EPOCH};

#[cfg(test)]
use encoding_rs::{EUC_JP, SHIFT_JIS, UTF_16BE, UTF_16LE, WINDOWS_1252};

use super::{normalize_path_for_display, should_skip_preview, PagedTextPreview, PreviewPageError};
pub fn build_preview_text(path: &Path) -> String {
    build_preview_text_with_kind(path, path.is_dir())
}

pub fn build_preview_text_with_kind(path: &Path, is_dir: bool) -> String {
    build_preview_text_with_kind_cancellable(path, is_dir, &|| false)
        .expect("non-cancellable preview")
}

/// Cancellation is cooperative between filesystem calls; one OS call cannot be interrupted.
pub fn build_preview_text_with_kind_cancellable(
    path: &Path,
    is_dir: bool,
    canceled: &(impl Fn() -> bool + ?Sized),
) -> Option<String> {
    if canceled() {
        return None;
    }
    let normalized_path = normalize_path_for_display(path);
    if !is_dir && should_skip_preview(path, is_dir) {
        return Some(format!(
            "File: {normalized_path}\n\n<on-demand file: preview skipped>"
        ));
    }
    if canceled() {
        return None;
    }
    let metadata = std::fs::metadata(path).ok();
    if canceled() {
        return None;
    }
    let symlink_metadata = std::fs::symlink_metadata(path).ok();
    if canceled() {
        return None;
    }
    if is_dir {
        return build_directory_preview_text(
            path,
            &normalized_path,
            metadata.as_ref(),
            symlink_metadata.as_ref(),
            canceled,
        );
    }
    let head = build_entry_header(
        path,
        "File",
        &normalized_path,
        metadata.as_ref(),
        symlink_metadata.as_ref(),
    );
    if canceled() {
        return None;
    }
    let text = match PagedTextPreview::tui_head(path, &|| canceled()) {
        Ok(preview) => {
            let lines = (0..preview.line_count())
                .filter_map(|index| preview.line(index))
                .collect::<Vec<_>>();
            format!("{head}\n{}", lines.join("\n"))
        }
        Err(PreviewPageError::Empty) => format!("{head}\n<empty file>"),
        Err(PreviewPageError::Canceled) => return None,
        Err(error) => format!(
            "{head}\n<binary or unreadable file>\nReason: {}",
            tui_page_error_label(error)
        ),
    };
    (!canceled()).then_some(text)
}

fn tui_page_error_label(error: PreviewPageError) -> &'static str {
    match error {
        PreviewPageError::Empty => "empty file",
        PreviewPageError::Binary => "binary file",
        PreviewPageError::DecodeFailed => "text decoding failed",
        PreviewPageError::PermissionDenied => "permission denied",
        PreviewPageError::NotFound => "file not found",
        PreviewPageError::OnDemandSkipped => "on-demand file: preview skipped",
        PreviewPageError::ReadFailed => "read failed",
        PreviewPageError::Changed => "file changed",
        PreviewPageError::LimitReached => "display limit reached",
        PreviewPageError::Canceled => "canceled",
    }
}

pub(crate) fn format_file_size(bytes: u64) -> String {
    const UNITS: [&str; 5] = ["B", "KiB", "MiB", "GiB", "TiB"];
    let mut value = bytes as f64;
    let mut unit = 0usize;
    while value >= 1024.0 && unit < UNITS.len() - 1 {
        value /= 1024.0;
        unit += 1;
    }
    if unit == 0 {
        format!("{} {}", bytes, UNITS[unit])
    } else {
        format!("{value:.1} {}", UNITS[unit])
    }
}

#[cfg(test)]
fn read_preview_lines(
    path: &Path,
    max_lines: usize,
    max_bytes: usize,
) -> std::io::Result<Vec<String>> {
    const UTF8_BOUNDARY_LOOKAHEAD_BYTES: usize = 3;
    let mut file = File::open(path)?;
    let mut bytes = Vec::with_capacity(max_bytes.min(8192));
    let mut handle =
        (&mut file).take(max_bytes.saturating_add(UTF8_BOUNDARY_LOOKAHEAD_BYTES) as u64);
    handle.read_to_end(&mut bytes)?;
    let boundary = bytes.len().min(max_bytes);
    let (bytes, boundary_lookahead) = bytes.split_at(boundary);
    decode_preview_lines(bytes, max_lines, boundary_lookahead).ok_or_else(|| {
        std::io::Error::new(std::io::ErrorKind::InvalidData, "preview decode failed")
    })
}

#[cfg(test)]
fn decode_preview_lines(
    bytes: &[u8],
    max_lines: usize,
    boundary_lookahead: &[u8],
) -> Option<Vec<String>> {
    if bytes.is_empty() {
        return Some(Vec::new());
    }
    if looks_like_binary(bytes) {
        return None;
    }

    let mut candidates = preview_decoding_candidates(bytes, boundary_lookahead);
    candidates.push(decode_utf8_preview(bytes, boundary_lookahead));
    candidates.extend(preview_fallback_decoders(bytes));

    candidates
        .into_iter()
        .flatten()
        .map(|decoded| split_preview_lines(&decoded, max_lines))
        .next()
}

#[cfg(test)]
fn preview_decoding_candidates(bytes: &[u8], boundary_lookahead: &[u8]) -> Vec<Option<String>> {
    if bytes.starts_with(&[0xEF, 0xBB, 0xBF]) {
        return vec![decode_utf8_preview(&bytes[3..], boundary_lookahead)];
    }
    if bytes.starts_with(&[0xFF, 0xFE]) {
        return vec![decode_with_encoding(&bytes[2..], UTF_16LE)];
    }
    if bytes.starts_with(&[0xFE, 0xFF]) {
        return vec![decode_with_encoding(&bytes[2..], UTF_16BE)];
    }
    Vec::new()
}

#[cfg(test)]
fn preview_fallback_decoders(bytes: &[u8]) -> Vec<Option<String>> {
    #[cfg(windows)]
    {
        vec![
            decode_with_encoding(bytes, SHIFT_JIS),
            decode_with_encoding(bytes, EUC_JP),
            decode_with_encoding(bytes, WINDOWS_1252),
        ]
    }
    #[cfg(not(windows))]
    {
        vec![
            decode_with_encoding(bytes, SHIFT_JIS),
            decode_with_encoding(bytes, EUC_JP),
            decode_with_encoding(bytes, WINDOWS_1252),
        ]
    }
}

#[cfg(test)]
fn decode_utf8_preview(bytes: &[u8], boundary_lookahead: &[u8]) -> Option<String> {
    match std::str::from_utf8(bytes) {
        Ok(text) => Some(text.to_string()),
        // Regression guard: discard an incomplete boundary scalar only after the
        // lookahead proves that the following bytes complete valid UTF-8.
        Err(error)
            if valid_utf8_boundary_prefix_len(bytes, boundary_lookahead, &error).is_some() =>
        {
            std::str::from_utf8(&bytes[..error.valid_up_to()])
                .ok()
                .map(str::to_string)
        }
        Err(_) => None,
    }
}

#[cfg(test)]
fn valid_utf8_boundary_prefix_len(
    bytes: &[u8],
    boundary_lookahead: &[u8],
    error: &std::str::Utf8Error,
) -> Option<usize> {
    if error.error_len().is_some() {
        return None;
    }
    let valid_up_to = error.valid_up_to();
    let partial = bytes.get(valid_up_to..)?;
    let width: usize = match *partial.first()? {
        0xC2..=0xDF => 2,
        0xE0..=0xEF => 3,
        0xF0..=0xF4 => 4,
        _ => return None,
    };
    let missing = width.checked_sub(partial.len())?;
    if missing == 0 {
        return None;
    }
    let completion = boundary_lookahead.get(..missing)?;
    let mut scalar = [0u8; 4];
    scalar[..partial.len()].copy_from_slice(partial);
    scalar[partial.len()..width].copy_from_slice(completion);
    std::str::from_utf8(&scalar[..width]).ok()?;
    Some(valid_up_to)
}

#[cfg(test)]
fn decode_with_encoding(bytes: &[u8], encoding: &'static encoding_rs::Encoding) -> Option<String> {
    let (decoded, _used_encoding, had_errors) = encoding.decode(bytes);
    if had_errors {
        return None;
    }
    let text = decoded.into_owned();
    if contains_too_many_control_chars(&text) {
        return None;
    }
    Some(text)
}

#[cfg(test)]
fn split_preview_lines(decoded: &str, max_lines: usize) -> Vec<String> {
    decoded
        .lines()
        .take(max_lines)
        .map(|line| line.trim_end_matches('\r').to_string())
        .collect()
}

#[cfg(test)]
fn looks_like_binary(bytes: &[u8]) -> bool {
    bytes.contains(&0) && !has_utf16_bom(bytes)
}

#[cfg(test)]
fn has_utf16_bom(bytes: &[u8]) -> bool {
    bytes.starts_with(&[0xFF, 0xFE]) || bytes.starts_with(&[0xFE, 0xFF])
}

#[cfg(test)]
fn contains_too_many_control_chars(text: &str) -> bool {
    let mut suspicious = 0usize;
    let mut total = 0usize;
    for ch in text.chars() {
        if ch == '\n' || ch == '\r' || ch == '\t' {
            continue;
        }
        total = total.saturating_add(1);
        if ch.is_control() {
            suspicious = suspicious.saturating_add(1);
        }
    }
    total > 0 && suspicious.saturating_mul(20) > total
}

const DIRECTORY_SAMPLE_LIMIT: usize = 4096;

struct DirectorySample<T> {
    entries: Vec<T>,
    observed: usize,
    truncated: bool,
    partial_error: bool,
}

fn collect_directory_sample<T>(
    mut iter: impl Iterator<Item = std::io::Result<T>>,
    canceled: &(impl Fn() -> bool + ?Sized),
) -> Option<DirectorySample<T>> {
    let mut sample = DirectorySample {
        entries: Vec::new(),
        observed: 0,
        truncated: false,
        partial_error: false,
    };
    // One lookahead distinguishes an exact cap from a truncated directory.
    // Errors count toward the work budget too, including an all-error stream.
    for index in 0..=DIRECTORY_SAMPLE_LIMIT {
        if canceled() {
            return None;
        }
        let Some(entry) = iter.next() else {
            break;
        };
        if canceled() {
            return None;
        }
        if index == DIRECTORY_SAMPLE_LIMIT {
            sample.truncated = true;
        }
        match entry {
            Ok(entry) => {
                sample.observed += 1;
                if !sample.truncated {
                    sample.entries.push(entry);
                }
            }
            Err(_) => sample.partial_error = true,
        }
    }
    Some(sample)
}

fn build_directory_preview_text(
    path: &Path,
    normalized_path: &str,
    metadata: Option<&Metadata>,
    symlink_metadata: Option<&Metadata>,
    canceled: &(impl Fn() -> bool + ?Sized),
) -> Option<String> {
    const MAX_LINES: usize = 24;
    const MAX_NAME_CHARS: usize = 80;
    if canceled() {
        return None;
    }
    let header = build_entry_header(
        path,
        "Directory",
        normalized_path,
        metadata,
        symlink_metadata,
    );
    if canceled() {
        return None;
    }
    let Ok(iter) = std::fs::read_dir(path) else {
        return (!canceled()).then(|| format!("{header}\nChildren: <unavailable>"));
    };
    let mut sample = collect_directory_sample(iter, canceled)?;
    sample
        .entries
        .sort_by_cached_key(|e| e.file_name().to_string_lossy().to_ascii_lowercase());
    if canceled() {
        return None;
    }
    let limited = sample.truncated || sample.partial_error;
    if sample.observed == 0 && !limited {
        return Some(format!("{header}\nChildren: 0\n<empty>"));
    }
    let mut lines = Vec::new();
    for entry in sample.entries.iter().take(MAX_LINES) {
        if canceled() {
            return None;
        }
        let name = entry.file_name().to_string_lossy().to_string();
        let short = truncate_chars(&name, MAX_NAME_CHARS);
        let marker = match entry.file_type() {
            Ok(kind) if kind.is_dir() => "[D]",
            Ok(_) => "[F]",
            Err(_) => "[?]",
        };
        lines.push(format!("{marker} {short}"));
    }
    if canceled() {
        return None;
    }
    if sample.truncated {
        lines.push("... (listing truncated; alphabetized sample only)".into());
    } else if sample.observed > MAX_LINES {
        lines.push(format!("... ({} more)", sample.observed - MAX_LINES));
    }
    if sample.partial_error {
        lines.push("<partial listing: some children could not be read>".into());
    }
    let count = if limited {
        format!("at least {}", sample.observed)
    } else {
        sample.observed.to_string()
    };
    Some(format!(
        "{header}\nChildren: {count}\nScope: direct children only\n\n{}",
        lines.join("\n")
    ))
}

fn build_entry_header(
    path: &Path,
    kind: &str,
    normalized_path: &str,
    metadata: Option<&Metadata>,
    symlink_metadata: Option<&Metadata>,
) -> String {
    let mut lines = vec![format!("{kind}: {normalized_path}")];
    let is_symlink = symlink_metadata
        .map(|metadata| metadata.file_type().is_symlink())
        .unwrap_or(false);
    let metadata_prefix = if is_symlink { "Target " } else { "" };

    if let Some(metadata) = metadata {
        if kind == "File" && metadata.is_file() {
            lines.push(format!(
                "{metadata_prefix}Size: {}",
                format_file_size(metadata.len())
            ));
        }
        if let Some(created) = metadata.created().ok().and_then(format_system_time) {
            lines.push(format!("{metadata_prefix}Created: {created}"));
        }
        if let Some(updated) = metadata.modified().ok().and_then(format_system_time) {
            lines.push(format!("{metadata_prefix}Updated: {updated}"));
        }
    }

    if let Some(attribute_metadata) = symlink_metadata.or(metadata) {
        let attributes = metadata_attributes(attribute_metadata);
        if !attributes.is_empty() {
            lines.push(format!("Attributes: {}", attributes.join(", ")));
        }
    }

    if is_symlink {
        let target = std::fs::read_link(path)
            .map(|target| normalize_path_for_display(&target))
            .unwrap_or_else(|_| "<unavailable>".to_string());
        lines.push(format!("Target: {target}"));
    }

    lines.join("\n")
}

pub(crate) fn metadata_attributes(metadata: &Metadata) -> Vec<&'static str> {
    let mut attributes = Vec::new();
    if metadata.permissions().readonly() {
        attributes.push("Read-only");
    }
    #[cfg(windows)]
    {
        use std::os::windows::fs::MetadataExt;

        const FILE_ATTRIBUTE_HIDDEN: u32 = 0x0002;
        if metadata.file_attributes() & FILE_ATTRIBUTE_HIDDEN != 0 {
            attributes.push("Hidden");
        }
    }
    attributes
}

pub(crate) fn format_system_time(time: SystemTime) -> Option<String> {
    let seconds = match time.duration_since(UNIX_EPOCH) {
        Ok(duration) => i64::try_from(duration.as_secs()).ok()?,
        Err(error) => {
            let duration = error.duration();
            let seconds = i64::try_from(duration.as_secs()).ok()?;
            seconds
                .checked_neg()?
                .checked_sub(i64::from(duration.subsec_nanos() > 0))?
        }
    };
    let days = seconds.div_euclid(86_400);
    let day_seconds = seconds.rem_euclid(86_400);
    let (year, month, day) = civil_date_from_days(days);
    let hour = day_seconds / 3_600;
    let minute = day_seconds % 3_600 / 60;
    Some(format!(
        "{year:04}-{month:02}-{day:02} {hour:02}:{minute:02} UTC"
    ))
}

// Howard Hinnant's proleptic Gregorian conversion, kept dependency-free so
// preview formatting remains deterministic across supported platforms.
fn civil_date_from_days(days_since_unix_epoch: i64) -> (i64, u32, u32) {
    let z = days_since_unix_epoch + 719_468;
    let era = if z >= 0 { z } else { z - 146_096 } / 146_097;
    let doe = z - era * 146_097;
    let yoe = (doe - doe / 1_460 + doe / 36_524 - doe / 146_096) / 365;
    let year = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let day = doy - (153 * mp + 2) / 5 + 1;
    let month = mp + if mp < 10 { 3 } else { -9 };
    let year = year + if month <= 2 { 1 } else { 0 };
    (year, month as u32, day as u32)
}

fn truncate_chars(text: &str, max_chars: usize) -> String {
    if text.chars().count() <= max_chars {
        return text.to_string();
    }
    let keep = max_chars.saturating_sub(3);
    let mut out: String = text.chars().take(keep).collect();
    out.push_str("...");
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::path::PathBuf;
    use std::time::{Duration, SystemTime, UNIX_EPOCH};

    fn test_root(name: &str) -> PathBuf {
        let nonce = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock")
            .as_nanos();
        std::env::temp_dir().join(format!("fff-rs-ui-{name}-{nonce}"))
    }

    #[test]
    fn build_preview_text_for_directory() {
        let root = test_root("preview-dir");
        fs::create_dir_all(&root).expect("create dir");
        let child_dir = root.join("child");
        fs::create_dir_all(&child_dir).expect("create child dir");
        fs::write(root.join("a.txt"), "x").expect("write file");
        fs::write(child_dir.join("b.txt"), "y").expect("write nested file");

        let preview = build_preview_text(&root);
        assert!(preview.contains("Directory:"));
        assert!(preview.contains("Children:"));
        assert!(preview.contains("Updated:"));
        assert!(preview.contains("Scope: direct children only"));
        assert!(preview.contains("[D] child"));
        assert!(preview.contains("[F] a.txt"));
        assert!(!preview.contains("b.txt"));
        let _ = fs::remove_dir_all(&root);
    }

    #[test]
    fn build_preview_text_for_file_contains_content_without_action_policy() {
        let root = test_root("preview-file");
        fs::create_dir_all(&root).expect("create dir");

        #[cfg(not(target_os = "windows"))]
        {
            use std::os::unix::fs::PermissionsExt;

            let file = root.join("run.sh");
            fs::write(&file, "#!/bin/sh\necho hi\n").expect("write file");
            let mut perms = fs::metadata(&file).expect("metadata").permissions();
            perms.set_mode(0o755);
            fs::set_permissions(&file, perms).expect("set permissions");

            let preview = build_preview_text(&file);
            assert!(preview.contains("File:"));
            assert!(preview.contains("Size: 18 B"));
            assert!(preview.contains("hi"));
            assert!(!preview.contains("Action:"));
            assert!(!preview.contains("Execute"));
        }

        #[cfg(target_os = "windows")]
        {
            let file = root.join("tool.exe");
            fs::write(&file, "bin").expect("write file");

            let preview = build_preview_text(&file);
            assert!(preview.contains("File:"));
            assert!(preview.contains("Size: 3 B"));
            assert!(!preview.contains("Action:"));
            assert!(!preview.contains("Execute"));
        }

        let _ = fs::remove_dir_all(&root);
    }

    #[test]
    fn build_preview_text_for_file_includes_updated_metadata() {
        let root = test_root("preview-updated");
        fs::create_dir_all(&root).expect("create dir");
        let file = root.join("sample.txt");
        fs::write(&file, "hello\n").expect("write file");

        let preview = build_preview_text(&file);
        assert!(preview.contains("Updated:"), "{preview}");
        if fs::metadata(&file).expect("metadata").created().is_ok() {
            assert!(preview.contains("Created:"), "{preview}");
        }
        let _ = fs::remove_dir_all(&root);
    }

    #[test]
    fn build_preview_text_for_readonly_file_includes_attribute() {
        let root = test_root("preview-readonly");
        fs::create_dir_all(&root).expect("create dir");
        let file = root.join("readonly.txt");
        fs::write(&file, "hello\n").expect("write file");
        let mut permissions = fs::metadata(&file).expect("metadata").permissions();
        permissions.set_readonly(true);
        fs::set_permissions(&file, permissions).expect("set readonly");

        let preview = build_preview_text(&file);
        assert!(preview.contains("Attributes: Read-only"), "{preview}");
        let _ = fs::remove_dir_all(&root);
    }

    #[cfg(unix)]
    #[test]
    fn build_preview_text_for_symlink_includes_target() {
        use std::os::unix::fs::symlink;

        let root = test_root("preview-symlink");
        fs::create_dir_all(&root).expect("create dir");
        let target = root.join("target.txt");
        let link = root.join("link.txt");
        fs::write(&target, "hello\n").expect("write target");
        symlink("target.txt", &link).expect("create symlink");

        let preview = build_preview_text(&link);
        assert!(preview.contains("Target Size: 6 B"), "{preview}");
        assert!(preview.contains("Target Updated:"), "{preview}");
        if fs::metadata(&target)
            .expect("target metadata")
            .created()
            .is_ok()
        {
            assert!(preview.contains("Target Created:"), "{preview}");
        }
        assert!(preview.contains("Target: target.txt"), "{preview}");
        let _ = fs::remove_dir_all(&root);
    }

    #[test]
    fn format_system_time_uses_compact_utc_format() {
        let timestamp = UNIX_EPOCH + Duration::from_secs(1_783_020_900);

        assert_eq!(
            format_system_time(timestamp).as_deref(),
            Some("2026-07-02 19:35 UTC")
        );
    }

    #[test]
    fn format_system_time_supports_dates_before_unix_epoch() {
        let timestamp = UNIX_EPOCH - Duration::from_secs(60);

        assert_eq!(
            format_system_time(timestamp).as_deref(),
            Some("1969-12-31 23:59 UTC")
        );
    }

    #[cfg(windows)]
    #[test]
    fn build_preview_text_for_hidden_file_includes_attribute() {
        const FILE_ATTRIBUTE_HIDDEN: u32 = 0x0002;

        let root = test_root("preview-hidden");
        fs::create_dir_all(&root).expect("create dir");
        let file = root.join("hidden.txt");
        fs::write(&file, "hello\n").expect("write file");
        let original_attributes = windows_file_attributes(&file);
        set_windows_file_attributes(&file, original_attributes | FILE_ATTRIBUTE_HIDDEN);

        let preview = build_preview_text(&file);
        assert!(preview.contains("Attributes: Hidden"), "{preview}");

        set_windows_file_attributes(&file, original_attributes);
        let _ = fs::remove_dir_all(&root);
    }

    #[cfg(windows)]
    #[test]
    fn build_preview_text_for_windows_symlink_includes_target_metadata() {
        use std::os::windows::fs::symlink_file;

        let root = test_root("preview-windows-symlink");
        fs::create_dir_all(&root).expect("create dir");
        let target = root.join("target.txt");
        let link = root.join("link.txt");
        fs::write(&target, "hello\n").expect("write target");
        if let Err(error) = symlink_file("target.txt", &link) {
            eprintln!("skipping Windows symlink preview test: {error}");
            let _ = fs::remove_dir_all(&root);
            return;
        }

        let preview = build_preview_text(&link);
        assert!(preview.contains("Target Size: 6 B"), "{preview}");
        assert!(preview.contains("Target Updated:"), "{preview}");
        assert!(preview.contains("Target:"), "{preview}");
        let _ = fs::remove_dir_all(&root);
    }

    #[cfg(windows)]
    fn windows_file_attributes(path: &Path) -> u32 {
        use std::os::windows::fs::MetadataExt;

        fs::symlink_metadata(path)
            .expect("metadata")
            .file_attributes()
    }

    #[cfg(windows)]
    fn set_windows_file_attributes(path: &Path, attributes: u32) {
        use std::os::windows::ffi::OsStrExt;

        #[link(name = "kernel32")]
        unsafe extern "system" {
            fn SetFileAttributesW(path: *const u16, attributes: u32) -> i32;
        }

        let wide = path
            .as_os_str()
            .encode_wide()
            .chain(std::iter::once(0))
            .collect::<Vec<_>>();
        let result = unsafe { SetFileAttributesW(wide.as_ptr(), attributes) };
        assert_ne!(
            result,
            0,
            "SetFileAttributesW failed for {}",
            path.display()
        );
    }

    #[test]
    fn build_preview_text_formats_large_file_size() {
        let root = test_root("preview-size");
        fs::create_dir_all(&root).expect("create dir");
        let file = root.join("large.bin");
        fs::write(&file, vec![0u8; 1536]).expect("write file");

        let preview = build_preview_text(&file);
        assert!(preview.contains("Size: 1.5 KiB"), "{preview}");
        let _ = fs::remove_dir_all(&root);
    }

    #[test]
    fn build_preview_text_limits_lines() {
        let root = test_root("preview-limit-lines");
        fs::create_dir_all(&root).expect("create dir");
        let file = root.join("many-lines.txt");
        let body = (1..=40)
            .map(|i| format!("line{i}"))
            .collect::<Vec<_>>()
            .join("\n");
        fs::write(&file, format!("{body}\n")).expect("write file");

        let preview = build_preview_text(&file);
        assert!(preview.contains("line1"));
        assert!(preview.contains("line20"));
        assert!(!preview.contains("line21"));
        let _ = fs::remove_dir_all(&root);
    }

    #[test]
    fn regression_truncated_utf8_preview_keeps_the_valid_prefix_encoding() {
        const PREVIEW_MAX_BYTES: usize = 64 * 1024;
        let root = test_root("preview-truncated-utf8");
        fs::create_dir_all(&root).expect("create dir");
        let file = root.join("japanese.txt");
        let mut body = "日本語 ".as_bytes().to_vec();
        body.resize(PREVIEW_MAX_BYTES - 1, b'a');
        body.extend_from_slice("日\n".as_bytes());
        assert!(std::str::from_utf8(&body).is_ok());
        fs::write(&file, body).expect("write utf8 file");

        let preview = build_preview_text(&file);

        assert!(preview.contains("日本語"), "{preview}");
        assert!(!preview.contains("æ—¥"), "{preview}");
        let _ = fs::remove_dir_all(&root);
    }

    #[test]
    fn regression_utf8_boundary_requires_a_valid_continuation() {
        const PREVIEW_MAX_BYTES: usize = 64 * 1024;
        let root = test_root("preview-invalid-utf8-boundary");
        fs::create_dir_all(&root).expect("create dir");
        let file = root.join("legacy.txt");
        let mut body = vec![b'a'; PREVIEW_MAX_BYTES - 1];
        body.extend_from_slice(&[0xC2, b'A']);
        fs::write(&file, body).expect("write legacy file");

        let preview = read_preview_lines(&file, 1, PREVIEW_MAX_BYTES).expect("decode preview");

        assert_eq!(preview.len(), 1);
        assert_ne!(
            preview[0].chars().last(),
            Some('a'),
            "an invalid UTF-8 continuation must use a legacy fallback instead of dropping the lead byte"
        );
        let _ = fs::remove_dir_all(&root);
    }

    #[test]
    fn regression_utf8_boundary_accepts_one_to_three_missing_bytes() {
        for scalar in ["¢", "日", "😀"] {
            let encoded = scalar.as_bytes();
            let capped = [b'a', encoded[0]];
            let decoded = decode_preview_lines(&capped, 1, &encoded[1..])
                .expect("valid split UTF-8 boundary");
            assert_eq!(decoded, vec!["a"]);
        }
    }

    #[test]
    fn regression_exact_limit_utf8_preview_keeps_complete_final_codepoint() {
        const PREVIEW_MAX_BYTES: usize = 64 * 1024;
        let root = test_root("preview-exact-limit-utf8");
        fs::create_dir_all(&root).expect("create dir");
        let file = root.join("exact.txt");
        let mut body = "日本語 ".as_bytes().to_vec();
        body.resize(PREVIEW_MAX_BYTES - "日".len(), b'a');
        body.extend_from_slice("日".as_bytes());
        assert_eq!(body.len(), PREVIEW_MAX_BYTES);
        fs::write(&file, body).expect("write utf8 file");

        let preview = build_preview_text(&file);

        assert!(preview.contains("日本語"), "{preview}");
        let _ = fs::remove_dir_all(&root);
    }

    #[test]
    fn build_preview_text_decodes_shift_jis_script() {
        let root = test_root("preview-shift-jis");
        fs::create_dir_all(&root).expect("create dir");
        let file = root.join("script.vbs");
        let (encoded, _used_encoding, had_errors) = SHIFT_JIS.encode("msgbox \"こんにちは\"\r\n");
        assert!(!had_errors);
        fs::write(&file, encoded.as_ref()).expect("write shift_jis file");

        let preview = build_preview_text(&file);
        assert!(preview.contains("script.vbs"));
        assert!(preview.contains("こんにちは"));
        let _ = fs::remove_dir_all(&root);
    }

    #[test]
    fn build_preview_text_decodes_utf16le_with_bom() {
        let root = test_root("preview-utf16le");
        fs::create_dir_all(&root).expect("create dir");
        let file = root.join("script.ps1");
        let mut bytes = vec![0xFF, 0xFE];
        for unit in "Write-Host \"hello\"\r\n".encode_utf16() {
            bytes.extend_from_slice(&unit.to_le_bytes());
        }
        fs::write(&file, bytes).expect("write utf16 file");

        let preview = build_preview_text(&file);
        assert!(preview.contains("Write-Host \"hello\""), "{preview}");
        let _ = fs::remove_dir_all(&root);
    }

    #[test]
    fn build_preview_text_keeps_binary_files_unreadable() {
        let root = test_root("preview-binary");
        fs::create_dir_all(&root).expect("create dir");
        let file = root.join("blob.bin");
        fs::write(&file, [0x00, 0x01, 0x02, 0x03, 0x04]).expect("write binary file");

        let preview = build_preview_text(&file);
        assert!(preview.contains("<binary or unreadable file>"));
        let _ = fs::remove_dir_all(&root);
    }
}

#[cfg(test)]
mod bounded_directory_tests {
    use super::*;
    use std::cell::Cell;

    #[test]
    fn directory_preview_bounds_enumeration_and_reports_lower_bound() {
        for count in [4095, 4096, 4097, 1_000_000] {
            let calls = Cell::new(0);
            let iter = (0..count).map(|n| {
                calls.set(calls.get() + 1);
                Ok(n)
            });
            let sample = collect_directory_sample(iter, &|| false).unwrap();
            assert_eq!(sample.entries.len(), count.min(4096));
            assert_eq!(sample.observed, count.min(4097));
            assert_eq!(sample.truncated, count > 4096);
            assert_eq!(calls.get(), count.min(4097));
        }
    }

    #[test]
    fn directory_preview_cancels_between_entries_and_preserves_partial_errors() {
        let calls = Cell::new(0);
        let iter = (0..1_000_000).map(|n| {
            calls.set(calls.get() + 1);
            Ok(n)
        });
        assert!(collect_directory_sample(iter, &|| calls.get() >= 3).is_none());
        assert_eq!(calls.get(), 3);
        let sample = collect_directory_sample(
            [Ok(1), Err(std::io::Error::other("unreadable")), Ok(2)].into_iter(),
            &|| false,
        )
        .unwrap();
        assert_eq!(sample.entries, vec![1, 2]);
        assert_eq!(sample.observed, 2);
        assert!(sample.partial_error);
    }

    #[test]
    fn canceled_preview_does_not_probe_missing_path() {
        assert!(
            build_preview_text_with_kind_cancellable(Path::new("missing"), true, &|| true)
                .is_none()
        );
    }
}
