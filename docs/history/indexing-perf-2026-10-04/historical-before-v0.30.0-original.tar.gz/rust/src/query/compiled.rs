use super::{
    include_alternatives, parse_include_alternative, parse_query, split_anchor,
    token_uses_regex_syntax, QueryField, QueryTerm,
};
use crate::path_utils::{display_path_with_mode, normalize_windows_path};
use fuzzy_matcher::skim::SkimMatcherV2;
use fuzzy_matcher::FuzzyMatcher;
use regex::{Regex, RegexBuilder};
use std::collections::{BTreeMap, BTreeSet};
use std::path::Path;

#[cfg(test)]
thread_local! {
    static QUERY_COMPILE_COUNT: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
    static IGNORE_COMPILE_COUNT: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
}

#[cfg(test)]
pub(crate) fn reset_compile_counts() {
    QUERY_COMPILE_COUNT.set(0);
    IGNORE_COMPILE_COUNT.set(0);
}

#[cfg(test)]
pub(crate) fn query_compile_count() -> usize {
    QUERY_COMPILE_COUNT.get()
}

#[cfg(test)]
pub(crate) fn ignore_compile_count() -> usize {
    IGNORE_COMPILE_COUNT.get()
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct QueryOptions {
    pub use_regex: bool,
    pub ignore_case: bool,
}

#[derive(Debug, Clone, Copy)]
pub struct QueryScope<'a> {
    pub root: Option<&'a Path>,
    pub prefer_relative: bool,
    pub ignore_case: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EvidenceLevel {
    RankOnly,
    WithSpans,
}

#[derive(Debug, Clone, PartialEq)]
pub struct QueryEvaluation {
    pub score: f64,
    pub spans: Vec<usize>,
}

#[derive(Debug, Clone)]
pub struct PreparedCandidate {
    name: String,
    full: String,
    path: String,
    field_path_byte_start: usize,
    field_path_start: usize,
    dir: String,
    extension: String,
    extension_visible: String,
    visible: String,
    filename: String,
    filename_start: usize,
    directory_visible: String,
    extension_start: usize,
}

impl PreparedCandidate {
    fn from_path(path: &Path, scope: QueryScope<'_>, is_dir: Option<bool>) -> Self {
        let normalized_path = normalize_windows_path(path);
        let filename = normalized_path
            .file_name()
            .and_then(|value| value.to_str())
            .unwrap_or_default()
            .to_string();
        let visible_root = scope.root.unwrap_or_else(|| Path::new(""));
        let visible = display_path_with_mode(
            &normalized_path,
            visible_root,
            scope.prefer_relative && scope.root.is_some(),
        );
        let filename_start = visible
            .chars()
            .count()
            .saturating_sub(filename.chars().count());
        // Field matching is rooted independently of display mode; offsets alone depend
        // on the visible representation. Keep `path` below for legacy ignore scope.
        let field_path_byte_start = if scope.prefer_relative || scope.root.is_none() {
            0
        } else {
            let relative = display_path_with_mode(&normalized_path, visible_root, true);
            visible.len().saturating_sub(relative.len())
        };
        let field_path_start = visible[..field_path_byte_start].chars().count();
        let field_path_visible = &visible[field_path_byte_start..];
        let directory_visible = field_path_visible
            .rfind(['/', '\\'])
            .map_or_else(String::new, |index| field_path_visible[..index].to_string());
        let extension = if is_dir == Some(true) {
            String::new()
        } else {
            normalized_path
                .extension()
                .and_then(|value| value.to_str())
                .unwrap_or_default()
                .to_string()
        };
        let extension_start = visible
            .chars()
            .count()
            .saturating_sub(extension.chars().count());
        Self {
            name: normalize_text(&filename, scope.ignore_case),
            full: normalize_text(&visible, scope.ignore_case),
            path: normalize_field_path(&visible, scope.ignore_case),
            field_path_byte_start,
            field_path_start,
            dir: normalize_field_path(&directory_visible, scope.ignore_case),
            extension: normalize_text(&extension, scope.ignore_case),
            extension_visible: extension,
            visible,
            filename,
            filename_start,
            directory_visible,
            extension_start,
        }
    }

    pub fn visible_text(&self) -> &str {
        &self.visible
    }
}

#[derive(Debug, Clone)]
struct LiteralPattern {
    anchored_start: bool,
    anchored_end: bool,
    core: String,
    core_chars: Vec<char>,
    first_char: Option<char>,
    last_char: Option<char>,
}

#[derive(Debug, Clone)]
struct AlternativeSet {
    alternatives: Vec<LiteralPattern>,
}

#[derive(Debug, Clone)]
struct ExactTermMatcher {
    field: QueryField,
    set: AlternativeSet,
    required_unanchored_count: usize,
}

#[derive(Debug, Clone)]
struct IncludeAlternative {
    exact: bool,
    literal: LiteralPattern,
}

#[derive(Debug, Clone)]
enum IncludeMatcher {
    Regex(Regex),
    Alternatives(Vec<IncludeAlternative>),
}

#[derive(Debug, Clone)]
struct ScopedAlternativeSet {
    field: QueryField,
    set: AlternativeSet,
}

#[derive(Debug, Clone)]
struct ScopedIncludeMatcher {
    field: QueryField,
    matcher: IncludeMatcher,
}

#[derive(Debug, Clone)]
pub struct CompiledQuery {
    exact_terms: Vec<ExactTermMatcher>,
    exclude_terms: Vec<ScopedAlternativeSet>,
    include_terms: Vec<ScopedIncludeMatcher>,
    include_literal_bonus_terms: Vec<ScopedAlternativeSet>,
    include_exact_bonus_terms: Vec<(QueryField, LiteralPattern)>,
    score_query: String,
    ignore_case: bool,
    requires_file_kind: bool,
}

#[derive(Debug, Clone)]
pub struct CompiledIgnoreTerms {
    terms: Vec<AlternativeSet>,
}

impl CompiledIgnoreTerms {
    pub fn compile(terms: &[String], ignore_case: bool) -> Self {
        #[cfg(test)]
        IGNORE_COMPILE_COUNT.set(IGNORE_COMPILE_COUNT.get().saturating_add(1));
        Self {
            terms: terms
                .iter()
                .map(|term| compile_raw_alternative_set(term, ignore_case))
                .collect(),
        }
    }

    pub fn matches(&self, candidate: &PreparedCandidate) -> bool {
        self.terms
            .iter()
            .any(|term| matches_alternative_set(term, &candidate.name, &candidate.path))
    }

    pub fn matches_path(&self, path: &Path, scope: QueryScope<'_>) -> bool {
        self.matches(&PreparedCandidate::from_path(path, scope, None))
    }
}

impl CompiledQuery {
    pub fn compile(query: &str, options: QueryOptions) -> Result<Self, String> {
        #[cfg(test)]
        QUERY_COMPILE_COUNT.set(QUERY_COMPILE_COUNT.get().saturating_add(1));
        let spec = parse_query(query);
        if !spec.invalid_terms.is_empty() {
            return Err(format!(
                "field query requires a value: {}",
                spec.invalid_terms.join(", ")
            ));
        }
        let exact_terms = compile_exact_term_matchers(&spec.exact_terms, options.ignore_case);
        let exclude_terms = spec
            .exclude_terms
            .iter()
            .map(|term| ScopedAlternativeSet {
                field: term.field,
                set: compile_alternative_set(
                    &literal_field_value(term.field, &term.value),
                    options.ignore_case,
                ),
            })
            .collect::<Vec<_>>();
        let mut include_terms = Vec::with_capacity(spec.include_terms.len());
        let mut include_literal_bonus_terms = Vec::new();
        let mut include_exact_bonus_terms = Vec::new();
        for term in &spec.include_terms {
            include_terms.push(ScopedIncludeMatcher {
                field: term.field,
                matcher: compile_include_matcher(
                    &term.value,
                    term.field,
                    options.use_regex,
                    options.ignore_case,
                )?,
            });
            if !options.use_regex {
                let literal_bonus_set = compile_non_exact_alternative_set(
                    &literal_field_value(term.field, &term.value),
                    options.ignore_case,
                );
                if !literal_bonus_set.alternatives.is_empty() {
                    include_literal_bonus_terms.push(ScopedAlternativeSet {
                        field: term.field,
                        set: literal_bonus_set,
                    });
                }
                for candidate in include_alternatives(&term.value) {
                    let Some((exact, parsed)) = parse_include_alternative(candidate) else {
                        continue;
                    };
                    if !exact {
                        continue;
                    }
                    let (_, _, core) = split_anchor(&parsed);
                    if let Some(pattern) = compile_literal_pattern(
                        &literal_field_value(term.field, core),
                        options.ignore_case,
                    ) {
                        include_exact_bonus_terms.push((term.field, pattern));
                    }
                }
            }
        }

        Ok(Self {
            exact_terms,
            exclude_terms,
            include_terms,
            include_literal_bonus_terms,
            include_exact_bonus_terms,
            score_query: build_score_query(
                &spec.include_terms,
                &spec.exact_terms,
                options.ignore_case,
            ),
            ignore_case: options.ignore_case,
            requires_file_kind: spec
                .include_terms
                .iter()
                .chain(spec.exact_terms.iter())
                .chain(spec.exclude_terms.iter())
                .any(|term| term.field == QueryField::Ext),
        })
    }

    pub fn evaluate(
        &self,
        candidate: &PreparedCandidate,
        evidence: EvidenceLevel,
    ) -> Option<QueryEvaluation> {
        self.evaluate_with_matcher(candidate, evidence, &SkimMatcherV2::default())
    }

    pub fn prepare_candidate(
        &self,
        path: &Path,
        root: Option<&Path>,
        prefer_relative: bool,
    ) -> PreparedCandidate {
        PreparedCandidate::from_path(
            path,
            QueryScope {
                root,
                prefer_relative,
                ignore_case: self.ignore_case,
            },
            None,
        )
    }

    pub fn prepare_candidate_with_kind(
        &self,
        path: &Path,
        root: Option<&Path>,
        prefer_relative: bool,
        is_dir: Option<bool>,
    ) -> PreparedCandidate {
        PreparedCandidate::from_path(
            path,
            QueryScope {
                root,
                prefer_relative,
                ignore_case: self.ignore_case,
            },
            is_dir,
        )
    }

    // Regression guard: public visibility/highlight adapters intentionally project positive
    // clauses only. Do not replace these helpers with full evaluate() without updating the
    // paired tc_155_regression_* tests and the public compatibility contract.
    pub(crate) fn matches_positive_projection(&self, candidate: &PreparedCandidate) -> bool {
        matches_positive_terms(self, candidate)
    }

    pub(crate) fn positive_projection_spans(&self, candidate: &PreparedCandidate) -> Vec<usize> {
        collect_spans(self, candidate)
    }

    pub(crate) fn evaluate_with_matcher(
        &self,
        candidate: &PreparedCandidate,
        evidence: EvidenceLevel,
        matcher: &SkimMatcherV2,
    ) -> Option<QueryEvaluation> {
        if !matches_compiled_query(self, candidate) {
            return None;
        }
        let spans = match evidence {
            EvidenceLevel::RankOnly => Vec::new(),
            EvidenceLevel::WithSpans => collect_spans(self, candidate),
        };
        Some(QueryEvaluation {
            score: score_entry(matcher, self, candidate),
            spans,
        })
    }

    pub(crate) fn evaluate_unknown_kind_with_matcher<F>(
        &self,
        path: &Path,
        root: Option<&Path>,
        prefer_relative: bool,
        evidence: EvidenceLevel,
        matcher: &SkimMatcherV2,
        resolve_is_dir: F,
    ) -> Option<QueryEvaluation>
    where
        F: FnOnce() -> bool,
    {
        let mut candidate =
            self.prepare_candidate_with_kind(path, root, prefer_relative, Some(false));
        let file_evaluation = self.evaluate_with_matcher(&candidate, evidence, matcher);
        if candidate.extension.is_empty() {
            return file_evaluation;
        }

        candidate.extension.clear();
        candidate.extension_visible.clear();
        let directory_evaluation = self.evaluate_with_matcher(&candidate, evidence, matcher);
        if file_evaluation == directory_evaluation {
            return file_evaluation;
        }

        if resolve_is_dir() {
            directory_evaluation
        } else {
            file_evaluation
        }
    }

    pub(crate) fn requires_file_kind(&self) -> bool {
        self.requires_file_kind
    }
}

fn normalize_text(text: &str, ignore_case: bool) -> String {
    if ignore_case {
        text.to_ascii_lowercase()
    } else {
        text.to_string()
    }
}

fn normalize_field_path(text: &str, ignore_case: bool) -> String {
    normalize_text(&text.replace('\\', "/"), ignore_case)
}

fn literal_field_value(field: QueryField, value: &str) -> String {
    if matches!(field, QueryField::Path | QueryField::Dir) {
        value.replace('\\', "/")
    } else {
        value.to_string()
    }
}

// Only query-level pipes separate alternatives. Regex groups, nested character
// classes and escaped pipes retain their regex meaning. An exact alternative's
// contents are literal, so its brackets and parentheses cannot hide separators.
fn regex_alternatives(term: &str) -> Vec<&str> {
    let mut alternatives = Vec::new();
    let mut start = 0;
    let mut groups = 0usize;
    // Class position: 0 = opening, 1 = after negation, 2 = after an item.
    let mut classes = Vec::<u8>::new();
    let mut escaped = false;
    for (index, ch) in term.char_indices() {
        let exact = term[start..].starts_with('\'') || term[start..].starts_with("^'");
        if exact {
            if ch == '|' {
                alternatives.push(&term[start..index]);
                start = index + 1;
            }
            continue;
        }
        if escaped {
            escaped = false;
            if let Some(first) = classes.last_mut() {
                *first = 2;
            }
            continue;
        }
        if ch == '\\' {
            escaped = true;
            continue;
        }
        if let Some(first) = classes.last_mut() {
            match ch {
                ']' if *first == 2 => {
                    classes.pop();
                }
                '[' => {
                    *first = 2;
                    classes.push(0);
                }
                '^' if *first == 0 => *first = 1,
                _ => *first = 2,
            }
            continue;
        }
        match ch {
            '[' => classes.push(0),
            '(' => groups += 1,
            ')' => groups = groups.saturating_sub(1),
            '|' if groups == 0 => {
                alternatives.push(&term[start..index]);
                start = index + 1;
            }
            _ => {}
        }
    }
    alternatives.push(&term[start..]);
    alternatives
}

fn normalize_regex_alternatives(term: &str, field: QueryField, ignore_case: bool) -> String {
    regex_alternatives(term)
        .into_iter()
        .filter_map(parse_include_alternative)
        .filter_map(|(exact, value)| {
            if !exact {
                return Some(value);
            }
            let value = literal_field_value(field, &value);
            let (start, end, core) = split_anchor(&value);
            if core.is_empty() {
                return None;
            }
            // Literal query clauses have ASCII-only case folding and strict anchors.
            // Keep adjacent regex flags from changing that contract.
            let literal = core
                .chars()
                .map(|ch| {
                    if ignore_case && ch.is_ascii_alphabetic() {
                        format!("[{}{}]", ch.to_ascii_lowercase(), ch.to_ascii_uppercase())
                    } else {
                        regex::escape(&ch.to_string())
                    }
                })
                .collect::<String>();
            Some(format!(
                "(?-ix:{}{}{})",
                if start { r"\A" } else { "" },
                literal,
                if end { r"\z" } else { "" }
            ))
        })
        .collect::<Vec<_>>()
        .join("|")
}

fn compile_literal_pattern(term: &str, ignore_case: bool) -> Option<LiteralPattern> {
    let normalized = normalize_text(term, ignore_case);
    let (anchored_start, anchored_end, core) = split_anchor(&normalized);
    if core.is_empty() {
        return None;
    }
    let core = core.to_string();
    let core_chars = core.chars().collect::<Vec<_>>();
    Some(LiteralPattern {
        anchored_start,
        anchored_end,
        first_char: core_chars.first().copied(),
        last_char: core_chars.last().copied(),
        core,
        core_chars,
    })
}

fn compile_alternative_set(term: &str, ignore_case: bool) -> AlternativeSet {
    let normalized = normalize_text(term, ignore_case);
    AlternativeSet {
        alternatives: include_alternatives(&normalized)
            .into_iter()
            .filter_map(|candidate| parse_include_alternative(candidate).map(|(_, value)| value))
            .filter_map(|candidate| compile_literal_pattern(&candidate, ignore_case))
            .collect(),
    }
}

fn compile_raw_alternative_set(term: &str, ignore_case: bool) -> AlternativeSet {
    let normalized = normalize_field_path(term, ignore_case);
    AlternativeSet {
        alternatives: include_alternatives(&normalized)
            .into_iter()
            .filter_map(|candidate| compile_literal_pattern(candidate, ignore_case))
            .collect(),
    }
}

fn compile_exact_term_matchers(terms: &[QueryTerm], ignore_case: bool) -> Vec<ExactTermMatcher> {
    let mut counts = BTreeMap::<QueryTerm, usize>::new();
    for term in terms {
        *counts.entry(term.clone()).or_default() += 1;
    }
    counts
        .into_iter()
        .map(|(term, count)| {
            let set =
                compile_alternative_set(&literal_field_value(term.field, &term.value), ignore_case);
            let unanchored = set
                .alternatives
                .first()
                .is_some_and(|pattern| !pattern.anchored_start && !pattern.anchored_end);
            ExactTermMatcher {
                field: term.field,
                set,
                required_unanchored_count: if unanchored { count } else { 1 },
            }
        })
        .collect()
}

fn compile_non_exact_alternative_set(term: &str, ignore_case: bool) -> AlternativeSet {
    let normalized = normalize_text(term, ignore_case);
    AlternativeSet {
        alternatives: include_alternatives(&normalized)
            .into_iter()
            .filter_map(parse_include_alternative)
            .filter_map(|(exact, candidate)| {
                (!exact)
                    .then(|| compile_literal_pattern(&candidate, ignore_case))
                    .flatten()
            })
            .collect(),
    }
}

fn compile_include_matcher(
    term: &str,
    field: QueryField,
    use_regex: bool,
    ignore_case: bool,
) -> Result<IncludeMatcher, String> {
    if use_regex && token_uses_regex_syntax(term) {
        let pattern = normalize_regex_alternatives(term, field, ignore_case);
        return RegexBuilder::new(&pattern)
            .case_insensitive(ignore_case)
            .build()
            .map(IncludeMatcher::Regex)
            .map_err(|error| format!("invalid regex '{term}': {error}"));
    }
    Ok(IncludeMatcher::Alternatives(
        include_alternatives(term)
            .into_iter()
            .filter_map(parse_include_alternative)
            .filter_map(|(exact, candidate)| {
                compile_literal_pattern(&literal_field_value(field, &candidate), ignore_case)
                    .map(|literal| IncludeAlternative { exact, literal })
            })
            .collect(),
    ))
}

fn build_score_query(
    include_terms: &[QueryTerm],
    exact_terms: &[QueryTerm],
    ignore_case: bool,
) -> String {
    let mut score_query = include_terms
        .iter()
        .flat_map(|term| include_alternatives(&term.value))
        .filter_map(|term| {
            let (_, candidate) = parse_include_alternative(term)?;
            let (_, _, core) = split_anchor(&candidate);
            (!core.is_empty()).then_some(normalize_text(core, ignore_case))
        })
        .collect::<Vec<_>>()
        .join(" ");
    if score_query.is_empty() {
        if let Some(first_exact) = exact_terms.first() {
            score_query = normalize_text(&first_exact.value, ignore_case);
        }
    }
    score_query
}

fn is_subsequence(query: &[char], text: &str) -> bool {
    let mut qi = 0usize;
    for ch in text.chars() {
        if qi < query.len() && ch == query[qi] {
            qi += 1;
        }
    }
    qi == query.len()
}

fn matches_anchored_literal(pattern: &LiteralPattern, text: &str) -> bool {
    if pattern.anchored_start && pattern.anchored_end {
        text == pattern.core
    } else if pattern.anchored_start {
        text.starts_with(&pattern.core)
    } else if pattern.anchored_end {
        text.ends_with(&pattern.core)
    } else {
        text.contains(&pattern.core)
    }
}

fn matches_alternative_set(set: &AlternativeSet, name: &str, full: &str) -> bool {
    set.alternatives.iter().any(|pattern| {
        matches_anchored_literal(pattern, name) || matches_anchored_literal(pattern, full)
    })
}

fn candidate_field_texts(candidate: &PreparedCandidate, field: QueryField) -> (&str, &str) {
    match field {
        QueryField::Any => (&candidate.name, &candidate.full),
        QueryField::Name => (&candidate.name, &candidate.name),
        QueryField::Path => {
            let path = &candidate.path[candidate.field_path_byte_start..];
            (path, path)
        }
        QueryField::Dir => (&candidate.dir, &candidate.dir),
        QueryField::Ext => (&candidate.extension, &candidate.extension),
    }
}

fn literal_occurrence_count(text: &str, needle: &str) -> usize {
    if needle.is_empty() {
        return 0;
    }
    let mut count = 0;
    let mut search_from = 0;
    while let Some(offset) = text[search_from..].find(needle) {
        count += 1;
        search_from += offset + needle.len();
    }
    count
}

fn matches_exact_term(term: &ExactTermMatcher, candidate: &PreparedCandidate) -> bool {
    let (name, full) = candidate_field_texts(candidate, term.field);
    if term.required_unanchored_count <= 1 {
        return matches_alternative_set(&term.set, name, full);
    }
    term.set.alternatives.iter().any(|pattern| {
        literal_occurrence_count(name, &pattern.core)
            .max(literal_occurrence_count(full, &pattern.core))
            >= term.required_unanchored_count
    })
}

fn matches_include_literal(pattern: &LiteralPattern, name: &str, full: &str) -> bool {
    if pattern.anchored_start
        && !matches!(pattern.first_char, Some(ch) if name.starts_with(ch) || full.starts_with(ch))
    {
        return false;
    }
    if pattern.anchored_end
        && !matches!(pattern.last_char, Some(ch) if name.ends_with(ch) || full.ends_with(ch))
    {
        return false;
    }
    name.contains(&pattern.core)
        || is_subsequence(&pattern.core_chars, name)
        || full.contains(&pattern.core)
        || is_subsequence(&pattern.core_chars, full)
}

fn matches_include_matcher(matcher: &ScopedIncludeMatcher, candidate: &PreparedCandidate) -> bool {
    let (name, full) = candidate_field_texts(candidate, matcher.field);
    match &matcher.matcher {
        IncludeMatcher::Regex(regex) => regex.is_match(name) || regex.is_match(full),
        IncludeMatcher::Alternatives(alternatives) => alternatives.iter().any(|alternative| {
            if alternative.exact {
                matches_anchored_literal(&alternative.literal, name)
                    || matches_anchored_literal(&alternative.literal, full)
            } else {
                matches_include_literal(&alternative.literal, name, full)
            }
        }),
    }
}

fn matches_compiled_query(compiled: &CompiledQuery, candidate: &PreparedCandidate) -> bool {
    !compiled.exclude_terms.iter().any(|term| {
        let (name, full) = candidate_field_texts(candidate, term.field);
        matches_alternative_set(&term.set, name, full)
    }) && matches_positive_terms(compiled, candidate)
}

fn matches_positive_terms(compiled: &CompiledQuery, candidate: &PreparedCandidate) -> bool {
    compiled
        .exact_terms
        .iter()
        .all(|term| matches_exact_term(term, candidate))
        && compiled
            .include_terms
            .iter()
            .all(|matcher| matches_include_matcher(matcher, candidate))
}

fn fallback_score(query: &str, text: &str) -> f64 {
    if query.is_empty() {
        return 0.0;
    }
    let mut score = 0.0;
    if text.contains(query) {
        score += 25.0;
    }
    if text.starts_with(query) {
        score += 30.0;
    }
    score + query.len().min(text.len()) as f64
}

fn bonus_for_alternative_set(set: &ScopedAlternativeSet, candidate: &PreparedCandidate) -> f64 {
    let (name, full) = candidate_field_texts(candidate, set.field);
    let mut bonus = 0.0;
    if set.set.alternatives.iter().any(|pattern| {
        matches_anchored_literal(pattern, name) || matches_anchored_literal(pattern, full)
    }) {
        bonus += 150.0;
    }
    if set
        .set
        .alternatives
        .iter()
        .any(|pattern| name == pattern.core || full == pattern.core)
    {
        bonus += 150.0;
    }
    bonus
}

fn score_entry(
    matcher: &SkimMatcherV2,
    compiled: &CompiledQuery,
    candidate: &PreparedCandidate,
) -> f64 {
    let mut score = if compiled.score_query.is_empty() {
        0.0
    } else {
        matcher
            .fuzzy_match(&candidate.full, &compiled.score_query)
            .map(|value| value as f64)
            .unwrap_or_else(|| fallback_score(&compiled.score_query, &candidate.full))
    };
    if !compiled.score_query.is_empty() && candidate.name == compiled.score_query {
        score += 1000.0;
    } else if !compiled.score_query.is_empty() && candidate.full == compiled.score_query {
        score += 900.0;
    }
    for term in &compiled.exact_terms {
        if matches_exact_term(term, candidate) {
            score += 800.0;
        }
    }
    for term in &compiled.include_literal_bonus_terms {
        score += bonus_for_alternative_set(term, candidate);
    }
    for (field, pattern) in &compiled.include_exact_bonus_terms {
        let (name, full) = candidate_field_texts(candidate, *field);
        if matches_anchored_literal(pattern, name) || matches_anchored_literal(pattern, full) {
            score += 300.0;
            if name == pattern.core {
                score += 300.0;
            }
        }
    }
    score
}

fn chars_equal(left: char, right: char, ignore_case: bool) -> bool {
    if ignore_case && left.is_ascii() && right.is_ascii() {
        left.eq_ignore_ascii_case(&right)
    } else {
        left == right
    }
}

fn exact_positions(text: &str, pattern: &LiteralPattern, ignore_case: bool) -> Vec<usize> {
    let text_chars = text.chars().collect::<Vec<_>>();
    let core_chars = pattern.core.chars().collect::<Vec<_>>();
    if core_chars.is_empty() || core_chars.len() > text_chars.len() {
        return Vec::new();
    }
    for start in 0..=text_chars.len() - core_chars.len() {
        if !core_chars
            .iter()
            .enumerate()
            .all(|(offset, query)| chars_equal(text_chars[start + offset], *query, ignore_case))
        {
            continue;
        }
        if pattern.anchored_start && start != 0 {
            continue;
        }
        if pattern.anchored_end && start + core_chars.len() != text_chars.len() {
            continue;
        }
        return (start..start + core_chars.len()).collect();
    }
    Vec::new()
}

fn fuzzy_positions(text: &str, pattern: &LiteralPattern, ignore_case: bool) -> Vec<usize> {
    if pattern.anchored_start
        && !matches!(pattern.core.chars().next(), Some(first) if text.chars().next().is_some_and(|value| chars_equal(value, first, ignore_case)))
    {
        return Vec::new();
    }
    if pattern.anchored_end
        && !matches!(pattern.core.chars().last(), Some(last) if text.chars().last().is_some_and(|value| chars_equal(value, last, ignore_case)))
    {
        return Vec::new();
    }
    let text_chars = text.chars().collect::<Vec<_>>();
    let query_chars = pattern.core.chars().collect::<Vec<_>>();
    if query_chars.len() <= text_chars.len() {
        for start in 0..=text_chars.len() - query_chars.len() {
            if query_chars
                .iter()
                .enumerate()
                .all(|(offset, query)| chars_equal(text_chars[start + offset], *query, ignore_case))
            {
                return (start..start + query_chars.len()).collect();
            }
        }
    }
    let mut positions = Vec::with_capacity(query_chars.len());
    let mut query_index = 0usize;
    for (index, value) in text_chars.iter().enumerate() {
        if query_index < query_chars.len()
            && chars_equal(*value, query_chars[query_index], ignore_case)
        {
            positions.push(index);
            query_index += 1;
        }
    }
    if query_index == query_chars.len() {
        positions
    } else {
        Vec::new()
    }
}

fn regex_positions(text: &str, regex: &Regex) -> Vec<usize> {
    let mut positions = Vec::new();
    for matched in regex.find_iter(text) {
        if matched.start() == matched.end() {
            continue;
        }
        let start = text[..matched.start()].chars().count();
        let len = text[matched.start()..matched.end()].chars().count();
        positions.extend(start..start + len);
    }
    positions
}

fn add_pattern_positions(
    spans: &mut BTreeSet<usize>,
    candidate: &PreparedCandidate,
    field: QueryField,
    pattern: &LiteralPattern,
    exact: bool,
    ignore_case: bool,
) {
    if field != QueryField::Any {
        let (text, offset) = match field {
            QueryField::Any => unreachable!(),
            QueryField::Name => (candidate.filename.clone(), candidate.filename_start),
            QueryField::Path => (
                candidate.visible[candidate.field_path_byte_start..].replace('\\', "/"),
                candidate.field_path_start,
            ),
            QueryField::Dir => (
                candidate.directory_visible.replace('\\', "/"),
                candidate.field_path_start,
            ),
            QueryField::Ext => (
                candidate.extension_visible.clone(),
                candidate.extension_start,
            ),
        };
        let hits = if exact {
            exact_positions(&text, pattern, ignore_case)
        } else {
            fuzzy_positions(&text, pattern, ignore_case)
        };
        spans.extend(hits.into_iter().map(|position| offset + position));
        return;
    }
    let filename_hits = if exact {
        exact_positions(&candidate.filename, pattern, ignore_case)
    } else {
        fuzzy_positions(&candidate.filename, pattern, ignore_case)
    };
    if !filename_hits.is_empty() {
        spans.extend(
            filename_hits
                .into_iter()
                .map(|position| candidate.filename_start + position),
        );
        return;
    }
    let visible_hits = if exact {
        exact_positions(&candidate.visible, pattern, ignore_case)
    } else {
        fuzzy_positions(&candidate.visible, pattern, ignore_case)
    };
    spans.extend(visible_hits);
}

fn collect_spans(compiled: &CompiledQuery, candidate: &PreparedCandidate) -> Vec<usize> {
    let mut spans = BTreeSet::new();
    for term in &compiled.exact_terms {
        let (name, full) = candidate_field_texts(candidate, term.field);
        if let Some(pattern) = term.set.alternatives.iter().find(|pattern| {
            matches_anchored_literal(pattern, name) || matches_anchored_literal(pattern, full)
        }) {
            add_pattern_positions(
                &mut spans,
                candidate,
                term.field,
                pattern,
                true,
                compiled.ignore_case,
            );
        }
    }
    for matcher in &compiled.include_terms {
        let (name, full) = candidate_field_texts(candidate, matcher.field);
        match &matcher.matcher {
            IncludeMatcher::Regex(regex) => {
                if matcher.field == QueryField::Any {
                    let filename_hits = regex_positions(&candidate.filename, regex);
                    if filename_hits.is_empty() {
                        spans.extend(regex_positions(&candidate.visible, regex));
                    } else {
                        spans.extend(
                            filename_hits
                                .into_iter()
                                .map(|position| candidate.filename_start + position),
                        );
                    }
                } else {
                    let (text, offset) = match matcher.field {
                        QueryField::Any => unreachable!(),
                        QueryField::Name => (candidate.filename.clone(), candidate.filename_start),
                        QueryField::Path => (
                            candidate.visible[candidate.field_path_byte_start..].replace('\\', "/"),
                            candidate.field_path_start,
                        ),
                        QueryField::Dir => (
                            candidate.directory_visible.replace('\\', "/"),
                            candidate.field_path_start,
                        ),
                        QueryField::Ext => (
                            candidate.extension_visible.clone(),
                            candidate.extension_start,
                        ),
                    };
                    spans.extend(
                        regex_positions(&text, regex)
                            .into_iter()
                            .map(|position| offset + position),
                    );
                }
            }
            IncludeMatcher::Alternatives(alternatives) => {
                if let Some(alternative) = alternatives.iter().find(|alternative| {
                    if alternative.exact {
                        matches_anchored_literal(&alternative.literal, name)
                            || matches_anchored_literal(&alternative.literal, full)
                    } else {
                        matches_include_literal(&alternative.literal, name, full)
                    }
                }) {
                    add_pattern_positions(
                        &mut spans,
                        candidate,
                        matcher.field,
                        &alternative.literal,
                        alternative.exact,
                        compiled.ignore_case,
                    );
                }
            }
        }
    }
    spans.into_iter().collect()
}
