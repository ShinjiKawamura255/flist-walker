use super::events::{Event, IndexData, TerminalOutcome, WorkerOutcome};
use super::invariants::{validate, SemanticSnapshot, TabSemanticSnapshot};
use crate::app::tests::*;
use crate::app::worker::channel::BoundedReceiver;
use std::collections::hash_map::DefaultHasher;
use std::hash::{Hash, Hasher};

// Stateful endurance validates response ownership across event boundaries, not frame timing.
// Process every directly available response without a wall-clock cutoff; asynchronous reclaimer
// deferrals are covered by routed-owner sets and the bounded quiescence deadline below.
const ENDURANCE_RESPONSE_DRAIN_BUDGET: Duration = Duration::MAX;
const ENDURANCE_QUIESCENCE_TIMEOUT: Duration = Duration::from_secs(2);

pub(super) struct StatefulHarness {
    app: FlistWalkerApp,
    base: PathBuf,
    roots: Vec<PathBuf>,
    index_requests: BoundedReceiver<IndexRequest>,
    index_responses: mpsc::Sender<IndexResponse>,
    pending_indexes: VecDeque<IndexRequest>,
    submitted_index_responses: VecDeque<u64>,
    search_requests: mpsc::Receiver<SearchRequest>,
    search_responses: mpsc::Sender<SearchResponse>,
    pending_searches: VecDeque<SearchRequest>,
    preview_requests: mpsc::Receiver<PreviewRequest>,
    preview_responses: mpsc::Sender<PreviewResponse>,
    pending_previews: VecDeque<PreviewRequest>,
    action_requests: BoundedReceiver<ActionRequest>,
    action_responses: mpsc::Sender<ActionResponse>,
    pending_actions: VecDeque<ActionRequest>,
    sort_requests: mpsc::Receiver<SortMetadataRequest>,
    sort_responses: mpsc::Sender<SortMetadataResponse>,
    pending_sorts: VecDeque<SortMetadataRequest>,
    filelist_requests: mpsc::Receiver<FileListRequest>,
    filelist_responses: mpsc::Sender<FileListResponse>,
    pending_filelists: VecDeque<FileListRequest>,
    next_stale_request_id: u64,
    next_index_entry_id: u64,
    replay_steps: usize,
}

impl StatefulHarness {
    pub(super) fn new(label: &str) -> Self {
        let base = test_root(label);
        let roots = (0..3)
            .map(|index| base.join(format!("root-{index}")))
            .collect::<Vec<_>>();
        for (root_index, root) in roots.iter().enumerate() {
            fs::create_dir_all(root).expect("create endurance root");
            for file_index in 0..3 {
                fs::write(
                    root.join(format!("root-{root_index}-file-{file_index}.txt")),
                    format!("fixture {root_index}/{file_index}"),
                )
                .expect("write endurance fixture");
            }
            fs::write(root.join("fixture.txt"), format!("fixture {root_index}"))
                .expect("write shared endurance fixture");
        }

        let mut app = FlistWalkerApp::new(roots[0].clone(), 20, String::new());
        reset_index_request_state_for_test(&mut app);

        let (index_tx, index_requests) = bounded_request_channel::<IndexRequest>(8);
        let (index_responses, index_rx) = mpsc::channel::<IndexResponse>();
        app.shell.indexing.tx = index_tx;
        app.shell.indexing.rx = index_rx;

        let (search_tx, search_requests) = mpsc::channel::<SearchRequest>();
        let (search_responses, search_rx) = mpsc::channel::<SearchResponse>();
        app.shell.search = SearchCoordinator::new(search_tx, search_rx);

        let (preview_tx, preview_requests) = mpsc::channel::<PreviewRequest>();
        let (preview_responses, preview_rx) = mpsc::channel::<PreviewResponse>();
        app.shell.worker_bus.preview.tx = preview_tx;
        app.shell.worker_bus.preview.worker_inflight_request_id = None;
        app.shell.worker_bus.preview.rx = preview_rx;
        app.shell.worker_bus.preview.clear_request();

        let (action_tx, action_requests) = bounded_request_channel::<ActionRequest>(8);
        let (action_responses, action_rx) = mpsc::channel::<ActionResponse>();
        app.shell.worker_bus.action.tx = action_tx;
        app.shell.worker_bus.action.rx = action_rx;
        app.shell.worker_bus.action.clear_request();

        let (sort_tx, sort_requests) = mpsc::channel::<SortMetadataRequest>();
        let (sort_responses, sort_rx) = mpsc::channel::<SortMetadataResponse>();
        app.shell.worker_bus.sort.tx = sort_tx;
        app.shell.worker_bus.sort.rx = sort_rx;
        app.shell.worker_bus.sort.clear_request();

        let (filelist_tx, filelist_requests) = mpsc::channel::<FileListRequest>();
        let (filelist_responses, filelist_rx) = mpsc::channel::<FileListResponse>();
        app.shell.worker_bus.filelist.tx = filelist_tx;
        app.shell.worker_bus.filelist.rx = filelist_rx;
        app.sync_active_tab_state();

        Self {
            app,
            base,
            roots,
            index_requests,
            index_responses,
            pending_indexes: VecDeque::new(),
            submitted_index_responses: VecDeque::new(),
            search_requests,
            search_responses,
            pending_searches: VecDeque::new(),
            preview_requests,
            preview_responses,
            pending_previews: VecDeque::new(),
            action_requests,
            action_responses,
            pending_actions: VecDeque::new(),
            sort_requests,
            sort_responses,
            pending_sorts: VecDeque::new(),
            filelist_requests,
            filelist_responses,
            pending_filelists: VecDeque::new(),
            next_stale_request_id: 1_000_000,
            next_index_entry_id: 1,
            replay_steps: 0,
        }
    }

    pub(super) fn run(&mut self, seed: u64, events: &[Event]) {
        self.replay_steps = events.len();
        self.capture_requests();
        self.assert_invariants(seed, 0, &Event::RefreshIndex);
        for (step, event) in events.iter().enumerate() {
            let before = self.snapshot();
            let response_owners = self.response_owners(event);
            self.apply(event);
            self.capture_requests();
            let after = self.snapshot();
            if let Some(mut owners) = response_owners {
                // Completing one response can admit a previously queued request. Compare
                // request identity as well as tab identity so replacing an old route with
                // a new route for the same tab still proves the downstream transfer.
                owners.extend(newly_routed_tab_ids(
                    &before.routed_requests,
                    &after.routed_requests,
                ));
                // A response can admit a queued index request whose resource reservation
                // deterministically evicts one background snapshot. Treat only the tab
                // whose lifecycle actually crossed into Evicted as a downstream owner.
                owners.extend(newly_evicted_tab_ids(&before.tabs, &after.tabs));
                self.assert_other_tab_content_unchanged(
                    &before,
                    &after,
                    &owners,
                    seed,
                    step + 1,
                    event,
                );
            }
            self.assert_invariants(seed, step + 1, event);
        }
    }

    pub(super) fn pending_worker_request_counts(&mut self) -> (usize, usize, usize, usize) {
        self.capture_requests();
        (
            self.pending_previews.len(),
            self.pending_actions.len(),
            self.pending_sorts.len(),
            self.pending_filelists.len(),
        )
    }

    pub(super) fn quiesce(&mut self, seed: u64) {
        let deadline = Instant::now() + ENDURANCE_QUIESCENCE_TIMEOUT;
        let mut step = 0usize;
        while Instant::now() < deadline {
            self.capture_requests();
            if let Some(request) = self.pending_indexes.pop_front() {
                self.respond_to_index(request, TerminalOutcome::Canceled);
            } else if let Some(request) = self.pending_searches.pop_front() {
                self.respond_to_search(request);
            } else if let Some(request) = self.pending_previews.pop_front() {
                self.respond_to_preview(request, WorkerOutcome::Finished);
            } else if let Some(request) = self.pending_actions.pop_front() {
                self.respond_to_action(request, WorkerOutcome::Finished);
            } else if let Some(request) = self.pending_sorts.pop_front() {
                self.respond_to_sort(request, WorkerOutcome::Finished);
            } else if let Some(request) = self.pending_filelists.pop_front() {
                self.respond_to_filelist(request, TerminalOutcome::Canceled);
            } else {
                self.poll_index_responses_and_track_consumption();
                self.app.poll_search_response();
                self.app.dispatch_index_queue();
                self.capture_requests();
                if self.is_quiescent() {
                    self.assert_invariants(seed, step, &Event::DeliverStaleIndex);
                    return;
                }
            }
            step = step.saturating_add(1);
            thread::yield_now();
        }

        panic!(
            "stateful endurance did not quiesce: seed={seed:#x}; phase=quiescence; timeout={ENDURANCE_QUIESCENCE_TIMEOUT:?}; steps={step}; index_routes={:?}; search_routes={:?}; response_routes={:?}; filelist_route={:?}; state={}; replay={}",
            self.app.shell.indexing.request_tabs,
            self.app.shell.search.request_routes_for_test(),
            self.app.shell.tabs.routed_tab_ids_for_test(),
            self.app.shell.features.filelist.workflow.pending_request_tab_id,
            self.snapshot().digest(),
            self.replay_command(seed),
        );
    }

    pub(super) fn cleanup(self) {
        let Self { app, base, .. } = self;
        drop(app);
        let _ = fs::remove_dir_all(base);
    }

    fn apply(&mut self, event: &Event) {
        match *event {
            Event::CreateTab => {
                if self.app.shell.tabs.len() < 5 {
                    self.app.create_new_tab();
                }
            }
            Event::CloseTab(index) => {
                let len = self.app.shell.tabs.len();
                self.app.close_tab_index(index % len.max(1));
            }
            Event::RestoreTab => self.app.restore_recently_closed_tab(),
            Event::SwitchTab(index) => {
                let len = self.app.shell.tabs.len();
                self.app.switch_to_tab_index(index % len.max(1));
            }
            Event::ReorderTab { from, to } => {
                let len = self.app.shell.tabs.len();
                self.app.move_tab(from % len.max(1), to % len.max(1));
            }
            Event::ChangeQuery(query) => {
                self.app.shell.runtime.query_state.query = match query % 6 {
                    0 => String::new(),
                    1 => "file".to_string(),
                    2 => "root".to_string(),
                    3 => "^root".to_string(),
                    4 => "!missing".to_string(),
                    _ => "'fixture".to_string(),
                };
                self.app.update_results();
                self.app.sync_active_tab_state();
            }
            Event::ChangeRoot(index) => {
                self.app
                    .apply_root_change_direct(self.roots[index % self.roots.len()].clone());
            }
            Event::RefreshIndex => self.app.request_index_refresh(),
            Event::DeliverOldestIndexData(data) => {
                if let Some((request_id, root)) = self
                    .pending_indexes
                    .front()
                    .map(|request| (request.request_id, request.root.clone()))
                {
                    self.respond_with_index_data(request_id, &root, data);
                }
            }
            Event::DeliverNewestIndexData(data) => {
                if let Some((request_id, root)) = self
                    .pending_indexes
                    .back()
                    .map(|request| (request.request_id, request.root.clone()))
                {
                    self.respond_with_index_data(request_id, &root, data);
                }
            }
            Event::CompleteOldestIndex(outcome) => {
                if let Some(request) = self.pending_indexes.pop_front() {
                    self.respond_to_index(request, outcome);
                }
            }
            Event::CompleteNewestIndex(outcome) => {
                if let Some(request) = self.pending_indexes.pop_back() {
                    self.respond_to_index(request, outcome);
                }
            }
            Event::CompleteOldestSearch => {
                if let Some(request) = self.pending_searches.pop_front() {
                    self.respond_to_search(request);
                }
            }
            Event::RequestPreview => self.request_preview(),
            Event::CompleteOldestPreview(outcome) => {
                if let Some(request) = self.pending_previews.pop_front() {
                    self.respond_to_preview(request, outcome);
                }
            }
            Event::RequestAction => self.request_action(),
            Event::CompleteOldestAction(outcome) => {
                if let Some(request) = self.pending_actions.pop_front() {
                    self.respond_to_action(request, outcome);
                }
            }
            Event::RequestSort => self.request_sort(),
            Event::CompleteOldestSort(outcome) => {
                if let Some(request) = self.pending_sorts.pop_front() {
                    self.respond_to_sort(request, outcome);
                }
            }
            Event::RequestFileList => self.request_filelist(),
            Event::CompleteOldestFileList(outcome) => {
                if let Some(request) = self.pending_filelists.pop_front() {
                    self.respond_to_filelist(request, outcome);
                }
            }
            Event::DeliverStaleIndex => self.deliver_stale_index(),
            Event::DeliverStaleSearch => self.deliver_stale_search(),
        }
    }

    fn response_owners(&self, event: &Event) -> Option<HashSet<u64>> {
        let mut owners = match event {
            Event::DeliverOldestIndexData(_) | Event::CompleteOldestIndex(_) => request_owner(
                self.pending_indexes
                    .front()
                    .map(|request| request.request_id),
                self.app
                    .shell
                    .indexing
                    .request_tabs
                    .iter()
                    .map(|(request_id, tab_id)| (*request_id, *tab_id)),
            ),
            Event::DeliverNewestIndexData(_) | Event::CompleteNewestIndex(_) => request_owner(
                self.pending_indexes
                    .back()
                    .map(|request| request.request_id),
                self.app
                    .shell
                    .indexing
                    .request_tabs
                    .iter()
                    .map(|(request_id, tab_id)| (*request_id, *tab_id)),
            ),
            Event::DeliverStaleIndex => HashSet::new(),
            Event::CompleteOldestSearch => request_owner(
                self.pending_searches
                    .front()
                    .map(|request| request.request_id),
                self.app.shell.search.request_routes_for_test(),
            ),
            Event::DeliverStaleSearch => HashSet::new(),
            Event::CompleteOldestPreview(_) => self
                .pending_previews
                .front()
                .and_then(|request| self.app.preview_request_tab(request.request_id))
                .into_iter()
                .collect(),
            Event::CompleteOldestAction(_) => self
                .pending_actions
                .front()
                .and_then(|request| self.app.action_request_tab(request.request_id))
                .into_iter()
                .collect(),
            Event::CompleteOldestSort(_) => self
                .pending_sorts
                .front()
                .and_then(|request| self.app.sort_request_tab(request.request_id))
                .into_iter()
                .collect(),
            Event::CompleteOldestFileList(_) => self
                .pending_filelists
                .front()
                .and_then(|request| {
                    let workflow = &self.app.shell.features.filelist.workflow;
                    (workflow.pending_request_id == Some(request.request_id))
                        .then_some(request.tab_id)
                })
                .into_iter()
                .collect(),
            _ => return None,
        };
        if matches!(
            event,
            Event::DeliverOldestIndexData(_)
                | Event::DeliverNewestIndexData(_)
                | Event::CompleteOldestIndex(_)
                | Event::CompleteNewestIndex(_)
                | Event::DeliverStaleIndex
        ) {
            // Selection is not completion: the arbitrator can select an injected
            // response into a deferred queue, then stop on an active terminal.
            // Include the exact retained responses even after selection tracking
            // removes their submitted IDs. Duplicate IDs remain one owner, and
            // unrelated in-flight routes do not acquire ownership here.
            let indexing = &self.app.shell.indexing;
            // prepare_frame retries retained work before reading the new
            // response. Attribute the exact pending finish, not every route.
            if let Some(tab) = self
                .app
                .shell
                .tabs
                .iter()
                .enumerate()
                .filter(|(index, _)| *index != self.app.shell.tabs.active_tab_index())
                .find_map(|(_, tab)| tab.index_state.pending_index_finish.as_ref().map(|_| tab))
            {
                let finish = tab.index_state.pending_index_finish.as_ref().unwrap();
                if tab.index_state.pending_index_request_id == Some(finish.request_id)
                    && indexing.request_tabs.get(&finish.request_id) == Some(&tab.id)
                {
                    owners.insert(tab.id);
                }
            }
            // Retrying a previously requested activation can change the
            // current tab's waiting notice and transfer the target's state.
            if let Some(target_id) = self.app.shell.tabs.pending_activation_tab_id {
                if self.app.find_tab_index_by_id(target_id).is_some() {
                    if let Some(active_id) = self.app.current_tab_id() {
                        if active_id != target_id {
                            owners.extend([active_id, target_id]);
                        }
                    }
                }
            }
            let deferred_request_ids = indexing
                .deferred_response
                .iter()
                .chain(indexing.deferred_non_active_responses.iter())
                .chain(indexing.pending_replace_all.iter())
                .map(crate::app::index_coordinator::IndexCoordinator::response_request_id);
            for request_id in self
                .submitted_index_responses
                .iter()
                .copied()
                .chain(deferred_request_ids)
            {
                owners.extend(request_owner(
                    Some(request_id),
                    self.app
                        .shell
                        .indexing
                        .request_tabs
                        .iter()
                        .map(|(request_id, tab_id)| (*request_id, *tab_id)),
                ));
            }
        }
        if matches!(
            event,
            Event::CompleteOldestSearch | Event::DeliverStaleSearch
        ) {
            let worker_owned_request_ids = self
                .pending_searches
                .iter()
                .map(|request| request.request_id)
                .collect::<HashSet<_>>();
            owners.extend(
                self.app
                    .shell
                    .search
                    .request_routes_for_test()
                    .into_iter()
                    .filter_map(|(request_id, tab_id)| {
                        (!worker_owned_request_ids.contains(&request_id)).then_some(tab_id)
                    }),
            );
        }
        Some(owners)
    }

    fn assert_other_tab_content_unchanged(
        &self,
        before: &SemanticSnapshot,
        after: &SemanticSnapshot,
        owners: &HashSet<u64>,
        seed: u64,
        step: usize,
        event: &Event,
    ) {
        for before_tab in before.tabs.iter().filter(|tab| !owners.contains(&tab.id)) {
            let Some(after_tab) = after.tabs.iter().find(|tab| tab.id == before_tab.id) else {
                panic!(
                    "stateful response removed unrelated tab {}; {}",
                    before_tab.id,
                    self.failure_context(seed, step, event, after)
                );
            };
            let content_unchanged = is_allowed_unowned_tab_transition(before_tab, after_tab);
            assert!(
                content_unchanged,
                "stateful response changed unrelated tab {}; before={before_tab:?}; after={after_tab:?}; {}",
                before_tab.id,
                self.failure_context(seed, step, event, after)
            );
        }
    }

    fn capture_requests(&mut self) {
        while let Ok(request) = self.index_requests.try_recv() {
            self.pending_indexes.push_back(request);
        }
        while let Ok(request) = self.search_requests.try_recv() {
            self.pending_searches.push_back(request);
        }
        while let Ok(request) = self.preview_requests.try_recv() {
            self.pending_previews.push_back(request);
        }
        while let Ok(request) = self.action_requests.try_recv() {
            self.pending_actions.push_back(request);
        }
        while let Ok(request) = self.sort_requests.try_recv() {
            self.pending_sorts.push_back(request);
        }
        while let Ok(request) = self.filelist_requests.try_recv() {
            self.pending_filelists.push_back(request);
        }
    }

    fn poll_index_responses_and_track_consumption(&mut self) {
        self.app.shell.indexing.mailbox_selection_trace.clear();
        self.app
            .poll_index_response_with_budget_for_test(ENDURANCE_RESPONSE_DRAIN_BUDGET);
        for request_id in std::mem::take(&mut self.app.shell.indexing.mailbox_selection_trace) {
            if let Some(index) = self
                .submitted_index_responses
                .iter()
                .position(|submitted| *submitted == request_id)
            {
                self.submitted_index_responses.remove(index);
            }
        }
    }

    fn respond_to_index(&mut self, request: IndexRequest, outcome: TerminalOutcome) {
        let request_id = request.request_id;
        self.submitted_index_responses.push_back(request_id);
        match outcome {
            TerminalOutcome::Finished => {
                self.index_responses
                    .send(IndexResponse::Finished {
                        request_id,
                        source: IndexSource::Walker,
                    })
                    .expect("send index finish");
            }
            TerminalOutcome::Failed => self
                .index_responses
                .send(IndexResponse::Failed {
                    request_id,
                    error: "injected endurance failure".to_string(),
                })
                .expect("send index failure"),
            TerminalOutcome::Canceled => self
                .index_responses
                .send(IndexResponse::Canceled { request_id })
                .expect("send index cancel"),
        }
        self.poll_index_responses_and_track_consumption();
        self.app.poll_search_response();
        self.app.dispatch_index_queue();
    }

    fn respond_with_index_data(&mut self, request_id: u64, root: &Path, data: IndexData) {
        let entry_path = root.join(format!(
            "request-{request_id}-entry-{}.txt",
            self.next_index_entry_id
        ));
        self.next_index_entry_id = self.next_index_entry_id.saturating_add(1);
        fs::write(&entry_path, "controlled endurance index entry")
            .expect("write controlled index entry");
        let entry = IndexEntry {
            path: entry_path,
            kind: EntryKind::file(),
            kind_known: true,
        };
        let response = match data {
            IndexData::Batch => IndexResponse::Batch {
                request_id,
                entries: vec![entry],
            },
            IndexData::ReplaceAll => IndexResponse::ReplaceAll {
                request_id,
                entries: vec![entry],
            },
        };
        self.submitted_index_responses.push_back(request_id);
        self.index_responses
            .send(response)
            .expect("send index data");
        self.poll_index_responses_and_track_consumption();
        self.app.poll_search_response();
        self.app.dispatch_index_queue();
    }

    fn respond_to_search(&mut self, request: SearchRequest) {
        let SearchRequest {
            request_id,
            entries,
            limit,
            sort_mode,
            sort_scope,
            ..
        } = request;
        let results = entries
            .iter()
            .take(limit.min(2))
            .enumerate()
            .map(|(index, entry)| (entry.path.clone(), 10.0 - index as f64))
            .collect::<Vec<_>>();
        let total_match_count = results.len();
        self.search_responses
            .send(SearchResponse {
                request_id,
                results,
                total_match_count,
                sort_mode,
                sort_scope,
                error: None,
            })
            .expect("send search response");
        self.app.poll_search_response();
    }

    fn prepare_current_result(&mut self) -> Option<PathBuf> {
        let path = self.app.shell.runtime.results.first()?.0.clone();
        self.app.shell.runtime.committed_for_test_mut().current_row = Some(0);
        self.app.set_entry_kind(&path, EntryKind::file());
        Some(path)
    }

    fn request_preview(&mut self) {
        if self.prepare_current_result().is_none() {
            return;
        }
        self.app.clear_preview_cache();
        self.app.request_preview_for_current();
    }

    fn respond_to_preview(&mut self, request: PreviewRequest, outcome: WorkerOutcome) {
        let preview = match outcome {
            WorkerOutcome::Finished => "controlled endurance preview",
            WorkerOutcome::Failed => "Preview failed: controlled endurance failure",
        };
        self.preview_responses
            .send(PreviewResponse {
                canceled: false,
                request_id: request.request_id,
                path: request.path,
                preview: preview.to_string(),
                document: None,
                page_error: None,
                is_more: false,
            })
            .expect("send preview response");
        self.app.poll_preview_response();
    }

    fn request_action(&mut self) {
        if self.prepare_current_result().is_none() {
            return;
        }
        self.app.execute_selected();
    }

    fn respond_to_action(&mut self, request: ActionRequest, outcome: WorkerOutcome) {
        let notice = match outcome {
            WorkerOutcome::Finished => "controlled endurance action",
            WorkerOutcome::Failed => "Action failed: controlled endurance failure",
        };
        self.action_responses
            .send(ActionResponse {
                request_id: request.request_id,
                notice: notice.to_string(),
            })
            .expect("send action response");
        self.app.poll_action_response();
    }

    fn request_sort(&mut self) {
        if self.prepare_current_result().is_none() {
            return;
        }
        self.app.clear_sort_metadata_cache();
        self.app.set_result_sort_mode(ResultSortMode::SizeDesc);
    }

    fn respond_to_sort(&mut self, request: SortMetadataRequest, outcome: WorkerOutcome) {
        let entries = request
            .paths
            .into_iter()
            .map(|path| {
                let metadata = match outcome {
                    WorkerOutcome::Finished => SortMetadata {
                        size_bytes: Some(1),
                        ..SortMetadata::default()
                    },
                    WorkerOutcome::Failed => SortMetadata::default(),
                };
                (path, metadata)
            })
            .collect();
        self.sort_responses
            .send(SortMetadataResponse {
                request_id: request.request_id,
                entries,
                mode: request.mode,
            })
            .expect("send sort response");
        self.app.poll_sort_response();
    }

    fn request_filelist(&mut self) {
        if self.app.shell.features.filelist.workflow.in_progress {
            return;
        }
        let tab_id = self.app.current_tab_id().expect("active endurance tab");
        let root = self.app.shell.runtime.root.clone();
        self.app
            .request_filelist_creation(tab_id, root.clone(), vec![root.join("fixture.txt")]);
    }

    fn respond_to_filelist(&mut self, request: FileListRequest, outcome: TerminalOutcome) {
        if matches!(request.phase, FileListRequestPhase::Discard) {
            return;
        }
        let response = match (request.phase, outcome) {
            (FileListRequestPhase::Preflight, TerminalOutcome::Finished) => {
                FileListResponse::PreflightFinished {
                    request_id: request.request_id,
                    root: request.root,
                    existing_path: None,
                    ancestor_confirmation_needed: false,
                }
            }
            (FileListRequestPhase::Write, TerminalOutcome::Finished) => {
                FileListResponse::Finished {
                    request_id: request.request_id,
                    path: request.root.join("FileList.txt"),
                    root: request.root,
                    count: 1,
                }
            }
            (_, TerminalOutcome::Failed) => FileListResponse::Failed {
                request_id: request.request_id,
                root: request.root,
                error: "controlled endurance failure".to_string(),
            },
            (_, TerminalOutcome::Canceled) => FileListResponse::Canceled {
                request_id: request.request_id,
                root: request.root,
            },
            (FileListRequestPhase::Discard, _) => unreachable!("discard handled above"),
        };
        self.filelist_responses
            .send(response)
            .expect("send filelist response");
        self.app.poll_filelist_response();
    }

    fn deliver_stale_index(&mut self) {
        let request_id = self.take_stale_request_id();
        self.submitted_index_responses.push_back(request_id);
        self.index_responses
            .send(IndexResponse::Finished {
                request_id,
                source: IndexSource::Walker,
            })
            .expect("send stale index");
        self.poll_index_responses_and_track_consumption();
    }

    fn deliver_stale_search(&mut self) {
        let request_id = self.take_stale_request_id();
        self.search_responses
            .send(SearchResponse {
                request_id,
                results: Vec::new(),
                total_match_count: 0,
                sort_mode: ResultSortMode::Score,
                sort_scope: ResultSortScope::ShownResults,
                error: None,
            })
            .expect("send stale search");
        self.app.poll_search_response();
    }

    fn take_stale_request_id(&mut self) -> u64 {
        let request_id = self.next_stale_request_id;
        self.next_stale_request_id = self.next_stale_request_id.saturating_add(1);
        request_id
    }

    fn snapshot(&self) -> SemanticSnapshot {
        snapshot_for_app(&self.app, &self.roots)
    }

    fn assert_invariants(&self, seed: u64, step: usize, event: &Event) {
        let snapshot = self.snapshot();
        if let Err(error) = validate(&snapshot) {
            panic!(
                "stateful endurance invariant failed: {error}; {}",
                self.failure_context(seed, step, event, &snapshot)
            );
        }
    }

    fn replay_command(&self, seed: u64) -> String {
        format!(
            "FLISTWALKER_ENDURANCE_SEED={seed:#x} FLISTWALKER_ENDURANCE_STEPS={} cargo test --locked stateful_endurance_replay --lib -- --ignored --nocapture",
            self.replay_steps
        )
    }

    fn failure_context(
        &self,
        seed: u64,
        step: usize,
        event: &Event,
        snapshot: &SemanticSnapshot,
    ) -> String {
        format!(
            "seed={seed:#x}; step={step}; event={event:?}; pending_activation={:?}; state={}; replay={}",
            self.app.shell.tabs.pending_activation_tab_id,
            snapshot.digest(),
            self.replay_command(seed)
        )
    }

    fn is_quiescent(&self) -> bool {
        let snapshot = self.snapshot();
        self.pending_indexes.is_empty()
            && self.pending_searches.is_empty()
            && self.pending_previews.is_empty()
            && self.pending_actions.is_empty()
            && self.pending_sorts.is_empty()
            && self.pending_filelists.is_empty()
            && self.app.shell.indexing.pending_queue.is_empty()
            && self.app.shell.indexing.inflight_requests.is_empty()
            && self.app.shell.indexing.pending_request_id.is_none()
            && !self.app.shell.indexing.in_progress
            && self.app.shell.indexing.build.pending_entries.is_empty()
            && self.app.shell.indexing.pending_finish.is_none()
            && self.app.shell.search.pending_request_id().is_none()
            && !self.app.shell.search.in_progress()
            && snapshot.routed_tab_ids.is_empty()
            && !snapshot.preview_pending
            && !snapshot.action_pending
            && !snapshot.sort_pending
            && !snapshot.filelist_pending
            && snapshot.tabs.iter().all(|tab| {
                !tab.index_pending
                    && !tab.search_pending
                    && !tab.preview_pending
                    && !tab.action_pending
                    && !tab.sort_pending
            })
    }
}

fn request_owner(
    request_id: Option<u64>,
    routes: impl IntoIterator<Item = (u64, u64)>,
) -> HashSet<u64> {
    let Some(request_id) = request_id else {
        return HashSet::new();
    };
    routes
        .into_iter()
        .filter_map(|(routed_request_id, tab_id)| {
            (routed_request_id == request_id).then_some(tab_id)
        })
        .collect()
}

fn newly_evicted_tab_ids(
    before: &[TabSemanticSnapshot],
    after: &[TabSemanticSnapshot],
) -> HashSet<u64> {
    after
        .iter()
        .filter_map(|after_tab| {
            before
                .iter()
                .find(|before_tab| before_tab.id == after_tab.id)
                .is_some_and(|before_tab| {
                    before_tab.lifecycle != TabResourceLifecycle::Evicted
                        && after_tab.lifecycle == TabResourceLifecycle::Evicted
                })
                .then_some(after_tab.id)
        })
        .collect()
}

fn newly_routed_tab_ids(before: &[(u8, u64, u64)], after: &[(u8, u64, u64)]) -> HashSet<u64> {
    after
        .iter()
        .filter(|route| !before.contains(route))
        .map(|(_, _, tab_id)| *tab_id)
        .collect()
}

fn is_allowed_unowned_tab_transition(
    before: &TabSemanticSnapshot,
    after: &TabSemanticSnapshot,
) -> bool {
    before.root == after.root
        && before.query == after.query
        && before.results_len == after.results_len
        && before.total_match_count == after.total_match_count
        && before.current_row == after.current_row
        && before.results_digest == after.results_digest
        && (before.notice == after.notice || is_expected_scheduler_notice_transition(before, after))
}

fn is_expected_scheduler_notice_transition(
    before: &TabSemanticSnapshot,
    after: &TabSemanticSnapshot,
) -> bool {
    (before.index_pending
        && !after.index_pending
        && after.notice == "Index request dropped due to queue limit")
        || (before.reclaim_pending
            && after.notice == "Waiting for background tab resource reclamation")
        || (before.index_finalization_pending
            && after.index_finalization_pending
            && matches!(
                before.notice.as_str(),
                "" | "Waiting for background tab resource reclamation"
                    | "Waiting for background tab resource finalization"
            )
            && after.notice == "Waiting for background tab resource finalization")
        || (before.reclaim_pending
            && after.reclaim_pending
            && matches!(
                before.notice.as_str(),
                "Waiting for background tab resource reclamation"
                    | "Waiting for background tab resource finalization"
            )
            && matches!(
                after.notice.as_str(),
                "Waiting for background tab resource reclamation"
                    | "Waiting for background tab resource finalization"
            ))
}

pub(super) fn snapshot_for_app(app: &FlistWalkerApp, roots: &[PathBuf]) -> SemanticSnapshot {
    let tab_ids = app.shell.tabs.iter().map(|tab| tab.id).collect::<Vec<_>>();
    let mut routed_requests = app
        .shell
        .search
        .request_routes_for_test()
        .into_iter()
        .map(|(request_id, tab_id)| (0, request_id, tab_id))
        .chain(
            app.shell
                .indexing
                .request_tabs
                .iter()
                .map(|(request_id, tab_id)| (1, *request_id, *tab_id)),
        )
        .chain(
            app.shell
                .tabs
                .routed_requests_for_test()
                .into_iter()
                .map(|(family, request_id, tab_id)| (family + 2, request_id, tab_id)),
        )
        .chain(
            app.shell
                .features
                .filelist
                .workflow
                .pending_request_id
                .zip(app.shell.features.filelist.workflow.pending_request_tab_id)
                .map(|(request_id, tab_id)| (5, request_id, tab_id)),
        )
        .collect::<Vec<_>>();
    routed_requests.sort_unstable();
    let mut routed_tab_ids = routed_requests
        .iter()
        .map(|(_, _, tab_id)| *tab_id)
        .collect::<Vec<_>>();
    routed_tab_ids.sort_unstable();

    let root_index = |candidate: &PathBuf| {
        roots
            .iter()
            .position(|root| path_key(root) == path_key(candidate))
            .unwrap_or(usize::MAX)
    };
    let active_tab = app.shell.tabs.active_tab_index();
    let active_root = root_index(&app.shell.runtime.root);
    let results_digest = |results: &[(PathBuf, f64)]| {
        let mut hasher = DefaultHasher::new();
        for (path, score) in results {
            path.hash(&mut hasher);
            score.to_bits().hash(&mut hasher);
        }
        hasher.finish()
    };
    let tabs = app
        .shell
        .tabs
        .iter()
        .enumerate()
        .map(|(index, tab)| {
            if index == active_tab {
                TabSemanticSnapshot {
                    id: tab.id,
                    root: active_root,
                    lifecycle: app.shell.indexing.lifecycle(),
                    query: app.shell.runtime.query_state.query.clone(),
                    results_len: app.shell.runtime.results.len(),
                    retained_results_len: app.shell.runtime.base_results.len(),
                    results_compacted: false,
                    total_match_count: app.shell.runtime.total_match_count,
                    current_row: app.shell.runtime.current_row,
                    results_digest: results_digest(&app.shell.runtime.results),
                    notice: app.shell.runtime.notice.clone(),
                    reclaim_pending: app.shell.indexing.build_reclaim_pending
                        || app.shell.indexing.pending_finish.is_some()
                        || app.shell.indexing.root_after_pending_finish.is_some(),
                    index_finalization_pending: app.shell.indexing.pending_finish.is_some(),
                    index_pending: app.shell.indexing.pending_request_id.is_some()
                        || app.shell.indexing.in_progress,
                    search_pending: app.shell.search.pending_request_id().is_some()
                        || app.shell.search.in_progress(),
                    preview_pending: app.shell.worker_bus.preview.pending_request_id.is_some()
                        || app.shell.worker_bus.preview.in_progress,
                    action_pending: app.shell.worker_bus.action.pending_request_id.is_some()
                        || app.shell.worker_bus.action.in_progress,
                    sort_pending: app.shell.worker_bus.sort.pending_request_id.is_some()
                        || app.shell.worker_bus.sort.in_progress,
                }
            } else {
                TabSemanticSnapshot {
                    id: tab.id,
                    root: root_index(&tab.root),
                    lifecycle: tab.index_state.lifecycle(),
                    query: tab.query_state.query.clone(),
                    results_len: tab.result_state.committed.results.len(),
                    retained_results_len: tab.result_state.committed.base_results.len(),
                    results_compacted: tab.result_state.results_compacted,
                    total_match_count: tab.result_state.committed.total_match_count,
                    current_row: tab.result_state.committed.current_row,
                    results_digest: results_digest(&tab.result_state.committed.results),
                    notice: tab.notice.clone(),
                    reclaim_pending: tab.index_state.build_reclaim_pending
                        || tab.index_state.pending_index_finish.is_some()
                        || tab.index_state.root_after_pending_finish.is_some(),
                    index_finalization_pending: tab.index_state.pending_index_finish.is_some(),
                    index_pending: tab.index_state.pending_index_request_id.is_some()
                        || tab.index_state.index_in_progress,
                    search_pending: tab.pending_request_id.is_some() || tab.search_in_progress,
                    preview_pending: tab.pending_preview_request_id.is_some()
                        || tab.preview_in_progress,
                    action_pending: tab.pending_action_request_id.is_some()
                        || tab.action_in_progress,
                    sort_pending: tab.result_state.pending_sort_request_id.is_some()
                        || tab.result_state.sort_in_progress,
                }
            }
        })
        .collect();

    SemanticSnapshot {
        tab_ids,
        tabs,
        active_tab,
        active_root,
        active_query: app.shell.runtime.query_state.query.clone(),
        results_len: app.shell.runtime.results.len(),
        total_match_count: app.shell.runtime.total_match_count,
        current_row: app.shell.runtime.current_row,
        index_pending: app.shell.indexing.pending_queue.len(),
        index_inflight: app.shell.indexing.inflight_requests.len(),
        routed_requests,
        routed_tab_ids,
        active_index_pending: app.shell.indexing.pending_request_id.is_some()
            || app.shell.indexing.in_progress,
        active_search_pending: app.shell.search.pending_request_id().is_some()
            || app.shell.search.in_progress(),
        preview_pending: app.shell.worker_bus.preview.pending_request_id.is_some()
            || app.shell.worker_bus.preview.in_progress,
        action_pending: app.shell.worker_bus.action.pending_request_id.is_some()
            || app.shell.worker_bus.action.in_progress,
        sort_pending: app.shell.worker_bus.sort.pending_request_id.is_some()
            || app.shell.worker_bus.sort.in_progress,
        filelist_pending: app
            .shell
            .features
            .filelist
            .workflow
            .pending_request_id
            .is_some()
            || app
                .shell
                .features
                .filelist
                .workflow
                .pending_request_tab_id
                .is_some()
            || app.shell.features.filelist.workflow.pending_root.is_some()
            || app
                .shell
                .features
                .filelist
                .workflow
                .pending_cancel
                .is_some()
            || app.shell.features.filelist.workflow.cancel_requested
            || app
                .shell
                .features
                .filelist
                .workflow
                .pending_after_index
                .is_some()
            || app.shell.features.filelist.workflow.in_progress,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tc_183_pending_background_finish_keeps_only_its_exact_owner() {
        let mut harness = StatefulHarness::new("endurance-pending-finish-owner");
        harness.app.create_new_tab();
        harness.app.create_new_tab();
        let background_id = harness.app.shell.tabs.get(0).unwrap().id;
        let unrelated_id = harness.app.shell.tabs.get(1).unwrap().id;
        let active_id = harness.app.current_tab_id().unwrap();
        let request_id = 42;
        let state = &mut harness.app.shell.tabs.get_mut(0).unwrap().index_state;
        state.pending_index_request_id = Some(request_id);
        state.pending_index_finish = Some(PendingActiveIndexFinish {
            request_id,
            source: IndexSource::Walker,
        });
        harness
            .app
            .shell
            .indexing
            .request_tabs
            .insert(request_id, background_id);
        let event = Event::DeliverStaleIndex;
        let owners = harness.response_owners(&event).unwrap();
        assert_eq!(owners, HashSet::from([background_id]));
        assert!(!owners.contains(&unrelated_id));
        assert!(!owners.contains(&active_id));

        // A legitimate finish may publish A's own snapshot; C must still fail
        // isolation if its content changes while only A owns pending work.
        let before = harness.snapshot();
        let mut after = before.clone();
        after
            .tabs
            .iter_mut()
            .find(|tab| tab.id == background_id)
            .unwrap()
            .results_digest += 1;
        harness.assert_other_tab_content_unchanged(&before, &after, &owners, 0x1839, 1, &event);
        after
            .tabs
            .iter_mut()
            .find(|tab| tab.id == unrelated_id)
            .unwrap()
            .results_digest += 1;
        assert!(std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            harness.assert_other_tab_content_unchanged(&before, &after, &owners, 0x1839, 1, &event);
        }))
        .is_err());
        harness
            .app
            .shell
            .tabs
            .get_mut(0)
            .unwrap()
            .index_state
            .pending_index_finish = None;
        assert!(
            harness.response_owners(&event).unwrap().is_empty(),
            "an in-flight route without retained terminal work is not a retry owner"
        );
        harness.cleanup();
    }

    #[test]
    fn tc_183_pending_activation_retry_owns_only_current_and_target() {
        let mut harness = StatefulHarness::new("endurance-pending-activation-owner");
        harness.app.create_new_tab();
        harness.app.create_new_tab();
        let target_id = harness.app.shell.tabs.get(0).unwrap().id;
        let unrelated_id = harness.app.shell.tabs.get(1).unwrap().id;
        let active_id = harness.app.current_tab_id().unwrap();
        let event = Event::DeliverStaleIndex;
        assert!(harness.response_owners(&event).unwrap().is_empty());
        harness.app.shell.tabs.pending_activation_tab_id = Some(target_id);
        let owners = harness.response_owners(&event).unwrap();
        assert_eq!(owners, HashSet::from([active_id, target_id]));
        assert!(!owners.contains(&unrelated_id));
        // Exercise the actual frame-start retry: a superseded target build
        // cannot retire while the bounded reclaimer is paused and full.
        harness.app.shell.tabs.pause_resource_reclaimer();
        for _ in 0..crate::app::tab_resources::TAB_RESOURCE_RECLAIMER_CAPACITY {
            let mut retired = crate::app::tab_resources::RetiredIndexBuildResources::empty();
            retired.set_stale_index_entries(vec![IndexEntry {
                path: harness.roots[0].join("retired"),
                kind: EntryKind::file(),
                kind_known: true,
            }]);
            assert!(harness
                .app
                .shell
                .tabs
                .try_retire_index_build_resources(retired)
                .is_ok());
        }
        let request_id = 42;
        let target = harness.app.shell.tabs.get_mut(0).unwrap();
        target.index_state.pending_index_request_id = Some(request_id);
        target.index_state.build.index.entries = (0..1024)
            .map(|index| file_entry(harness.roots[0].join(format!("pending-{index}"))))
            .collect();
        harness
            .app
            .shell
            .indexing
            .request_tabs
            .insert(request_id, target_id);
        harness
            .app
            .shell
            .indexing
            .superseded_request_ids
            .insert(request_id);
        let before = harness.snapshot();
        harness.poll_index_responses_and_track_consumption();
        let after = harness.snapshot();
        assert_eq!(harness.app.current_tab_id(), Some(active_id));
        assert_eq!(
            harness.app.shell.tabs.pending_activation_tab_id,
            Some(target_id)
        );
        assert_eq!(
            after
                .tabs
                .iter()
                .find(|tab| tab.id == active_id)
                .unwrap()
                .notice,
            "Waiting for background tab resource reclamation"
        );
        harness.assert_other_tab_content_unchanged(&before, &after, &owners, 0x183e, 1, &event);
        harness.app.shell.tabs.pending_activation_tab_id = None;
        let owners = harness.response_owners(&event).unwrap();
        assert!(owners.is_empty());
        assert!(
            std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                harness.assert_other_tab_content_unchanged(
                    &before, &after, &owners, 0x183e, 1, &event,
                );
            }))
            .is_err(),
            "a waiting notice without pending activation must remain an isolation failure"
        );
        harness.app.shell.tabs.pending_activation_tab_id = Some(u64::MAX);
        assert!(
            harness.response_owners(&event).unwrap().is_empty(),
            "a closed activation target must not grant ownership"
        );
        harness.app.shell.tabs.pending_activation_tab_id = None;
        harness.app.shell.tabs.resume_resource_reclaimer();
        harness.cleanup();
    }

    #[test]
    fn tc_183_deferred_index_responses_keep_exact_owner_after_selection() {
        let mut harness = StatefulHarness::new("endurance-deferred-owner");
        harness.app.request_index_refresh();
        harness.capture_requests();
        let background = harness
            .pending_indexes
            .pop_front()
            .expect("background request");
        let background_tab = harness.app.current_tab_id().unwrap();
        harness.app.create_new_tab();
        let active_tab = harness.app.current_tab_id().unwrap();
        assert_ne!(active_tab, background_tab);
        harness.app.request_index_refresh();
        harness.capture_requests();
        let active = harness.pending_indexes.pop_front().expect("active request");

        // Both messages belong to the same background request. Selection from the
        // injected channel only moves them to the deferred queue; the active
        // terminal then ends this poll before either background message applies.
        for response in [
            IndexResponse::Batch {
                request_id: background.request_id,
                entries: Vec::new(),
            },
            IndexResponse::Failed {
                request_id: background.request_id,
                error: "injected endurance failure".into(),
            },
            IndexResponse::Finished {
                request_id: active.request_id,
                source: IndexSource::Walker,
            },
        ] {
            harness.submitted_index_responses.push_back(
                crate::app::index_coordinator::IndexCoordinator::response_request_id(&response),
            );
            harness.index_responses.send(response).unwrap();
        }
        harness.poll_index_responses_and_track_consumption();
        assert_eq!(
            harness
                .app
                .shell
                .indexing
                .deferred_non_active_responses
                .len(),
            2
        );
        assert!(harness.submitted_index_responses.is_empty());
        let owners = harness.response_owners(&Event::DeliverStaleIndex).unwrap();
        assert_eq!(owners, HashSet::from([background_tab]));

        let before = harness.snapshot();
        harness.poll_index_responses_and_track_consumption();
        let after = harness.snapshot();
        harness.assert_other_tab_content_unchanged(
            &before,
            &after,
            &owners,
            0x184,
            1,
            &Event::DeliverStaleIndex,
        );
        let background_state = after
            .tabs
            .iter()
            .find(|tab| tab.id == background_tab)
            .unwrap();
        assert_eq!(background_state.lifecycle, TabResourceLifecycle::Failed);
        assert_eq!(
            background_state.notice,
            "Indexing failed: injected endurance failure"
        );
        assert!(harness
            .response_owners(&Event::DeliverStaleIndex)
            .unwrap()
            .is_empty());
        harness.cleanup();
    }

    fn snapshot(index_pending: bool, notice: &str) -> TabSemanticSnapshot {
        TabSemanticSnapshot {
            id: 1,
            root: 0,
            lifecycle: TabResourceLifecycle::Ready,
            query: String::new(),
            results_len: 0,
            retained_results_len: 0,
            results_compacted: false,
            total_match_count: 0,
            current_row: None,
            results_digest: 0,
            notice: notice.to_string(),
            reclaim_pending: false,
            index_finalization_pending: false,
            index_pending,
            search_pending: false,
            preview_pending: false,
            action_pending: false,
            sort_pending: false,
        }
    }

    #[test]
    fn tc_184_queue_drop_notice_is_expected_scheduler_side_effect() {
        let before = snapshot(true, "Root changed: C:\\root");
        let after = snapshot(false, "Index request dropped due to queue limit");
        assert!(is_expected_scheduler_notice_transition(&before, &after));
    }

    #[test]
    fn tc_184_unrelated_reclaimer_wait_notice_is_not_ignored_regression() {
        let before = snapshot(false, "Action completed");
        let after = snapshot(false, "Waiting for background tab resource reclamation");
        assert!(!is_expected_scheduler_notice_transition(&before, &after));
    }

    #[test]
    fn tc_184_reclaimer_wait_notice_requires_matching_pending_transition() {
        let mut before = snapshot(false, "Refreshing");
        before.reclaim_pending = true;
        let after = snapshot(false, "Waiting for background tab resource reclamation");
        assert!(is_expected_scheduler_notice_transition(&before, &after));
    }

    #[test]
    fn tc_184_reclaimer_phase_notice_transition_requires_known_pending_phases() {
        let mut before = snapshot(false, "Waiting for background tab resource reclamation");
        before.reclaim_pending = true;
        before.index_finalization_pending = true;
        let mut after = snapshot(false, "Waiting for background tab resource finalization");
        after.reclaim_pending = true;
        after.index_finalization_pending = true;
        assert!(is_expected_scheduler_notice_transition(&before, &after));

        before.notice = "Action completed".to_string();
        assert!(!is_expected_scheduler_notice_transition(&before, &after));
    }

    #[test]
    fn tc_184_empty_notice_to_finalization_requires_exact_pending_phase() {
        let mut before = snapshot(false, "");
        before.reclaim_pending = true;
        before.index_finalization_pending = true;
        let mut after = before.clone();
        after.notice = "Waiting for background tab resource finalization".to_string();
        assert!(is_expected_scheduler_notice_transition(&before, &after));

        before.index_finalization_pending = false;
        after.index_finalization_pending = false;
        assert!(!is_expected_scheduler_notice_transition(&before, &after));
    }

    #[test]
    fn tc_184_response_owner_is_exact_and_cross_owner_mutation_is_rejected_regression() {
        assert_eq!(
            request_owner(Some(11), [(11, 1), (12, 2)]),
            HashSet::from([1])
        );
        let before = snapshot(false, "ready");
        let mut after = before.clone();
        after.root = 1;
        assert!(!is_allowed_unowned_tab_transition(&before, &after));
    }

    #[test]
    fn tc_184_response_owner_includes_only_the_exact_newly_evicted_tab() {
        let before_ready = snapshot(false, "ready");
        let mut after_evicted = before_ready.clone();
        after_evicted.lifecycle = TabResourceLifecycle::Evicted;
        let mut already_evicted = before_ready.clone();
        already_evicted.id = 2;
        already_evicted.lifecycle = TabResourceLifecycle::Evicted;

        assert_eq!(
            newly_evicted_tab_ids(
                &[before_ready, already_evicted.clone()],
                &[after_evicted, already_evicted],
            ),
            HashSet::from([1])
        );
    }

    #[test]
    fn tc_184_downstream_owner_uses_request_identity_when_tab_is_already_routed() {
        assert_eq!(
            newly_routed_tab_ids(&[(1, 10, 4)], &[(1, 11, 4)]),
            HashSet::from([4])
        );
        assert!(newly_routed_tab_ids(&[(1, 10, 4)], &[(1, 10, 4)]).is_empty());
    }

    #[test]
    fn tc_184_unrelated_notice_change_is_not_ignored() {
        let before = snapshot(true, "Root changed: C:\\root");
        let after = snapshot(false, "Indexing failed: controlled endurance failure");
        assert!(!is_expected_scheduler_notice_transition(&before, &after));
    }
}
