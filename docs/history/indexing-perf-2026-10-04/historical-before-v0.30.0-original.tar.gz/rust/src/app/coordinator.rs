use super::tab_state::TabResourceTransition;
use super::{normalize_windows_path_buf, FlistWalkerApp};
use crate::path_utils::normalize_text_for_display;
use crate::ui_model::normalize_path_for_display;
use eframe::egui;
use memory_stats::memory_stats;
use std::path::{Path, PathBuf};
use std::time::Instant;

#[derive(Debug, Clone)]
pub(super) struct StatusLineContext<'a> {
    pub(super) active_tab: usize,
    pub(super) tab_count: usize,
    pub(super) indexed_count: usize,
    pub(super) results_len: usize,
    pub(super) total_match_count: usize,
    pub(super) limit: usize,
    pub(super) pinned_paths_len: usize,
    pub(super) search_in_progress: bool,
    pub(super) indexing_in_progress: bool,
    pub(super) action_in_progress: bool,
    pub(super) filelist_in_progress: bool,
    pub(super) filelist_cancel_requested: bool,
    pub(super) update_in_progress: bool,
    pub(super) sort_in_progress: bool,
    pub(super) history_search_active: bool,
    pub(super) history_search_results_len: usize,
    pub(super) query_history_len: usize,
    pub(super) notice: &'a str,
    pub(super) memory_text: Option<String>,
}

pub(super) fn build_status_line(ctx: StatusLineContext<'_>) -> String {
    let tab_label = if ctx.tab_count == 0 {
        "Tab: 1/1".to_string()
    } else {
        format!("Tab: {}/{}", ctx.active_tab + 1, ctx.tab_count)
    };
    let clip_text = if ctx.total_match_count > ctx.results_len {
        format!(" of {} shown", ctx.total_match_count)
    } else if ctx.results_len >= ctx.limit {
        format!(" (limit {} reached)", ctx.limit)
    } else {
        String::new()
    };
    let pinned = if ctx.pinned_paths_len == 0 {
        String::new()
    } else {
        format!(" | Pinned: {}", ctx.pinned_paths_len)
    };
    let searching = if ctx.search_in_progress {
        " | Searching..."
    } else {
        ""
    };
    let indexing = if ctx.indexing_in_progress {
        " | Indexing..."
    } else {
        ""
    };
    let executing = if ctx.action_in_progress {
        " | Executing..."
    } else {
        ""
    };
    let creating_filelist = if ctx.filelist_in_progress {
        if ctx.filelist_cancel_requested {
            " | Canceling FileList..."
        } else {
            " | Creating FileList..."
        }
    } else {
        ""
    };
    let updating = if ctx.update_in_progress {
        " | Updating..."
    } else {
        ""
    };
    let sorting = if ctx.sort_in_progress {
        " | Sorting..."
    } else {
        ""
    };
    let history_search = if ctx.history_search_active {
        format!(
            " | History search: {}/{}",
            ctx.history_search_results_len, ctx.query_history_len
        )
    } else {
        String::new()
    };
    let memory = match ctx.memory_text {
        Some(mem) => format!(" | Mem: {mem}"),
        None => String::new(),
    };

    let summary = format!(
        "{} | Entries: {} | Results: {}{}{}{}{}{}{}{}{}{}{}",
        tab_label,
        ctx.indexed_count,
        ctx.results_len,
        clip_text,
        pinned,
        searching,
        indexing,
        executing,
        creating_filelist,
        updating,
        sorting,
        history_search,
        memory
    );
    if ctx.notice.is_empty() {
        summary
    } else {
        format!("{} | {summary}", normalize_text_for_display(ctx.notice))
    }
}

pub(super) fn normalized_compare_key(path: &Path) -> String {
    let mut key = normalize_windows_path_buf(path.to_path_buf())
        .to_string_lossy()
        .replace('\\', "/");
    while key.len() > 1 && key.ends_with('/') {
        key.pop();
    }
    #[cfg(windows)]
    {
        key.make_ascii_lowercase();
    }
    key
}

impl FlistWalkerApp {
    pub(super) fn status_line_text(&mut self) -> String {
        self.status_line_text_with_memory_sample(false)
    }

    fn status_line_text_with_memory_sample(&mut self, sample_memory: bool) -> String {
        let indexed_count =
            if self.shell.indexing.in_progress || self.shell.indexing.pending_finish.is_some() {
                let active_indexed_count = self
                    .shell
                    .indexing
                    .build
                    .index
                    .entries
                    .len()
                    .saturating_add(self.shell.indexing.build.pending_entries.len());
                if active_indexed_count == 0 {
                    self.shell.runtime.all_entries.len()
                } else {
                    active_indexed_count
                }
            } else {
                self.shell.runtime.all_entries.len()
            };
        let memory = self.memory_usage_text(sample_memory);
        let status_line = build_status_line(StatusLineContext {
            active_tab: self.shell.tabs.active_tab_index(),
            tab_count: self.shell.tabs.len(),
            indexed_count,
            results_len: self.shell.runtime.results.len(),
            total_match_count: self.shell.runtime.total_match_count,
            limit: self.shell.runtime.limit,
            pinned_paths_len: self.shell.runtime.pinned_paths.len(),
            search_in_progress: self.shell.search.in_progress()
                || self.active_entry_filter_pending(),
            indexing_in_progress: self.shell.indexing.in_progress,
            action_in_progress: self.shell.worker_bus.action.in_progress,
            filelist_in_progress: self.shell.features.filelist.workflow.in_progress,
            filelist_cancel_requested: self.shell.features.filelist.workflow.cancel_requested,
            update_in_progress: self.shell.features.update.state.in_progress,
            sort_in_progress: self.shell.worker_bus.sort.in_progress,
            history_search_active: self.shell.runtime.query_state.history_search_active,
            history_search_results_len: self.shell.runtime.query_state.history_search_results.len(),
            query_history_len: self.shell.runtime.query_state.query_history.len(),
            notice: &self.shell.runtime.notice,
            memory_text: memory,
        });
        let status_line = match self.session_persistence_label() {
            Some(label) if self.shell.ui.persistence.error().is_some() => {
                format!("{label} | {status_line}")
            }
            Some(label) => format!("{status_line} | {label}"),
            None => status_line,
        };
        self.shell.runtime.status_line = status_line.clone();
        status_line
    }

    /// 現在の進行状況と notice から status line を再構築する。
    pub(super) fn refresh_status_line(&mut self) {
        self.shell.runtime.status_line = self.status_line_text();
    }

    pub(super) fn refresh_status_line_with_memory_sample(&mut self) {
        self.shell.runtime.status_line = self.status_line_text_with_memory_sample(true);
    }

    /// 定期的にメモリ使用量をサンプリングし表示文字列へ変換する。
    fn memory_usage_text(&mut self, sample_memory: bool) -> Option<String> {
        if sample_memory {
            self.shell.ui.last_memory_sample = Instant::now();
            self.shell.ui.memory_usage_bytes =
                memory_stats().map(|stats| stats.physical_mem as u64);
        }
        self.shell
            .ui
            .memory_usage_bytes
            .map(|bytes| format!("{:.1} MiB", bytes as f64 / 1024.0 / 1024.0))
    }

    /// notice を更新し status line と同期する。
    pub(super) fn set_notice(&mut self, notice: impl Into<String>) {
        self.shell.runtime.notice = normalize_text_for_display(&notice.into());
        self.refresh_status_line();
    }

    /// notice を消去し status line を再計算する。
    pub(super) fn clear_notice(&mut self) {
        self.shell.runtime.notice.clear();
        self.refresh_status_line();
    }

    pub(super) fn set_current_row(&mut self, row: Option<usize>) {
        self.shell.runtime.set_current_row(row);
    }

    pub(super) fn request_scroll_to_current(&mut self) {
        self.shell.ui.scroll_to_current = true;
    }

    pub(super) fn ensure_results_cursor_visible(&mut self) {
        if self.shell.runtime.results.is_empty() {
            return;
        }
        if self.shell.runtime.current_row.is_none() {
            self.shell.runtime.set_current_row(Some(0));
        }
        if self.shell.runtime.current_row.is_some() {
            self.request_scroll_to_current();
        }
    }

    pub(super) fn clear_scroll_to_current(&mut self) {
        self.shell.ui.scroll_to_current = false;
    }

    pub(super) fn request_focus_query(&mut self) {
        self.shell.ui.focus_query_requested = true;
    }

    pub(super) fn request_unfocus_query(&mut self) {
        self.shell.ui.unfocus_query_requested = true;
    }

    pub(super) fn clear_focus_query_request(&mut self) {
        self.shell.ui.focus_query_requested = false;
    }

    pub(super) fn clear_unfocus_query_request(&mut self) {
        self.shell.ui.unfocus_query_requested = false;
    }

    pub(super) fn request_query_cursor_to_end(&mut self) {
        self.shell.ui.query_cursor_to_end_requested = true;
    }

    pub(super) fn finish_programmatic_query_replacement(&mut self) {
        self.shell.ui.search_assist.note_query_edit();
        self.shell.tabs.mark_active_tab_meaningfully_engaged();
        // Regression guard: replacing query text outside TextEdit must also replace
        // its retained cursor state, or the caret can remain beyond/inside old text.
        self.request_query_cursor_to_end();
        self.request_focus_query();
        self.clear_unfocus_query_request();
    }

    pub(super) fn query_cursor_to_end_requested(&self) -> bool {
        self.shell.ui.query_cursor_to_end_requested
    }

    pub(super) fn clear_query_cursor_to_end_request(&mut self) {
        self.shell.ui.query_cursor_to_end_requested = false;
    }

    pub(super) fn set_query_history_dirty_since(&mut self, value: Option<Instant>) {
        self.shell.runtime.query_state.query_history_dirty_since = value;
    }

    pub(super) fn settle_tab_canceled_generation(&mut self, tab_id: u64) {
        if self.current_tab_id() == Some(tab_id) {
            self.shell
                .indexing
                .apply_resource_transition(TabResourceTransition::Cancel);
        } else if let Some(tab_index) = self.find_tab_index_by_id(tab_id) {
            if let Some(tab) = self.shell.tabs.get_mut(tab_index) {
                tab.index_state
                    .apply_resource_transition(TabResourceTransition::Cancel);
            }
        }
    }

    /// action worker 実行中の進捗ラベルを返す。
    pub(super) fn action_progress_label(&self) -> Option<&'static str> {
        if self.shell.worker_bus.action.in_progress {
            Some("Opening...")
        } else {
            None
        }
    }

    /// clipboard 向けの複数 path 文字列を構築する。
    pub(super) fn clipboard_paths_text(paths: &[PathBuf]) -> String {
        paths
            .iter()
            .map(|p| normalize_path_for_display(p))
            .collect::<Vec<_>>()
            .join("\n")
    }

    /// 現在の index source を status 向け文言へ整形する。
    pub(super) fn source_text(&self) -> String {
        self.freshness_source_text()
    }

    pub(super) fn run_update_cycle(&mut self, ui: &mut egui::Ui) -> bool {
        let ctx = ui.ctx().clone();
        self.maybe_apply_pending_cjk_font(&ctx);
        self.poll_runtime_events();
        self.tick_freshness(&ctx);
        if self.request_viewport_close_if_needed(&ctx) {
            return false;
        }
        self.commit_query_history_if_needed(false);
        self.schedule_frame_repaint(&ctx);
        self.run_ui_frame(ui);
        true
    }
}

impl eframe::App for FlistWalkerApp {
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        self.run_update_cycle(ui);
    }

    fn on_exit(&mut self, _gl: Option<&eframe::glow::Context>) {
        self.persist_state_and_shutdown("app exit");
    }
}

impl Drop for FlistWalkerApp {
    fn drop(&mut self) {
        self.persist_state_and_shutdown("drop fallback");
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::actions::{lexical_action_path_precheck, ActionPathPrecheck};

    #[test]
    fn build_status_line_includes_progress_and_notice() {
        let status = build_status_line(StatusLineContext {
            active_tab: 1,
            tab_count: 3,
            indexed_count: 42,
            results_len: 7,
            total_match_count: 12,
            limit: 10,
            pinned_paths_len: 2,
            search_in_progress: true,
            indexing_in_progress: true,
            action_in_progress: false,
            filelist_in_progress: true,
            filelist_cancel_requested: true,
            update_in_progress: false,
            sort_in_progress: true,
            history_search_active: true,
            history_search_results_len: 4,
            query_history_len: 12,
            notice: "hello",
            memory_text: Some("123.4 MiB".to_string()),
        });

        assert!(status.contains("Tab: 2/3"));
        assert!(status.contains("Entries: 42"));
        assert!(status.contains("Results: 7"));
        assert!(status.contains("of 12 shown"));
        assert!(status.contains("Pinned: 2"));
        assert!(status.contains("Searching..."));
        assert!(status.contains("Indexing..."));
        assert!(status.contains("Canceling FileList..."));
        assert!(status.contains("Sorting..."));
        assert!(status.contains("History search: 4/12"));
        assert!(status.contains("Mem: 123.4 MiB"));
        assert!(status.contains("hello"));
        assert!(
            status.starts_with("hello | Tab: 2/3"),
            "a truncated footer must show the notice before status metrics"
        );
    }

    #[test]
    #[cfg(target_os = "windows")]
    fn tc202_regression_status_notice_hides_embedded_verbatim_paths() {
        let status = build_status_line(StatusLineContext {
            active_tab: 0,
            tab_count: 1,
            indexed_count: 0,
            results_len: 0,
            total_match_count: 0,
            limit: 10,
            pinned_paths_len: 0,
            search_in_progress: false,
            indexing_in_progress: false,
            action_in_progress: false,
            filelist_in_progress: false,
            filelist_cancel_requested: false,
            update_in_progress: false,
            sort_in_progress: false,
            history_search_active: false,
            history_search_results_len: 0,
            query_history_len: 0,
            notice: r"Created \\?\C:\work\FileList.txt from \\?\UNC\server\share",
            memory_text: None,
        });

        assert!(status.contains(r"Created C:\work\FileList.txt from \\server\share"));
        assert!(!status.contains(r"\\?\"));
    }

    #[test]
    fn path_guard_defers_descendants_and_distinct_absolute_paths() {
        let base = std::env::temp_dir().join("flistwalker-path-guard");
        let root = base.join("root");
        let inside = root.join("sub").join("file.txt");
        let outside = base.join("other").join("file.txt");

        assert_eq!(
            lexical_action_path_precheck(&root, &inside),
            ActionPathPrecheck::Defer
        );
        assert_eq!(
            lexical_action_path_precheck(&root, &outside),
            ActionPathPrecheck::Defer
        );
    }

    #[test]
    fn tc_050_path_guard_rejects_parent_component_escape() {
        let root = std::env::temp_dir()
            .join("flistwalker-path-guard-parent")
            .join("root");
        let escaped = root.join("..").join("outside").join("tool.exe");

        assert_eq!(
            lexical_action_path_precheck(&root, &escaped),
            ActionPathPrecheck::Reject
        );
    }
}
