mod top_panel;
mod widgets;

use self::widgets::{centered_top_panel_label, paint_compact_combo_selected_text};
use super::paged_preview_flow::{PagedPreviewView, PreviewAction};
use super::{
    render_theme, EntryDisplayKind, EntryKind, FlistWalkerApp, ResultSortMode, ResultSortScope,
};
use crate::ui_model::{
    format_file_size, format_system_time, normalize_path_for_display, PagedTextPreview,
    PreviewPageState, SyntaxTokenKind,
};
use eframe::egui;
#[cfg(test)]
use std::cell::RefCell;
use std::path::Path;

#[cfg(test)]
#[derive(Clone, Copy)]
pub(super) enum TestResultRowInteraction {
    None,
    Click(usize),
    DoubleClick(usize),
}

#[cfg(test)]
#[derive(Default)]
pub(super) struct ResultRenderProbe {
    pub(super) rendered_rows: Vec<usize>,
    pub(super) action_rows: Vec<usize>,
    pub(super) row_rects: Vec<(usize, egui::Rect)>,
    pub(super) header_controls: Vec<(&'static str, egui::Rect)>,
    pub(super) header_bounds: Option<egui::Rect>,
    pub(super) scroll: Option<(egui::Id, egui::Vec2, egui::Rect)>,
}

#[cfg(test)]
pub(super) struct PreviewControlProbe {
    pub(super) action: PreviewAction,
    pub(super) rect: egui::Rect,
    pub(super) enabled: bool,
    pub(super) selected: bool,
}

#[cfg(test)]
struct ActiveResultRenderProbe {
    interaction: TestResultRowInteraction,
    result: ResultRenderProbe,
}

#[cfg(test)]
thread_local! {
    static RESULT_RENDER_PROBE: RefCell<Option<ActiveResultRenderProbe>> = const { RefCell::new(None) };
    static FORCE_IGNORE_LIST_CHECKBOX_CLICK: RefCell<bool> = const { RefCell::new(false) };
    static PREVIEW_RENDER_ROWS: RefCell<Option<usize>> = const { RefCell::new(None) };
    static PREVIEW_CONTROL_PROBE: RefCell<Option<Vec<PreviewControlProbe>>> = const { RefCell::new(None) };
}

#[cfg(test)]
pub(super) fn begin_preview_control_probe() {
    PREVIEW_CONTROL_PROBE.with(|probe| *probe.borrow_mut() = Some(Vec::new()));
}

#[cfg(test)]
pub(super) fn take_preview_control_probe() -> Vec<PreviewControlProbe> {
    PREVIEW_CONTROL_PROBE.with(|probe| probe.borrow_mut().take().unwrap_or_default())
}

#[cfg(test)]
pub(super) fn force_ignore_list_checkbox_click() {
    FORCE_IGNORE_LIST_CHECKBOX_CLICK.with(|forced| *forced.borrow_mut() = true);
}

#[cfg(test)]
fn take_forced_ignore_list_checkbox_click() -> bool {
    FORCE_IGNORE_LIST_CHECKBOX_CLICK.with(|forced| std::mem::take(&mut *forced.borrow_mut()))
}

#[cfg(test)]
pub(super) fn begin_result_render_probe(interaction: TestResultRowInteraction) {
    RESULT_RENDER_PROBE.with(|probe| {
        *probe.borrow_mut() = Some(ActiveResultRenderProbe {
            interaction,
            result: ResultRenderProbe::default(),
        });
    });
}

#[cfg(test)]
pub(super) fn take_result_render_probe() -> ResultRenderProbe {
    RESULT_RENDER_PROBE.with(|probe| {
        probe
            .borrow_mut()
            .take()
            .map(|active| active.result)
            .unwrap_or_default()
    })
}

#[cfg(test)]
fn record_rendered_result_row(index: usize, rect: egui::Rect) -> TestResultRowInteraction {
    RESULT_RENDER_PROBE.with(|probe| {
        let mut probe = probe.borrow_mut();
        let Some(active) = probe.as_mut() else {
            return TestResultRowInteraction::None;
        };
        active.result.rendered_rows.push(index);
        active.result.row_rects.push((index, rect));
        active.interaction
    })
}

#[cfg(test)]
fn record_result_action(index: usize) -> bool {
    RESULT_RENDER_PROBE.with(|probe| {
        let mut probe = probe.borrow_mut();
        let Some(active) = probe.as_mut() else {
            return false;
        };
        active.result.action_rows.push(index);
        true
    })
}

pub(super) fn centered_checkbox(
    ui: &mut egui::Ui,
    checked: &mut bool,
    label: &str,
) -> egui::Response {
    top_panel::centered_checkbox(ui, checked, label)
}

#[cfg(test)]
pub(super) fn centered_checkbox_layout(
    rect: egui::Rect,
    checkbox_size: f32,
    icon_spacing: f32,
    text_size: egui::Vec2,
    label_y_offset: f32,
    checkbox_y_offset: f32,
) -> (egui::Rect, egui::Pos2) {
    top_panel::centered_checkbox_layout(
        rect,
        checkbox_size,
        icon_spacing,
        text_size,
        label_y_offset,
        checkbox_y_offset,
    )
}

#[cfg(test)]
pub(super) fn update_max_depth_draft_for_unlimited(draft: &mut usize, unlimited: bool) {
    top_panel::update_max_depth_draft_for_unlimited(draft, unlimited);
}

pub(super) fn render_top_panel(app: &mut FlistWalkerApp, ui: &mut egui::Ui) {
    top_panel::render(app, ui);
}

pub(super) fn preview_text_style() -> egui::TextStyle {
    // The proportional family has the asynchronously loaded CJK font first.
    // Using the monospace fallback made Japanese glyphs and Latin text use
    // different vertical metrics, which visibly shifted mixed-language lines.
    egui::TextStyle::Body
}

pub(super) fn render_status_panel(app: &mut FlistWalkerApp, ui: &mut egui::Ui) {
    egui::Panel::bottom("status")
        .resizable(false)
        .exact_size(24.0)
        .show(ui, |ui| {
            ui.horizontal(|ui| {
                let version_text = format!("v{}", env!("CARGO_PKG_VERSION"));
                let version_font = egui::TextStyle::Body.resolve(ui.style());
                let version_width = ui
                    .painter()
                    .layout_no_wrap(
                        version_text.clone(),
                        version_font.clone(),
                        ui.visuals().text_color(),
                    )
                    .size()
                    .x;
                if let Some(label) = app.action_progress_label() {
                    ui.add(egui::Spinner::new().size(14.0));
                    ui.label(label);
                    ui.separator();
                }
                if app.can_cancel_create_filelist() {
                    let cancel_label = if app.shell.features.filelist.workflow.cancel_requested {
                        "Canceling FileList..."
                    } else {
                        "Cancel Create File List"
                    };
                    if ui
                        .add_enabled(
                            !app.shell.features.filelist.workflow.cancel_requested,
                            egui::Button::new(cancel_label),
                        )
                        .clicked()
                    {
                        app.cancel_create_filelist();
                    }
                    ui.separator();
                }
                let reserved_width =
                    version_width + ui.spacing().item_spacing.x + ui.spacing().icon_width;
                let status_width = (ui.available_width() - reserved_width).max(0.0);
                let status_line = app.status_line_text();
                ui.allocate_ui_with_layout(
                    egui::vec2(status_width, ui.available_height()),
                    egui::Layout::left_to_right(egui::Align::Center),
                    |ui| {
                        ui.set_width(status_width);
                        ui.add(egui::Label::new(&status_line).truncate())
                            .on_hover_text(&status_line);
                    },
                );
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    ui.label(version_text);
                    ui.separator();
                });
            });
        });
}

fn result_row_height(ui: &egui::Ui) -> f32 {
    ui.text_style_height(&egui::TextStyle::Body) + (FlistWalkerApp::RESULT_ROW_V_MARGIN * 2.0)
}

fn preview_visible_prefix(line: &str) -> (&str, bool) {
    if let Some((boundary, _)) = line.char_indices().nth(4_096) {
        (&line[..boundary], true)
    } else {
        (line, false)
    }
}

pub(super) fn preview_paged_row_height(ui: &egui::Ui) -> f32 {
    ui.text_style_height(&preview_text_style()) + 4.0
}

fn preview_token_color(kind: SyntaxTokenKind, dark: bool) -> egui::Color32 {
    const COLUMN_DARK: [(u8, u8, u8); 8] = [
        (103, 183, 255),
        (132, 213, 157),
        (255, 190, 116),
        (211, 164, 255),
        (255, 142, 164),
        (98, 216, 207),
        (245, 225, 126),
        (200, 211, 232),
    ];
    const COLUMN_LIGHT: [(u8, u8, u8); 8] = [
        (31, 91, 158),
        (29, 112, 63),
        (158, 78, 18),
        (112, 68, 157),
        (166, 47, 73),
        (10, 112, 111),
        (126, 101, 0),
        (75, 85, 110),
    ];
    let (r, g, b) = match (kind, dark) {
        (SyntaxTokenKind::Keyword, true) => (198, 155, 255),
        (SyntaxTokenKind::String, true) => (157, 213, 161),
        (SyntaxTokenKind::Comment, true) => (143, 151, 163),
        (SyntaxTokenKind::Number, true) => (242, 182, 126),
        (SyntaxTokenKind::Heading | SyntaxTokenKind::Tag, true) => (107, 191, 246),
        (SyntaxTokenKind::Attribute | SyntaxTokenKind::Preprocessor, true) => (239, 194, 117),
        (SyntaxTokenKind::Delimiter, true) => (220, 220, 220),
        (SyntaxTokenKind::Column(column), true) => COLUMN_DARK[column as usize % 8],
        (SyntaxTokenKind::Keyword, false) => (111, 50, 150),
        (SyntaxTokenKind::String, false) => (26, 111, 54),
        (SyntaxTokenKind::Comment, false) => (96, 103, 111),
        (SyntaxTokenKind::Number, false) => (151, 82, 27),
        (SyntaxTokenKind::Heading | SyntaxTokenKind::Tag, false) => (29, 92, 157),
        (SyntaxTokenKind::Attribute | SyntaxTokenKind::Preprocessor, false) => (135, 88, 16),
        (SyntaxTokenKind::Delimiter, false) => (120, 120, 120),
        (SyntaxTokenKind::Column(column), false) => COLUMN_LIGHT[column as usize % 8],
    };
    egui::Color32::from_rgb(r, g, b)
}

pub(super) fn preview_line_job(
    document: &PagedTextPreview,
    index: usize,
    color_enabled: bool,
    ui: &egui::Ui,
) -> egui::text::LayoutJob {
    let original = document.line(index).unwrap_or("");
    let (visible, _) = preview_visible_prefix(original);
    let prefix_len = visible.len();
    let mut job = egui::text::LayoutJob::default();
    job.wrap.max_width = f32::INFINITY;
    let plain = egui::TextFormat {
        font_id: preview_text_style().resolve(ui.style()),
        color: ui.visuals().text_color(),
        ..Default::default()
    };
    if !color_enabled
        || document
            .syntax()
            .is_none_or(|syntax| syntax.is_plain_fallback())
    {
        job.append(visible, 0.0, plain);
        return job;
    }
    let Some(line_range) = document.line_range(index) else {
        return job;
    };
    let line_start = line_range.start as usize;
    let line_end = line_start + prefix_len;
    let mut position = line_start;
    let spans = document.syntax_spans();
    let first = spans.partition_point(|span| span.range.end as usize <= line_start);
    for span in &spans[first..] {
        let span_start = span.range.start as usize;
        if span_start >= line_end {
            break;
        }
        let span_end = (span.range.end as usize).min(line_end);
        let start = span_start.max(position).max(line_start);
        if position < start {
            job.append(
                &original[position - line_start..start - line_start],
                0.0,
                plain.clone(),
            );
        }
        if start < span_end {
            let mut style = plain.clone();
            style.color = preview_token_color(span.kind, ui.visuals().dark_mode);
            job.append(
                &original[start - line_start..span_end - line_start],
                0.0,
                style,
            );
            position = span_end;
        }
    }
    if position < line_end {
        job.append(
            &original[position - line_start..prefix_len],
            0.0,
            plain.clone(),
        );
    }
    job
}

fn render_paged_preview(
    ui: &mut egui::Ui,
    document: &PagedTextPreview,
    view: &mut PagedPreviewView,
) -> Option<PreviewAction> {
    let generation = view.display_generation;
    let busy = view.busy;
    let error = view.error;
    let color_enabled = view.color_enabled;
    ui.label(format!(
        "File: {}",
        normalize_path_for_display(&document.header.path)
    ));
    let prefix = if document.header.is_symlink {
        "Target "
    } else {
        ""
    };
    ui.label(format!(
        "{prefix}Size: {}",
        format_file_size(document.header.size)
    ));
    if let Some(created) = document.header.created.and_then(format_system_time) {
        ui.label(format!("{prefix}Created: {created}"));
    }
    if let Some(modified) = document.header.modified.and_then(format_system_time) {
        ui.label(format!("{prefix}Updated: {modified}"));
    }
    if !document.header.attributes.is_empty() {
        ui.label(format!(
            "Attributes: {}",
            document.header.attributes.join(", ")
        ));
    }
    if let Some(target) = &document.header.target {
        ui.label(format!("Target: {target}"));
    }
    ui.separator();
    let controls_height = 110.0 + if error.is_some() { 22.0 } else { 0.0 };
    let body_height = (ui.available_height() - controls_height).max(80.0);
    let row_height = preview_paged_row_height(ui);
    if view.scroll_generation != generation {
        view.scroll_offset = 0.0;
        view.scroll_generation = generation;
    }
    let mut scroll = egui::ScrollArea::both().id_salt(("paged-preview", generation));
    if view.scroll_pages != 0 {
        scroll = scroll.vertical_scroll_offset(
            (view.scroll_offset + view.scroll_pages as f32 * body_height).max(0.0),
        );
        view.scroll_pages = 0;
    }
    let scroll_output = scroll
        .max_height(body_height)
        .auto_shrink([false, false])
        .show_rows(ui, row_height, document.line_count(), |ui, rows| {
            for index in rows {
                #[cfg(test)]
                PREVIEW_RENDER_ROWS.with(|count| {
                    if let Some(value) = count.borrow_mut().as_mut() {
                        *value += 1;
                    }
                });
                ui.horizontal(|ui| {
                    ui.add(
                        egui::Label::new(
                            egui::RichText::new(format!("{:>5}", index + 1))
                                .weak()
                                .monospace(),
                        )
                        .selectable(false),
                    );
                    ui.add(
                        egui::Label::new(preview_line_job(document, index, color_enabled, ui))
                            .selectable(true)
                            .wrap_mode(egui::TextWrapMode::Extend),
                    );
                    if document
                        .line(index)
                        .is_some_and(|line| preview_visible_prefix(line).1)
                    {
                        ui.add(egui::Label::new("… [line truncated]").selectable(false));
                    }
                });
            }
        });
    view.scroll_offset = scroll_output.state.offset.y;
    ui.separator();
    let mut action = None;
    ui.horizontal_wrapped(|ui| {
        let status = match document.state() {
            PreviewPageState::More => "More available",
            PreviewPageState::Eof => "End of file",
            PreviewPageState::LimitReached => "Display limit reached",
        };
        ui.label(format!("{} lines shown · {status}", document.line_count()));
        if busy {
            ui.spinner();
        }
    });
    if let Some(error) = error {
        ui.colored_label(
            ui.visuals().error_fg_color,
            super::paged_preview_flow::page_error_label(error),
        );
    }
    let focus_hint = format!(
        "{}+Shift+L: Search / Preview",
        FlistWalkerApp::primary_shortcut_label()
    );
    ui.weak(&focus_hint);
    ui.horizontal_wrapped(|ui| {
        for candidate in PreviewAction::ALL {
            let label = match candidate {
                PreviewAction::ToggleColor => if color_enabled { "Color: on" } else { "Color: off" },
                PreviewAction::More => "Load more",
                PreviewAction::Reload => "Reload preview",
            };
            let selected = view.controls_focused && view.selected_control == candidate;
            let button = egui::Button::new(label).stroke(if selected {
                egui::Stroke::new(2.0, ui.visuals().selection.stroke.color)
            } else {
                ui.visuals().widgets.inactive.bg_stroke
            });
            let response = ui.add_enabled(candidate.available(document, busy, error), button)
                .on_hover_text(format!("{focus_hint}\nLeft / Right: select; Enter / Space: activate; Esc: return to search"));
            if selected && !ui.clip_rect().contains_rect(response.rect) {
                response.scroll_to_me(Some(egui::Align::Center));
            }
            #[cfg(test)]
            PREVIEW_CONTROL_PROBE.with(|probe| {
                if let Some(controls) = probe.borrow_mut().as_mut() {
                    controls.push(PreviewControlProbe { action: candidate, rect: response.rect, enabled: response.enabled(), selected });
                }
            });
            if response.clicked() {
                view.selected_control = candidate;
                action = Some(candidate);
            }
        }
    });
    action
}

pub(super) fn render_results_and_preview(app: &mut FlistWalkerApp, ui: &mut egui::Ui) {
    if app.shell.runtime.query_state.history_search_active {
        app.shell.ui.set_preview_resize_in_progress(false);
        render_history_search_results(app, ui);
        app.clear_scroll_to_current();
        return;
    }
    if app.shell.ui.show_preview() {
        let paged_document = app.paged_preview_for_current().cloned();
        let mut preview_action = None;
        let max_preview_width = (ui.available_width() - FlistWalkerApp::MIN_RESULTS_PANEL_WIDTH)
            .max(FlistWalkerApp::MIN_PREVIEW_PANEL_WIDTH);
        let panel = egui::Panel::right("preview-panel")
            .resizable(true)
            .default_size(app.shell.ui.preview_panel_width().min(max_preview_width))
            .min_size(FlistWalkerApp::MIN_PREVIEW_PANEL_WIDTH)
            .max_size(max_preview_width);
        let response = panel.show(ui, |ui| {
            ui.heading("Preview");
            let preview_width = ui.available_width();
            let preview_height = ui.available_height();
            ui.allocate_ui_with_layout(
                egui::vec2(preview_width, preview_height),
                egui::Layout::top_down(egui::Align::Min),
                |ui| {
                    let frame_fill = ui.visuals().extreme_bg_color;
                    egui::Frame::NONE.fill(frame_fill).show(ui, |ui| {
                        ui.set_min_size(egui::vec2(preview_width, preview_height));
                        if let Some(document) = paged_document.as_ref() {
                            egui::ScrollArea::vertical()
                                .id_salt((
                                    "preview-details",
                                    app.paged_preview_view.display_generation,
                                ))
                                .max_height(preview_height)
                                .auto_shrink([false, false])
                                .show(ui, |ui| {
                                    preview_action = render_paged_preview(
                                        ui,
                                        document,
                                        &mut app.paged_preview_view,
                                    );
                                });
                        } else {
                            egui::ScrollArea::both()
                                .auto_shrink([false, false])
                                .show(ui, |ui| {
                                    ui.add_sized(
                                        egui::vec2(preview_width, preview_height),
                                        egui::TextEdit::multiline(
                                            app.shell.runtime.preview_text_mut(),
                                        )
                                        .interactive(false)
                                        .font(preview_text_style())
                                        .desired_width(f32::INFINITY)
                                        .desired_rows(1),
                                    );
                                });
                        }
                    });
                },
            );
        });
        if let Some(action) = preview_action {
            app.apply_preview_action(action);
        }
        let new_width = response
            .response
            .rect
            .width()
            .max(FlistWalkerApp::MIN_PREVIEW_PANEL_WIDTH);
        if (new_width - app.shell.ui.preview_panel_width()).abs() > 1.0 {
            app.shell.ui.set_preview_panel_width(new_width);
            app.mark_ui_state_dirty();
        }
        let splitter_x = response.response.rect.left();
        let splitter_pressed = ui.input(|i| {
            let Some(pos) = i.pointer.interact_pos() else {
                return false;
            };
            i.pointer.primary_down() && (pos.x - splitter_x).abs() <= 8.0
        });
        app.shell
            .ui
            .set_preview_resize_in_progress(response.response.dragged() || splitter_pressed);
        render_results_list(app, ui);
    } else {
        app.shell.ui.set_preview_resize_in_progress(false);
        render_results_list(app, ui);
    }
    app.clear_scroll_to_current();
}

fn labeled_results_combo(
    ui: &mut egui::Ui,
    label: &str,
    combo_width: f32,
    render_combo: impl FnOnce(&mut egui::Ui) -> egui::Response,
) -> egui::Response {
    let label_width = ui
        .painter()
        .layout_no_wrap(
            label.to_owned(),
            egui::TextStyle::Button.resolve(ui.style()),
            ui.visuals().text_color(),
        )
        .size()
        .x;
    // ComboBox builds its own horizontal UI. Reserve the complete labeled group
    // in the wrapping parent before rendering it, so its button cannot overflow
    // into Preview when the current line has too little remaining space.
    ui.allocate_ui_with_layout(
        egui::vec2(
            label_width + ui.spacing().item_spacing.x + combo_width,
            ui.spacing().interact_size.y,
        ),
        egui::Layout::left_to_right(egui::Align::Center),
        |ui| {
            centered_top_panel_label(ui, label);
            render_combo(ui)
        },
    )
    .inner
}

pub(super) fn render_results_list(app: &mut FlistWalkerApp, ui: &mut egui::Ui) {
    #[cfg(test)]
    RESULT_RENDER_PROBE.with(|probe| {
        if let Some(active) = probe.borrow_mut().as_mut() {
            active.result.header_bounds = Some(ui.available_rect_before_wrap());
        }
    });
    // Labeled controls wrap as bounded groups within the Results pane.
    ui.horizontal_wrapped(|ui| {
        ui.heading("Results");
        let total = app.shell.runtime.total_match_count;
        let shown = app.shell.runtime.results.len();
        if total > shown {
            ui.label(format!("{shown} of {total} shown"));
        } else {
            ui.label(format!("{shown} shown"));
        }
        let original_scope = app.shell.runtime.result_sort_scope;
        let mut selected_scope = original_scope;
        let mut selected = app.shell.runtime.result_sort_mode;
        let sort_response = labeled_results_combo(
            ui,
            "Sorted by",
            FlistWalkerApp::RESULT_SORT_SELECTOR_WIDTH,
            |ui| {
                egui::ComboBox::from_id_salt("results-sort-selector")
                    .width(FlistWalkerApp::RESULT_SORT_SELECTOR_WIDTH)
                    .selected_text("")
                    .show_ui(ui, |ui| {
                        ui.set_min_width(FlistWalkerApp::RESULT_SORT_SELECTOR_WIDTH);
                        for mode in [
                            ResultSortMode::Score,
                            ResultSortMode::NameAsc,
                            ResultSortMode::NameDesc,
                            ResultSortMode::PathAsc,
                            ResultSortMode::PathDesc,
                            ResultSortMode::ModifiedDesc,
                            ResultSortMode::ModifiedAsc,
                            ResultSortMode::CreatedDesc,
                            ResultSortMode::CreatedAsc,
                            ResultSortMode::SizeDesc,
                            ResultSortMode::SizeAsc,
                        ] {
                            ui.selectable_value(&mut selected, mode, mode.label());
                        }
                    })
                    .response
            },
        );
        #[cfg(test)]
        RESULT_RENDER_PROBE.with(|probe| {
            if let Some(active) = probe.borrow_mut().as_mut() {
                active
                    .result
                    .header_controls
                    .push(("sort", sort_response.rect));
            }
        });
        paint_compact_combo_selected_text(ui, &sort_response, selected.label());

        let scope_response = labeled_results_combo(ui, "Scope", 126.0, |ui| {
            egui::ComboBox::from_id_salt("results-sort-scope-selector")
                .width(126.0)
                .selected_text("")
                .show_ui(ui, |ui| {
                    ui.set_min_width(126.0);
                    for scope in [ResultSortScope::ShownResults, ResultSortScope::AllMatches] {
                        ui.selectable_value(&mut selected_scope, scope, scope.label());
                    }
                })
                .response
        });
        #[cfg(test)]
        RESULT_RENDER_PROBE.with(|probe| {
            if let Some(active) = probe.borrow_mut().as_mut() {
                active
                    .result
                    .header_controls
                    .push(("scope", scope_response.rect));
            }
        });
        paint_compact_combo_selected_text(ui, &scope_response, selected_scope.label());

        if selected != app.shell.runtime.result_sort_mode {
            app.select_result_sort_mode(selected);
        }
        if selected_scope != original_scope {
            app.set_result_sort_scope(selected_scope);
        }
    });
    if app.shell.runtime.result_sort_mode.uses_metadata()
        && app.shell.runtime.result_sort_scope == ResultSortScope::ShownResults
    {
        ui.weak(format!(
            "Sorting shown {} results only",
            app.shell.runtime.results.len()
        ));
    }
    app.render_empty_result_assistance(ui);
    let scroll_enabled =
        FlistWalkerApp::results_scroll_enabled(app.shell.ui.preview_resize_in_progress());
    let scroll_source = if scroll_enabled {
        egui::scroll_area::ScrollSource::SCROLL_BAR | egui::scroll_area::ScrollSource::MOUSE_WHEEL
    } else {
        egui::scroll_area::ScrollSource::NONE
    };
    let mut clicked_row: Option<usize> = None;
    let mut execute_row: Option<usize> = None;
    let prefer_relative = app.prefer_relative_display();
    app.ensure_highlight_cache_scope(prefer_relative);
    let row_height = result_row_height(ui);
    let total_rows = app.shell.runtime.results.len();
    // ScrollArea converts its salt to IdSalt before making the persistent ID. Match
    // that conversion: a different ID silently reads offset 0 and scrolls on every
    // upward step. Keep regression_results_cursor_round_trip_* paired with this.
    let scroll_area_id = ui.make_persistent_id(egui::IdSalt::new("results-scroll-area"));
    let mut scroll_area = egui::ScrollArea::both()
        .id_salt("results-scroll-area")
        .scroll_source(scroll_source)
        .auto_shrink([false, false]);
    if app.shell.ui.scroll_to_current() {
        if let Some(current) = app
            .shell
            .runtime
            .current_row
            .filter(|row| *row < total_rows)
        {
            // Regression guard: materialize an offscreen current row without pinning every
            // keyboard step to the viewport top. Do not replace this visibility clamp with
            // an unconditional row offset; keep it paired with regression_single_step_*.
            let row_stride = row_height + ui.spacing().item_spacing.y;
            let current_top = current as f32 * row_stride;
            let current_bottom = current_top + row_height;
            let viewport_height = ui.available_height().max(row_height);
            let previous_offset = egui::scroll_area::State::load(ui.ctx(), scroll_area_id)
                .unwrap_or_default()
                .offset
                .y;
            let next_offset = if current_top < previous_offset {
                current_top
            } else if current_bottom > previous_offset + viewport_height {
                current_bottom - viewport_height
            } else {
                previous_offset
            };
            scroll_area = scroll_area.vertical_scroll_offset(next_offset.max(0.0));
        }
    }
    let scroll_output = scroll_area.show_rows(ui, row_height, total_rows, |ui, visible_rows| {
        let row_width = ui.available_width().max(0.0);
        // Regression guard: only visible rows may clone paths or allocate widgets;
        // iterating the full result set here makes every frame O(total results).
        for i in visible_rows {
            let Some((path, _score)) = app.shell.runtime.results.get(i) else {
                continue;
            };
            let path = path.clone();
            let is_current = app.shell.runtime.current_row == Some(i);
            let (rect, response) =
                ui.allocate_exact_size(egui::vec2(row_width, row_height), egui::Sense::click());
            render_result_row(app, ui, rect, &path, is_current, prefer_relative);
            #[cfg(test)]
            let test_interaction = record_rendered_result_row(i, rect);
            #[cfg(test)]
            let test_clicked =
                matches!(test_interaction, TestResultRowInteraction::Click(row) if row == i);
            #[cfg(not(test))]
            let test_clicked = false;
            #[cfg(test)]
            let test_double_clicked = matches!(
                test_interaction,
                TestResultRowInteraction::DoubleClick(row) if row == i
            );
            #[cfg(not(test))]
            let test_double_clicked = false;
            if response.clicked() || test_clicked {
                clicked_row = Some(i);
            }
            if response.double_clicked() || test_double_clicked {
                execute_row = Some(i);
            }
        }
    });
    #[cfg(test)]
    RESULT_RENDER_PROBE.with(|probe| {
        if let Some(active) = probe.borrow_mut().as_mut() {
            active.result.scroll = Some((
                scroll_output.id,
                scroll_output.state.offset,
                scroll_output.inner_rect.intersect(ui.clip_rect()),
            ));
        }
    });
    #[cfg(not(test))]
    let _ = scroll_output;
    if let Some(i) = clicked_row {
        if app.shell.runtime.current_row != Some(i) {
            app.shell.tabs.mark_active_tab_meaningfully_engaged();
        }
        app.set_current_row(Some(i));
        app.request_preview_for_current();
        app.refresh_status_line();
    }
    if let Some(i) = execute_row {
        app.shell.tabs.mark_active_tab_meaningfully_engaged();
        app.set_current_row(Some(i));
        let open_parent_for_files = ui.input(|i| i.modifiers.shift);
        #[cfg(test)]
        if !record_result_action(i) {
            app.execute_result_row_for_activation(i, open_parent_for_files);
        }
        #[cfg(not(test))]
        app.execute_result_row_for_activation(i, open_parent_for_files);
    }
}

pub(in crate::app) fn selection_scroll_requested(
    ui: &egui::Ui,
    surface: &'static str,
    selection: egui::Id,
) -> bool {
    let frame = ui.ctx().cumulative_frame_nr();
    ui.ctx().data_mut(|data| {
        let key = egui::Id::new(("selection-scroll", surface));
        let previous = data.get_temp::<(egui::Id, u64)>(key);
        data.insert_temp(key, (selection, frame));
        previous.is_none_or(|(old, last_frame)| old != selection || last_frame + 1 < frame)
    })
}

#[cfg(test)]
#[derive(Clone, Copy, Debug)]
pub(in crate::app) struct ListScrollProbe {
    pub id: egui::Id,
    pub offset: egui::Vec2,
    pub viewport: egui::Rect,
    pub selected: Option<egui::Rect>,
}

#[cfg(test)]
pub(in crate::app) fn record_list_scroll(
    ctx: &egui::Context,
    surface: &'static str,
    id: egui::Id,
    offset: egui::Vec2,
    viewport: egui::Rect,
    selected: Option<egui::Rect>,
) {
    ctx.data_mut(|data| {
        data.insert_temp(
            egui::Id::new(surface),
            ListScrollProbe {
                id,
                offset,
                viewport,
                selected,
            },
        )
    });
}

pub(super) fn render_history_search_results(app: &mut FlistWalkerApp, ui: &mut egui::Ui) {
    ui.heading("History Results");
    ui.label(format!(
        "{} items in history, {} matches",
        app.shell.runtime.query_state.query_history.len(),
        app.shell.runtime.query_state.history_search_results.len()
    ));
    let follow_selection = selection_scroll_requested(
        ui,
        "history-search-results",
        egui::Id::new((
            app.current_tab_id(),
            &app.shell.runtime.query_state.history_search_query,
            app.shell.runtime.query_state.history_search_current,
        )),
    );
    #[cfg(test)]
    let mut selected_rect = None;
    let scroll = egui::ScrollArea::vertical()
        .id_salt("history-search-results")
        .animated(false)
        .scroll_source(
            egui::scroll_area::ScrollSource::SCROLL_BAR
                | egui::scroll_area::ScrollSource::MOUSE_WHEEL,
        )
        .auto_shrink([false, false])
        .show(ui, |ui| {
            let mut clicked_row: Option<usize> = None;
            let mut accept_row: Option<usize> = None;

            for (index, entry) in app
                .shell
                .runtime
                .query_state
                .history_search_results
                .iter()
                .enumerate()
            {
                let is_current =
                    app.shell.runtime.query_state.history_search_current == Some(index);
                let prefix = if is_current { "▶" } else { "·" };
                let text = format!("{prefix} {entry}");
                let selected_bg = render_theme::selected_fill(ui.visuals().dark_mode);
                let fill = if is_current {
                    selected_bg
                } else {
                    egui::Color32::TRANSPARENT
                };
                let row = egui::Frame::NONE
                    .fill(fill)
                    .inner_margin(egui::Margin::symmetric(3, 2))
                    .corner_radius(egui::CornerRadius::same(3))
                    .show(ui, |ui| {
                        ui.add(
                            egui::Label::new(egui::RichText::new(text).monospace())
                                .extend()
                                .sense(egui::Sense::click()),
                        )
                    });
                let response = row.inner;
                if is_current && follow_selection {
                    response.scroll_to_me(None);
                }
                #[cfg(test)]
                if is_current {
                    selected_rect = Some(response.rect);
                }
                if response.clicked() {
                    clicked_row = Some(index);
                }
                if response.double_clicked() {
                    accept_row = Some(index);
                }
            }

            if let Some(index) = clicked_row {
                app.select_history_search_result(index);
            }
            if let Some(index) = accept_row {
                app.shell.runtime.query_state.history_search_current = Some(index);
                app.accept_history_search();
            }
        });
    #[cfg(test)]
    record_list_scroll(
        ui.ctx(),
        "history-search-results",
        scroll.id,
        scroll.state.offset,
        scroll.inner_rect,
        selected_rect,
    );
    #[cfg(not(test))]
    let _ = scroll;
}

fn render_result_row(
    app: &mut FlistWalkerApp,
    ui: &egui::Ui,
    rect: egui::Rect,
    path: &Path,
    is_current: bool,
    prefer_relative: bool,
) {
    let is_pinned = app.shell.runtime.pinned_paths.contains(path);
    let kind = app.find_entry_kind(path);
    let display = super::display_path_with_mode(path, &app.shell.runtime.root, prefer_relative);
    let positions = app.highlight_positions_for_path_cached(path, prefer_relative);
    let job = build_result_row_job(
        ui,
        &display,
        positions.as_slice(),
        is_current,
        is_pinned,
        kind,
    );
    let selected_bg = render_theme::selected_fill(ui.visuals().dark_mode);
    if is_current {
        ui.painter().rect_filled(
            rect,
            egui::CornerRadius::same(FlistWalkerApp::RESULT_ROW_ROUNDING as u8),
            selected_bg,
        );
    }

    let inner_rect = rect.shrink2(egui::vec2(
        FlistWalkerApp::RESULT_ROW_H_MARGIN,
        FlistWalkerApp::RESULT_ROW_V_MARGIN,
    ));
    let galley = ui.painter().layout_job(job);
    let text_pos = FlistWalkerApp::result_row_text_pos(inner_rect, galley.size());
    ui.painter()
        .galley(text_pos, galley, ui.visuals().text_color());
}

fn build_result_row_job(
    ui: &egui::Ui,
    display: &str,
    positions: &[u16],
    is_current: bool,
    is_pinned: bool,
    kind: Option<EntryKind>,
) -> egui::text::LayoutJob {
    let marker_current = if is_current { "▶" } else { "·" };
    let marker_pin = if is_pinned { "◆" } else { "·" };
    let mut job = egui::text::LayoutJob::default();
    job.append(
        &format!("{} {} ", marker_current, marker_pin),
        0.0,
        egui::TextFormat {
            color: if is_current {
                egui::Color32::LIGHT_BLUE
            } else {
                ui.visuals().weak_text_color()
            },
            ..Default::default()
        },
    );
    let (kind_label, kind_color) = match kind.map(|k| k.display) {
        Some(display_kind @ EntryDisplayKind::Dir) => {
            ("DIR ", render_theme::entry_kind_color(display_kind))
        }
        Some(display_kind @ EntryDisplayKind::File) => {
            ("FILE", render_theme::entry_kind_color(display_kind))
        }
        Some(display_kind @ EntryDisplayKind::Link) => {
            ("LINK", render_theme::entry_kind_color(display_kind))
        }
        Some(display_kind @ EntryDisplayKind::Other) => {
            ("OTHR", render_theme::entry_kind_color(display_kind))
        }
        None => ("....", ui.visuals().weak_text_color()),
    };
    job.append(
        kind_label,
        0.0,
        egui::TextFormat {
            color: kind_color,
            ..Default::default()
        },
    );
    job.append(" ", 0.0, egui::TextFormat::default());

    for (idx, ch) in display.chars().enumerate() {
        let color = if FlistWalkerApp::is_highlighted_position(positions, idx) {
            render_theme::highlight_text_color()
        } else {
            ui.visuals().text_color()
        };
        job.append(
            &ch.to_string(),
            0.0,
            egui::TextFormat {
                color,
                ..Default::default()
            },
        );
    }
    job
}

pub(super) fn render_central_panel(app: &mut FlistWalkerApp, ui: &mut egui::Ui) {
    egui::CentralPanel::default().show(ui, |ui| {
        render_results_and_preview(app, ui);
    });
}

#[cfg(test)]
mod preview_render_tests {
    use super::*;
    use std::fs;

    #[test]
    fn delimited_column_colors_are_distinct_and_cycle_in_both_themes() {
        for dark in [false, true] {
            let colors = (0..8)
                .map(|column| preview_token_color(SyntaxTokenKind::Column(column), dark))
                .collect::<Vec<_>>();
            for (index, color) in colors.iter().enumerate() {
                assert!(!colors[..index].contains(color), "theme dark={dark}");
                assert_ne!(
                    *color,
                    preview_token_color(SyntaxTokenKind::Delimiter, dark),
                    "theme dark={dark}"
                );
                assert_eq!(
                    *color,
                    preview_token_color(SyntaxTokenKind::Column(index as u8 + 8), dark),
                    "theme dark={dark}"
                );
            }
        }
    }

    #[test]
    fn paged_preview_renders_only_visible_rows() {
        let path = std::env::temp_dir().join(format!(
            "flistwalker-preview-rows-{}.rs",
            std::process::id()
        ));
        let source = "fn row() {}\n".repeat(5_000);
        fs::write(&path, source).expect("write fixture");
        let mut document = PagedTextPreview::initial(&path, &|| false).expect("first page");
        while document.state() == PreviewPageState::More {
            document = document.read_more(&path, &|| false).expect("more page");
        }
        assert_eq!(document.line_count(), 5_000);
        let ctx = egui::Context::default();
        let mut rendered = 0;
        for _ in 0..2 {
            PREVIEW_RENDER_ROWS.with(|count| *count.borrow_mut() = Some(0));
            let _ = ctx.run_ui(
                egui::RawInput {
                    screen_rect: Some(egui::Rect::from_min_size(
                        egui::Pos2::ZERO,
                        egui::vec2(800.0, 480.0),
                    )),
                    ..Default::default()
                },
                |ui| {
                    let mut view = PagedPreviewView::default();
                    view.display_generation = 1;
                    render_paged_preview(ui, &document, &mut view);
                },
            );
            rendered = PREVIEW_RENDER_ROWS.with(|count| count.borrow_mut().take().unwrap_or(0));
        }
        assert!(
            rendered > 0 && rendered < 100,
            "rendered {rendered} of 5,000 lines"
        );
        fs::remove_file(path).expect("cleanup fixture");
    }
}
