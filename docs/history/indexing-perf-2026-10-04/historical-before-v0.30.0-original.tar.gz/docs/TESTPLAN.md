﻿# TESTPLAN

This file is the entry point for FlistWalker test planning. Detailed test strategy, TC tables, runner commands, manual procedures, and traceability are split by topic under `docs/testplan/`.

## Document Map
| Topic | Content |
| --- | --- |
| [Test Strategy and Levels](testplan/strategy-levels.md) | Scope, priority, unit/integration/manual/perf/sec levels |
| [Test Cases](testplan/test-cases.md) | TC ID table and related SP mapping |
| [Validation Matrix and Runner Commands](testplan/validation-matrix.md) | Change-type checklist, VM routing, and commands |
| [Release Validation Selection](testplan/release-validation.md) | Every-release gates, change-triggered checks and evidence reuse |
| [Validation Details](testplan/validation/) | Per-VM required, conditional, platform, and manual checks |
| [Regression Guards](testplan/regression-guards.md) | Defect-specific behavior, related tests, and future-change rules |
| [Manual Regression and Traceability](testplan/manual-regression-traceability.md) | Environment, manual self-update, diagnostics trace smoke, structural GUI smoke, later regression guards, traceability excerpt |

## Change-Type Checklist
Use the checklist in [Validation Matrix and Runner Commands](testplan/validation-matrix.md#change-type-checklist) before choosing commands. It maps common change intents such as docs-only edits, search contract changes, GUI orchestration, indexing, runtime config, release/update work, and supportability docs to the required docs, tests, and follow-up checks.

## ID Ordering
ID-bearing tables and normative sections SHOULD be kept in ascending ID order to make later insertions predictable. Suffix IDs such as `TC-003A` SHOULD be placed immediately after their parent ID. History, release notes, regression guards, and narrative examples MAY use chronological, risk, or topic order when that is clearer than numeric order.

## Validation Matrix
- Full matrix: [Validation Matrix and Runner Commands](testplan/validation-matrix.md)
- [VM-001 Docs only](testplan/validation/vm-001.md): affected doc diff review and `rg` ID/reference checks; Rust implementation untouched means `cargo test` is not required.
- [VM-002 App/UI orchestration](testplan/validation/vm-002.md): `cd rust && cargo test` plus focused render/GUI checks when relevant.
- [VM-003 Indexing path](testplan/validation/vm-003.md): `cd rust && cargo test` plus ignored perf tests for FileList / Walker indexing paths.
- [VM-004 Search/query contract](testplan/validation/vm-004.md): `cd rust && cargo test` and focused query GUI checks when relevant.
- [VM-005 CLI / build / release / updater](testplan/validation/vm-005.md): `cd rust && cargo test` plus release/update-specific checks.
- [VM-006 CI coverage gate / GUI validation docs](testplan/validation/vm-006.md): coverage command or script/parser checks as applicable.
- [VM-007 Supportability docs/templates](testplan/validation/vm-007.md): affected doc/template diff review and support wording checks.
- [VM-008 Runtime config bootstrap](testplan/validation/vm-008.md): `cd rust && cargo test` plus first-run/config precedence checks when relevant.
- [VM-009 CI reliability / pins / merge policy](testplan/validation/vm-009.md): all repository-tooling unit tests, repository contract, guardian fail-closed mode, workflow parse, Rust/audit regression, PR `CI Gate` / `CI Policy Guardian`, and repository-settings/protected-auto-merge evidence.
- [VM-010 Stateful endurance](testplan/validation/vm-010.md): deterministic fixed corpus/seed replay, invariant self-tests, quiescence, full Rust regression; add VM-002/003/009 when production orchestration/index/CI surfaces change.

## Docs-only Validation
For documentation-only restructuring, apply VM-001:
- review affected doc diff;
- scan ID/reference consistency with `rg`;
- confirm local Markdown links resolve;
- confirm the top-level SDD/TDD files link to the detail topic files.

## Action Authorization Verification
- TC-050 is the automated contract for the UI `Reject` / `Defer` precheck, lexical-or-resolved root worker preauthorization, immediate per-target recheck, fail-closed resolution handling, recording-executor call count, display/execution path separation, and partial completion.
- TC-051 adds Unix symlink-root and linked-target coverage, Windows link/junction-root/path-form coverage, plus the environment-dependent real-UNC evidence in [Manual Regression and Traceability](testplan/manual-regression-traceability.md#action-authorization-platform-evidence-tc-050--tc-051).
- An unavailable Windows junction or real-UNC environment is recorded as `not run`; it is not equivalent to passing evidence.

## Bounded Worker Scheduling Verification
- TC-150 through TC-153 fix the action/kind/index capacity arithmetic, accepted-only non-blocking dispatch, `Full`/`Disconnected` settlement, stale-before-I/O cancellation, RAII load accounting, lock boundaries, named worker ownership, 250ms shutdown budget, and structured load/correlation trace.
- Apply VM-002 to action/kind/runtime scheduling and VM-003 to index scheduling; TC-149 remains the independent background-index snapshot regression guard.

## Tab Ownership Transfer Verification
- TC-154 retains the allocation-preserving active/inactive ownership transfer and release-mode transition ceiling. TC-203 through TC-211 define startup precedence, explicit lifecycle/last-good snapshots, Active+Warm scheduling, ordered bounded request mailboxes, common live/closed LRU, engagement-qualified Recent Inactive retention, bounded reclaimer, and repeated native switching coverage.
- Apply VM-002 with focused tab owner tests; use both non-sparse and deliberately sparse fixtures for pointer/capacity identity, retain computed results across activation, and run the release-mode tab-transition latency fixture when the activation hot path changes.
- `tab_contract::query_payload_swap_preserves_every_tab_field_and_allocation_but_keeps_global_state` checks the canonical query payload, including Unicode/history/error fields, while keeping debounce and kill buffer app-global. `result_parity` compares active/background rows, ranking, counts, selection, errors and pending metadata across both sort scopes. `rust/tests/architecture_boundaries.rs` guards shared persistence and result-policy dependencies.

## Shared Persistence Verification

- TC-167/168 storage tests live in `rust/src/persistence/worker/tests.rs`; GUI restore and dialog tests remain in `app/tests/`.
- Preserve complete-document deserialization, malformed known-field fallback, unknown-field merge, public API round trips, test settings isolation, and the child-process writer's nonzero executed-test count when moving storage code.
- TC-167 also rejects unreadable/invalid/non-object merge bases before either settings file is written, retains queued history until repair, and verifies actual rollback after an earlier write succeeds. Fault tests cover failure before replacement and after replacement, including failure of both restore attempts with all original/rollback errors retained.
- Apply VM-008 to `rust/src/persistence/` changes and VM-002 when changing GUI save/restore adapters.

## GUI Evidence Axes
- `docs/GUI-TESTPLAN.md` is the procedure owner for GSM-001..013. Its report records Deterministic, Native interaction, and Liveness independently; process liveness and headless tests do not imply native interaction PASS.
- `scripts/gui-deterministic-scenarios.tsv` is the canonical nonzero owner-test inventory used by both platform wrappers.
- Headful smoke MUST launch only a fresh BaseDir-owned staged executable with isolated settings, the exact binary/ignore/sample allowlist, and no `.flistwalker-update*` artifact. External actions, clipboard mutation, network update checks, and live updater activation are not validation defaults.
- Windows `-ScriptedQueryProbe` extends the staged headful smoke with PID-bound visible-window responsiveness, Unicode query initialization, and isolated trace verification. It is not physical input focus, IME composition, Copy Path, Open/Reveal, or multi-display evidence.
- Apply VM-006 after changing the GUI plan/template, deterministic wrappers/inventory, fixture, or headful scripts; select its text/coverage/tooling branch. Plan/template text alone requires reference and selection review, not coverage or native execution.
- Routine releases use [Release Validation Selection](testplan/release-validation.md); required affected axes and prior evidence are reconciled rather than rerunning every GSM flow.

## Traceability (excerpt)
- Full excerpt: [Manual Regression and Traceability](testplan/manual-regression-traceability.md)
- TC-001 -> SP-001 -> DES-001 -> FR-001
- TC-003, TC-155 -> SP-003 -> DES-003 -> FR-003
- TC-010 -> SP-010 -> DES-009 -> FR-007
- TC-150, TC-151, TC-152, TC-153 -> SP-010 -> DES-006, DES-007, DES-009 -> FR-007, NFR-008
- TC-154, TC-203, TC-204, TC-205, TC-208, TC-209, TC-210 -> SP-010 -> DES-009 -> FR-007, NFR-009
- TC-205, TC-206, TC-207, TC-208, TC-209, TC-211 -> SP-010 -> DES-006, DES-007, DES-009 -> NFR-015
- TC-156 -> SP-007 -> DES-006 -> NFR-001
- TC-157 -> SP-014 -> DES-014 -> NFR-010
- TC-158, TC-159, TC-160, TC-171, TC-186, TC-187 -> SP-014 -> DES-014 -> FR-033
- TC-159, TC-160, TC-171, TC-186, TC-187 -> SP-014 -> DES-014 -> NFR-010
- TC-161 -> SP-001, SP-007 -> DES-001, DES-006 -> FR-034, NFR-001
- TC-006, TC-006A, TC-015, TC-162, TC-163, TC-164 -> SP-004, SP-006, SP-013 -> DES-004, DES-005, DES-006 -> FR-006, FR-009, NFR-011
- TC-165, TC-166 -> SP-001, SP-006 -> DES-005, DES-007 -> FR-010, NFR-012
- TC-167, TC-168 -> SP-016 -> DES-017 -> FR-011, FR-026, NFR-012
- TC-169 -> SP-006, SP-014 -> DES-005, DES-014 -> FR-035
- TC-172 -> SP-006 -> DES-005 -> FR-006
- TC-173 -> SP-010 -> DES-009 -> FR-036
- TC-174 -> SP-019 -> DES-020 -> FR-037
- TC-175 -> SP-020 -> DES-021 -> FR-038
- TC-176 -> SP-015 -> DES-016 -> FR-025
- TC-177 -> SP-006 -> DES-005 -> FR-006
- TC-178 -> SP-012 -> DES-012 -> NFR-005
- TC-198 -> SP-012 -> DES-012 -> NFR-005
- TC-180 -> SP-021 -> DES-022 -> FR-039
- TC-181, TC-182, TC-183, TC-184 -> SP-022 -> DES-023 -> NFR-013
- TC-185 -> SP-007 -> DES-006 -> NFR-001
- TC-186, TC-187 -> SP-014 -> DES-014 -> FR-033, NFR-010
- TC-188, TC-189 -> SP-014 -> DES-014 -> NFR-002, NFR-007, FR-033, NFR-010
- TC-190 -> SP-014 -> DES-014 -> FR-020, FR-023, CON-004
- TC-191 -> SP-014 -> DES-014 -> NFR-005, FR-020, NFR-010
- TC-192 -> SP-010 -> DES-009 -> FR-007, NFR-008
- TC-195, TC-197 -> SP-010 -> DES-009 -> FR-007, NFR-008
- TC-196 -> SP-014 -> DES-014 -> NFR-005, NFR-010
- TC-200 -> SP-014 -> DES-014 -> FR-020, NFR-010
- TC-193 -> SP-023 -> DES-024 -> FR-040, NFR-014
- TC-215 -> SP-006, SP-014, SP-018, SP-023 -> DES-005, DES-014, DES-019, DES-024 -> FR-032, FR-033, FR-040, NFR-010, NFR-014
- TC-201 -> SP-006, SP-010 -> DES-005, DES-009 -> FR-041
- TC-202 -> SP-014 -> DES-014 -> FR-033, NFR-010
- TC-194 -> SP-014 -> DES-014 -> FR-020, NFR-010
- TC-050, TC-051 -> SP-004 -> DES-004, DES-007 -> FR-009
- TC-056 -> SP-012 -> DES-012 -> NFR-005
- TC-074 -> SP-014 -> DES-014 -> FR-019
- TC-111 -> SP-016 -> DES-017 -> FR-026
- TC-145 -> SP-018 -> DES-019 -> FR-032

- TC-213 -> SP-002 -> DES-002 -> FR-042
- TC-214 -> SP-010 -> DES-009 -> FR-043
- TC-216, TC-217, TC-218 -> SP-024 -> DES-025 -> FR-028, FR-044
- TC-219, TC-220, TC-221, TC-222 -> SP-025 -> DES-026 -> FR-045, NFR-008

- TC-227 -> SP-026 -> DES-028 -> FR-048
