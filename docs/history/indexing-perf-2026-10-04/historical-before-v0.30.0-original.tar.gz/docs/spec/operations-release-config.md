﻿# Operations, Release, and Runtime Configuration Specification

## SP-012 CI / Release Security Hygiene
### Requirements
- MUST: required CI は Windows/macOS/Linux の release 対象 OS を version-addressed runner 世代、固定 Rust、full SHA Action、固定 CI tool version で継続検証し、hosted image version を run evidence に残す。番号付き hosted runner image 内の package drift は残存リスクとして扱う。
- MUST: tag release preflight は Linux/macOS/Windows native の各 job で `cargo test --locked` と `cargo clippy --locked --all-targets -- -D warnings` を実行し、OS 条件付き unused/dead code を release asset build 前に blocker として検出する。
- MUST: `master` 変更は PR と required `CI Gate` / `CI Policy Guardian` を経由し、required approving review は 0 件とする。PR ごとに rebase auto-merge と merge後branch削除を1回だけ登録し、merge commit と squash merge を禁止して linear history を要求する。ローカルcommitの境界・順序・message・authorは保持し、SHAとcommitter metadataの変更は許容する。各変更は、clean な local `master` で fetch、FF-only pull、current branch `master`、および `master == origin/master` を確認してから、最初のcommit前にfeature branchで開始しなければならない。auto-merge の実完了後は、active task が作業ツリーの clean 状態、記録済み PR 番号の `MERGED` 状態、`mergedAt`、base `master`、および削除候補と一致するhead branchを確認してから `origin/master` を fetch し、ローカル `master` を fast-forward 同期する。current branch `master` と `master == origin/master` を再確認した後、local feature branch は `master` に到達可能で他 worktree が使用していない場合だけ通常削除する。rebaseでSHAが書き換わり通常削除だけが拒否された場合に限り、対象が `master` 以外、同一PR identity、同期済みmaster、未使用worktree、`git rev-list --merges origin/master..refs/heads/<head-branch>` の空出力、および `git log --cherry-pick --right-only --no-merges origin/master...refs/heads/<head-branch>` の空出力を全て確認して、local feature branchだけを強制削除してよい。未マージ、dirty worktree、branch作成前または同期後の確認失敗、PR不一致、patch差分、feature branchのmerge commit、または branch 使用中では状態を変更せず停止する。feature branchは自由にpushでき、force-with-leaseは非保護feature branchに限る。`master` の直接push、force push、branch deletion、admin bypass、強制 reset、`master`へのrebase/merge、remote branch削除でgateまたは後処理を回避してはならない。
- MUST: `CI Gate` は CI policy、release 対象 OS test/build、clippy/coverage を集約する。任意階層の `Cargo.toml` / `Cargo.lock`、`rust/.cargo/audit.toml`、audit workflow、CI policy checker/test の変更では `cargo audit` も集約し、対象変更で audit が skipped の場合は失敗しなければならない。非対象変更の skipped は正常としてよい。
- MUST: heavy PR CIはLinuxのclippy/coverage jobに加え、macOS/Windows native matrixで`cargo clippy --locked --all-targets -- -D warnings`を実行し、platform cfg固有warningをtag作成前にblockする。
- MUST: native platform matrix、Windows GNU updater producer/E2E、clippy/coverageをskipできるのは、change detectionが成功し、base SHAが既知で、全変更が明示allowlist内のdocumentation `A`/`M`である場合だけとする。rename/delete、unknown path、base不明、diff失敗はheavy CI実行へfail closedする。`CI Gate`はheavy実行時に全対象jobの`success`、safe skip時に全対象jobの`skipped`を要求する。
- MUST: Windows GNU updater E2Eは専用`windows-gnu-updater-build` artifact producerにだけ依存し、無関係なnative matrix完了で直列化してはならない。platform test/build、coverage threshold、Universal/Fw E2E契約は維持する。
- MUST: accepted vulnerability advisory はcargo-auditがproject-local configとして自動読込する`rust/.cargo/audit.toml`に限定し、根拠・owner・review cadence・再評価 trigger を `docs/OSS_COMPLIANCE.md` に保持する。unmaintained warning は出力上で可視のままにする。
- MUST: workflow、Dependabot設定、toolchain、audit exception、CI policy checker/testはdefault branch版をimmutable trusted setとし、通常PRではrunner/action/tool version pinだけを変更可能にする。accepted advisoryを含む構造変更は設定snapshot、独立agent review、guardian requirementの一時解除と即時復元、protected-route再検証を伴うcontrolled rolloutでのみ行う。
- MUST: scheduled security audit は後日公開 advisory を検知し、失敗 issue を同じ run で作成または更新する。agent は 24 時間以内に分類する。
- MUST: latest runner/Rust canary は required gate と分離し、失敗 issue を同じ run で作成または更新する。agent は 7 日以内に分類する。
- MUST: canary failure/success、security notice、EOL/deprecation、dependency MSRV、hosted image drift を pin 更新検討 trigger とする。通常 promotion は scheduled canary 2 回連続成功と candidate `CI Gate` 成功を必要とし、security/EOL/deprecation 対応でも candidate gate を省略してはならない。
- MUST: workflow は least privilege permissions、job timeout、branch/PR concurrency を定義し、untrusted code を `pull_request_target` で実行してはならない。`CI Policy Guardian` に限り read-only `pull_request_target` を許可し、default branch の trusted policy だけを実行して PR policy blob を data として検査し、PR head checkout/実行、secret、cache、artifact を禁止する。Cargo cache は download data に限定し、tool binary と `rust/target` を共有してはならない。
- MUST: `x86_64-pc-windows-gnu` 向け release build は最終 `flistwalker.exe` に Windows icon resource を含み、Explorer 上で埋め込みアイコンを表示できなければならない。
- MUST: Windows release ZIP のarchive rootは`flistwalker.exe`、`README.txt`、`LICENSE.txt`、`THIRD_PARTY_NOTICES.txt`の4項目だけを含み、flat GitHub Release asset用のversion付きsidecar名をarchive内へ流用してはならない。
- MUST: draft release 作成後、macOS notarization は別工程で確認できる状態を維持する。
- MUST: notarization 環境が未整備な当面の間は、macOS 配布物の notarization 確認を publish 前提条件にしてはならない。その場合 publish 時は GitHub Release 本文の `Security` または `Known issues` に未 notarized である旨を明記しなければならない。
- SHOULD: release note / release template / release docs に checksum 検証手順と notarization の扱いを明記する。

### Regression Guard: fail-closed heavy CI classification

- Scenario: CI短縮のpath分類がdenylistまたは成功前提になると、rename/delete、unknown path、base SHA不明、diff failureでheavy CIを誤ってskipする。
- Expected Behavior: allowlisted documentation `A`/`M`だけがsafe skipとなり、その他はheavy CIを実行する。GNU E2Eは専用producer完了後に開始し、native matrix全体を待たない。
- Non-goals: test/coverage/audit/E2Eの削除、hosted runner queue時間の固定、trusted policy controlled rolloutの省略。
- Related Tests: `test_heavy_ci_change_classification_regression`, `test_heavy_ci_result_truth_table_regression`, `test_ci_contract_requires_fail_closed_heavy_ci_skip_regression`.

### Regression Guard: native release warning gate

- Scenario: release preflightのclippyをLinuxだけに限定すると、macOS/Windowsの`cfg`でのみunused/dead codeになるwarningがrelease build logへ残ってもworkflowが成功する。
- Expected Behavior: heavy PR CIのmacOS/Windows native jobと、Linux/macOS/Windows nativeの全release preflight jobがlocked clippyを明示的な安全な`bash` shellで実行する。trusted policy testは対象job内のblocking stepを一意かつ許可されたプロパティ行の完全一致で要求し、PR側clippyの非Linux条件/command欠落、release側clippyへのplatform限定condition/command欠落、`continue-on-error`、`|| true`やcustom shell/envなどのfailure握り潰し、stepの別job移動または重複を拒否する。
- Non-goals: 通常PRのcoverage jobをplatformごとに複製すること、hosted runner queue時間の固定、warningのallowlist化。
- Related Tests: TC-198、`test_ci_contract_requires_non_linux_native_clippy_before_merge_regression`、`test_release_contract_requires_clippy_on_every_native_preflight_platform_regression`.

### Preconditions / Postconditions
- Preconditions: CI、release workflow、runner/Rust/Action/tool pin、または repository merge policy を更新する。
- Postconditions: default branch の`scripts/check_ci_policy.py`を実行する`CI Policy Guardian`と`CI Gate`がrequired契約を検証し、security/latest driftは追跡issueへ接続される。
## SP-014 起動時自己更新
### Requirements
- MUST: release tag の候補 version は直前の公開 release version より厳密に新しくなければならず、同一または古い version を N-1 compatibility gate で拒否する。
- MUST: GUI 起動時に GitHub Releases の最新 version 確認を非同期 worker で実行し、UI スレッドをブロックしてはならない。
- MUST: TUI 起動時にも最新 version 確認を非同期 worker で実行し、入力ループをブロックしてはならない。candidate の受信は英語の手動更新案内だけを表示し、download/apply を開始してはならない。
- MUST: CLI からの更新適用は利用者が `--update` を明示した場合だけ開始し、`--check-update` と TUI 通知は installation state を変更してはならない。alias 由来の `--cli` は更新承認を追加も取消もしない。
- MUST: 現在 version より新しい release が存在する場合、利用者へ更新承認ダイアログを表示する。
- MUST: Windows/Linux の自動更新対象は、現在実行中バイナリに対応する standalone asset と `SHA256SUMS` / `SHA256SUMS.sig` に限定する。
- MUST: OS/CPU architecture の自動更新可否は asset lookup より前に判定し、対応外 architecture と macOS の candidate は release metadata と手動更新案内だけを持ち、download URL/name を含む install payload を持ってはならない。対応外 CPU を x86_64 asset 名へ仮装してはならない。
- MUST: Windows/Linux の自動更新では、standalone asset に対応する sidecar `*.LICENSE.txt` と `*.THIRD_PARTY_NOTICES.txt` も取得し、更新後の実行バイナリと同一ディレクトリへ `LICENSE.txt` / `THIRD_PARTY_NOTICES.txt` として配置しなければならない。
- MUST: Windows/Linux の自動更新では、standalone asset に対応する sidecar `*.README.txt` も取得し、更新後の実行バイナリと同一ディレクトリへ `README.txt` として配置しなければならない。
- MUST: release metadata は 2 MiB、`SHA256SUMS` は 1 MiB、`SHA256SUMS.sig` は 64 KiB、standalone binary は 512 MiB、各 sidecar は 16 MiB の decoded byte 上限を持ち、`Content-Length` の有無や値にかかわらず streaming reader が実受信 byte 数を強制しなければならない。
- MUST: 接続 timeout は 10 秒、無通信 timeout は 30 秒、1 request の deadline は 5 分、update staging 全体の monotonic deadline は 10 分とし、timeout/deadline 到達時は更新を中止しなければならない。
- MUST: redirect は最大 3 hop を明示処理し、production は HTTPS かつ `api.github.com`、`github.com`、または `*.githubusercontent.com` のみに制限しなければならない。開発・自動試験だけは loopback HTTP を許可してよい。
- MUST: 先に `SHA256SUMS` と `SHA256SUMS.sig` だけを取得し、埋め込み公開鍵で署名を検証してから配布 asset を取得しなければならない。manifest はASCIIの64桁hex digest、正確に2つのspace、単一の安全なfilenameからなる厳密な行文法を使い、`FlistWalker-` または `fw-` で始まる release asset basename 以外の未知/近似prefix、空manifest、path separator、空白、重複、無効digestを拒否しなければならない。
- MUST: 署名検証通過後、対象 binary と全 sidecar を private create-new file へ streaming download しながら SHA-256 を計算し、manifest と一致した完全な bundle だけを `VerifiedUpdateBundle` として activation へ渡さなければならない。
- MUST: staging 失敗時は main process がこの要求で create-new した partial file と staging directory だけを helper 起動前に削除し、既存 path を cleanup 対象にしてはならない。
- MUST: activation 準備は現在 executable の canonical parent 内の固定派生名を使い、target、`.new`、backup、lock、marker が directory、symlink、Windows reparse point、または parent 外である場合は更新を開始してはならない。
- MUST: 1 個の create-new active lock と versioned durable marker で transaction を排他し、marker は transaction/parent/helper identity、global phase、各 target の存在・旧新 hash・`prepared|intent|applied|rolled_back` 状態を write-ahead で記録しなければならない。
- MUST: helper は parent が durable `helper_registered` phase と helper identity を記録したことを確認し、create-new acknowledgement を同期するまで filesystem mutation を行ってはならない。parent は acknowledgement を検証するまで適用開始を通知せず、本体終了を許可してはならない。
- MUST: GUI の native close または signal shutdown が update check/staging 中に要求された場合、同じ per-request cancellation token を設定して root viewport close を保留しなければならない。install state は `CancelableStaging`、`CommitHandoff`、`Terminal` を区別し、`prepare_transaction` 直前に `CommitHandoff` へ入った後は cancellation を無視して helper acknowledgement まで完遂し、`ApplyStarted`、pre-handoff `Canceled`、または `Failed` の terminal 応答後だけ close を再送しなければならない。強制終了・電源断は durable recovery の対象とする。
- MUST: helper 起動は installation directory を child current directory に固定してはならない。Windows の hidden updater child は entrypoint subsystem や利用可能な console handle の有無に依存せず stdin/stdout/stderr を `NUL` へ固定し、launcher/test 由来の無効または stale 標準 handle を継承してはならない。helper 起動は最大3ラウンド、ラウンド間100msの bounded retry とし、canonical helper path が `\\?\` / `\\?\UNC\` 形式なら各ラウンドで同一 path の非 verbatim 表現も試さなければならない。全試行失敗の通知は各 OS error を保持しつつ利用者向け path から `\\?\` を除去しなければならない。
- MUST: helper は acknowledgement 後に旧 process の終了を最大 30 秒待ち、timeout を binary commit 前失敗として扱わなければならない。
- MUST: sidecar を先に適用し、binary 置換を唯一の commit point として最後に行わなければならない。Windows の既存 target は同一 volume の native `ReplaceFileW(target, new, backup, 0, null, null)` を updater process 内で使い、Linux の既存 target は create-new backup の同期後に同一 directory rename を使い、不在 target は同一 directory の no-overwrite hard-link promotion と source unlink を使わなければならない。
- MUST: binary commit 前の失敗と新 process の生成失敗では、元から存在した target を検証済み backup から復元し、元から無かった target を削除して旧 bundle の hash を確認しなければならない。
- MUST: Windows の更新後 process 起動は最大3ラウンド、ラウンド間100msの bounded retry とし、canonical target が verbatim drive/UNC形式なら各ラウンドで同一 path の非verbatim表現も試さなければならない。GUI restart は生成後500ms以内に終了した process を起動失敗として扱い、新版起動失敗時は旧 bundle へ rollback して同じ起動契約で旧GUIを再起動しなければならない。新版と旧版の起動が両方失敗した場合は、両方の診断を失わず helper failure として終了しなければならない。
- MUST: 起動時 recovery は marker phase と旧新 hash から precommit rollback、完全な committed bundle、rolled-back bundle のいずれかへ収束させなければならない。live 登録 helper が存在する transaction と同時に回復してはならず、欠落 backup、hash 不一致、不正 state 遷移、path/type 変化は ambiguous として証跡を保持し、新しい update を開始してはならない。ambiguous state の利用者向け案内は [UPDATER_RECOVERY.md](../UPDATER_RECOVERY.md) へ誘導し、未検証 artifact の削除、改名、上書きを自動または一般手順として勧めてはならない。
- MUST: 通常のGUI/CLI起動時recoveryは最大5秒で`Deferred`を返して起動を長時間ブロックしてはならず、live helperのexecutable identityを確認できない場合は`Ambiguous`として証跡を保持しなければならない。一方、helperが起動する更新後processはrestart mode別の内部flagでcleanup handoff ownerであることを識別し、validated terminal markerのhelper PIDだけを対象にartifact無変更で最大30秒のbounded exit waitを行い、live中の一時的なidentity照会失敗でhandoffを中断してはならない。helper終了後はmarker identity/phaseを再検証し、通常のhash/classification recoveryでcommitted/rolled-back transactionをterminal cleanupへ収束させなければならない。GUI modeは回復完了後に内部flagを公開CLI引数へ渡さず通常GUIを続行し、Headless modeは回復後に終了する。30秒後も`Deferred`なら正常終了として扱ってはならない。この契約はUniversalと`fw`で共通とする。
- MUST: hidden helper の transaction/restart failure は、marker、transaction ID、helper PID/token/path/hash を検証済みの transaction context からだけ固定 basename の versioned diagnostic record として最大 16 KiB で永続化してよい。control character を sanitize し、利用者向け文字列の共有表示境界で文中の全 `\\?\` / `\\?\UNC\` prefix を除去し、create-new temporary file と atomic no-overwrite promotion を使い、symlink/reparse/wrong type を拒否し、診断記録失敗で rollback または元 error を置き換えてはならない。rollback 後に旧 binary を再起動する場合は、その process が起動診断を読むより前に record を publish しなければならない。信頼済み install directory を確定する前の failure は永続化対象外とする。
- MUST: 起動時は diagnostic record を bounded read して一度だけ消費し、通常の抑止可能な update-check failure と分離した `Previous Update Failed` modal へ表示しなければならない。
- MUST: 検証では Windows/Linux の同一 filesystem 上にある inert dummy file だけを使い、実行中 FlistWalker binary の置換または外部 application の起動を行ってはならない。
- SHOULD: 署名公開鍵が埋め込まれていない開発用ビルドでは、自動更新を manual-only として扱える。
- MUST: macOS では新しい release を検知しても自動置換を試みず、手動更新が必要であることを通知する。
- MUST: 更新ダイアログは、現在提示中の target version を「次のバージョンが出るまで表示しない」として抑止できなければならず、この抑止状態は起動間で保持されなければならない。
- MUST: 抑止済み target version 以下の更新候補は次回起動以降も再表示してはならず、より新しい version を検知した場合のみ再び更新ダイアログを表示しなければならない。
- MUST: 起動時の更新確認が失敗した場合、失敗理由を利用者へ確認できる軽量ダイアログを表示しなければならない。ただし通常の検索/操作は継続可能でなければならない。
- MUST: 更新候補の承認後に staging、manifest、signature、checksum、network、または activation が失敗した場合、提示中の `Update Available` を閉じ、現在の installation が変更されていないこと、失敗詳細、候補 release URL、および可能な場合は同一 variant の binary と checksum manifest を使う手動復旧手順を専用ダイアログへ表示しなければならない。同じ失敗後に `Update Available` だけを再表示してはならない。
- MUST: update worker 応答は request_id で相関し、stale 応答が新しい prompt / failure / install_started 状態を上書きしてはならない。
- MUST: update check / install が失敗、抑止、または supersede された場合、pending / in_progress 状態は解放され、通常操作を継続できなければならない。
- SHOULD: 上記の起動時更新確認失敗ダイアログは、「今後この種の起動時エラーを表示しない」として抑止でき、この設定は起動間で保持される。
- MUST: `FLISTWALKER_DISABLE_SELF_UPDATE` が truthy な場合、または実行中バイナリと同一ディレクトリに `FLISTWALKER_DISABLE_SELF_UPDATE` というファイルが存在する場合、起動時の更新確認、更新ダイアログ表示、更新適用開始を行ってはならない。
- MUST: 手動試験用 override 環境変数（更新 feed URL 差し替え、同一 version 許可、downgrade 許可）は内部検証専用とし、README、release note、配布物、ユーザ向けヘルプへ露出してはならない。
- SHOULD: 内部検証用に `FLISTWALKER_FORCE_UPDATE_CHECK_FAILURE` を受け付け、起動時更新確認を意図的に失敗させて失敗ダイアログを強制表示できる。
- SHOULD: 更新チェック失敗やダウンロード失敗は通常の検索/操作を妨げない。
- SHOULD: 手動試験のために、更新 feed URL 差し替え、同一 version 許可、downgrade 許可を環境変数で上書きできる。

### Preconditions / Postconditions
- Preconditions: GUI/TUI の自動確認、または明示的な CLI 更新操作で起動し、ネットワーク経由で GitHub Releases へ到達可能。
- Postconditions: 新版が無ければ何も変更せず、新版があれば承認後に検証済み bundle 全体が置換・再起動される。失敗または中断時は検証済み旧 bundle へ戻るか、完全な新 bundle を保持するか、曖昧状態を変更せず停止する。

### Edge / Error
- GitHub API 失敗、timeout/deadline、redirect/origin 違反、上限超過、manifest 不正、asset 欠落、checksum 不一致は更新失敗として通知し、現行バイナリで継続する。
- transaction lock/marker 衝突、helper acknowledgement 不成立、parent wait timeout、backup/atomic primitive 不成立、recovery ambiguity は fail closed とし、既存 installation と recovery 証跡を変更しない。
- 対応外 OS/arch は新版検知のみ行い、自動更新非対応の案内だけを返す。

### Regression Guard: windows-updater-in-process-replace
- Scenario: Windows updater が marker と target の原子的置換ごとに `powershell.exe` を外部起動し、更新中にターミナルが何度も表示されるか、一時的な process 起動失敗で適用が失敗する。
- Expected Behavior: Windows の既存 target 置換は updater process 内の `ReplaceFileW` だけで行い、`powershell.exe` の存在や `PATH` に依存しない。backup あり/なし、失敗時の source 保持、verbatim/UNC を含む非 lossy UTF-16 path、interior NUL 拒否を維持する。
- Non-goals: antivirus、権限、別 process による file lock 自体の解消、production binary を使った live update の自動試験。
- Related Tests: TC-158, TC-159, TC-160, TC-171; `tc171_regression_windows_file_replace_*`.
- Notes for Future Changes: 外部 shell/process に戻す、Windows path を lossy 変換する、または `ReplaceFileW` の target/source/backup 順を変更する場合は paired regression tests と VM-005 を同一変更で更新する。

### Regression Guard: windows-updater-helper-spawn-path
- Scenario: Windows の長い installation directory で canonical path が `\\?\` 形式になり、helper 起動時に同じ長い directory を child current directory に指定すると、実行ファイル自体は有効でも `CreateProcessW` が失敗する。
- Expected Behavior: helper は parent の current directory を継承して起動し、最大3ラウンドの各ラウンドで verbatim path と非 verbatim の同一 path を順に試す。起動失敗で parent 所有 transaction を破棄して次回試行を妨げず、最終エラーには全ラウンドの OS error を含めるが `\\?\` / `\\?\UNC\` を表示しない。
- Non-goals: directory の実行権限不足、antivirus/WDAC による executable block、別 process の file lock を迂回すること。
- Related Tests: TC-179, TC-187; `tc179_regression_helper_launch_does_not_force_install_directory_as_current_dir`, `tc179_regression_windows_helper_launch_retries_without_verbatim_prefix`, `tc179_regression_windows_helper_spawn_error_hides_verbatim_prefix`, `tc179_regression_failed_helper_launch_cleanup_allows_a_fresh_prepare`, `tc187_regression_windows_helper_retry_rounds_include_verbatim_fallback`.
- Notes for Future Changes: helper の working directory、Windows path spelling、retry、または spawn error の組み立てを変更するときは TC-179、TC-187、VM-005 の sandbox self-update を同一変更で確認する。

### Regression Guard: windows-updater-hidden-child-stdio
- Scenario: Windows GUI-subsystem process、console なし launcher、または無効/stale standard handle を持つ test process が、既定の stdio 継承で copied helper を起動すると、standard handle の複製に失敗し、GUI の自己更新だけが一過性または継続的に失敗する。
- Expected Behavior: helper と更新後/rollback後 process の hidden `Command` は stdin/stdout/stderr を明示的に `NUL` へ接続する。通常 helper path の一過性起動失敗は最大3ラウンド・100ms間隔で再試行し、GUI/CLI の restart mode と transaction acknowledgement 順序は維持する。
- Non-goals: antivirus/WDAC の永続的な executable block の迂回、外部 application の標準入出力変更、production binary を置換する自動試験。
- Related Tests: TC-187; `tc187_regression_hidden_updater_child_does_not_inherit_stale_stdio`, `tc187_regression_windows_helper_retries_transient_normal_path_failure`, `tc187_regression_windows_helper_retry_rounds_include_verbatim_fallback`.
- Notes for Future Changes: Windows executable subsystem、hidden updater child の stdio/window flag、または helper retry を変更するときは TC-187 の native subprocess probe、TC-191 の Universal/Fw copied-sandbox E2E、VM-005 を同一変更で確認する。

### Regression Guard: windows-updater-restart-handoff
- Scenario: Windows の更新で新版 process の生成が一過性に失敗し、旧 bundle への rollback 後に行う旧GUIの単発再起動も失敗すると、installation は安全に旧版へ戻っていても画面が再表示されず、利用者が手動起動するまで停止する。
- Expected Behavior: 新版とrollback後の旧版は、最大3ラウンド・100ms間隔、verbatim path時の非verbatim代替を含む同じbounded restart契約を使い、起動元のrestart modeを維持する。Universal GUIはGUI、`fw --update`はHeadlessとして旧版を再起動する。GUI childが500ms以内に終了した場合も再試行し、全試行失敗時は新版と旧版の両エラーを保持する。
- Non-goals: antivirus/WDACや権限設定を迂回すること、500ms経過後の任意時点のGUI crashを完全検出すること、production binaryを置換する自動試験。
- Related Tests: TC-159, TC-160, TC-186; `tc186_regression_windows_restart_retries_a_transient_spawn_failure`, `tc186_regression_windows_restart_retries_without_verbatim_prefix`, `tc186_regression_windows_restart_exhaustion_is_bounded_and_diagnostic`, `tc186_regression_new_and_old_restart_failures_are_both_reported`.
- Notes for Future Changes: restart attempt数、待機時間、path表現、GUI startup grace、rollback後の再起動error処理を変更するときはTC-186とVM-005を同一変更で確認し、旧版復旧を単発・silent failureへ戻さない。

### Regression Guard: restart-cleanup-handoff

- Scenario: helperが新版を`binary_committed/applied`へ更新してGUIを生成した直後、新GUIの通常startup recoveryがlive helperの一時的なexecutable identity照会失敗を`Ambiguous`と判定し、更新済みversionであるにもかかわらず`Previous Update Failed`を表示する。またはHeadless childが`Deferred`のまま終了してcleanup ownerが消える。
- Expected Behavior: helperが起動するGUI/Headless processはmode別の内部restart flagを公開引数解析より前に処理し、validated terminal markerのhelper PID終了をartifact無変更で最大30秒待つ。終了観測後にmarkerとbundle hashを再検証してcleanupし、GUIだけ通常画面へ進む。更新診断とGUI noticeは共有文字列表示境界を通り、drive/UNC pathが文中に複数あっても`\\?\`を表示しない。
- Non-goals: 通常起動の5秒上限やfail-closed identity判定の緩和、live helperとの同時artifact変更、30秒を超えて停止したhelperの強制終了、filesystem APIへ渡すverbatim pathの変更。
- Related Tests: TC-159、TC-189、TC-191、TC-202、`tc159_headless_restart_handoff_outlives_normal_startup_deadline_regression`、`tc159_headless_handoff_waits_through_transient_helper_identity_failure_regression`、`tc202_regression_gui_restart_uses_internal_recovery_handoff`、`tc202_regression_failure_record_hides_embedded_windows_verbatim_prefixes`、`tc202_regression_display_text_strips_all_embedded_verbatim_path_prefixes`、`tc202_regression_status_notice_hides_embedded_verbatim_paths`。
- Notes for Future Changes: internal restart flag、process entry dispatch、startup recovery deadline、helper lifetime、failure/notice表示を変更するときはTC-202のfocused testとWindows GNU Universal/Fw E2Eを同一変更で実行する。

### Regression Guard: mixed-family updater feed isolation

- Scenario: Universalと`fw`のloopback feed assetが同一payload/hashだとwrong-family asset selectionでも最終hash検証が成功し、family discriminatorの回帰を検出できない。また対象外familyのbinary/sidecarがsandboxに無いとcross-family mutationを検出できない。
- Expected Behavior: 各fresh sandboxは対象assetとcounterpart assetに異なる有効PE overlay/hashを持ち、installed binaryは対象hashとだけ一致する。対象外familyのbinaryと3 sidecarをsentinelとしてseedし、更新後も全hashが不変であることをUniversal→Fwの連続signed E2Eで確認する。
- Non-goals: 1transactionで両familyを更新すること、公開release assetの変更、test signing keyをsandbox childへ渡すこと。
- Related Tests: TC-191、`test_manual_self_update_cleanup_and_signing_environment_are_fail_closed`、Windows GNU updater E2E。
- Notes for Future Changes: mixed feedの両assetを同一copyへ戻さず、wrong-family選択が必ずinstalled hash mismatchになる識別力を維持する。

## SP-015 Ignore List フィルタ
### Requirements
- MUST: 実行中 binary と同じフォルダにある `flistwalker.ignore.txt` を ignore list ファイルとして読み取れる。
- MUST: ignore list ファイルは 1 行 1 ルールを基本とし、空行と `#` コメント行を無視しなければならない。
- MUST: ignore list は UTF-8 と任意の先頭 UTF-8 BOM、LF/CRLFを同じterm列として解釈し、path separatorの `/` と `\\` をplatform間で同じliteral pathとして比較しなければならない。
- MUST: 検索クエリの `!` 除外は fuzzy fallback を使わず、literal substring / `^` 先頭 / `$` 末尾の一致で候補を除外しなければならない。
- MUST: ignore list の各ルールは、検索クエリの `!` 除外と同じ非 fuzzy の比較ルールで候補を除外しなければならない。
- MUST: GUI は `Use Ignore List` チェックボックスを提供し、既定で有効にしなければならない。
- MUST: GUI で `Use Ignore List` を切り替えた frame は committed candidate 全件を同期 scan/clone してはならない。変更は request identity 付きの bounded index refresh へ渡し、active/background tab のいずれでも既存の表示 snapshot と現在の result sort mode/scope を維持したまま増分 filter と terminal settlement を行わなければならない。非 Score sort では、増分到着順の未sort結果や別世代の件数を表示せず、同期sortまたは bounded sort/search worker の結果を適用できるまでsort済みlast-good snapshotとその件数を維持しなければならない。空queryのAllMatches sortはlimit適用前の全候補をworkerでsortしなければならない。sort/search worker が利用不能ならlast-goodを維持して失敗を表示し、stale応答で置換してはならない。
- MUST: チェックボックス有効時は、ignore list に一致する候補を検索結果と空クエリ表示から除外しなければならない。
- MUST: チェックボックス無効時は、ignore list の除外を適用してはならない。
- MUST: batch CLI とTUIは既定sidecarと `--ignore-file` の同じdecoder/matcherを使い、FileList/Walker、空query/非空queryのどの経路でも除外を適用しなければならない。

### Preconditions / Postconditions
- Preconditions: 実行中 binary のフォルダに ignore list ファイルが存在する、または空/未存在である。
- Postconditions: ignore list に一致する候補は、既定有効時に一覧から除外される。

### Edge / Error
- ignore list ファイルが存在しない、または空なら空termとして正常継続する。CLI/TUIでは、存在する既定sidecarまたは明示fileが読めない、もしくはUTF-8不正なら除外なしで続行せず明示errorにする。
- 1 つのルールが他のルールにマッチしなくても、残りのルールは継続して評価する。

### Regression Guard
- 発生条件: `Use Ignore List` が有効で、`Files` / `Folders` が両方有効な既定状態のまま `all_entries` の高速経路を通ると、ignore 判定が省略されて `old` や `~` を含む候補が結果へ戻る。
- 期待動作: ignore list は空クエリ表示と検索結果の両方で維持され、`Files` / `Folders` 両有効でも literal に一致する除外候補は表示されない。fuzzy でだけ一致する候補は除外しない。
- 非対象範囲: `Use Ignore List` を無効化した場合の候補除外。
- 関連テストID: TC-110, TC-112, TC-117, TC-176.

## SP-016 Runtime Config Bootstrap
### Requirements
- MUST: UI-state 保存は既存文書と merge 後文書の既知フィールド型を検証し、型不正時は関連ファイルを変更してはならない。起動時に既存 UI-state の読込が失敗した process は、修復後も再起動まで full autosave と settings commit を停止し、default fallback で既存設定を上書きしてはならない。
- MUST: autosave の受理待ちと失敗後の保留を合わせて有限件数に制限する。満杯時は非同期受付を拒否し、GUI は最新 dirty snapshot を再送する。拒否した履歴を送信済み baseline へ進めてはならない。受理順の patch と履歴を保持し、保存成功と単なる受理を区別する。
- MUST: GUI は保存失敗を編集がなくても表示し続け、保存復旧を反映する。古い保存完了で新しい未受理変更や失敗を消してはならない。shutdown flush の失敗も診断へ残す。
- MUST: ツールは runtime config file と関連する永続化ファイルを、Windows では `%LocalAppData%\flistwalker\`、Linux/macOS では `~/.flistwalker/` へ保存しなければならない。
- MUST: runtime config file は Windows では `%LocalAppData%\flistwalker\.flistwalker_config.json`、Linux/macOS では `~/.flistwalker/.flistwalker_config.json` を使わなければならない。
- MUST: Windows の旧バージョンで実行ファイル横または home directory に残っている同名ファイル、Linux/macOS の旧バージョンで home directory 直下に残っている同名ファイルは、新しい保存先に同名ファイルが存在しない場合に限り、新しい保存先へ移行しなければならない。
- MUST: runtime config の legacy 移行、初回 seed、および GUI 設定 open 時の不足 file 生成は current path の sidecar lock で協調 writer を直列化し、lock 取得後に current を再確認しなければならない。先に current が確定した場合はそれを採用し、legacy、seed、または起動時の実効 config で上書きしてはならない。rename 不可時は legacy bytes を同一ディレクトリの create-new temporary fileへ完全書込み・同期してから atomic replace し、昇格失敗時は partial current を残さず legacy を保持しなければならない。
- MUST: runtime config file が存在しない場合、ツールは有効な GUI、batch CLI、interactive CLI、`--list-saved-roots`、`--create-filelist` の dispatch 前に現在の `FLISTWALKER_*` 環境変数を seed にした runtime config file を自動生成しなければならない。内部 update helper と引数検証失敗は bootstrap 対象外とする。
- MUST: 自動生成される runtime config file には、一般利用者が調整してよい `walker_max_entries`、`history_persist_disabled`、`restore_tabs_enabled`、`emacs_keybindings_enabled`、`tab_pin_moves_to_next_row`、`filelist_auto_check_enabled` を既定値で含めなければならない。
- SHOULD: 既存 runtime config file に上記 5 項目が欠けている場合、読み込み時に現在の実効値で項目を補完して書き戻す。書き戻しは current path の sidecar lock を取得して最新 JSON を再読込した後に行い、並行して成功した設定保存を古い snapshot で上書きしてはならない。
- MUST: runtime config file が存在する場合、ツールはその内容を runtime settings の source of truth として適用し、同名環境変数は seed としてのみ扱わなければならない。
- MUST: shared persistence は default/saved-root の read-only access と query-history mutation を分離する。`history_persist_disabled` が true のとき、history load/save と history diagnostic text は no-op とする。
- MUST: history writer は full snapshot ではなく ordered、trimmed、nonempty delta を submit する。cross-process sidecar lock の下で latest JSON を reread し、各 delta を exact duplicate removal、most-recent append、front trim 100 entries の順で適用する。serialized writers が別 query を追加した場合は commit order で両方を保持する。
- MUST: GUI/TUI frame code は `UiStatePatch + history_delta` を enqueue するだけとする。non-history leaf は last-write-wins、history delta は enqueue order で全て concat し、unknown top-level/nested JSON field は保持する。lock timeout/write failure は exact coalesced patch/delta を retry 用に保持し、successful commit はその generation だけ clear する。
- MUST: UI-state の保存前再読込は、ファイル未存在の場合だけ空 object を初期値とする。既存ファイルの read/UTF-8 failure、不正 JSON、object 以外の JSON は保存エラーとし、UI-state と関連する saved-roots の bytes を変更してはならない。通常の pending patch/history delta は保持し、ファイルが修復された後の再試行で最新 object へ merge する。明示 settings commit は request identity 付きエラーを返して再操作可能とする。起動時 reader の default fallback は既存ファイルの上書きを許可するものではない。
- MUST: bounded lock wait、path canonicalize、latest-read merge、UI state / saved roots の atomic write は persistence worker が行い、frame dispatch を block してはならない。利用者が確定を要求する settings commit は request identity 付きの結果を返し、関連する複数ファイルの一方が失敗した場合は確定前の内容へ戻すか、rollback failure を明示する。replace 後の directory sync failure は該当 file を変更済みとして rollback し、元の durability error と rollback error の両方を保持しなければならない。opt-in window trace は bounded queue へ non-blocking enqueue し、満杯時は diagnostics event を破棄して UI frame を待たせない。graceful shutdown は frame rendering 外で bounded flush を要求する。crash-before-flush history loss と trace queue overflow による diagnostics loss は residual risk とする。
- MUST: runtime config file には search parallelism、walker limits、window trace settings、query history persistence、tab restore、Emacs 風 keybindings、Tab pin movement、update policy を含めなければならない。GUI/TUI の通常 Walker index は同じ `walker_max_entries` と adaptive initial/max limit を参照しなければならない。
- MUST: GUI は runtime config file を開く設定ボタンを提供し、押下時に config file が存在しない場合は生成してから OS 既定アプリケーションで開かなければならない。既定アプリケーションで開けない場合は、標準的なテキストエディタ相当のフォールバックを試行しなければならない。
- MUST: GUI設定openは単一workerでpath解決・不足file生成・OS openを実行し、UI dispatchを待機させない。受理から完了まで重複要求を抑止して処理中を表示し、失敗後は再試行できる。不足 file 生成は sidecar lock 内の再確認後だけ行い、file生成には起動時の実効configを使い、設定を開く操作でprocess envへ再適用してはならない。
- SHOULD: runtime config file は手動追記された `developer` セクションを読み取れる。ただし `developer` セクションは自動生成 config seed に含めてはならず、公開 README や通常ヘルプで案内してはならない。
- MUST: runtime config file の読み込みや自動生成に失敗しても、ツールは通常起動を継続しなければならない。
- SHOULD: runtime config file の読み込み失敗や自動生成失敗は、利用者または診断ログへ警告として出力する。

### Preconditions / Postconditions
- Preconditions: current settings base directory が解決できる、または解決できない場合は config file を生成しない。
- Postconditions: runtime config file が存在する場合、その設定は起動時に process env へ反映されたうえで既存の env 読み取り経路へ伝播する。

### Edge / Error
- runtime config file が破損していても、ツールは安全に default / current env へフォールバックできる。
- seed-only 挙動のため、runtime config file が作成済みの場合は後から環境変数を変えても runtime settings は変化しない。
- sidecar lock は FlistWalker の協調 writer 間の優先順位を保証する。lock を使わない外部 writer が再確認と atomic replace の間に介入する TOCTOU は residual risk とする。
- Windows の `%LocalAppData%\flistwalker\`、Linux/macOS の `~/.flistwalker/` にある UI state / saved roots / window trace の各ファイルは、同じ保存先ルールで扱う。

## SP-017 Release Sample Ignore List
### Requirements
- MUST: ツールは ignore list sample を埋め込み、起動時に `flistwalker.ignore.txt.example` が実行中 binary と同じフォルダに存在しない場合は sample を自動生成しなければならない。
- MUST: sample は `flistwalker.ignore.txt` にリネームして live ignore list として使えることを利用者へ明示しなければならない。
- MUST: 既存の `flistwalker.ignore.txt` が存在する場合、sample 配置は既存 ignore list を上書きしてはならない。
- SHOULD: sample の生成に失敗しても、本体起動や自己更新は継続できなければならない。

### Preconditions / Postconditions
- Preconditions: 実行中 binary の所在が判定できる。
- Postconditions: sample は利用者が見つけやすい場所に配置され、既存 ignore list は保持される。

### Edge / Error
- sample が既に存在する場合は上書きしない。
- 実行中 binary の隣に ignore list が既にある場合は sample の生成だけを行い、live ignore list を作成しない。

## SP-018 PowerShell Windows GNU Build
### Requirements
- MUST: `scripts/build-rust-win.ps1` は Windows PowerShell から `cargo build --release --locked --target x86_64-pc-windows-gnu` を実行し、`rust/target/x86_64-pc-windows-gnu/release/flistwalker.exe` と `FlistWalker.exe` を生成しなければならない。
- MUST: `scripts/build-rust-win-clean.ps1` は同じ依存解決契約を使い、対象 target の clean 後に release build を実行しなければならない。
- MUST: `-CheckOnly` は検出だけを行い、install、`rustup target add`、clean、build、copy、strip を実行してはならない。
- MUST: `-NoInstall` は prompt を表示せず、不足項目と手動導入コマンドを表示して非ゼロ終了しなければならない。
- MUST: `-InstallMissing` は Rustup、Rust GNU target、MSYS2、`mingw-w64-x86_64-gcc` の導入を明示承認済みとして扱う。通常モードは各導入単位を別々に確認し、非対話環境では `-NoInstall` 相当で動作しなければならない。
- MUST: Rustup と MSYS2 の bootstrap は `winget` の exact package ID と `winget` source を指定し、実行前に package ID、変更内容、管理者権限を要求する可能性を表示しなければならない。
- MUST: MSYS2 package 導入は `C:\msys64\usr\bin\pacman.exe` または検出した同等パスを直接実行し、`pacman -S --needed --noconfirm mingw-w64-x86_64-gcc` を使わなければならない。`pacman -Sy` 単独による partial upgrade を行ってはならない。
- MUST: install 後は process/User/Machine PATH、Cargo home、MSYS2 固定候補を再読込し、`cargo`、`rustup`、`gcc`、`g++`、`ar`、`ranlib`、`windres`、`strip` を再検出しなければならない。永続 PATH をスクリプト自身が直接変更してはならない。
- MUST: GNU tool は `FLISTWALKER_WINDOWS_*` override、MSYS2 mingw64 固定候補、PATH の順で解決し、解決結果を Cargo target と `build.rs` 用環境変数へ設定しなければならない。
- MUST: Windows host の GNU build でも `windres` と `ar` を使って Windows resource を生成し、`resource.o` を `flistwalker` GUI binary へ明示リンクしなければならない。
- MUST: strip は実体へ一度だけ適用し、大小文字を無視して同一パスとなる自己 copy を避けたうえで、最終的な 2 名の EXE を byte-identical にしなければならない。

### Preconditions / Postconditions
- Preconditions: Windows PowerShell 5.1 または PowerShell 7 で repository checkout を利用し、既存依存を使うか、利用者が不足依存の導入を承認する。
- Postconditions: build 成功時は Windows icon/resource、`asInvoker` manifest、GUI subsystem を持つ byte-identical の `flistwalker.exe` / `FlistWalker.exe` と2名が存在し、`fw.exe` は同じ resource/manifest と console subsystem を持つ。いずれも意図しない MSYS2 runtime DLL に依存しない。

### Edge / Error
- `winget` 不在、承認拒否、install 失敗、install 後の再検出失敗、build/strip 失敗では後続 build を実行せず、原因と再実行または手動導入コマンドを表示する。
- install 後に現在の process で再検出できない場合は、新しい PowerShell を開いて再実行する案内を表示する。
- partial install は自動 rollback せず、導入済み package ID/package 名を表示して再実行可能な状態を保つ。
## SP-024 GUI settings editor

- 設定モーダルが読み込む raw JSON と保存前に生成する JSON は各64 KiB以下とする。64 KiBを超える入力または保存結果は理由を表示して拒否し、既存bytesを変更しない。失敗画面からも従来の JSON open を使えるようにする。この制限は起動時の runtime config 読込には適用しない。
- GUI の歯車は設定モーダルを開く。起動・履歴、キー操作、検索の群に、`restore_tabs_enabled`、`history_persist_disabled` の反転、`emacs_keybindings_enabled`、`ctrl_w_deletes_word_in_query`、`tab_pin_moves_to_next_row`、`walker_max_entries`、`filelist_auto_check_enabled` を表示する。保存済み JSON を起点とし、現在の実効設定とは分ける。
- 7項目はすべて次回起動から反映する。保存成功時はモーダルを閉じ、次回起動から反映する旨をフッターの省略表示より前に見える位置へ通知する。保存、キャンセル、既定値へ戻す、JSON を開く、JSON の再読み込みを提供する。既定値へ戻す操作は草稿だけを変更する。Ctrl+W の子設定は Emacs キー操作無効時に操作不可とし、値は保持する。
- Walker 上限は正の `usize` 整数だけを受理する。空、0、負、小数、overflow は保存前に拒否し、暗黙に補正しない。
- JSON を開く操作は従来の既定アプリ→標準エディタ fallback を使用し、モーダルと未保存草稿を維持する。外部編集後の再読み込みは草稿を置き換える明示操作とし、草稿が変更済みなら破棄確認を要求する。再読込失敗では元の草稿を保持する。読込中は取消可能とし、遅延応答は適用しない。
- 保存は raw JSON と読込時の bytes を比較し、協調 writer の sidecar lock 下で最新内容と一致する場合だけ7キーを更新して atomic replace する。未知キーと developer 設定を保持する。外部変更、削除、不正 JSON、lock または書込失敗時は草稿を保持してエラーを示す。replace 後の directory sync 失敗では元 bytes への rollback を試み、rollback も失敗した場合は両方のエラーを示す。保存中のキャンセル・再保存・再読込・JSON open は受理しない。
- 読込と保存は有界 worker に置き、応答はモーダル generation と対応付ける。現在の runtime config、既存 tab、履歴 writer、既存 worker を即時更新しない。履歴保存を OFF にしても既存履歴は削除せず、復元 tab の query 保存とは別設定である。明示起動引数は復元 tab より優先する。
