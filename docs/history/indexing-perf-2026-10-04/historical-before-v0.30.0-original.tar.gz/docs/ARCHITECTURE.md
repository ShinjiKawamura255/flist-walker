# ARCHITECTURE

This document owns the current implementation ownership map, threading boundaries, major runtime flows, and structural regression guards. Normative DES items remain in [DESIGN.md](DESIGN.md), while deeper data and sequence mechanics remain in [DETAILED_DESIGN.md](DETAILED_DESIGN.md).

## Overview
FlistWalker は Rust 製の GUI/CLI ハイブリッド検索ツールで、FileList 優先インデクシングと walker ベース再帰走査の両方を扱う。主要コンポーネントは search/index domain、GUI coordinator、OS integration、shared utility に分かれる。

## Top-Level Modules
- [main.rs](../rust/src/main.rs)
  - thin startup entrypoint。tracing、internal update helper、引数検証、runtime config、GUI/CLI 起動の順序を固定する。
- [cli.rs](../rust/src/cli.rs), [cli/args.rs](../rust/src/cli/args.rs), [cli/batch.rs](../rust/src/cli/batch.rs)
  - binary-private CLI owner。typed clap contract/validation、batch・interactive・FileList dispatch、action/exec/reporting と exit mapping を分担する。
- [cli_tui.rs](../rust/src/cli_tui.rs), [cli_tui/](../rust/src/cli_tui/)
  - public TUI facade と private protocol/state/worker/FileList/input/render/terminal owner。terminal cleanup と request freshness を owner-aligned test で固定する。
- [gui_launch.rs](../rust/src/gui_launch.rs), [launch_path.rs](../rust/src/launch_path.rs)
  - native window bootstrap と CLI/GUI 共通 root resolution を担当する。
- [lib.rs](../rust/src/lib.rs)
  - 共有モジュール公開面。
- [persistence/mod.rs](../rust/src/persistence/mod.rs), [persistence/](../rust/src/persistence/)
  - GUI/CLI/TUI 共通の保存 API。`schema.rs` は保存形式全体、`paths.rs` は保存先・移行・起動時読み込み、`worker.rs` は bounded admission、generation/status、ordered barrier と retry を所有する。`worker/document.rs` は型検証・JSON leaf merge・履歴と単一文書の lock/atomic write、`worker/settings.rs` は設定の複数ファイル書込・rollback を所有する。GUI 型や `FlistWalkerApp` に依存しない。
- [entry.rs](../rust/src/entry.rs)
  - `Entry` / `EntryKind` を定義し、index/search/app 間の候補表現を統一する。
- [indexer/mod.rs](../rust/src/indexer/mod.rs)
  - public indexer facade、`IndexSource` / `IndexBuildResult`、index build orchestration を担当する。
- [indexer/filelist_reader.rs](../rust/src/indexer/filelist_reader.rs)
  - FileList 検出、stream parse、hierarchy 読み込みを担当する。
- [indexer/filelist_hierarchy.rs](../rust/src/indexer/filelist_hierarchy.rs)
  - nested FileList override の queue/discovery、mtime precedence、subtree replacement を担当する。
- [indexer/filelist_writer.rs](../rust/src/indexer/filelist_writer.rs)
  - FileList text 生成、書き出し、ancestor 伝播、write 補助を担当する。
- [indexer/walker.rs](../rust/src/indexer/walker.rs)
  - walker ベースの file/dir 収集を担当する。
- [query.rs](../rust/src/query.rs)
  - fzf 互換 query tokenization と演算子解釈を担当する。
- [query_history.rs](../rust/src/query_history.rs)
  - GUI/TUI 共通の query history 検索順位、重複除去、最新化、100 件上限を担当する。
- [text_editing.rs](../rust/src/text_editing.rs)
  - GUI/TUI 共通の Unicode 文字位置操作と Emacs 風編集 reducer を担当する。widget/terminal の key event 解釈は各 adapter に残す。
- [search/mod.rs](../rust/src/search/mod.rs)
  - public search facade と high-level search orchestration の入口を担当する。
- [search/match_eval.rs](../rust/src/search/match_eval.rs)
  - query compile、literal/regex match、searchable entry materialization、candidate score evaluation を担当する。
- [search/cache.rs](../rust/src/search/cache.rs)
  - prefix cache と snapshot key を担当する。
- [search/config.rs](../rust/src/search/config.rs)
  - parallel threshold / thread count / execution mode 判定を担当する。
- [search/execute.rs](../rust/src/search/execute.rs)
  - sequential / parallel collect と candidate evaluation の execution path を担当する。
- [search/rank.rs](../rust/src/search/rank.rs)
  - ranking、result materialization、visible-result filter を担当する。
- [ui_model/mod.rs](../rust/src/ui_model/mod.rs)
  - highlight 判定、preview 文面、表示パス整形を担当する。action decision policy は持たず、表示専用 helper に限定する。
- [path_utils.rs](../rust/src/path_utils.rs)
  - Windows path normalization と path identity helper を担当する。
- [app/coordinator.rs](../rust/src/app/coordinator.rs)
  - status line、notice/status helper、frame/update glue、root/path compare の coordinator helper を担当する。
- [app/shell_support.rs](../rust/src/app/shell_support.rs)
  - process shutdown、egui font setup、window trace、root visibility/cache helper など shell-local helper policy を担当する。
- [app/response_flow.rs](../rust/src/app/response_flow.rs)
  - background response polling / routing helper を担当する。
- [app/root_browser.rs](../rust/src/app/root_browser.rs)
  - root selector dialog state と root change lifecycle を担当する。
- [actions.rs](../rust/src/actions.rs)
  - open / execute の OS 差分吸収、action decision policy、testable seam を担当する。
- [command_exec.rs](../rust/src/command_exec.rs)
  - CLI/TUI の明示的な外部 command template、root 認可、OS argv budget、greedy batch、direct process 実行と report を担当する。
- [updater.rs](../rust/src/updater.rs), [updater/](../rust/src/updater/)
  - self-update の公開 facade、release/candidate 解決、staging/download、manifest 検証、platform apply helper を担当する。
  - `apply` は検証済み bundle のみを受け取り、staged file/helper script creation は no-overwrite primitive を経由する。
  - `updater/transaction.rs` は transaction の prepare / activate / rollback / recovery を調停する。`transaction/model.rs` は marker-v1 の永続化モデル、`transaction/filesystem.rs` は path・型・hash の再検証と marker/artifact 操作、`transaction/platform.rs` は OS 固有の process 制御と atomic replacement、`transaction/tests.rs` は transaction contract の characterization を所有する。
  - 依存方向は transaction coordinator から model/filesystem/platform への一方向とし、platform は transaction model や filesystem policy に依存しない。Windows の `ReplaceFileW` 呼び出しは platform に置き、backup/no-overwrite/revalidation policy は filesystem に残す。
- [update_security.rs](../rust/src/update_security.rs)
  - update manifest 署名検証を担当する。
- [fs_atomic.rs](../rust/src/fs_atomic.rs)
  - atomic write helper。

- [app/freshness.rs](../rust/src/app/freshness.rs), [app/freshness/worker.rs](../rust/src/app/freshness/worker.rs)
  - snapshot の source/取得時刻/fingerprint と tab-local status、単一 filesystem probe の物理占有と論理 timeout を分担する。coordinator は描画更新時に poll し、timeout は元 tab/root/generation/path にだけ適用する。timeout 後も物理 slot を保持し、同じ snapshot の監視を停止する。
- [app/paged_preview_flow.rs](../rust/src/app/paged_preview_flow.rs)
  - preview control mode の選択/有効条件/command と request identity を所有する。input adapter と pointer rendering は共通 command seam を使用し、本文・encoding・pagination は `ui_model/paged_preview.rs` に置く。

## app Coordinator
[mod.rs](../rust/src/app/mod.rs) の `FlistWalkerApp` は egui/eframe の coordinator であり、feature 実装は `rust/src/app/` に分割されている。state holder は worker / UI / query の単位でも分離されている。
- `FlistWalkerApp` は `AppShellState` を介して app-global / tab-local / feature-local state をまとめ、`AppRuntimeState` を内側の runtime bundle として保持する。coordinator 直下には shell/orchestration の入口だけを残し、細かな state ownership は shell bundle を経由して参照する。shell-local helper policy は [shell_support.rs](../rust/src/app/shell_support.rs) へ移した。

- `FlistWalkerApp` に残す fixed point は「egui/eframe entrypoint」「top-level orchestration」「cross-feature state holder」「owner API の呼び分け」に限定し、feature ごとの state transition と policy 判定は各 owner module へ寄せる。
- `FlistWalkerApp` の state inventory は少なくとも次の 4 束で追跡する。
  - `app-global shared state`
    - root、filter flag、index snapshot、worker-facing coordinator state のように active tab 以外でも参照される束。
  - `active-tab-local state`
    - query、results、selection、preview、notice のように現在前面 tab にだけ適用される束。
  - `persisted/background tab state`
    - `AppTabState` と restore/switch/reorder/request-routing に紐づく tab/session 束。
  - `feature dialog/update state`
    - FileList dialog、self-update dialog、window/root browser など feature 単位の補助束。live owner は `state.rs` の `FeatureStateBundle` に寄せる。
- `mod.rs` の責務棚卸しは少なくとも次の 6 区分で追跡する。
  - `startup/bootstrap`
    - 残置: `new` / `from_launch` / `new_with_launch` による app 初期化の入口。
    - owner: worker 起動と launch seed 構築は [bootstrap.rs](../rust/src/app/bootstrap.rs)、session restore は [session.rs](../rust/src/app/session.rs)。
  - `frame update cycle`
    - 残置: egui frame ごとの top-level update loop と repaint 判断。
    - owner: index/search/poll の lifecycle は [pipeline.rs](../rust/src/app/pipeline.rs)、active result refresh は [pipeline_owner.rs](../rust/src/app/pipeline_owner.rs)、render command は [render.rs](../rust/src/app/render.rs)。
  - `shutdown/persist`
    - 残置: eframe callback から shutdown seam を呼ぶ top-level exit orchestration。
    - owner: state 永続化は [session.rs](../rust/src/app/session.rs)、worker join/shutdown は [worker/runtime.rs](../rust/src/app/worker/runtime.rs)。
  - `tab routing`
    - 残置: active tab index と owner API 呼び分け。
    - owner: tab snapshot / switch / move / close / activation refresh は [tabs.rs](../rust/src/app/tabs.rs)、background response polling / apply は [response_flow.rs](../rust/src/app/response_flow.rs)、root selector lifecycle は [root_browser.rs](../rust/src/app/root_browser.rs)。
  - `filelist/update dialog dispatch`
    - 残置: dialog command の top-level dispatch と status/notice 連携。
    - owner: FileList flow は [filelist.rs](../rust/src/app/filelist/mod.rs)、self-update lifecycle は [update.rs](../rust/src/app/update.rs)。
  - `trace helper`
    - 残置: opt-in 診断の入口と egui lifecycle に紐づく top-level trace 発火。
    - owner: worker protocol tracing は [worker/tasks.rs](../rust/src/app/worker/tasks.rs) の worker body と [worker/protocol.rs](../rust/src/app/worker/protocol.rs)、window/session diagnostics は [session.rs](../rust/src/app/session.rs) と各 owner helper。

- [bootstrap.rs](../rust/src/app/bootstrap.rs)
  - worker 起動と launch seed 構築。
- [session.rs](../rust/src/app/session.rs)
  - GUI の保存 snapshot 作成、launch/tab/window geometry restore、shutdown 時の保存要求を所有する。共通の読み込み・書き込み・保存形式は `persistence/` に委譲する。
- [tabs.rs](../rust/src/app/tabs.rs)
  - tab lifecycle、snapshot capture/apply、activation 時の restore/refresh 入口、tab routing owner を担当する。background tab 向け search/index response apply は `response_flow.rs` へ委譲し、live 側の tab/session orchestration は `state.rs` の `TabSessionState` を介して保持する。`TabSessionState` は明示的な collection API と active tab / tab id / pending restore / request routing の owner API を持ち、Vec 全体への暗黙透過はしない。
- [pipeline.rs](../rust/src/app/pipeline.rs)
  - index queue、index response poll、dispatcher を担当し、active path は `PipelineOwner`、background path は `tabs.rs` の background-flow helper 群へ橋渡しする thin coordinator として振る舞う。
- [pipeline_owner.rs](../rust/src/app/pipeline_owner.rs)
  - active tab 向け search/result refresh、entry filter 再適用、incremental search refresh を結線する app adapter。横断的な状態アクセスを持つため、独立した domain owner としては扱わない。表示結果の判断規則は `result_policy.rs` に置く。
- [active_filter.rs](../rust/src/app/active_filter.rs)
  - 大量候補のfilter再適用とunknown-kind収集をframe予算内で進める。continuationはtabのbuild payloadが所有し、完了時のidentity検証と旧payloadのreclaimer受付が揃ってから表示へ公開する。known候補は4ms/最大32,768件、unknown discoveryは512件/backlog4096件で進める。identityが一致するlive incremental subsetは除外再評価・二重copyを省いて再利用する。不要なterminal incremental scratchはcommitted ownerの変更前にreclaimerへ退役する。
- [search_coordinator.rs](../rust/src/app/search_coordinator.rs)
  - search worker channel、request_id、tab routing に加え、active/background search request lifecycle helper を保持する。
- [index_coordinator.rs](../rust/src/app/index_coordinator.rs)
  - index worker channel、queue/inflight、incremental state、background tab state に加え、request id 採番、active/background refresh 開始、terminal cleanup など index request lifecycle の owner API を保持する。
- [index_worker.rs](../rust/src/app/index_worker.rs)
  - FileList / Walker streaming、kind classification、index worker thread 実装を担当する。
- [walker_runtime/mod.rs](../rust/src/walker_runtime/mod.rs), [walker_runtime/adaptive.rs](../rust/src/walker_runtime/adaptive.rs)
  - GUI/TUI から独立した adaptive Walker backend、runtime settings、entry classification、truncation notice、single-worker serial fast path、read_dir 制御指標を担当する。
- [worker.rs](../rust/src/app/worker.rs), [worker/](../rust/src/app/worker/)
  - GUI worker subsystem の private namespace/facade。protocol、bounded channel、bus state、worker body、shutdown runtime を `app::worker` 配下に閉じる。
- [worker/protocol.rs](../rust/src/app/worker/protocol.rs)
  - search/index/preview/action/sort/kind/filelist/update の request/response 型を集約し、worker protocol surface を実装モジュールから分離する。
- [worker/channel.rs](../rust/src/app/worker/channel.rs)
  - bounded request channel と worker load trace helper を担当する。
- [worker/bus.rs](../rust/src/app/worker/bus.rs)
  - preview/action/sort/kind/filelist/update worker channel と request lifecycle state を束ねる。
- [worker/runtime.rs](../rust/src/app/worker/runtime.rs)
  - worker shutdown signal と join timeout 管理を担当する。join 済み panic と未終了 worker を別々に記録し、panic は名前付き `shutdown_panicked` warning、未終了は `shutdown_timeout`、全員が正常終了した場合だけ `shutdown_complete` を出す。
- [response_flow.rs](../rust/src/app/response_flow.rs)
  - preview/action/sort を中心に worker response の polling と routing を集約する。
- [root_browser.rs](../rust/src/app/root_browser.rs)
  - root selector dialog の state と root change cleanup を担当する。
- [ui_state.rs](../rust/src/app/ui_state.rs)
  - runtime UI focus、scroll、preview panel、tab drag などの一時状態を保持する。
- [query_state.rs](../rust/src/app/query_state.rs)
  - `TabQueryState` は live/background 共通の query・history-navigation payload。`QueryState` はこれを保持し、app-global の history debounce と kill buffer を別に持つ。タブ切替では payload 全体を swap し、全体共有状態を移動しない。
- [cache.rs](../rust/src/app/cache.rs)
  - preview/highlight/sort metadata cache state と bounded invalidation を担当する。
- [result_reducer.rs](../rust/src/app/result_reducer.rs)
  - result/preview/sort 応答を GUI 状態へ適用する adapter。request freshness、selection、preview retirement、scroll/status、worker dispatch を扱う。
- [result_policy.rs](../rust/src/app/result_policy.rs)
  - app や worker を受け取らず、前面・背景共通の検索結果公開、ranking membership、エラー、sort scope、並べ替えを判断する。local sort 待ちでは visible results とその件数を同時に保留し、AllMatches の empty query は limit 前に worker で評価する。
- [result_flow.rs](../rust/src/app/result_flow.rs)
  - result sort の orchestration を担当しつつ、reducer boundary への thin wrapper として振る舞う。
- [preview_flow.rs](../rust/src/app/preview_flow.rs)
  - preview request/response、highlight lookup、preview routing の orchestration を担当しつつ、response apply は reducer boundary を呼ぶ。
- [render.rs](../rust/src/app/render.rs)
  - `RenderCommand` / frame orchestration / facade wrapper を担当し、frame 後段で render command を dispatch する。
- [render_panels.rs](../rust/src/app/render_panels.rs), [render_panels/](../rust/src/app/render_panels/), [render_dialogs.rs](../rust/src/app/render_dialogs.rs), [render_dialogs/](../rust/src/app/render_dialogs/), [render_tabs.rs](../rust/src/app/render_tabs.rs), [render_snapshot.rs](../rust/src/app/render_snapshot.rs), [render_theme.rs](../rust/src/app/render_theme.rs)
  - facade/results/status、private top-panel、FileList/update/root-list dialog、tab/snapshot/theme の描画責務を分担する。render owner は既存 owner method と `RenderCommand` のみを mutation seam とし、filesystem/network/process/worker 実装へ依存しない。
- [input.rs](../rust/src/app/input/mod.rs)
  - shortcut、IME、history search の GUI adapter。履歴 policy と Emacs 風文字編集は top-level shared module へ委譲する。
- [filelist.rs](../rust/src/app/filelist/mod.rs)
  - FileList 作成フローと filelist dialog dispatch owner。
- [update.rs](../rust/src/app/update.rs)
  - self-update dialog と update state transition。request_id-correlated な update trace を supportability 用に橋渡しし、update dialog dispatch owner として振る舞う。
- [state.rs](../rust/src/app/state.rs)
  - GUI 横断 state 型。`FileListManager` / `UpdateManager` / `RootBrowserState` / catalog snapshot・picker・preset editor・Named Root manager draftを持つ`PresetManagerState`を束ねる`FeatureStateBundle`、live tab/session registryを束ねる`TabSessionState`、cache/request routingなどbundle inventoryの受け皿として扱う。`AppRuntimeState`は`FlistWalkerApp`のapp-global / active-result live stateを束ねるruntime bundleとして扱う。
  - `FileListManager` と `UpdateManager` は内部 bundle を透明に露出せず、`workflow` / `state` を明示的に触る boundary として扱う。
- [tab_state.rs](../rust/src/app/tab_state.rs)
  - tab snapshot 用 state 型。`AppTabState` は persisted/background tab state の canonical snapshot とし、active tab 側の live state とは区別して追跡する。`TabSessionState` は snapshot と live tab set の橋渡しを担い、owner API でのみ更新する。
  - `rust/src/app/tests/tab_contract.rs` の contract test は `TabIndexState` / `TabQueryState` / `TabResultState` / `AppTabState` の field layout をフルリテラルで固定し、field drift を compile-time で検出する。
- [worker/tasks.rs](../rust/src/app/worker/tasks.rs)
  - search/preview/action/sort/update/filelist/kind worker の spawn registry、use-case 本体、共有 action notice formatting を担当する。

## App Test Boundaries
- `rust/tests/architecture_boundaries.rs`, `rust/src/app/tests/result_parity.rs`
  - 共通保存層と結果判断の依存境界、前面・背景の検索結果・件数・エラー・metadata 待ちの一致を検証する。
- `rust/src/persistence/worker/tests.rs`
  - TC-167/168 の保存互換、未知フィールド、複数 writer、lock contention、設定 rollback と公開 API を GUI から独立して検証する。
- `rust/src/app/tests/update_commands.rs`
  - update dialog / manager / worker-response lifecycle を command 境界で検証する。
- `rust/src/app/tests/session_restore.rs`
  - startup root 選択、saved tab sanitize、restore 時の active/background tab 初期化を restore owner 境界で検証する。
- `rust/src/app/tests/tab_lifecycle.rs`, `rust/src/app/tests/tab_drag.rs`, `rust/src/app/tests/tab_background_responses.rs`, `rust/src/app/tests/tab_contract.rs`
  - tab switch/close/restore、tab reorder、background tab 応答 routing、tab snapshot contract を tab owner 境界で検証する。
- `rust/src/app/tests/index_pipeline/*`
  - filelist、index inflight、kind resolution、search refresh の pipeline lifecycle を command 単位で検証する。
- `rust/src/app/tests/app_core.rs`
  - app coordinator の汎用 state transition と cross-cutting regression だけを保持し、update/restore の専用責務は各 owner-aligned module へ寄せる。

## Threading Model
- UI thread:
  - egui frame ごとに request enqueue と response poll を行う。
- Search worker:
  - query と entry snapshot を受けて結果を返す。
- Index worker:
  - FileList / walker を使って candidate を生成する。
- Preview worker:
  - テキスト preview を生成する。
- Action / sort / kind / filelist / update workers:
  - 補助的な非同期処理を担当する。
- Tracing:
  - `RUST_LOG` 指定時のみ worker-side `tracing` が有効になり、async worker flow は canonical な `flow` / `event` / `request_id`（request-scoped flow のみ）を構造化 field として記録する。
  - search / preview / filelist / action / sort metadata / update worker は `started` / `finished` / `failed` / `receiver_closed` 系の event family を使い、support 時に request 単位で追跡できるようにする。
  - index worker は `flow=index` を共有しつつ `source_kind=filelist|walker|none` を併記して started/finished/completed/superseded/failed を記録する。
  - `FLISTWALKER_WINDOW_TRACE=1` は GUI/session/input/update の opt-in 診断面であり、`append_window_trace` 経由の event family を `RUST_LOG` 側へ混在させない。

request_id によって最新応答だけを反映し、古い応答による UI 巻き戻りを防ぐ。

## Main Data Flow
1. launch settings と root を決定する。runtime settings と session state は current settings base directory から読み込み、旧保存先が残っている場合は新保存先が空のときだけ移行する。
2. index request を発行する。
3. index response から `all_entries` / `entries` を更新する。
4. query が空なら一覧表示、非空なら search request を発行する。
5. current row に応じて preview request を発行する。
6. action または update request を必要に応じて発行する。

## Shared Utility Policy
OS ごとの差異や表示用正規化のような cross-cutting helper は app 内に複製せず shared utility に寄せる。

- [path_utils.rs](../rust/src/path_utils.rs)
  - Windows パス正規化、path identity、display/shell 変換。
- [ui_model/mod.rs](../rust/src/ui_model/mod.rs)
  - preview/highlight 計算。
- [fs_atomic.rs](../rust/src/fs_atomic.rs)
  - 原子的ファイル書き込み。

## Related Docs
- [INDEX.md](./INDEX.md)
- [STRUCTURE.md](./STRUCTURE.md)
- [ARCHITECTURE_OVERVIEW.md](./ARCHITECTURE_OVERVIEW.md)
- [CURRENT_STATUS.md](./CURRENT_STATUS.md)
- [REQUIREMENTS.md](./REQUIREMENTS.md)
- [SPEC.md](./SPEC.md)
- [DESIGN.md](./DESIGN.md)
- [DETAILED_DESIGN.md](./DETAILED_DESIGN.md)
- [TESTPLAN.md](./TESTPLAN.md)
- [RELEASE.md](./RELEASE.md)
- [TASKS.md](./TASKS.md)
- [history/INDEX.md](./history/INDEX.md)

## Document Roles
- `CURRENT_STATUS.md`
  - 現在の品質姿勢と保守優先度を保持する。validation command や完了履歴は owning document へリンクする。
- `INDEX.md`
  - docs 全体の索引と用途別の読み順を保持する。詳細な仕様、設計、検証内容は各 owning document へリンクする。
- `STRUCTURE.md`
  - リポジトリのディレクトリ構成、主要 entrypoint、build/test/release hook の所在を保持する。
- `ARCHITECTURE_OVERVIEW.md`
  - 初見の Agent / 開発者が短時間で product shape、runtime flow、ownership map、変更種別ごとの入口を把握するための短い地図を保持する。
- `REQUIREMENTS.md` / `SPEC.md`
  - プロダクト契約と振る舞いの規範面を保持する。
- `ARCHITECTURE.md`
  - 現在の module ownership、threading boundary、主要 runtime flow、構造上の regression guard を保持する。
- `DESIGN.md`
  - 規範的な DES 項目、実現方式、FR/SP/TC との traceability を保持する。
- `DETAILED_DESIGN.md`
  - module、data、sequence、resilience、operations の実装詳細への入口を保持する。
- `TESTPLAN.md`
  - 継続運用する validation matrix、manual test、regression guard を保持する。
- `RELEASE.md`
  - release 運用と配布手順を保持する。
- `TASKS.md`
  - active task の所有境界と、current context・completed record への routing を保持する。
- `history/INDEX.md`
  - 完了した maintenance program と closure record への索引を保持する。

## Regression Guards

### Kind Resolution Arc Clone Freeze (v0.16.0)

- Scenario: 50万件のエントリを持つ Walker インデクシングの途中で、UI が `KindResolverWorker` から解決済みのメタデータ（`EntryKind`）バッチを 512 個受け取る。このとき `apply_entry_kind_updates` 内で `Arc::make_mut(&mut self.entries)` などを呼び出すと、検索スレッドが別のスナップショットをホールドしているため毎フレーム50万要素の巨大な `Arc<Vec<Entry>>` クローン（数百万回の `PathBuf` アロケーション）が発生し、UI が完全にフリーズする。
- Expected Behavior: UI は巨大リストに対する O(N) のクローンをせず、`self.cache.entry_kind` へ解決された Kind を安全に書き込み、それを参照することでメタデータ解決の恩恵（アイコン表示やフィルタ反映）を O(1) で得る。
- Non-goals: Walker 自身の遅延解決以外の部分（メタデータ取得そのものの OS I/O 遅延）は Background スレッドに閉じるため本件の責務ではない。
- Related Tests: `poll_kind_response_does_not_clone_arc_shared_entries_regression` (in `kind_resolution.rs`)
- Notes for Future Changes: `app.entries` および他のエントリリスト(`all_entries`, `incremental_filtered_entries`, `index.entries`) に対して、チャンク処理中のループ内で一括更新を目的に `mut` 参照を要求・上書きしてはいけない。常に Cache (辞書) を更新し、描画やフィルタリング時は Cache を `Entry` より優先して参照すること。

### FileList Restore Discovery Cancellation

- Scenario: Restore tabs で FileList を使う background tab の index request が進行中に、その tab を active にして新しい request を発行する。旧 request が root 解決後の FileList discovery（特に大量の root-level directory scan）へ進む。
- Expected Behavior: stale request は FileList discovery/parse を開始せず `Canceled` へ収束し、active tab の indexing request が obsolete discovery によって待たされない。既存の `FileList.txt` 優先順と root 直下限定の検出範囲は維持する。
- Non-goals: FileList の候補解釈、nested FileList の hierarchy override、Walker の走査順、filesystem metadata 自体の OS I/O latency は本 guard の対象外。
- Related Tests: `tc_152_filelist_restore_index_regression_cancels_before_filelist_start` (in `app/index_worker/tests/mod.rs`), `find_filelist_cancellable_regression_stops_when_request_is_stale` (in `indexer/tests/mod.rs`)
- Notes for Future Changes: index worker の source selection 前に request freshness を再確認し、root-level FileList discovery を非キャンセルの `read_dir` scan に戻してはならない。検出 API の変更時は TC-152 と VM-003 の FileList/Walker perf guards を再実行すること。
