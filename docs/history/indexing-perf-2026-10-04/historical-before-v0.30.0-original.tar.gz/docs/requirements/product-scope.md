﻿# Product Scope and Acceptance Criteria

## Background / KPI
- CLI/GUI で `fzf --walker` 相当の高速検索体験を提供する。
- `FileList.txt`（`filelist.txt` 含む）を既存資産として利用し、対象集合を明示的に管理できるようにする。
- KPI-001: 10万件規模の候補に対して、インデックス構築後の検索応答を 100ms 未満（目標）にする。
- KPI-002: Windows/macOS/Linux で同等の検索・オープン体験を提供する。

## Scope
### In
- Rust での CLI/GUI 実装。
- ファイル/フォルダの収集（walker / FileList 両対応）。
- fzf 互換クエリでの検索。
- 検索結果からの実行/オープン。
- GitHub Releases を用いた起動時の更新確認と、Windows/Linux 向け自己更新。
- SDD + TDD ドキュメントとテスト整備。

### Out
- 旧プロトタイプの機能追加。
- ネットワーク共有ドライブ最適化。
- 配布インストーラ作成。
- macOS `.app` bundle の自動更新。

## Use cases
- UC-001: 開発者がプロジェクト配下を横断検索し、目的ファイルを即時オープンする。
- UC-002: 利用者が `FileList.txt` に列挙した対象のみ検索し、実行可能ファイルを起動する。
- UC-003: 利用者が検索結果のフォルダを選択し、OS のファイルマネージャで開く。
- UC-004: 利用者が GUI で候補を確認しながら、複数選択して一括アクションを実行する。
- UC-005: 利用者が起動時に新しい release を検知し、承認後にダウンロードと再起動で更新を適用する。

## Acceptance Criteria
- AC-001: FileList 優先モード有効時、`FileList.txt` 系ファイルが存在すれば walker を使わず、列挙対象のみが候補になる。
- AC-002: `FileList.txt`、`filelist.txt`、および `filelist.txt` の大文字小文字違いで同等に動作する。
- AC-003: クエリ入力で関連度順の上位 N 件を返せる。
- AC-004: ファイル選択時に実行/オープン、フォルダ選択時にオープンが行われる。
- AC-005: Rust テスト（unit/integration）が成功する。
- AC-006: GUI で検索・選択・実行/オープン・再読込を確認できる。`Manage list` では root を追加でき、通常時の単一行選択から編集でき、削除モード中だけ表示されるチェックボックスで複数 root を draft から削除できる。
- AC-007: root 外パスは結果一覧に表示されても実行/オープンされず、利用者へブロック理由が通知される。
- AC-008: UNC root 配下の候補は root 外判定に誤って拒否されない。
- AC-009: Create File List 実行時、既存 root FileList の置換と祖先 FileList 更新はそれぞれ明示 consent を要求し、拒否時は未認可 target を更新しない。取消または部分失敗では commit 済み target の rollback を試み、失敗 target を報告する。hard abort に対しては祖先を下位から先に更新し、root を最後の commit point とする。root commit 前に停止した場合は root の旧状態または不在を維持し、祖先には既存論理行を失わない重複除去可能な参照だけを残して、再実行で一意な完了状態へ収束する。置換前に権限と祖先の必要な時刻 metadata を適用し、既存の UTF-8 BOM / CRLF 入力は writer の正規化契約に従う。
- AC-010: runtime config の `history_persist_disabled` が有効なときは query history を読み書きしない。有効時は複数 writer の ordered delta を失わず、既存/unknown UI state field を保持して最大 100 件へ merge する。
- AC-010A: runtime config の `emacs_keybindings_enabled` が `false` のときは Emacs 風ショートカットをアプリ操作として消費せず、`true` または未指定時は既存どおり有効にする。GUI では `ctrl_w_deletes_word_in_query=true` と併用し、検索欄または履歴検索フィルターへフォーカス中の場合だけ `Ctrl+W` を直前単語の削除へ割り当て、タブ終了より優先する。単語間の `:`、`\\`、`/` などの区切り文字へ到達しても削除が停止せず、繰り返し操作で query 全体を削除できる。新規オプションの既定値は `false` とし、検索欄外、Emacs 無効時、または新規オプション無効時は従来の primary modifier + `W` によるタブ終了を維持する。IME 合成中はこの切替による単語削除もタブ終了も起動しない。
- AC-010B: GUI/TUI は runtime config の `tab_pin_moves_to_next_row` が `true` のとき、`Tab` / `Shift+Tab` / `Ctrl+I` による PIN 固定/解除後に選択行を次行へ進める。未指定または `false` のときは既存どおり現在行に留まる。`Ctrl+I` を含む Emacs 風操作は `emacs_keybindings_enabled` が `true` のときだけ有効にする。
- AC-011: CI は Linux/macOS/Windows でテストを実行し、依存脆弱性検査を通過する。
- AC-012: GUI の結果ペインから `Score` / `Name` / `Path` / `Modified` / `Created` / `Size` を選択できる。
- AC-013: `Name` / `Path` ソートは即時に並び替わり、`Modified` / `Created` / `Size` ソートは UI を固めずに完了する。`Path` は完全な正規化済み path、`Size` は通常ファイルの byte size を使い、フォルダや取得不可項目は末尾へ送る。
- AC-014: query 変更後はソート結果が維持されず、検索スコア順へ戻る。
- AC-015: インデクシング時の path 種別/日付属性取得は増えず、ソート属性は検索結果に対してのみ遅延取得される。
- AC-016: GUI でタブをドラッグすると並び順だけが更新され、active tab の root/query/filter は他タブへ入れ替わらない。
- AC-017: GUI の検索オプションに `Ignore Case` が表示され、起動直後から有効で、切り替えると検索結果とハイライトが追従する。
- AC-018: GUI 起動直後と `Esc` / `Ctrl+G` の検索キャンセル後に、候補がある場合は結果リストの 1 行目が選択状態になる。
- AC-019: GUI 起動後に新しい GitHub Release が見つかった場合、更新承認ダイアログが表示される。
- AC-020: Windows/Linux で更新を承認すると、対象 asset と `SHA256SUMS` / detached signature を検証後に置換し、新版本体が再起動する。
- AC-021: Windows では実行中 EXE の自己上書きではなく、一時 updater 経由で更新が適用される。
- AC-022: macOS では更新検知時に自動更新非対応が案内され、誤って自己置換しない。
- AC-023: 利用者が更新ダイアログで「次のバージョンが出るまで表示しない」を選ぶと、その target version は次回起動以降も再表示されず、より新しい version が見つかった場合のみ再びダイアログが表示される。
- AC-024: 実行中 binary と同じフォルダの ignore list ファイルに列挙した項目は、`!old !~` 相当の非 fuzzy 除外として検索候補から外れ、GUI の Use Ignore List チェックボックスで有効/無効を切り替えられる。
- AC-025: runtime config file が存在しない初回起動では、Windows では `%LocalAppData%\flistwalker\`、Linux/macOS では `~/.flistwalker/` に、現在の `FLISTWALKER_*` 環境変数を反映した config file が自動生成される。自動生成された config file は、一般利用者向けの `walker_max_entries` / `history_persist_disabled` / `restore_tabs_enabled` / `emacs_keybindings_enabled` / `tab_pin_moves_to_next_row` を既定値で保持し、詳細項目は設定済み環境変数だけを保持する。runtime config file が既に存在する場合は、その内容が runtime settings として反映され、環境変数の変更だけでは runtime settings が変化しない。
- AC-027: UI state、saved roots、window trace などの永続化ファイルは、Windows では `%LocalAppData%\flistwalker\` に、Linux/macOS では `~/.flistwalker/` に保存される。
- AC-028: Windows の旧バージョンで実行ファイル横または home directory にあった runtime config / UI state / saved roots / window trace、Linux/macOS の旧バージョンで home directory 直下にあった同名ファイルは、新しい保存先に同名ファイルが無い場合だけ自動移行される。runtime config の移行と初回 seed は current path の sidecar lock 取得後に current を再確認し、協調する並行起動が先に作成した current を上書きしない。cross-filesystem fallback が失敗しても partial current を残さず legacy を保持する。
- AC-026: `flistwalker.ignore.txt.example` が存在しない状態で起動しても、ツールは sample を実行バイナリの隣へ自動生成し、`flistwalker.ignore.txt` へのリネーム案内を提供する。
- AC-029: GUI の設定ボタンを押すと runtime config file が生成済みの状態で開かれ、既定アプリケーションが失敗した場合はテキストエディタ相当のフォールバックが試行される。
- AC-030: 保存済みウィンドウ位置が現在の仮想ディスプレイ矩形外にある状態で GUI を起動しても、初期ウィンドウは現在の表示範囲内に配置される。現在の仮想ディスプレイ内の負座標配置は維持される。
- AC-031: タブの close ボタン上へマウスを移動すると、close ボタンの押下領域が背景・枠・カーソルなどでタブ本体の押下領域と区別できる。
- AC-032: GUI で複数タブを閉じた後、`Ctrl+Shift+T` は最後に閉じたタブから順に active tab として復元し、可能な限り閉じる前の tab 位置へ戻す。復元対象がない場合はタブ数を変えずに通知する。
- AC-033: `scripts/build-rust-win.ps1` と `scripts/build-rust-win-clean.ps1` は Windows PowerShell から GNU release artifact を生成できる。`-CheckOnly` は環境を変更せず、`-NoInstall` は不足時に手動コマンドを表示して失敗し、通常モードは Rustup、Rust target、MSYS2、GNU package を個別確認し、`-InstallMissing` はそれらを明示承認済みとして扱う。生成後の `flistwalker.exe` と `FlistWalker.exe` は同一内容で、Windows icon/resource、`asInvoker` manifest、GUI subsystem を保持し、console の attach/detach を行わず GUI を起動する。`fw.exe` は同じ resource/manifest と console subsystem を保持し、PowerShell/cmd が CLI/TUI/update/help/version の完了・標準 handle・終了 code を取得できる。
- AC-034: 自己更新は署名済み manifest を先に検証し、定義済み byte/time 上限内で streaming hash が一致した bundle だけを適用する。Windows/Linux の dummy transaction では、成功、binary commit 前の失敗、再起動生成失敗、中断 recovery の各経路で旧 bundle または完全な新 bundle のどちらかへ収束し、partial file・lock・backup は所有権を検証して cleanup される。
- AC-035: UTF-8 および先頭 UTF-8 BOM 付き FileList は同じ候補を返す。UTF-16 BOM、NUL、不正・途中切れ UTF-8、1 MiB 超の論理行は候補を返す前に明示的に失敗し、階層 FileList の失敗は親由来 subtree を部分置換しない。
- AC-036: Linux/macOS universal の legacy `--cli [QUERY] --root ... --limit ...` invocation と、全 platform の `fw [QUERY] --root ... --limit ...`、既定 path-only stdout を維持する。Windows の正式 CLI/TUI/update/help/version 入口は console-subsystem の `fw.exe` とし、GUI-subsystem の universal が持つ旧 CLI 引数は direct process caller 向け best-effort として残すが、PowerShell/cmd の同期・stdio 契約には含めない。batch は name/path を含む sort-before-limit、`--type file|files|f|folder|folders|directory|directories|dir|d`、print/open/reveal の明示 action と mass-action guard、default/saved root、saved-root listing、安全な FileList create を提供する。`--progress` 指定時に limit が全一致集合を切り詰めた場合は stderr へ警告する。interactive CLI は redirect 可能な stdout へ terminal 復旧後の選択 path だけを出力し、preview、current-only action、history、clear/help、sort/options/root picker、refresh、FileList confirmation を stderr TUI で提供する。FileList active は pending intent、rollback/report、worker join の settlement 前に output/root switch/return を行わず、terminal cleanup、exit code、stale response、非ブロッキング persistence を自動試験または Windows 実端末証跡で確認できる。
- AC-037: GUI の `Help` ボタンまたは `F1` でショートカット一覧を開き、`F1` / `Esc` / `Close` で閉じられる。一覧は macOS で primary modifier を `Cmd`、その他の OS で `Ctrl` と表示し、`emacs_keybindings_enabled` の状態を反映する。ヘルプ表示中のキー入力は背後の検索・選択・コピー・実行を変更しない。
- AC-038: CLI は positional QUERY を予約語化せず、明示 long option で named root と検索 preset を list/add/save/remove/applyでき、`--preset` は batch/TUI の検索開始時に適用できる。GUI はメイン画面の `Presets...` button または `Ctrl+Shift+P`（macOS は `Cmd+Shift+P`）で同じ modal picker を開き、名前を fuzzy filter して `Enter` で現在 tab の pure search state へ適用し、`Esc` で現在の検索状態を変えず閉じる。`Add` は現在tabのpure-search stateから新規draftを作り、選択中presetは`F2` / `Edit`から編集、`Delete` buttonから確認付き削除できる。追加・編集・削除はatomic catalog updateだけを行い現在tabへ適用しない。picker と preset editor から開く Named Root 管理画面は absolute path の追加、名称・path編集、確認付き削除を提供し、名称変更は参照presetを追従、削除は保存済みpath snapshotへフォールバックさせる。GUI のメイン画面には picker を開く単一の button だけを置き、preset 一覧・選択・編集 UI は modal 内に保つ。旧 `.flistwalker_roots.txt` と保存済みunknown fieldは保持され、preset適用・catalog編集だけでは副作用actionを開始しない。
- AC-039: GUI/CLI/TUI は `name:` / `path:` / `dir:` / `ext:` を term 単位で解釈し、`!`、`'`、`^`、`$`、token 内 `|`、regex、case、score、highlight と同じfield scopeを共有する。fieldなしqueryと未知の `prefix:` は従来どおりpath全体を検索し、既知fieldの空値は明示errorとする。
- AC-040: `--max-depth 2` では root 直下とその子までを候補とし、depth 2 のdirectory配下を走査しない。Walker/FileList/Autoは同じ候補範囲を返す。GUIでdepth付きpresetを適用すると現在tabだけが再indexされ、`Depth: ≤ 2` が表示され、query/root/source変更とtab切替後も維持される。他tabと新規tabは変更されず、FileList作成は全階層snapshotを維持する。
- AC-041: `fw QUERY --root PATH` は共有 CLI engine の direct-process 比較で `flistwalker --cli QUERY --root PATH` と同じ stdout/stderr/exit code を返し、`fw` の help/program name は短い command 名を表示する。Linux/macOS では両方を公開 CLI とし、Windows では `fw.exe` のみを shell-synchronous CLI とする。release には既存 archive を変更せず各 platform/arch の `fw` standalone asset が追加され、Windows の固定 200-file fixture で NFR-014 の起動性能基準を満たす。Windows 利用者向け文書は universal ZIP とは別に `fw` asset を取得する移行導線を示す。
- AC-042: `emacs_keybindings_enabled=true` の GUI では、通常の `Down` / `Up` / `Enter` / `Esc` が提供される対話面に対して `Ctrl+N` / `Ctrl+P` / `Ctrl+J` または `Ctrl+M` / `Ctrl+G` が同じ application command を実行する。少なくとも結果一覧、履歴、root dropdown、preset picker、Named Root manager、確認・通知 modal で一貫し、preset picker では絞り込み入力へフォーカス中でも選択移動・適用・cancel が動作する。さらに通常検索、履歴フィルター、preset filter/editor、Named Root editor、保存 root 管理の全単一行入力で `Ctrl+A` / `Ctrl+E` / `Ctrl+B` / `Ctrl+F` / `Ctrl+H` / `Ctrl+D` / `Ctrl+K` / `Ctrl+Y` / `Ctrl+U` が同じ共有 reducer 契約で動作する。`Ctrl+W` は別設定とタブ競合の契約に従い、設定が無効な場合は Emacs chord が選択・適用・cancelまたは独自 text edit を起動しない。

- AC-043: FR-042 のリンク追跡を有効にすると、Root 内外のリンク先の子ファイル・フォルダが各リンク経由のパスで検索でき、祖先へ戻る循環は打ち切られる。無効時は従来の候補集合、Depth・件数上限・取消を維持する。
- AC-044: FR-043 のリンク Root について Walker と FileList の逐次・置換応答で相対表示を維持し、入力 Root 自体や Root 外の独立した絶対パスを変更しない。
- AC-045: 歯車から設定画面を開き、7項目を編集・保存すると JSON の対象キーだけが更新され、現在のタブ・履歴・キー操作は変わらず次回起動に反映される。キャンセル、無効な上限値、外部編集との競合では保存せず、JSON を開く操作と明示的な再読み込みを利用できる。
- AC-046: 100行を超えるテキストの GUI プレビューは最初の100行を表示し、`Load more` で最大500行ずつ追加する。表示済み本文のコピーに行番号や装飾は含まれず、読込失敗・ファイル変更では既存本文が残る。C/C++/HTML を含む対応形式は色分けされ、画面内の切替でプレーン表示に戻せる。TUI は従来の20行表示を維持する。
- AC-047: PINを残して別の結果行をdouble clickするとその行だけを開き、EnterではPINを一括操作する。PIN一覧で非表示項目を個別解除でき、選択件数とClear Selectedの強調が残選択数に追従する。
- AC-048: GUIで日時・サイズ順を選ぶと表示上限外も含めた全一致から上位を表示する。`neme:`を入力すると任意修正候補を示し、検索完了後の0件では条件を個別変更できる。Escは変更した条件を保持し、Undoは直近の条件変更だけを取り消す。

- AC-049: root FileListを読んだ後、その更新・置換・削除をforegroundのactive tabで検知して通知する。通知から更新してもquery、filters、sortと残存する選択pathを維持する。別tab・旧世代の応答を採用せず、Walkerやchild FileListは監視しない。設定で監視を無効にでき、取得時刻を次回起動へ持ち越さない。
