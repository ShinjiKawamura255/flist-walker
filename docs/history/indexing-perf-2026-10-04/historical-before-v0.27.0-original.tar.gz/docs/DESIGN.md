# DESIGN

This file is the entry point for FlistWalker design. Detailed DES content is split by topic under `docs/design/`.

## Document Map
| Topic | Content |
| --- | --- |
| [Architecture Overview](design/architecture-overview.md) | DES-001 through DES-005, DES-009, DES-010, and DES-012 through DES-019 responsibilities and implementation locations |
| [Flows, Data Model, and API Contract](design/flows-data-api.md) | Main flows, data model, Rust API contract, DES-020 through DES-022 and DES-024 |
| [Non-functional Runtime Design](design/nonfunctional-runtime.md) | DES-006, DES-007, DES-008, DES-011, DES-023, and runtime policies |
| [Operations, Trade-offs, and Traceability](design/operations-traceability.md) | Error handling, migration/rollback, trade-offs, traceability excerpt |

## Architecture Summary
- Indexing separates FileList resolution, walker traversal, hierarchy reading, and FileList writing.
- Search separates query interpretation, match evaluation, ranking, cache/config, and execution while sharing interpretation with GUI/CLI highlighting.
- Actions separate the non-blocking UI precheck, authoritative worker-side resolved-path authorization, and the OS execution leaf; only the final authorized execution path crosses the OS boundary.
- The GUI keeps `egui/eframe` as the adapter and splits ownership across state, render, tabs, pipeline, workers, update, and filelist modules.
- Action, kind, and index execution use fixed worker counts, bounded queues, non-blocking dispatch, stale-before-I/O settlement, directly owned worker handles, and bounded shutdown.
- Runtime config, self update, ignore list, release sample, and supportability trace are tracked as separate DES concerns.

## Traceability (excerpt)
- Full excerpt: [Operations, Trade-offs, and Traceability](design/operations-traceability.md)
- DES-001 -> TC-001, TC-161 (SP-001)
- DES-003 -> TC-003, TC-155 (SP-003)
- DES-004, DES-007 -> TC-050, TC-051 (SP-004)
- DES-009 -> TC-010 (SP-010)
- DES-006, DES-007, DES-009 -> TC-150, TC-151, TC-152, TC-153 (SP-010)
- DES-009 -> TC-154, TC-203, TC-204, TC-205, TC-208, TC-209, TC-210 (SP-010)
- DES-006, DES-007, DES-009 -> TC-205, TC-206, TC-207, TC-208, TC-209, TC-211 (SP-010)
- DES-009 -> TC-173 (SP-010)
- DES-006 -> TC-007, TC-057B, TC-156, TC-161, TC-163, TC-185 (SP-007, SP-013)
- DES-012 -> TC-056, TC-178, TC-198 (SP-012)
- DES-014 -> TC-074, TC-075, TC-076, TC-077, TC-078, TC-081, TC-140, TC-157, TC-158, TC-159, TC-160, TC-169, TC-171, TC-186, TC-187 (SP-014)
- DES-009 -> TC-192 (SP-010)
- DES-009 -> TC-195, TC-197 (SP-010)
- DES-014 -> TC-196 (SP-014)
- DES-014 -> TC-188, TC-189, TC-190, TC-191 (SP-014)
- DES-014 -> TC-202 (SP-014)
- DES-017 -> TC-111, TC-127, TC-167, TC-168 (SP-016)
- DES-019 -> TC-145, TC-146, TC-147, TC-148 (SP-018)
- DES-005 -> TC-006, TC-006A, TC-015, TC-162, TC-163, TC-164, TC-166, TC-169, TC-172 (SP-006)
- DES-020 -> TC-174 (SP-019)
- DES-021 -> TC-175 (SP-020)
- DES-022 -> TC-180 (SP-021)
- DES-023 -> TC-181, TC-182, TC-183, TC-184 (SP-022)
- DES-024 -> TC-193 (SP-023)
- DES-005, DES-014, DES-019, DES-024 -> TC-215 (SP-006, SP-014, SP-018, SP-023)
- DES-005, DES-009 -> TC-201 (SP-006, SP-010)

- DES-002, DES-009 -> TC-213, TC-214 (SP-002, SP-010)
