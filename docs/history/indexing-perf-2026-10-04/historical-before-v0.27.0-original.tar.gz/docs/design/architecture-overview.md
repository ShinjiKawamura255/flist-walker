﻿# Architecture Overview

## Architecture overview
- DES-001 Index Source Resolver
- 役割: FileList 優先モード有効時に `FileList.txt`/`filelist.txt`（`filelist.txt` の大小違い含む）を検出して優先読み込み。
- 役割補足: `filelist_reader` は同じ open handle を 64 KiB 以下の chunk で事前検証し、UTF-8 と先頭 UTF-8 BOM だけを受理する。UTF-16 BOM、NUL、不正/途中切れ UTF-8、1 MiB 超の論理行は候補 callback 前に path/offset/limit を伴う error とし、validation 後は `BufReader::seek(SeekFrom::Start(0))` で内部 buffer を破棄してから strict byte-line parser を実行する。
- 役割補足: `filelist_hierarchy` は child FileList を local replacement vector へ完全に読み込んでから subtree を置換する。`filelist_writer` は UTF-8 BOM なしで生成し、祖先 FileList の重複判定/追記では同じ strict validator を使って先頭 BOM を参照文字列から除外し、拒否対象の親を変更しない。
- 役割補足: validation と parse の間の in-place valid UTF-8 rewrite は一貫 snapshot を保証しない。parser は parse 中も strict UTF-8/NUL/行上限/cancel を確認し、安定した拒否入力の zero-callback と invalid child の no-subtree-mutation を保証する。
- 実装: `rust/src/indexer/mod.rs`, `rust/src/indexer/filelist_reader.rs`, `rust/src/indexer/filelist_hierarchy.rs`, `rust/src/indexer/walker.rs`, `rust/src/indexer/filelist_writer.rs`

- DES-002 Walker Indexer
  - Batch collection and streaming share the adaptive serial fast path and common kind classifier; they remain uncapped. Interactive callers retain their bounded/adaptive concurrency policy. Directory links are never traversed.
- 役割: FileList 未使用時の再帰走査。
- 実装: `rust/src/indexer/mod.rs`, `rust/src/indexer/filelist_reader.rs`, `rust/src/indexer/filelist_hierarchy.rs`, `rust/src/indexer/walker.rs`

- DES-003 Fuzzy Search Engine
- regex matcher の構築前に top-level OR を正規化し、空枝を除去する。exact枝はASCII case条件と厳密anchorを保持したescaped literalとして組み込み、regex group/class/escapeは維持する。
- 役割: query domain の `CompiledQuery` / `PreparedCandidate` / `QueryEvaluation` がクエリ解釈（`'` `!` `^` `$` `|`）、候補文字列正規化、match/visibility、既存 score/bonus、任意の文字 index highlight span を一元的に担う。非 regex の `^`/`$` は隣接文字制約付きファジーとして評価し、regex モードでも plain include token は regex へ昇格させず、regex 構文を含む token だけを regex matcher として扱う。
- 役割補足: 空白で分割した通常語 token は AND 条件で絞り込みつつ、score では token ごとのリテラル一致を subsequence 一致より優先して順位付けする。
- 役割補足: 同じ unanchored 完全一致 token が複数回指定された場合は query compile 時に必要出現回数として保持し、search と visible highlight 判定の両方で同じ回数条件を適用する。
- 役割補足: GUI/CLI の `Ignore Case` フラグを受け取り、search と highlight で同じ比較モードを使う。
- 役割補足: 検索クエリは要求単位で1回 compile し、候補ごとの path 文字列化・正規化を `PreparedCandidate` で1回に抑える。rank-only 評価は span を割り当てず、大規模候補集合では search worker 内で並列評価しつつ表示用の上位 `limit` 件だけを抽出する。search は shared evaluation 後に別の visible 判定を行わない。
- 役割補足: `CompiledIgnoreTerms` は CLI filter operation と GUI ignore filter scope/pass で1回生成して候補 loop へ再利用する。prefix cache は search options/root と live snapshot identity を含む完全な意味論 key で分離する。
- 実装: `rust/src/query.rs`, `rust/src/search/mod.rs`, `rust/src/search/match_eval.rs`, `rust/src/search/cache.rs`, `rust/src/search/config.rs`, `rust/src/search/execute.rs`, `rust/src/search/rank.rs`, `rust/src/ui_model/highlight.rs`, `rust/src/app/cache.rs`, `rust/src/app/preview_flow.rs`

- DES-004 Action Executor
- 役割: UI の action intent、worker の root confinement、OS 固有の open/execute leaf を分離し、認可済み path だけが OS 境界へ到達する testable seam を保つ。
- 役割補足: UI は同期 filesystem I/O を行わない `Reject` / `Defer` の字句的 precheck と trusted root を含む request 構築だけを担当する。`Defer` は許可を意味せず、worker の権威的な判定へ必ず送る。
- 役割補足: action authorization module は action mode から raw effective target と display path を導出し、字句的 root と解決済み root の両 scope に対する component containment、解決済み execution path の deduplication、execution/display path の分離を担当する。raw target が字句的 root 配下、または解決先が解決済み root 配下なら許可するため、root 自体および root 配下の symlink/junction を OS 間で同じ契約として扱う。
- 役割補足: Action worker は全 target の fail-closed な事前認可、各 OS 呼び出し直前の再認可、実行順序、途中失敗時の残件停止と partial-completion 通知を担当する。OS leaf は認可済みの解決済み path を実行し、root policy を判断しない。
- 実装: `rust/src/app/coordinator.rs`, `rust/src/app/input/actions.rs`, `rust/src/app/shell_support.rs`, `rust/src/app/worker/protocol.rs`, `rust/src/app/worker/tasks.rs`, `rust/src/actions.rs`

- DES-005 CLI Adapter
- TUI producerは公開前にretirement workerへArc guardを登録する。retirementは保持4件＋queue4件に制限し、満杯時はproducerだけがcancel-aware待機する。indexはrequest単位のbatch owner、search/catalogは共有snapshotを持ち、UIで最後のPathBuf配列ownerを解放しない。
- TUI presetはF7 modalと容量1の専用catalog workerを持ち、request-owned search snapshotから保存する。表示のcloseとmutation settlementを分離し、pending中の出力はpath/root snapshot、取消は優先intentとして保持する。
- 役割: `clap` 引数を typed CLI options へ変換し、GUI、batch CLI、interactive CLI を明示 dispatch する。Linux/macOS universal の legacy `--cli` と全 platform の `fw` 契約を維持し、CLI-only option の依存/競合と mode-specific initialization/exit status を所有する。
- 役割補足: Windows は compile-time に GUI subsystem を指定する universal `FlistWalker.exe` と、console subsystem の `fw.exe` へ分離する。universal は console の attach/detach を行わず GUI と internal updater restart を所有し、`fw` が shell-synchronous な CLI/TUI/update/help/version と標準 handle を所有する。Windows universal の旧 CLI dispatch 実装は direct process caller 向け best-effort として残す。
- 役割補足: TUIが所有するuser-facing path文字列化は `tui_path_label` を唯一の境界とし、options summary、status、picker、errorがWindows extended prefixを直接表示しない。TUI本番sourceの直接 `Path::display` / `to_string_lossy` はTC-177の静的guardで拒否する。
- 役割補足: batch adapter は cancellable index/search、source/type/ignore/search option、relative/absolute path、newline/NUL framing を構成し、結果だけを stdout、進捗/診断を stderr へ送る。
- 役割補足: batch adapter は shared full-match sort の後に limit を適用し、print/open/reveal/exec、root selector、saved-root listing、FileList operation の引数整合性と exit status を所有する。`command_exec` は standalone placeholder、canonical root authorization、OS argv budget、optional path cap、stable greedy batch、direct spawn、stop-on-failure/cancel を所有し、adapter は report を exit/status へ変換する。
- 役割補足: interactive adapter は request identity を持つ index/search worker、cursor-aware editor、ordered pin、dynamic viewport、stderr renderer を分離する。renderer は complete frame をメモリ上へ構築して terminal synchronized update で一括送信し、全画面 clear と再描画の中間状態を表示させない。terminal session guard は raw/alternate/cursor/bracketed-paste の成立状態を所有して逆順復旧し、guard 解放後だけ selected path/root を main adapter へ返して stdout writer または external executor を呼ぶ。
- 役割補足: TUI FileList active は pending intent state machine を所有し、`CancelExit > SwitchRoot > SelectOutput` を settlement 後にだけ解決する。FileList worker は generic shutdown detach の対象外で、panic/disconnect を failed settlement として合成する。
- 実装: `rust/src/main.rs`, `rust/src/cli.rs`, `rust/src/cli/args.rs`, `rust/src/cli/batch.rs`, `rust/src/cli_tui.rs`, `rust/src/cli_tui/`, `rust/src/gui_launch.rs`, `rust/src/launch_path.rs`, `rust/src/command_exec.rs`, `rust/src/actions.rs`, `rust/src/indexer/mod.rs`, `rust/src/indexer/walker.rs`, `rust/src/walker_runtime/`

- DES-009 GUI Adapter (egui/eframe)
- 履歴/preset/Named Root一覧はegui scope内の選択identity変化だけで最小scrollを要求する。tab barは右端固定の設定ボタンと横ScrollAreaを分離し、追加ボタンはScrollArea内の末尾タブ直後に置く。active identityの変更だけで追従し、末尾タブの場合は追加ボタンを含む矩形を可視化する。
- 新規タブの継承結果はindex/search完了イベントを生じないため、`create_new_tab`が既存の表示結果kind queueとpreview requestを起動する。default walkへの再indexが必要な場合はその世代の確立後に行い、既存のbounded worker・tab ID/epoch/request IDによる応答制御を使う。
- 終了キー: `gui_launch.rs` は app creator で egui の `quit_shortcuts` を空にする。macOS は winit の標準メニュー生成後に `gui_launch/macos_menu.rs` が `terminate:` action の key equivalent だけを解除し、メニュー項目と他のキー割り当てを保持する。native close と updater の Close request は既存経路へ渡す。
- 役割: 検索入力、結果表示、プレビュー、複数選択と一括操作を提供。結果ハイライトは search と同じ query 解釈を shared module 経由で使用する。結果スナップショット更新時は current row を行番号ベースで維持し、結果数が減った場合のみ末尾へ丸める。
- 役割補足: Preview worker は File/Directory の header に取得可能な size、`Created` / `Updated`、条件付き属性、シンボリックリンクの `Target` を付加する。symlink では size/日時を `Target ...` としてリンク先、属性をリンク自身へ分ける。日時は依存追加なしの UTC 表示とし、metadata の取得失敗は該当行を省略して本文表示を継続する。
- 役割補足: 起動直後と `Ctrl+G` / `Esc` の検索キャンセル後は、候補が存在する場合に 1 行目を既定選択として復帰させる。
- 役割補足: 検索オプションの `Ignore Case` を既定有効で保持し、無効時は検索結果とハイライトを case-sensitive に切り替える。
- 役割補足: query history の検索順位・exact duplicate 最新化・100件上限は `query_history.rs`、Unicode character index と Emacs 風編集 reducer は `text_editing.rs` に置き、GUI/TUI adapter は event/selection の変換だけを担当する。
- 役割補足: ヘルプモーダルはキーボードショートカットに加え、共有compiled queryのfield指定（`name:`、`path:`、`dir:`、`ext:`）、fieldへ適用する演算子、複合例を静的な利用案内として表示する。検索要求やworkerを起動せず、表示中は既存の入力遮断契約を維持する。
- 役割補足: preset picker はメインpanelの`Presets...` top actionとOS primary modifierの`Primary+Shift+P`から同じopen transitionへ入るmodalとし、catalog を専用 worker で非同期 load して名前を fuzzy filter する。Enter は pure search state だけを現在 tab へ適用し、Addは現在tabから新規draft、F2は選択中presetの編集draft、Deleteは確認状態へ遷移する。presetとNamed Rootのadd/replace/deleteは同じworker経由でatomic更新する。Named Root renameは参照presetを追従させ、deleteはsnapshot fallbackへ移行する。catalog編集は背景actionや現在tabを変更せず、メインpanelにはpicker launcherだけを置いて一覧・選択・編集UIを埋め込まない。
- 役割補足: GUI の `次へ` / `前へ` / `確定` / `キャンセル` は `app/input/shortcuts.rs` の共有 semantic helper が通常キーと、設定有効時だけの Emacs chord を同じ command へ変換する。結果一覧、履歴、root dropdown、preset/Named Root、確認・通知 modal はこの境界を使い、新しい対話面で `ArrowDown` / `ArrowUp` / `Enter` / `Escape` と Emacs 判定を feature ごとに複製しない。
- 役割補足: GUI の単一行入力は `app/input/text_editing.rs` の共有 adapter から Unicode character index の reducer と共通 kill buffer を利用する。通常検索・履歴だけに閉じず、preset filter/editor、Named Root editor、保存 root 管理も同じ境界を通し、新しい `TextEdit::singleline` を素のまま追加しない。query/history 固有の検索再評価は adapter の text-changed 結果を各 owner が受けて実行する。
- 役割補足: 非空 query 時の結果一覧は、不可視行の `LayoutJob` / highlight 組み立てを行わず、可視行だけに描画コストを寄せてカーソル移動や再描画時の UI 応答性を維持する。
- 役割補足: `app/mod.rs` は横断 orchestration と feature 間の結線だけを保持し、feature ごとの state transition は `app/filelist/mod.rs`、`app/update.rs`、`app/preset_picker.rs`、`app/render.rs`、`app/input/mod.rs`、`app/session.rs`、`app/state.rs`、`app/tabs.rs`、`app/pipeline.rs`、`app/pipeline_owner.rs`、`app/cache.rs`、`app/result_reducer.rs`、`app/result_flow.rs`、`app/preview_flow.rs`、`app/response_flow.rs`、`app/root_browser.rs` へ分離する。status line / notice / update-cycle / root/path compare の純粋 helper は `app/coordinator.rs` へ寄せる。
- 役割補足: saved roots の `Manage list` は `RootListManagerState` に保存済み list とは分離した draft roots/default root、通常時の単一選択、編集中の index/path、削除モードと複数選択を保持する。`app/render_dialogs/root_list.rs` は通常・編集・削除モードを描画し、検証、正規化、重複排除、default root 追従、Apply/Cancel 境界は `app/root_browser.rs` が担当する。
- 役割補足: `app/mod.rs` の fixed point は `startup/bootstrap`、`frame update cycle`、`shutdown/persist`、`tab routing`、`filelist/update dialog dispatch`、`trace helper` の 6 区分を top-level で束ねることに限定し、各区分の state transition と policy 判定は owner module 側へ寄せる。process shutdown、window trace、egui font setup、root visibility/cache helper などの shell-local helper policy は `app/shell_support.rs` へ移した。
- 役割補足: `FlistWalkerApp` の field inventory は、`app-global shared state`、`active-tab-local state`、`persisted/background tab state`、`feature dialog/update state` の 4 束で追跡し、以後の state decomposition はこの分類を崩さない。
  - 役割補足: `FlistWalkerApp` は `AppShellState` を最上位の ownership boundary とし、その内側に `AppRuntimeState`、`TabSessionState`、`FeatureStateBundle`、`RuntimeUiState`、`CacheStateBundle`、worker/state coordinators をまとめる。shell は runtime bundle を透明に露出せず、coordinator は `shell` バンドル経由で state に明示的にアクセスする。
- 役割補足: `FlistWalkerApp` の app-global / active-result live fields は `AppRuntimeState` に束ね、coordinator 直下の direct field surface を runtime bundle へ寄せる。
- 役割補足: active tab の高容量 live payload（`TabIndexState`、`TabQueryState`、`TabResultState`、entry-kind cache、notice、pending request と進行状態）は `AppRuntimeState` / coordinator / live cache 側を唯一の authoritative owner とし、inactive tab は `AppTabState` が authoritative owner になる。active slot は `id` / accent と root/filter の小さな mirror を保持するが、その payload は scratch であり active-path reader/writer は参照しない。
- 役割補足: tab activation は `TabSessionState` から slot を一時的に remove して owned value とし、outgoing live payload を slot へ store、active index 更新、incoming root/filter の適用と payload の shell への load、scratch slot の reinsert、post-activation の順で行う。`&AppTabState` を保持したまま `&mut FlistWalkerApp` を更新せず、index/pending/kind/incremental/result container と entry-kind cache は move/swap し、activation hot path では allocator compaction、全件 drop、result rebuild を行わない。inactive tab の計算済み Results は保持し、Preview 本文だけを reload pending 付きで解放する。
- 役割補足: reorder は active shell payload を再ロードせず identity/mirror だけを更新する。create/active close/restore/session restore は同じ store/load 境界を使い、inactive close は active shell を変更しない。session persistence は active shell と inactive slot から persisted fields だけを射影し、`AppTabState` 全体を clone しない。
- 役割補足: `startup/bootstrap` では `new` / `from_launch` / `new_with_launch` が eframe entrypoint と app 初期化を束ねる一方、worker wiring と launch seed 構築は `app/bootstrap.rs`、restore/persist 契約は `app/session.rs` が owner を持つ。
- 役割補足: `shell_support.rs` は process shutdown、egui font setup、window trace、root visibility/cache helper などの shell-local helper policy を集約し、`app/mod.rs` から helper surface を外す。
- 役割補足: `frame update cycle` では `app/mod.rs` が egui frame ごとの orchestration と repaint 判断だけを持ち、`app/pipeline.rs` は index response の frame budget、route 選択、typed effect dispatch、`app/index_response_arbitration.rs` は tab/UI state を変更しない Active-first / Warm-second / request-id 順の mailbox 選択と quota、`app/index_coordinator.rs` は generation/role/mailbox tracking を担当する。`app/index_response_effects.rs` は active/stale response、terminal ownership、reclaim、incremental completion を適用して loop/frame effect を返し、background payload mutation は同 owner から `app/tabs.rs` の reducer へ委譲する。finalization の identity/policy/input payload と増分 workspace/advance は `app/index_finalization.rs`、active result refresh は `app/pipeline_owner.rs`、render command 生成は `app/render.rs` が担当する。
- 役割補足: `shutdown/persist` では `app/mod.rs` が eframe callback から shutdown seam を呼ぶだけに留め、UI state 永続化は `app/session.rs`、worker stop/join は `app/worker/runtime.rs` が担当する。
- 役割補足: `tab routing` では `app/mod.rs` が active tab と request routing の top-level context を持ち、tab switch/reorder/close と restore/refresh は `app/tabs.rs`、background response polling / apply は `app/response_flow.rs`、root selector lifecycle は `app/root_browser.rs` が owner を持つ。background reducer は routing 先 index が current active index の場合に応答を破棄し、active slot の scratch payload を更新しない。
- 役割補足: `filelist/update dialog dispatch` では `app/mod.rs` が dialog command dispatch と notice/status line 連携を束ね、FileList state transition は `app/filelist/mod.rs`、update state transition は `app/update.rs` が担当する。
- 役割補足: `trace helper` では `app/mod.rs` が opt-in window trace の入口だけを保持し、worker trace は `app/worker/tasks.rs` の実装 body と `app/worker/protocol.rs`、session/window 永続化まわりの補助 trace は `app/session.rs` など各 owner helper へ分離する。
- 役割補足: `app/session.rs` は UI state 永続化、saved roots、tab/session restore、window geometry の stabilize と restore を担当し、起動/終了まわりの永続化契約を一箇所へ集約する。
- 役割補足: `app/state.rs` は filelist/update dialog 状態、sort metadata、entry kind、tab drag など GUI 横断で共有される state 型を集約し、index finalization の高容量 workspace は `app/index_finalization.rs` に分離して `FlistWalkerApp` 本体から型定義のノイズを外す。
- 役割補足: feature 単位の live state は `app/state.rs` の `FeatureStateBundle` (`root_browser`, `filelist`, `update`) に寄せ、`FlistWalkerApp` 直下から dialog/update/root browser field を外す。tab/session registry は `TabSessionState`、feature dialog/update は `FeatureStateBundle` として ownership を分離する。
  - `FileListManager` / `UpdateManager` は内部 bundle を透明に露出せず、`workflow` / `state` を明示参照する前提で扱う。
- 役割補足: background tab snapshot は `app/tab_state.rs` の `TabQueryState`、`TabIndexState`、`TabResultState` へ分割し、tab capture/apply/restore で query/history/index/result の境界を明示する。
- 役割補足: `app/tabs.rs` は tab 初期化、intent/lifecycle/committed snapshot の ownership transition、switch/move/close/restore、新規 tab 作成、action/sort routing を担当する。`app/state.rs` の `TabSessionState` は live tab registry、activation sequence、closed lightweight intent、live/closed共通LRUを所有し、旧 `pending_activation_refresh` marker は使用しない。`app/index_coordinator.rs` は generation/role/mailbox と Active+sole Warm scheduler、`app/index_worker.rs` は mailbox publication、固定 reclaimer は detached heavy payload の最終 drop を所有する。

#### Regression Guard: cleanup 後の index mailbox 所有権

- Scenario: worker が request を dequeue した直後に UI 側 cleanup が mailbox owner を削除する。
- Expected Behavior: worker は事前登録済み mailbox の参照だけを取得し、不在なら request を破棄する。mailbox、route、terminal ownership を再生成しない。
- Non-goals: scheduler quota、frame budget、request ordering、worker 数は変更しない。
- Related Tests: `tc_206_dequeued_worker_request_regression_cannot_recreate_mailbox_after_cleanup`、`tc_207_repeated_rapid_demote_keeps_request_owners_bounded_and_quiesces`
- Notes for Future Changes: dequeue 後の mailbox lookup に `entry` / `or_insert_with` を戻さず、mailbox 登録は request enqueue 前の coordinator owner transition に限定する。
- 役割補足: root change、tab lifecycle、tab activation/background restore、tab close cleanup、tab reorder の state transition は専用 helper / command 境界へ寄せてあり、`app/mod.rs` には feature owner を呼び分ける coordinator だけを残す。
- 役割補足: `app/render.rs` は `run_ui_frame()`、`RenderCommand`、`dispatch_render_commands()`、小さな facade wrapper を保持する。results/status は `app/render_panels.rs`、top panel は `app/render_panels/top_panel.rs`、FileList/update/root-list/help dialog は `app/render_dialogs/` の private owner、tab/snapshot/theme は各 render module が担当し、interaction からの state transition は描画後 dispatcher で一段遅らせて実行する。help の開閉状態は `RuntimeUiState` にだけ保持し、`app/input/dialogs.rs` が表示中の背後キーイベントを遮断する。render owner は filesystem/network/process/worker 実装へ依存しない。
- 役割補足: `app/mod.rs` の frame/update/exit orchestration は `poll_runtime_events()`, `run_update_cycle()`, `schedule_frame_repaint()`, `request_viewport_close_if_needed()`, `persist_state_and_shutdown()` といった helper seam を経由し、`update()` / `on_exit()` / `Drop` の open-coded sequence を最小化する。
- 役割補足: app 起動時の worker wiring と launch 由来の seed 構築は `app/bootstrap.rs` へ寄せ、`new_with_launch` は coordinator として初期化結果を束ねる。
- 役割補足: worker request/response channel は `app/worker/bus.rs` へ集約し、`FlistWalkerApp` 直下には worker bus 全体を 1 フィールドで保持する。
- 役割補足: action、kind、index の dispatch owner は bounded sender の `try_send` 結果を state transition へ変換する。action は受理後だけ request routing と in-progress state を commit し、kind/index は `Full` の要求を owner の bounded retry state へ戻す。`Disconnected`、stale、cancel は owner が terminal response と同じ cleanup reducer へ流し、pending/routing を残さない。
- 役割補足: index coordinator は dispatch 済み要求を最大 2 件、app pending scheduler は全体最大 4 件かつ tab ごとに最新 1 件だけ所有する。dispatch 済み index request は replacement によって stale になっても terminal response まで tracking に残し、worker channel の送信成功時だけ inflight に加える。これにより coordinator の空き判定と物理 worker FIFO を一致させ、active-tab request が未追跡の stale backlog 後方へ入ることを防ぐ。kind owner は `Full` で取り出した path を queue 先頭へ戻し、worker からの `kind=None` terminal response で pending/in-flight set を解放する。
- 役割補足: runtime UI の一時状態は `app/ui_state.rs` の `RuntimeUiState` へ、query/history 系は `app/query_state.rs` の `QueryState` へ束ね、coordinator は state holder を介して feature 間を調停する。
- 役割補足: `app/pipeline.rs` は index queue、index response poll、dispatcher を担当し、active tab 向け search/result refresh と entry filter 再適用は `app/pipeline_owner.rs` の dedicated owner surface へ、background tab 向け search/index response apply は `app/tabs.rs` の background-flow helper へ委譲する。index request の採番・tracking・active/background refresh 開始・terminal cleanup の owner API は `app/index_coordinator.rs` 側へ寄せ、search worker の request/tab routing helper は `app/search_coordinator.rs` 側へ寄せる。
- 役割補足: `app/search_coordinator.rs` は search request_id 採番、active/background tab routing、stale response route 判定を担当し、active search の apply / rerun は `app/pipeline_owner.rs`、background search 応答の保持は `app/tabs.rs` が担当する。
- 役割補足: `app/filelist/mod.rs` は overwrite/ancestor/use-walker/deferred-after-index の pending state、cancel flag 伝播、`Finished` / `Failed` / `Canceled` 応答後の cleanup と follow-up dispatch を owner として扱う。`app/state.rs` の `FileListManager` は request_id と requested root を相関して `CurrentRoot` / `PreviousRoot` / `StaleRequestedRoot` を分類し、`poll_filelist_response()` が stale requested root を無視したまま reducer 的に post-settle command を dispatch できるようにする。
- 役割補足: `app/update.rs` は startup check / install request の dispatch を担当し、request_id-correlated response apply、stale 応答吸収、prompt/failure/install_started 遷移の cleanup は `app/state.rs` の `UpdateManager` command surface と合わせて owner 境界を保つ。
- 役割補足: `app/index_worker.rs` は FileList / Walker streaming、kind classification、index worker 実装を担当し、その他の worker spawn/use-case は `app/worker/tasks.rs` に集約する。
- 役割補足: `app/worker/protocol.rs` は search/index/preview/action/sort/kind/filelist/update/root-validation の request/response 型を集約し、worker protocol surface を worker 実装や bus wiring から独立して保守できるようにする。保存済み root の filesystem validation は Catalog worker と pending identity を共有せず、専用 `RootValidationWorkerBus` が request_id、dialog generation、intent/index、draft snapshot を受けて canonical duplicate 判定まで所有する。
- 役割補足: `app/worker/runtime.rs` は worker shutdown signal と join timeout の管理だけを持ち、個別 worker 実装から runtime orchestration を分離する。
- 役割補足: `app/worker/runtime.rs` は action 2、kind 1、index 2 の固定 worker handle を名前付きで直接所有し、stop accepting -> queued request settle -> join -> response close を全体 250ms の終了予算で調停する。
- 役割補足: `app/cache.rs` は preview/highlight/sort metadata/entry-kind cache state と invalidation に専念し、bounded storage と scope/eviction を局所化する。entry-kind cache は tab-local payload として activation 時に move/swap し、それ以外の cache は app-global とする。preview/highlight/routing の orchestration は `app/preview_flow.rs` へ、sort の orchestration は `app/result_flow.rs` へ、実際の response apply と snapshot refresh は `app/result_reducer.rs` へ分離する。
- 役割補足: `app/response_flow.rs` は preview/action/sort を中心に worker response の polling と routing を集約し、background tab 応答も owner ごとに dispatch できるようにする。
- 役割補足: `app/root_browser.rs` は root selector dialog の state と root change cleanup を担当し、root 変更時の一時 UI を tab/session state から分離する。
- 役割補足: action authorization policy は `actions.rs`、worker の共有 action notice formatting は `app/worker/tasks.rs` が直接所有し、re-export 専用の中間 module を置かない。
- 役割補足: search domain は `search/mod.rs` を public API と high-level orchestration の入口に保ちつつ、query compile / literal/regex match / searchable entry materialization / candidate score evaluation は `search/match_eval.rs`、prefix cache は `search/cache.rs`、execution mode と parallel tuning は `search/config.rs`、candidate collect は `search/execute.rs`、ranking/materialization は `search/rank.rs` へ分割して保守する。
- 役割補足: indexer domain は `indexer/mod.rs` を public API、型、FileList-vs-walker build orchestration の入口に保ちつつ、nested FileList override は `indexer/filelist_hierarchy.rs`、FileList read は `indexer/filelist_reader.rs`、walker は `indexer/walker.rs`、FileList write/ancestor propagation は `indexer/filelist_writer.rs` へ分割して保守する。
- 役割補足: active indexing の terminal response は `PendingActiveIndexFinish` として保留でき、未反映 `pending_entries` を frame budget 内で吸収し終えてから finalization する。既定の files+folders 両有効では、終端時に全件 filter / kind cache rebuild を再実行せず、incremental ingestion 済みの state を source of truth へ昇格する。
- 役割補足: runtime settings は Windows では `%LocalAppData%\flistwalker\`、Linux/macOS では `~/.flistwalker/` へ集約し、`FLISTWALKER_*` は初回 seed としてのみ使う。初回 seed には一般利用者向けの `walker_max_entries`、`history_persist_disabled`、`restore_tabs_enabled`、`emacs_keybindings_enabled`、`ctrl_w_deletes_word_in_query`、`tab_pin_moves_to_next_row` を既定値で含め、既存 config に欠けている場合も読み込み時に同じ項目を補完する。build/release と dev/test override は従来どおり env のまま保持し、公開 docs には config file の場所と seed-only 挙動を明記する。
- 役割補足: `walker_runtime/` は GUI/TUI 共通の adaptive traversal、runtime limit 解決、entry classification、truncation notice を UI 非依存で提供する。`app/index_worker.rs` は GUI protocol/batching/tracing/metrics を所有し、`cli_tui/` は path-only batch と request identity 付き truncation を所有する。FileList 作成の完全 snapshot は別経路に保つ。
- 役割補足: candidate は `entry.rs` の `Entry { path, kind }` で app/index/search worker 境界をまたいで表現し、app 側の kind side-channel を持たない。
- 実装: `rust/src/app/mod.rs`, `rust/src/app/coordinator.rs`, `rust/src/app/filelist/mod.rs`, `rust/src/app/update.rs`, `rust/src/app/render.rs`, `rust/src/app/input/mod.rs`, `rust/src/app/session.rs`, `rust/src/app/state.rs`, `rust/src/app/tab_state.rs`, `rust/src/app/tabs.rs`, `rust/src/app/pipeline.rs`, `rust/src/app/pipeline_owner.rs`, `rust/src/app/bootstrap.rs`, `rust/src/app/cache.rs`, `rust/src/app/result_reducer.rs`, `rust/src/app/result_flow.rs`, `rust/src/app/preview_flow.rs`, `rust/src/app/worker/bus.rs`, `rust/src/app/worker/protocol.rs`, `rust/src/app/worker/runtime.rs`, `rust/src/app/shell_support.rs`, `rust/src/app/ui_state.rs`, `rust/src/app/query_state.rs`, `rust/src/app/search_coordinator.rs`, `rust/src/app/index_coordinator.rs`, `rust/src/app/index_worker.rs`, `rust/src/app/worker/tasks.rs`, `rust/src/entry.rs`, `rust/src/ui_model/mod.rs`, `rust/src/query.rs`, `rust/src/query_history.rs`, `rust/src/text_editing.rs`, `rust/src/search/mod.rs`, `rust/src/search/cache.rs`, `rust/src/search/config.rs`, `rust/src/search/execute.rs`, `rust/src/search/rank.rs`, `rust/src/ignore_list.rs`, `rust/src/indexer/mod.rs`, `rust/src/indexer/filelist_reader.rs`, `rust/src/indexer/walker.rs`, `rust/src/indexer/filelist_writer.rs`
- 実装: `rust/src/app/mod.rs`, `rust/src/app/coordinator.rs`, `rust/src/app/filelist/mod.rs`, `rust/src/app/update.rs`, `rust/src/app/render.rs`, `rust/src/app/input/mod.rs`, `rust/src/app/session.rs`, `rust/src/app/state.rs`, `rust/src/app/tab_state.rs`, `rust/src/app/tabs.rs`, `rust/src/app/pipeline.rs`, `rust/src/app/pipeline_owner.rs`, `rust/src/app/bootstrap.rs`, `rust/src/app/cache.rs`, `rust/src/app/result_reducer.rs`, `rust/src/app/result_flow.rs`, `rust/src/app/preview_flow.rs`, `rust/src/app/worker/bus.rs`, `rust/src/app/worker/protocol.rs`, `rust/src/app/worker/runtime.rs`, `rust/src/app/shell_support.rs`, `rust/src/app/ui_state.rs`, `rust/src/app/query_state.rs`, `rust/src/app/search_coordinator.rs`, `rust/src/app/index_coordinator.rs`, `rust/src/app/index_worker.rs`, `rust/src/app/worker/tasks.rs`, `rust/src/entry.rs`, `rust/src/ui_model/mod.rs`, `rust/src/query.rs`, `rust/src/query_history.rs`, `rust/src/text_editing.rs`, `rust/src/runtime_config.rs`, `rust/src/search/mod.rs`, `rust/src/search/cache.rs`, `rust/src/search/config.rs`, `rust/src/search/execute.rs`, `rust/src/search/rank.rs`, `rust/src/ignore_list.rs`, `rust/src/indexer/mod.rs`, `rust/src/indexer/filelist_reader.rs`, `rust/src/indexer/walker.rs`, `rust/src/indexer/filelist_writer.rs`

- DES-010 GUI Test Artifacts
- 役割: GUI 回帰手順と結果を管理する。
- 実装: `docs/TESTPLAN.md` の GUI 手順節

- DES-012 CI / Release Hygiene
- 役割: version-addressed required CI と集約 `CI Gate`、trusted-base `CI Policy Guardian`、Cargo-change detector付き audit、scheduled security intelligence、latest canary、machine-PR rebase auto-merge、release検証を責務分離する。agent/workflowは正確なrebase登録と、clean かつ同期済み `master` からの feature-branch開始、rebase 後の限定的な local branch cleanup を担い、repository設定は他merge methodを無効化し、branch protectionはlinear historyとnon-bypass gateを担う。
- 実装: `.github/workflows/ci-cross-platform.yml`, `.github/workflows/ci-policy-guardian.yml`, `.github/workflows/security-audit.yml`, `.github/workflows/ci-canary.yml`, `.github/workflows/dependabot-auto-merge.yml`, `.github/workflows/perf-regression.yml`, `.github/workflows/release-tagged.yml`, `.github/dependabot.yml`, `scripts/check_ci_policy.py`, `scripts/tests/test_check_ci_policy.py`, `scripts/prepare-release.ps1`, `scripts/test-prepare-release-archive.ps1`, `rust/rust-toolchain.toml`, `rust/.cargo/audit.toml`, `docs/CI_OPERATIONS.md`, `docs/OSS_COMPLIANCE.md`
- 役割補足: Windows packagingはflat release sidecar名とarchive-local名を分離し、fresh Windows PowerShell processでTC-178を実行してZIP rootの4項目契約を固定する。
- 役割補足: required CI は product/change correctness を判定し、Cargo 関連変更時だけ mutable advisory database を merge gate に接続する。scheduled audit は後日 advisory、canary は latest compatibility を観測するため branch protection の required context にしない。
- 役割補足: numbered hosted runner label でも image 内容は更新されるため、各 job は `ImageOS` / `ImageVersion` を evidence とし、policy checker が full SHA、pin、permissions、timeout、cache、conditional audit/gate contract を検査する。
- 役割補足: heavy PR CIはmacOS/Windows native jobでlocked clippyを実行してplatform cfg固有warningをtag作成前にblockし、tag release preflightはLinux/macOS/Windows nativeの全jobでlocked test/clippyを再実行する。trusted policy checker/testはこれらのplatform coverage退行を拒否する。
- 役割補足: Guardian は default branch のworkflow一式、Dependabot設定、toolchain定義、audit exception設定、checker/testをtrusted policy setとし、PR headからAPI取得したallowlist policy blobだけを一時領域で検査する。通常変更はrunner/action/tool version pinに限定し、PR codeは実行しない。

- DES-013 Result Sort Controller
- 役割: Shownの結果snapshot内sortと、All matchesの全候補worker sort、日付属性の遅延取得、上限付き属性cacheを管理。
- committed payloadは元のScore順位かどうかを保持し、All matches由来のsnapshotからScoreへ戻す場合は全候補から再検索する。mode/scope変更は旧requestを失効させ、保留queryを新requestで再要求する。履歴適用やEscを含むquery変更はScoreへ戻し、presetの明示sortは維持する。
- 実装: `rust/src/app/mod.rs`, `rust/src/app/render.rs`, `rust/src/app/cache.rs`, `rust/src/app/worker/tasks.rs`, `rust/src/app/state.rs`, `rust/src/app/pipeline.rs`

- DES-014 Self Update Coordinator
- 役割: GitHub Releases の最新 version 確認、対象 asset と sidecar 文書 (`*.README.txt`, `*.LICENSE.txt`, `*.THIRD_PARTY_NOTICES.txt`) の選択、`SHA256SUMS.sig` と `SHA256SUMS` の検証、Windows/Linux 向け staged update と再起動を制御する。
- 実装: `rust/src/updater.rs`, `rust/src/updater/release.rs`, `rust/src/updater/staging.rs`, `rust/src/updater/manifest.rs`, `rust/src/updater/apply.rs`, `rust/src/updater/transaction.rs`, `rust/src/updater/transaction/model.rs`, `rust/src/updater/transaction/filesystem.rs`, `rust/src/updater/transaction/platform.rs`, `rust/src/main.rs`, `rust/src/app/update.rs`, `rust/src/app/render.rs`, `rust/src/app/worker/tasks.rs`, `rust/src/app/state.rs`
- 役割補足: `check_for_update()` は release fetch と candidate 解決を分け、candidate 解決側では release asset 選択と support classification を helper 化して contract を小さく保つ。
- 役割補足: self-update apply helper は署名検証と全 staged asset の checksum 検証を通過した private verified bundle だけを受け取り、未検証 staged path を platform apply へ渡さない。
- 役割補足: staged asset、copied Rust helper、transaction `.new` は no-overwrite file creation primitive を経由し、既存 path の暗黙上書きを避ける。
- 役割補足: staging は署名済み manifest を asset より先に取得し、strict manifest parser、redirect/origin policy、decoded-byte counter、request/overall deadline、streaming SHA-256 を通過した `VerifiedUpdateBundle` だけを生成する。main process の ownership guard が helper 起動前の partial cleanup を担当する。
- 役割補足: activation は executable parent 内の same-directory preparation、create-new lock、per-target write-ahead marker、parent/helper registration acknowledgement、sidecars-first/binary-last commit、platform atomic replacement、backup rollback、startup recovery を 1 transaction として管理する。Windows の既存 target は外部 shell を起動せず updater process 内の native `ReplaceFileW` で置換し、ambiguous state は証跡を保持して停止する。
- 役割補足: candidate は release metadata/support と optional `AutoUpdateAssets` を分離し、OS/CPU support を asset lookup より先に決める。manual-only candidate は install payload を持たず、apply 入口は `Auto + Some(payload)` の invariant を再検証する。
- 役割補足: GUI と update worker は per-request atomic control を共有し、cancelable staging と transaction/helper handoff の境界を CAS で固定する。native/signal close は staging を cancel して `CancelClose` で待機し、handoff 開始後は acknowledgement まで cancellation を観測しない。
- 役割補足: helper failure record は acknowledgement から得た検証済み install directory だけへ bounded structured record として best-effort 保存する。rollback 後の旧 binary 再起動では spawn 前に publish して startup read との race を避け、GUI startup は recovery と helper の両診断を保持したまま suppressible check error と別の one-shot modal へ渡す。
- 役割補足: transaction coordinator は状態遷移を調停し、marker-v1 schema は `model`、path/type/hash の再検証と artifact policy は `filesystem`、process 待機・再起動と OS native replacement は `platform` が所有する。platform から model/filesystem への逆依存を禁止し、serialized marker contract と rollback/recovery policy を構造変更から隔離する。
- 役割補足: helper は current executable を transaction 固有の同一ディレクトリ path へ create-new copy した Rust process とし、通常の CLI/config/GUI 初期化より前に hidden transaction ID/start token を検証して同じ transaction core を実行する。
- 役割補足: update request / apply / failure の主要遷移は `AppendWindowTrace` と worker-side `tracing` の両方で残し、worker trace は `flow=update` / `event=*` / `request_id=*` を canonical field として support 時の request_id correlation を取りやすくする。
- 役割補足: request/response trace の details には request_id を必ず含め、update_check_failed や update_failed は error 内容も併記して support 時の切り分けをしやすくする。
- 役割補足: `UpdateState` と update worker request/response の lifecycle、stale 応答吸収、prompt/failure/install_started の遷移は `app/update.rs` の manager 境界へ集約する。
- 役割補足: `render_dialogs/update.rs` は update dialog の描画と入力取得を担当し、`render.rs` は `RenderUpdateDialogCommand` の queue/dispatch 境界を保持する。永続化 (`session.rs`) と app close orchestration (`app/mod.rs`) は `FlistWalkerApp` 側に残したまま `UpdateAppCommand` で橋渡しする。
- 役割補足: top action button、FileList dialog、update dialog、tab bar reorder/close/switch は `RenderCommand` 境界を経由して owner helper (`filelist.rs`, `update.rs`, `tabs.rs`) へ渡す。描画コードは click/drag/dialog input の収集に寄せ、state transition は描画後 dispatcher で一段遅らせて実行する。

- DES-015 Diagnostics and Supportability Contract
- 役割: worker-side `tracing` と opt-in window trace の責務を分け、support/debug 用の canonical event family を維持する。
- 実装: `rust/src/app/worker/tasks.rs`, `rust/src/app/index_worker.rs`, `rust/src/app/mod.rs`, `rust/src/app/session.rs`, `rust/src/app/input/mod.rs`, `rust/src/main.rs`
- 役割補足: worker-side async flow は `flow` / `event` / `request_id` を中心に記録し、request-scoped でない flow は `epoch` や `source_kind` など最小の補助 field だけを追加する。
- 役割補足: search / preview / filelist / action / sort metadata / update は started/finished/failed/receiver_closed 系の event family に寄せ、index は `flow=index` と `source_kind` で filelist/walker/none を切り分ける。
- 役割補足: GUI/session/input/update の opt-in trace は `FLISTWALKER_WINDOW_TRACE=1` のみで有効化し、window geometry、IME composition、query text change、startup/update dialog などの GUI diagnostics を `append_window_trace` へ集約する。
- 役割補足: diagnostics 強化で request routing や response acceptance を変えない。hot UI path へ重い同期 I/O や新しい汎用 logging framework を導入しない。

- DES-016 Ignore List Filter
- 役割: 実行中 binary と同じフォルダにある ignore list を読み取り、検索候補と空クエリ表示から除外する。
- 実装: `rust/src/ignore_list.rs`, `rust/src/query.rs`, `rust/src/app/session.rs`, `rust/src/app/ui_state.rs`, `rust/src/app/bootstrap.rs`, `rust/src/app/shell_support.rs`, `rust/src/app/render.rs`, `rust/src/app/render_panels.rs`, `rust/src/app/render_panels/top_panel.rs`, `rust/src/main.rs`, `rust/src/cli/batch.rs`
- 役割補足: ignore list の各ルールは query の `!` 除外と同じ非 fuzzy の literal / anchor 比較で評価し、既定では GUI の `Use Ignore List` チェックボックスが有効な状態で候補集合へ反映する。
- 役割補足: parserは先頭UTF-8 BOMとCRLFを正規化し、compiled ignore matcherだけがpath separatorを `/` へ統一する。通常queryのpath表現は変更しない。
- 役割補足: 未存在sidecarは空ルールとして扱う。CLI/TUIは存在する既定sidecarまたは明示fileのread/UTF-8 failureを明示errorとして停止し、除外漏れをfail-openさせない。GUIの既存bootstrapは互換loaderを維持する。
- 役割補足: CLI/TUI の filter/sort/root transition は GUI と同じ ignore setting を shared query input として渡し、adapter 固有の別解釈を作らない。

- DES-017 Runtime Config Bootstrap
- GUI config openは`worker/config_open.rs`の単一workerと容量1のrequest/response mailboxを使い、response消費まで1件だけ受理する。完了は要求元tabだけへ通知し、shutdownは既存WorkerRuntimeのjoin budgetを共有する。設定openは既存fileを保持し、起動済みconfigを新しいfileのseedとして使う。
- 役割: Windows では `%LocalAppData%\flistwalker\`、Linux/macOS では `~/.flistwalker/` を runtime settings の保存先として扱い、起動初回のみ current env を seed に自動生成する。
- 実装: `rust/src/runtime_config.rs`, `rust/src/main.rs`, `rust/src/app/session.rs`, `rust/src/app/shell_support.rs`, `rust/src/search/config.rs`, `rust/src/app/index_worker.rs`, `rust/src/updater.rs`
- 役割補足: runtime config file が存在する場合は読み込み結果を process env に反映して既存の env 駆動経路へ伝播し、存在しない場合だけ current env を取り込んでファイルを生成する。main dispatch は引数検証後、`--list-saved-roots` / `--create-filelist` の早期 return より前に bootstrap を完了する。UI state、saved roots、window trace も同じ base directory 解決規則へ揃える。
- 役割補足: Windows の旧 exe-side / home-directory 配置ファイルと Linux/macOS の旧 home-root 配置ファイルは、新しい保存先が未作成のときだけ初回起動で移行し、既存の新配置ファイルを上書きしない。transition migration は v0.20.0 までの一時対応として扱う。
- 役割補足: GUI の設定ボタンは render command 経由で `shell_support` の config open 処理を呼び、`runtime_config_file_path` を生成済みにしたうえで `actions` の既定アプリ open を試す。既定アプリが失敗した場合は、Windows では `notepad.exe`、macOS では `open -t`、Linux では `VISUAL` / `EDITOR` または一般的な GUI editor へフォールバックする。
- 役割補足: build-time 公開鍵や release signing secret は runtime config file に含めず、既存の build / release / dev-test secret 経路に残す。
- 役割補足: session persistence は read-only roots API と async history/UI-state writer を分ける。worker は sidecar lock 下で latest-read delta merge と atomic write を行い、unknown JSON fields を保持する。GUI/TUI frame は enqueue のみを行い、lock timeout/write failure の generation は retry queue に残す。

- DES-018 Release Sample Ignore List
- 役割: release asset と self-update helper が ignore list サンプルを同梱・配置し、初回利用時の導線を提供する。
- 実装: `scripts/prepare-release.sh`, `scripts/prepare-release-linux.sh`, `scripts/prepare-release.ps1`, `scripts/prepare-release-macos.sh`, `rust/src/updater.rs`, `docs/RELEASE.md`
- 役割補足: ignore list sample は binary に埋め込まれ、起動時に `flistwalker.ignore.txt.example` が無ければ local 実体として生成される。
- 役割補足: 既存 `flistwalker.ignore.txt` を上書きせず、sample 生成失敗は本体起動や自己更新を妨げない。

- DES-019 PowerShell Windows GNU Build Coordinator
- 役割: Windows PowerShell での依存検出、導入承認、process PATH 再構成、GNU tool 解決、release/clean build、artifact 同期を一貫した契約で提供する。
- 実装: `scripts/common-win-gnu.ps1`, `scripts/build-rust-win.ps1`, `scripts/build-rust-win-clean.ps1`, `scripts/dev-check-windows.ps1`, `scripts/test-build-rust-win.ps1`, `scripts/test-windows-build-artifact.ps1`, `rust/build.rs`, `rust/windows_resource_build.rs`
- 役割補足: shared helper は検出、承認、install、PATH 再構成、tool/env export、checked command 実行だけを担当し、build/clean/test の操作順は各 entrypoint が所有する。
- 役割補足: install mode は `CheckOnly` / `NoInstall` / `InstallMissing` / interactive を明示し、非対話 interactive は `NoInstall` へ縮退する。machine state の変更は winget/pacman/rustup の利用者承認後だけ行い、script 自身は永続 PATH を変更しない。
- 役割補足: Windows-host GNU `build.rs` は resolved `windres` / `ar` で resource を生成し、GNU target の GUI binary へ `resource.o` を明示リンクする。
- 役割補足: build entrypoint は source/destination の正規化比較で自己 copy を避け、strip 済み実体を 2 名の artifact へ同期する。
