﻿# Manual Regression and Traceability

## Environment and data
- repository指定のRust toolchain（`rust/rust-toolchain.toml`、`rustup` 管理）
- OS: Windows 11 / Linux / macOS
- Data:
- 一時ディレクトリに擬似ファイル/フォルダを生成
- `FileList.txt`/`filelist.txt` をケース別に生成
- UNC path form は unit test、real UNC の解決・認可は Windows 実機の TC-051 procedure で確認
- 自己更新手動試験では、必要に応じてローカル HTTP サーバーで release JSON / asset / `SHA256SUMS` / `SHA256SUMS.sig` を配信する

## Action Authorization Platform Evidence (TC-050 / TC-051)

この確認は OS action backend を起動せず、worker の recording executor または authorization-only test seam を使用する。選択時の display path、最後に認可された execution path、backend call count、notice、実行環境を証跡として記録する。外部 canonical destination や実在する UNC の機微情報はマスクする。

### Windows junction / link
1. 同一ローカル volume の一時領域に `target-root/in-root` と `outside` を作成し、`junction-root` から `target-root` への directory junction、および `target-root/linked-outside` から `outside` への directory junction を作る。権限があれば同じ配置の directory/file symlink も作る。
2. `junction-root` を trusted root、解決済みの `target-root/in-root` を result path として GUI precheck と worker authorization seam を実行し、precheck が `Defer`、recording executor が解決済み path を 1 回受け取ることを確認する。
3. `target-root/linked-outside` を direct action と open-containing-folder の対象にして worker authorization seam を実行し、物理的な target が root 外でも recording executor が解決済み path を受け取ることを確認する。
4. root 内 file link が root 外の file を指す配置では、direct action が解決済み file target を受け取り、open-containing-folder は root 内の字句的親を解決した execution path を受け取ることを確認する。
5. trusted root の字句的表現と解決済み表現のどちらにも属さない通常 path を混在させた場合は、全 target の事前認可失敗、recording executor の call count 0、notice が display path を示し外部 canonical destination を含まないことを確認する。
6. 事前認可後に link/junction の解決先を変更できる環境では、直前再認可が変更を検出して残件を実行しないことを確認する。
7. junction/link の作成権限がない場合は `not run`、OS/build、失敗した作成操作と理由を記録し、pass として扱わない。一時領域は証跡取得後に削除する。

### Real UNC / Windows path forms
1. 実際に到達可能な UNC root と、その配下 target、同一 share の root 外 target、可能なら別 share target を用意する。認証情報と server/share の実名は証跡へ残さない。
2. authorization-only seam で同一 UNC root 配下が許可され、その解決済み execution path が recording executor に 1 回渡ることを確認する。
3. trusted root の字句的表現と解決済み表現のどちらにも属さない同一 share の root 外、別 share、解決不能 UNC は backend call 0 件で拒否されることを確認する。
4. unit evidence では Windows の大小文字差、extended/verbatim prefix、drive-relative、rooted-without-drive、別 absolute prefix を含む UI precheck 表を確認し、曖昧な形式が UI だけで許可されず `Defer` されることを確認する。
5. real UNC が利用できない場合は `not run` と理由を記録する。synthetic path の unit test は real UNC の代替 pass にしない。

### Evidence record
- Date / operator:
- OS / build / filesystem:
- Case: junction / symlink / real UNC / Windows path forms
- Expected result:
- Actual authorization result:
- Recording executor call count and masked execution path:
- Notice display-path check:
- Status: pass / fail / not run
- Residual note: 最終再検証後の filesystem object 差し替えは handle-relative launch がない backend では完全に排除できず、TOCTOU residual risk として残る。

#### Evidence 2026-09-03
- Date / operator: 2026-09-03 / Codex
- Unix link cases: macOS の一時領域で symlink root の解決済み result、root 配下の file/directory/ancestor symlink、link 解決先変更、broken link を recording executor で自動検証した。
- Windows junction root / root 配下 junction: Windows 環境がこの検証環境にないため未実行。`tc_051_windows_junction_target_manual_evidence` を上記手順の recording executor で実行するまで `not run` とする。
- Status: Unix automated evidence pass / Windows junction evidence not run

#### Evidence 2026-07-19
- Date / operator: 2026-07-19 / Codex
- OS / build / filesystem: Microsoft Windows NT 10.0.26200.0 / NTFS
- Windows path-form automated evidence: case 違いと extended/verbatim prefix の同一実体を worker が許可して canonical execution path を recording executor へ渡す test、および非 Unicode path を lossy normalization 前に UI が `Defer` する test が pass
- Case: real UNC
- Expected result: 同一 root 配下だけを許可し、同一 share の root 外、別 share、解決不能 UNC は backend call 0 件で拒否する。
- Actual authorization result: 到達可能な検証用 UNC share がこの環境にないため未実行
- Status: not run
- Residual note: synthetic UNC path の UI precheck test は pass しているが、real UNC の worker canonicalization evidence の代替にはしない。

## Self Update Manual Test
この節は VM-005 の operator-only 手順であり、通常の GUI smoke や closure validation では実行しない。`scripts/manual-self-update-test.ps1` が作成する private sandbox の copied executable と loopback 上の inert local feed だけを対象にし、production executable、production feed、外部 network endpoint を指定しない。`Download and Restart` を押す activation 手順は明示承認を得た場合だけ実行する。

1. 同一 version の表示確認:
Windows は `scripts/manual-self-update-test.ps1 -Mode SameVersion` を使い、helper が private sandbox へコピーした executable と current version と同じ `tag_name` の local feed で更新ダイアログが出ることを確認する。`-AppPath` / `-UpdateBinaryPath` は sandbox へコピーする test input だけに使い、実行中または配布用 production binary を指定しない。
2. downgrade 表示確認:
Windows は `scripts/manual-self-update-test.ps1 -Mode Downgrade` を使い、旧 version の release JSON を自動生成して downgrade 候補でもダイアログが出ることを確認する。patch が `0` の場合は `-FeedVersion` を明示する。
3. ローカル feed 確認:
PowerShell helper を`-Variant Universal`と`-Variant Fw`で別々に実行し、各fresh private sandbox、`latest.json`、両binary familyを含むinert manifest、共有remote sidecar文書（`*.README.txt`, `*.LICENSE.txt`, `*.THIRD_PARTY_NOTICES.txt`）、`SHA256SUMS`、`SHA256SUMS.sig`、loopback HTTP serverを確認する。外部URLや手作業のproduction-like feedへ切り替えない。
4. update 適用確認:
明示承認を得たWindows/Linuxのtest environmentで、helperが表示したsandbox copyに限って適用し、Universalは通常名、Fwは`fw.README.txt` / `fw.LICENSE.txt` / `fw.THIRD_PARTY_NOTICES.txt`を更新すること、headless再起動が終了してhelper/transaction artifactを残さないことを確認する。元のbuild出力のhashとtimestampが変わっていないことを確認する。
5. suppress 確認:
更新ダイアログで `Don't show again until the next version` をチェックして Later を押し、同じ feed version では次回起動しても再表示されず、feed version を 1 つ上げると再表示されることを確認する。
6. startup check failure dialog 確認:
helper の loopback server を停止した sandbox、または deterministic failure injection を使い、外部 network へ接続せず `Update Check Failed` の状態遷移と抑止を確認する。
7. startup check failure dialog 強制表示:
`cargo test update_check_failure_opens_failure_dialog --lib` と `cargo test forced_update_check_failure_bypasses_suppression_flag --lib` を実行し、network access なしで failure dialog state と suppression bypass を確認する。native focus/visual confirmation が必要な場合は `GUI-TESTPLAN.md` の GSM-008 として staged window で記録し、専用の安全な staged launch route がなければ `NOT RUN` とする。
8. install failure manual recovery dialog:
`cargo test failed_update_response_replaces_prompt_with_manual_recovery_state --lib` を実行し、candidate の install failure が `Update Available` を残さず、manual recovery state と release URL を保持することを確認する。native 表示確認では GSM-008 の staged window を使い、`Update Installation Failed`、現行 installation 不変、manual recovery 案内、release link、details、`Close` を確認する。

## Diagnostics Trace Smoke Test
1. worker-side trace:
`RUST_LOG=flist_walker::app::index_worker=info cargo test index_worker_trace_smoke_emits_canonical_fields --lib -- --nocapture` を実行し、Started/Finished 応答が通ることに加えて、出力ログに `flow=index`、`event=started|finished|completed`、`request_id=`、`source_kind=walker` が含まれることを確認する。
2. window trace:
window/session/input/update の observable output を変更した場合は、まず owner test（例: `cargo test update_check_failed_response_emits_trace_command --lib`）で変更対象 family の event を確認する。native trace file が必要な場合は dedicated staged trace launch だけを使用し、workspace debug executable を直接起動しない。dedicated route がない場合は native trace を `NOT RUN`、理由と owner test evidence を記録する。window trace に変更がない場合は `not needed` とする。

## Transactional Updater Platform Evidence (TC-160)
1. Windows と Linux でそれぞれ同一 filesystem の private temporary directory を作り、copied-helper transaction core に old/new binary と 3 sidecar の inert text fixture を渡す。production executable/feed は使用しない。
2. success injection で sidecars-first/binary-last の操作順、完全な new hash、startup cleanup 後の lock/marker/ack/backup 不在を記録する。
3. 各 sidecar 適用後と `binary_intent` 後の precommit failure injection で old bundle hash へ戻り、originally-absent target が残らないことを記録する。
4. binary commit 後の restart failure injection で old bundle へ rollback し、旧 binary の再起動は recording backend への call としてのみ確認する。
5. `prepared_parent_owned`、`helper_registered` ack 前後、各 target の `intent/applied`、`binary_intent/binary_committed` marker fixture を再読込し、live matching helper の回復除外、precommit rollback、committed promotion、ambiguous retention を記録する。
6. Windows adapter は existing target の native `ReplaceFileW` を updater process 内で実行し、PowerShell を起動せずに backup あり/なしと失敗時の source 保持が成功することを確認する。Linux adapter は backup/file/parent sync と same-directory rename が実際に成功することを確認する。いずれかの platform 証跡が無い場合、TC-160 と updater platform validation は未完了とする。

- Evidence directory: test-owned private temporary directories created by `staging::test_unique_update_temp_dir`; each fixture removes its exact directory after assertion.
- Windows result: native `x86_64-pc-windows-msvc` focused regression pass on 2026-07-30 (`cargo test --locked tc171_regression_windows_file_replace --lib -- --nocapture`: 5 passed). The adapter executed in-process `ReplaceFileW` against inert text files with `PATH` isolated from PowerShell, preserved the old target as backup, handled no-backup and missing-target boundaries, preserved verbatim path encoding, and rejected interior NUL. Transaction suite result: 32 passed (`updater::transaction::tests::tc`); full result: 759 library tests passed / 8 ignored, 8 binary tests passed, 35 CLI contract tests passed; GNU cross-check passed for `x86_64-pc-windows-gnu`.
- Linux result: pass under WSL2 Ubuntu (`cargo test tc160_linux_synced_rename_preserves_the_old_dummy_file_as_backup --lib`: 1 passed; `cargo test tc157_ / tc158_ / tc159_ --lib`: 12 / 5 / 22 passed). The production Linux adapter executed synced backup + same-directory rename against inert text files.
- Failure points covered: pre-marker orphan preservation/lone-lock cleanup、ack-before-mutation rejection、live-parent pre-mutation deferral、helper executable/hash/token mismatch、parent wait timeout、operation-time target/prepared hash change、absent-target racing destination、cleanup artifact hash/type mismatch、precommit sidecar failure、restart failure rollback、complete `binary_intent` promotion、unknown hash/invalid transition retention、interrupted postcommit rollback resumption。
- Cleanup/remaining artifacts: committed/rolled-back fixtures assert lock/marker removal; ambiguous fixtures intentionally retain lock/marker/`.new` evidence only inside fixture-owned directories, which fixture teardown removes.
- Production binary/external process untouched: yes. Restart behavior used only a recording/no-launch backend; no production update feed or application executable was targeted.

## Structural Refactoring GUI Smoke Test
GUI-adjacent structural refactoring は [GUI-TESTPLAN.md](../GUI-TESTPLAN.md) と [GUI-TESTREPORT.template.md](../GUI-TESTREPORT.template.md) を canonical owner とする。

1. Windows は `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\gui-deterministic-scenarios.ps1`、Linux/macOS/WSL は `scripts/gui-deterministic-scenarios.sh` を実行し、canonical 10 group と zero ignored を確認する。
2. Native observation が必要な場合は `scripts/gui-headful-smoke.sh --duration 300` または `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\gui-headful-smoke.ps1 -DurationSeconds 300` を実行し、helper が表示した isolated staged window だけを操作する。workspace debug executable は直接起動しない。
3. GSM-001..011 の該当 flowで startup/indexing、query operator、preview/selection、root/tab、FileList dialog、sort、theme、responsiveness、最大深度/preset を確認する。external action、clipboard、update activation は別途明示承認がない限り実行しない。
4. Deterministic、Native interaction、Liveness を独立して記録する。required native axis が `NOT RUN` の場合は overall PASS にせず、理由と再現手順を残す。

## Preset Application Manual Test (TC-174)

1. current rootと同じroot、Walker、Files、非空query、Ignore List有効、Name (A-Z) sortのpresetを用意する。ignore termに一致するpathと一致しないpathを候補へ含める。
2. GUIでメイン画面の`Presets...`からpickerを開いてpresetを適用し、rootの再index表示なしにignore対象が消え、Name sortが検索完了後も維持されることを確認する。pickerを閉じた後に`Primary+Shift+P`でも同じpickerが開くことを確認する。
3. 同じrootでIgnore List無効のpresetを適用し、除外されていた候補が戻り、検索完了後も指定sortと現在tabのsort scopeが維持されることを確認する。
4. 高速に別queryまたはpresetへ切り替え、古い検索responseが最新の候補・sort・scopeを巻き戻さないことを確認する。
5. GSM-008のNative interaction、GSM-009のvisual/layout、GSM-010の入力・スクロールlivenessへ、build SHA、OS、preset内容、期待/実結果、PASS/FAILを記録する。いずれかのrequired axisが未実行ならrelease readinessをPASSにしない。

### Regression Guard: atomic same-root preset application

- Scenario: 同一rootでIgnore Listまたはsortだけが変わるpresetを適用し、旧検索responseが遅れて到着する。
- Expected Behavior: filter済み最新requestだけが採用され、Ignore Listとpreset sortが結果へ反映され、tabのsort scopeは維持される。
- Non-goals: root/source/type変更時のindex refresh省略、presetによるsort scope保存、action実行。
- Related Tests: TC-174; `regression_same_root_preset_applies_filters_and_sort_before_fresh_search`, `regression_same_root_preset_disabling_ignore_restores_all_search_entries`.
- Notes for Future Changes: automated fixtureのignore termはplatform temp ancestorと衝突しないfilename固有sentinelにし、macOSの`/var/folders`のような親path一致で保持対象まで除外しないことを維持する。
- Notes for Future Changes: automated request-payload/freshness testとGSM-008/009/010の3軸を同じrelease候補で確認する。

## Entry / Exit criteria
- Entry:
- docs 4文書が揃い、FR/NFR/SP/DES/TC が対応付け済み。
- Exit:
- P0/P1 テストが全成功。
- 未達項目は TODO と根拠を記録。

## Report
- `cargo test` 結果を作業ログに記録。
- 性能計測は `docs/perf-notes.md`（必要時追加）へ記録。

## Regression Guard
- 発生条件: restored tab の優先応答を全 background request の cancel または shared response backlog の別 unbounded queue への移動で実現し、rapid switch で再indexを繰り返す。または closed/open-inactive tab の heavy state を予算なしで保持する。
- 期待動作: startup precedence、lifecycle/committed分離、Active+sole Warm、順序付きbounded mailbox、live/closed共通LRU、engagement-qualified Recent Inactive、soft/hard budget、bounded reclaimerをTC-203からTC-211で同時に確認する。Readyと猶予中のRecent Inactiveは再indexせず、瞬間表示だけのtabは保護枠を奪わず、Refreshing/Failedはlast-good、Dormant/EvictedだけLoadingする。
- 非対象範囲: full snapshotのprocess間永続化、単一active FileList snapshotのhard byte cap。
- 関連テストID: TC-203, TC-204, TC-205, TC-206, TC-207, TC-208, TC-209, TC-210, TC-211.

## Regression Guard
- 発生条件: include_files/include_dirs 両有効の FileList ストリーム解析で、候補選択のための per-line `metadata` probe を戻してしまい、Windows 由来 `\` 区切り FileList のインデクシングが遅くなる。
- 期待動作: `\` / `/` の差異は候補順序だけで吸収し、初期ストリームは line-only fast path を維持して metadata-probe baseline を上回る。
- 非対象範囲: include_files / include_dirs のいずれか片方のみ有効な場合の種別判定、root 外候補の実行拒否、階層 FileList の新旧判定、probe が必要な後段の kind 解決。
- 関連テストID: TC-082.

## Regression Guard
- 発生条件: 検索窓フォーカス中に `Ctrl+J` / `Ctrl+M`、`ArrowUp` / `ArrowDown`、`Ctrl+I` を押しても `Results` の実行・移動・PIN トグルが効かない。
- 期待動作: 検索窓フォーカス有無に関わらず、`Ctrl+J` / `Ctrl+M` は実行、`ArrowUp` / `ArrowDown` は current row 移動、`Ctrl+I` は PIN トグルを行う。
- 非対象範囲: IME 合成中は既存仕様通りフォーカス優先で一部ショートカットを抑制する。
- 関連テストID: TC-026, TC-027, TC-028.

## Regression Guard
- 発生条件: 起動直後または `Esc` / `Ctrl+G` で検索をキャンセルした直後に、候補が存在するのに current row が `None` のままになる。
- 期待動作: 候補がある場合は 1 行目を既定選択として表示し、検索結果の再適用で意図せず未選択へ戻さない。
- 非対象範囲: 検索結果更新時の行番号維持、手動で未選択へ戻した状態の保持、Root 変更による selection 破棄。
- 関連テストID: TC-070.

## Regression Guard
- 発生条件: `msvc` から `x86_64-pc-windows-gnu` へ切り替えた後、`windres` 生成物が最終 `flistwalker.exe` に入らず Windows Explorer で既定アイコン表示になる。
- 期待動作: GNU Windows ビルドでは `resource.o` を最終 `flistwalker` バイナリへ直接リンクし、Explorer 上で埋め込みアイコンが表示される。
- 非対象範囲: 実行中ウィンドウアイコン、`.lnk` ショートカット個別設定、ファイル関連付けアイコン。
- 関連テストID: TC-090.

## Regression Guard
- 発生条件: ある変更以降、GUI を閉じるたびに worker shutdown timeout まで待たされ、終了操作が体感で重くなる。
- 期待動作: shutdown 要求と request channel 切断後は短時間の join budget だけ待ち、残存 worker があっても close は 250ms 程度の待ちで返る。
- 非対象範囲: OS がプロセス自体を強制終了できないケース、個別 worker の I/O 完了保証。
- 関連テストID: TC-091.

## Regression Guard
- 発生条件: 起動時の更新確認が UI スレッドを塞ぎ、検索欄入力や一覧操作が数秒単位で固まる。
- 期待動作: 更新確認とダウンロードは worker で非同期実行され、失敗しても GUI の通常操作を継続できる。
- 非対象範囲: GitHub 側の API / asset 配信停止そのもの。
- 関連テストID: TC-078.

## Regression Guard: manual-self-update-sidecars

- Scenario: 手動の自己更新 feed が binary と `SHA256SUMS` だけを配り、`*.README.txt` を含む sidecar 文書を生成しないまま自己更新確認に使われる。
- Expected Behavior: `scripts/manual-self-update-test.ps1` は sandbox 限定の inert local feed として binary、`*.README.txt`、`*.LICENSE.txt`、`*.THIRD_PARTY_NOTICES.txt`、`SHA256SUMS`、`SHA256SUMS.sig` を必ず生成し、明示承認された更新後の sandbox に `README.txt` / `LICENSE.txt` / `THIRD_PARTY_NOTICES.txt` がそろって配置される。production executable/feed と外部 network は対象外とする。
- Non-goals: GitHub Releases 本番 asset の内容妥当性確認、README 本文そのものの文言レビュー。
- Related Tests: Self Update Manual Test step 3, step 4.
- Notes for Future Changes: 自己更新 asset 名や sidecar 種別を増減させた場合は、この helper script と manual test 手順を同一変更で更新すること。

## Regression Guard: sequential updater signing environment

- Scenario: 同一PowerShell processのCI loopでUniversal試験後にmanual updater scriptがcallerのsigning key環境変数を削除し、続くFw試験がmanifest署名前に失敗する。
- Expected Behavior: signer processだけがcallerからsigning keyを継承し、manual updater scriptはcaller環境を変更しない。sandbox app用`ProcessStartInfo`の環境コピーからはkeyを明示除外し、helperとrestarted childにも継承させない。CIは各variant実行後にcaller keyの完全一致を検証する。
- Non-goals: production signing keyの生成・表示・永続化、sandbox child内でのmanifest署名、variant間でのsandbox共有。
- Related Tests: TC-191、`regression_manual_self_update_process_environment_contract`、`test_manual_self_update_cleanup_and_signing_environment_are_fail_closed`。
- Notes for Future Changes: signer起動、sandbox process環境、またはCI variant loopを変更するときは、連続Universal/Fw invocationとchild key非継承を同一変更で検証する。

## Regression Guard: windows-updater-in-process-replace

- Scenario: Windows updater が durable marker と binary/sidecar の置換ごとに `powershell.exe` を起動し、更新中に複数の terminal window が表示されるか、外部 process 起動の一時失敗で update apply が不安定になる。
- Expected Behavior: Windows replacement は native `ReplaceFileW` を updater process 内で呼び、PowerShell/PATH に依存しない。backup、rollback 入力、UTF-16 path の同一性を維持する。
- Non-goals: AV、権限、第三者 process の file lock、production executable を用いた live activation の自動化。
- Related Tests: TC-171; `tc171_regression_windows_file_replace_does_not_require_powershell_on_path`, `tc171_regression_windows_file_replace_supports_no_backup_boundary`, `tc171_regression_windows_file_replace_failure_preserves_source`, `tc171_regression_windows_file_replace_preserves_verbatim_path_prefix`, `tc171_regression_windows_file_replace_rejects_interior_nul`.
- Notes for Future Changes: Windows replacement を外部 process へ戻したり path を文字列化したりせず、変更時は native Windows focused tests を必須実行する。

## Interactive CLI Terminal Matrix (TC-162)

- Automated evidence: `cargo test cli_tui::tests --lib` は stdin/stderr TTY policy、stdout非依存、partial setup、runtime error/unwind時の逆順復旧、cleanup-before-output、request freshness、選択/pin、editor/paste/page移動、Unicode幅と制御文字の安全なclipに加え、invalid root の `IndexFailed`、candidate batch の path allocation 共有、iteration ごとの response budget を検証する。`cargo test --test cli_contract` は batch 出力・段階別 progress・interactive/batch option 契約を検証する。
- Windows ConPTY E2E (2026-07-26): 一時 `pywinpty 3.0.5` harnessからnative Windows binaryを起動し、stdoutをraw file handleへredirectした状態でpaste、terminal resize、Enter選択、2件のpin順序、Esc、Ctrl-Cを送信した。選択はpathだけ、cancelは空stdout、Esc/Ctrl-Cはいずれもexit 130となり、全sessionでalternate screen退出、cursor再表示、bracketed paste無効化sequenceを確認した。結果: `conpty_select=ok conpty_pin_order=ok conpty_escape=130 conpty_ctrl_c=130 restoration=ok stdout_redirect=ok`。
- Windows ConPTY parity follow-up (2026-07-26): 現行native debug binaryを120x30で起動し、preview本文、`Alt+P` hide/show、`F1` helpとcurrent-row action案内、78x20から120x32へのresize、bracketed paste、Esc cancel、Enter選択を確認した。stdoutはraw file handleへredirectし、cancel時は空、選択時は相対path 1行のみ、Escはexit 130、全sessionでalternate screen退出、cursor再表示、bracketed paste無効化sequenceを確認した。結果: `conpty_preview=ok conpty_help=ok conpty_resize=ok conpty_paste=ok conpty_cancel=130 conpty_selection=ok restoration=ok stdout_redirect=ok`。実OS action launchは追加の明示承認を伴わないため実行せず、key dispatch、current-row限定、事前認可、backend call 0件の拒否経路はTC-164のrecording backendで検証した。
- Windows ConPTY operations follow-up (2026-07-26): 隔離したcurrent/saved rootとsettingsを使い、`F2`でFiles toggleを適用・復元、`F3`でName (A-Z) sort、`F4`でsaved root切替、`F5`で切替後rootの再index、`F6`でroot-only/ancestor scope表示と`Ctrl+G` cancelを実操作した。FileListは作成されず、最後のEscはexit 130、stdoutは空、terminal restoration sequenceも確認した。結果: `conpty_f2_toggle=ok conpty_f3_sort=ok conpty_f4_root_switch=ok conpty_f5_refresh=ok conpty_f6_confirmation_cancel=ok no_filelist_write=ok conpty_cancel=130 restoration=ok stdout_redirect=ok`。
- Environment note: MSYS2 `script` PTYはnative Windows crosstermへkey eventを配送できなかったため証跡に採用しない。Windows ConPTY E2Eがvalidation matrixのpseudo-TTY automation evidenceを満たす。Windows Terminalでの目視spot-checkは任意の追加確認とする。

## Traceability (excerpt)
- TC-001 -> SP-001 -> DES-001 -> FR-001
- TC-002 -> SP-002 -> DES-002 -> FR-002
- TC-003 -> SP-003 -> DES-003 -> FR-003
- TC-004 -> SP-004 -> DES-004 -> FR-004
- TC-005 -> SP-005 -> DES-004 -> FR-005
- TC-006, TC-006A -> SP-006 -> DES-005 -> FR-006
- TC-007 -> SP-007 -> DES-006 -> NFR-001
- TC-008 -> SP-008 -> DES-007 -> NFR-002
- TC-009 -> SP-009 -> DES-008 -> NFR-003
- TC-010 -> SP-010 -> DES-009 -> FR-007
- TC-011 -> SP-011 -> DES-010 -> NFR-004
- TC-012 -> SP-007 -> DES-006 -> NFR-001
- TC-013 -> SP-002, SP-007 -> DES-006 -> NFR-001
- TC-014 -> SP-010, SP-008 -> DES-009, DES-007 -> FR-007, NFR-002
- TC-015 -> SP-006, SP-008 -> DES-005, DES-007 -> FR-006, NFR-002
- TC-016 -> SP-010 -> DES-007, DES-009 -> FR-007
- TC-017 -> SP-010 -> DES-007, DES-009 -> FR-007
- TC-018 -> SP-010 -> DES-009 -> FR-007
- TC-019 -> SP-001, SP-007 -> DES-001, DES-006 -> FR-001, NFR-001
- TC-020 -> SP-010, SP-011 -> DES-011, DES-009 -> FR-007, NFR-004
- TC-021 -> SP-010 -> DES-009 -> FR-007
- TC-022 -> SP-010 -> DES-009 -> FR-007
- TC-023 -> SP-010 -> DES-009 -> FR-007
- TC-024 -> SP-010 -> DES-009 -> FR-007
- TC-025 -> SP-001, SP-010, SP-007 -> DES-001, DES-006, DES-009 -> FR-001, FR-007, NFR-001
- TC-026 -> SP-010 -> DES-009 -> FR-007
- TC-027 -> SP-010 -> DES-009 -> FR-007
- TC-028 -> SP-010 -> DES-009 -> FR-007
- TC-029 -> SP-010, SP-008 -> DES-009, DES-007 -> FR-007, NFR-002
- TC-031 -> SP-007, SP-010 -> DES-006, DES-009 -> NFR-001, FR-007
- TC-032 -> SP-008, SP-010 -> DES-007, DES-009 -> NFR-002, FR-007
- TC-033 -> SP-010 -> DES-009, DES-007 -> FR-007
- TC-034 -> SP-010 -> DES-009 -> FR-007
- TC-035 -> SP-010 -> DES-009 -> FR-007
- TC-036 -> SP-010 -> DES-007, DES-009 -> FR-007
- TC-037 -> SP-010 -> DES-009 -> FR-007
- TC-038 -> SP-010 -> DES-009, DES-011 -> FR-007
- TC-039 -> SP-010 -> DES-009 -> FR-007
- TC-040 -> SP-010 -> DES-009, DES-006 -> FR-007
- TC-041 -> SP-010 -> DES-009, DES-006 -> FR-007
- TC-046 -> SP-010 -> DES-009 -> FR-007
- TC-046A -> SP-010 -> DES-009 -> FR-007
- TC-047 -> SP-001 -> DES-001, DES-007 -> FR-001
- TC-048 -> SP-001 -> DES-001, DES-007 -> FR-001
- TC-049 -> SP-007 -> DES-006 -> FR-008
- TC-050 -> SP-004 -> DES-004, DES-007 -> FR-009
- TC-051 -> SP-004 -> DES-004, DES-007 -> FR-009
- TC-052 -> SP-001, SP-010 -> DES-007, DES-009 -> FR-010
- TC-053 -> SP-001, SP-010 -> DES-007, DES-009 -> FR-010
- TC-054 -> SP-010 -> DES-007, DES-009 -> FR-011
- TC-055 -> SP-010, SP-012 -> DES-007, DES-012 -> FR-011, NFR-005
- TC-056 -> SP-012 -> DES-012 -> NFR-005
- TC-057 -> SP-013 -> DES-013 -> FR-012
- TC-058 -> SP-013 -> DES-006, DES-013 -> FR-013, FR-014, NFR-006
- TC-059 -> SP-013 -> DES-013 -> FR-012, FR-014
- TC-060 -> SP-013 -> DES-013 -> FR-015
- TC-061 -> SP-013 -> DES-013 -> FR-012
- TC-062 -> SP-010, SP-013 -> DES-009, DES-013 -> FR-007, FR-012
- TC-063 -> SP-007, SP-013 -> DES-006, DES-013 -> FR-013, NFR-006
- TC-064 -> SP-010 -> DES-009 -> FR-016
- TC-068 -> SP-010 -> DES-009 -> FR-007
- TC-069 -> SP-010 -> DES-009 -> FR-017, FR-007
- TC-070 -> SP-010 -> DES-009 -> FR-018, FR-007
- TC-074 -> SP-014 -> DES-014 -> FR-019
- TC-075 -> SP-014 -> DES-014 -> FR-020
- TC-076 -> SP-014 -> DES-014 -> FR-021
- TC-077 -> SP-014 -> DES-014, DES-007 -> FR-023
- TC-078 -> SP-014 -> DES-006, DES-014 -> NFR-007
- TC-081 -> SP-014 -> DES-014 -> FR-024
- TC-082 -> SP-001, SP-007 -> DES-001, DES-006 -> FR-001, NFR-001
- TC-083 -> SP-002, SP-007 -> DES-002, DES-006 -> FR-002, NFR-001
- TC-084 -> SP-001, SP-010 -> DES-001, DES-009 -> FR-001, FR-010
- TC-085 -> SP-001, SP-010 -> DES-001, DES-009 -> FR-001, FR-010
- TC-086 -> SP-014 -> DES-014 -> FR-019, FR-020
- TC-087 -> SP-001, SP-010 -> DES-001, DES-009 -> FR-001, FR-010
- TC-088 -> SP-001, SP-010 -> DES-007, DES-009 -> FR-010, FR-007
- TC-089 -> SP-001 -> DES-001, DES-007 -> FR-010
- TC-090 -> SP-012 -> DES-012 -> NFR-005
- TC-091 -> SP-008, SP-010 -> DES-007, DES-009 -> NFR-002, FR-007
- TC-092 -> SP-003, SP-010 -> DES-003, DES-009 -> FR-003, FR-007
- TC-110 -> SP-015 -> DES-016 -> FR-025
- TC-111 -> SP-016 -> DES-017 -> FR-026
- TC-112 -> SP-015 -> DES-016 -> FR-025
- TC-113 -> SP-017 -> DES-018 -> FR-027
- TC-114 -> SP-017 -> DES-018 -> FR-027
- TC-115 -> SP-016 -> DES-017 -> FR-026, AC-027
- TC-116 -> SP-016 -> DES-017 -> FR-026, AC-028
- TC-117 -> SP-015 -> DES-016 -> FR-025
- TC-118 -> SP-004 -> DES-004 -> FR-022
- TC-119 -> SP-014 -> DES-014 -> FR-020, FR-023
- TC-120 -> SP-010, SP-014 -> DES-015, DES-014 -> FR-007, FR-019
- TC-121 -> SP-010 -> DES-009 -> FR-007
- TC-127 -> SP-016 -> DES-017 -> FR-028, AC-029
- TC-128 -> SP-010 -> DES-009 -> FR-007, NFR-004
- TC-129 -> SP-010 -> DES-009 -> FR-007, NFR-004
- TC-130 -> SP-010 -> DES-009 -> FR-007, NFR-004
- TC-131 -> SP-010 -> DES-009 -> FR-007, NFR-004
- TC-132 -> SP-010 -> DES-009 -> FR-007, NFR-004
- TC-133 -> SP-010 -> DES-009 -> FR-007, NFR-004
- TC-134 -> SP-010 -> DES-009 -> FR-007, NFR-004
- TC-135 -> SP-010 -> DES-009 -> FR-007, NFR-004
- TC-136 -> SP-010 -> DES-009 -> FR-007, NFR-004
- TC-137 -> SP-010 -> DES-009 -> FR-007, NFR-004
- TC-138 -> SP-010 -> DES-009 -> FR-029
- TC-139 -> SP-010 -> DES-009 -> FR-030
- TC-140 -> SP-014 -> DES-014 -> FR-019, FR-020
- TC-141 -> SP-010, SP-016 -> DES-009, DES-017 -> FR-007, FR-026
- TC-142 -> SP-010, SP-016 -> DES-009, DES-017 -> FR-007, FR-026
- TC-143 -> SP-010, SP-016 -> DES-009, DES-017 -> FR-007, FR-026
- TC-144 -> SP-010 -> DES-009 -> FR-031
- TC-145 -> SP-018 -> DES-019 -> FR-032, AC-033
- TC-146 -> SP-018 -> DES-019 -> FR-032, AC-033
- TC-147 -> SP-018 -> DES-019 -> FR-032, AC-033
- TC-148 -> SP-018 -> DES-019 -> FR-032, AC-033
- TC-149 -> SP-010 -> DES-009 -> FR-007
- TC-150, TC-151, TC-152, TC-153 -> SP-010 -> DES-006, DES-007, DES-009 -> FR-007, NFR-008
- TC-154, TC-203, TC-204, TC-205, TC-208, TC-209, TC-210 -> SP-010 -> DES-009 -> FR-007, NFR-009
- TC-205, TC-206, TC-207, TC-208, TC-209, TC-211 -> SP-010 -> DES-006, DES-007, DES-009 -> NFR-015
- TC-155 -> SP-003, SP-009 -> DES-003, DES-008 -> FR-003, NFR-003
- TC-156 -> SP-007 -> DES-006 -> NFR-001
- TC-157 -> SP-014 -> DES-014 -> NFR-010
- TC-158, TC-159, TC-160 -> SP-014 -> DES-014 -> FR-033
- TC-159, TC-160 -> SP-014 -> DES-014 -> NFR-010
- TC-161 -> SP-001, SP-007 -> DES-001, DES-006 -> FR-034, NFR-001
- TC-162 -> SP-006, SP-008 -> DES-005, DES-007 -> FR-006, NFR-002, NFR-011
- TC-163 -> SP-006, SP-013 -> DES-005, DES-006 -> FR-006
- TC-164 -> SP-004, SP-006 -> DES-004, DES-005 -> FR-006, FR-009
- TC-165 -> SP-001, SP-006 -> DES-005, DES-007 -> FR-010
- TC-166 -> SP-001, SP-006 -> DES-005, DES-007 -> FR-006, FR-010, NFR-012
- TC-167, TC-168 -> SP-016 -> DES-017 -> FR-011, FR-026, NFR-012
- TC-169 -> SP-006, SP-014 -> DES-005, DES-014 -> FR-035
- TC-170 -> SP-006, SP-008, SP-009 -> DES-004, DES-005, DES-007, DES-008 -> FR-006, NFR-002, NFR-003
- TC-171 -> SP-014 -> DES-014 -> FR-033, NFR-010
- TC-172 -> SP-006 -> DES-005 -> FR-006
- TC-173 -> SP-010 -> DES-009 -> FR-036
- TC-174 -> SP-019 -> DES-020 -> FR-037
- TC-175 -> SP-020 -> DES-021 -> FR-038
- TC-176 -> SP-015 -> DES-016 -> FR-025
- TC-177 -> SP-006 -> DES-005 -> FR-006
- TC-178 -> SP-012 -> DES-012 -> NFR-005
- TC-179 -> SP-014 -> DES-014 -> FR-033, NFR-010
- TC-180 -> SP-021 -> DES-022 -> FR-039
- TC-181, TC-182, TC-183, TC-184 -> SP-022 -> DES-023 -> NFR-013
- TC-185 -> SP-007 -> DES-006 -> NFR-001
- TC-186 -> SP-014 -> DES-014 -> FR-033, NFR-010
- TC-187 -> SP-014 -> DES-014 -> FR-033, NFR-010
- TC-200 -> SP-014 -> DES-014 -> FR-020, NFR-010
- TC-193 -> SP-023 -> DES-024 -> FR-040, NFR-014
- TC-201 -> SP-006, SP-010 -> DES-005, DES-009 -> FR-041, AC-042
- TC-202 -> SP-014 -> DES-014 -> FR-033, NFR-010
- TC-215 -> SP-006, SP-014, SP-018, SP-023 -> DES-005, DES-014, DES-019, DES-024 -> FR-032, FR-033, FR-040, NFR-010, NFR-014, AC-033, AC-036
