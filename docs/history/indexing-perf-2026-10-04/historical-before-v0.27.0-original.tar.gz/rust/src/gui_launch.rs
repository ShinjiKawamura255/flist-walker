use anyhow::{Context, Result};
use std::path::Path;
use std::time::Instant;

use flist_walker::app::{configure_egui_fonts, request_process_shutdown, FlistWalkerApp};
use flist_walker::updater::{
    recover_interrupted_update_on_startup, take_previous_update_failure_on_startup,
};
use resvg::{tiny_skia, usvg};
use tracing::warn;

use flist_walker::launch_path::resolve_root;

const APP_TITLE: &str = "FlistWalker";
const APP_ID: &str = "flistwalker";
const DEFAULT_WINDOW_SIZE: eframe::egui::Vec2 = eframe::egui::vec2(1400.0, 900.0);
const MIN_WINDOW_SIZE: eframe::egui::Vec2 = eframe::egui::vec2(640.0, 400.0);

#[cfg(target_os = "macos")]
mod macos_menu;

fn configure_quit_shortcuts(ctx: &eframe::egui::Context) {
    // egui handles its default primary+Q at end_pass, after app input handling.
    // Disable that source without suppressing native or updater close requests.
    ctx.options_mut(|options| options.quit_shortcuts.clear());
}

#[cfg(target_os = "windows")]
fn configure_windows_dpi_mode() {
    #[link(name = "user32")]
    extern "system" {
        fn SetProcessDPIAware() -> i32;
    }
    // SAFETY: process-wide DPI mode is switched before native window creation.
    // Keep this always-on for Windows to reduce monitor-crossing auto-resize jitter.
    let _ = unsafe { SetProcessDPIAware() };
    FlistWalkerApp::trace_window_event("windows_dpi_mode", "mode=system(always)");
}

#[cfg(not(target_os = "windows"))]
fn configure_windows_dpi_mode() {}

fn merge_update_diagnostic(target: &mut Option<String>, message: String) {
    if let Some(existing) = target.as_mut() {
        existing.push_str("\n\n");
        existing.push_str(&message);
    } else {
        *target = Some(message);
    }
}

pub(crate) fn initialize() -> Result<Option<String>> {
    let mut previous_update_failure = None;
    match recover_interrupted_update_on_startup() {
        Ok(Some(outcome)) => {
            warn!("startup updater recovery completed: {outcome}");
        }
        Ok(None) => {}
        Err(err) => {
            warn!("startup updater recovery requires operator attention: {err}");
            merge_update_diagnostic(
                &mut previous_update_failure,
                format!("Startup recovery requires attention: {err}"),
            );
        }
    }
    match take_previous_update_failure_on_startup() {
        Ok(Some(message)) => merge_update_diagnostic(
            &mut previous_update_failure,
            format!("Previous update failed: {message}"),
        ),
        Ok(None) => {}
        Err(err) => {
            warn!("failed to consume previous updater failure record: {err}");
            previous_update_failure.get_or_insert_with(|| {
                format!("Previous update diagnostics require attention: {err}")
            });
        }
    }
    ctrlc::set_handler(|| {
        request_process_shutdown();
    })
    .context("failed to install signal handler")?;
    Ok(previous_update_failure)
}

pub(crate) fn run(
    root: Option<&Path>,
    query: String,
    limit: usize,
    max_depth: flist_walker::indexer::MaxDepth,
    follow_links: bool,
    previous_update_failure: Option<String>,
) -> Result<()> {
    let startup_start = Instant::now();
    trace_startup_phase(startup_start, "run_gui_enter");
    configure_windows_dpi_mode();
    let root_explicit = root.is_some();
    let root = resolve_root(root.unwrap_or(Path::new(".")))?;
    trace_startup_phase(startup_start, "root_resolved");
    let mut native_options = eframe::NativeOptions::default();
    // Start hidden without forcing a position. The native window then gives access to real
    // monitors so session placement can choose and clamp one before the first visible frame.
    let startup_size = FlistWalkerApp::startup_window_placement(&[], None, false)
        .map(|placement| placement.logical_size);
    trace_startup_phase(startup_start, "startup_geometry_loaded");
    FlistWalkerApp::trace_window_event(
        "run_gui_start",
        &format!("root={} limit={}", root.display(), limit),
    );
    let icon = load_app_icon();
    trace_startup_phase(startup_start, "icon_prepared");
    native_options.viewport = build_root_viewport(startup_size, icon);

    trace_startup_phase(startup_start, "run_native_before");
    eframe::run_native(
        APP_TITLE,
        native_options,
        Box::new(move |cc| {
            if let Some(window) = cc.winit_window() {
                let monitors = window.available_monitors().collect::<Vec<_>>();
                let current = window
                    .current_monitor()
                    .and_then(|current| monitors.iter().position(|monitor| *monitor == current));
                let monitor_geometry = monitors
                    .iter()
                    .map(|monitor| {
                        let position = monitor.position();
                        let size = monitor.size();
                        (
                            eframe::egui::Rect::from_min_size(
                                eframe::egui::pos2(position.x as f32, position.y as f32),
                                eframe::egui::vec2(size.width as f32, size.height as f32),
                            ),
                            monitor.scale_factor() as f32,
                        )
                    })
                    .collect::<Vec<_>>();
                let outer_position = window.outer_position().ok();
                if let Some(placement) = FlistWalkerApp::startup_window_placement(
                    &monitor_geometry,
                    current,
                    outer_position.is_some(),
                ) {
                    if let (Some(mut position), Some(restored)) =
                        (outer_position, placement.physical_position)
                    {
                        position.x = restored.x.round() as i32;
                        position.y = restored.y.round() as i32;
                        window.set_outer_position(position);
                    }
                    let native_scale = if placement.physical_position.is_some() {
                        placement.scale_factor
                    } else {
                        window.scale_factor() as f32
                    };
                    let mut size = window.inner_size();
                    size.width = (placement.logical_size.x * native_scale).round().max(1.0) as u32;
                    size.height = (placement.logical_size.y * native_scale).round().max(1.0) as u32;
                    let mut minimum = size;
                    minimum.width = minimum.width.min((MIN_WINDOW_SIZE.x * native_scale) as u32);
                    minimum.height = minimum
                        .height
                        .min((MIN_WINDOW_SIZE.y * native_scale) as u32);
                    window.set_min_inner_size(Some(minimum));
                    let _ = window.request_inner_size(size);
                    FlistWalkerApp::trace_window_event(
                        "startup_native_placement",
                        &format!("{placement:?}"),
                    );
                }
            }
            configure_quit_shortcuts(&cc.egui_ctx);
            // winit creates the macOS menu before invoking the app creator.
            #[cfg(target_os = "macos")]
            macos_menu::disable_native_quit_shortcut()?;
            configure_egui_fonts(&cc.egui_ctx);
            trace_startup_phase(startup_start, "fonts_configured");
            let mut app = FlistWalkerApp::from_launch(
                root,
                limit,
                query,
                root_explicit,
                max_depth,
                follow_links,
            );
            if let Some(message) = previous_update_failure {
                app.set_previous_update_failure(message);
            }
            trace_startup_phase(startup_start, "app_created");
            Ok(Box::new(app))
        }),
    )
    .map_err(|e| anyhow::anyhow!(e.to_string()))?;
    Ok(())
}

fn build_root_viewport(
    startup_size: Option<eframe::egui::Vec2>,
    icon: Option<eframe::egui::IconData>,
) -> eframe::egui::ViewportBuilder {
    let mut viewport = eframe::egui::ViewportBuilder::default()
        .with_title(APP_TITLE)
        .with_app_id(APP_ID)
        .with_inner_size(DEFAULT_WINDOW_SIZE)
        .with_min_inner_size(MIN_WINDOW_SIZE);
    if let Some(size) = startup_size {
        viewport = viewport
            .with_inner_size(size)
            .with_min_inner_size(MIN_WINDOW_SIZE.min(size));
    }
    if let Some(icon) = icon {
        viewport = viewport.with_icon(icon);
    }
    viewport
}

fn load_app_icon() -> Option<eframe::egui::IconData> {
    let svg = include_bytes!("../assets/flistwalker-icon.svg");
    let tree = usvg::Tree::from_data(svg, &usvg::Options::default()).ok()?;
    let target_px = 256u32;
    let mut pixmap = tiny_skia::Pixmap::new(target_px, target_px)?;
    let size = tree.size().to_int_size();
    let sx = target_px as f32 / size.width() as f32;
    let sy = target_px as f32 / size.height() as f32;
    let transform = tiny_skia::Transform::from_scale(sx, sy);
    resvg::render(&tree, transform, &mut pixmap.as_mut());
    let rgba = premultiplied_to_unmultiplied_rgba(pixmap.data());

    Some(eframe::egui::IconData {
        rgba,
        width: target_px,
        height: target_px,
    })
}

fn trace_startup_phase(start: Instant, phase: &str) {
    FlistWalkerApp::trace_window_event(
        "startup_phase",
        &format!(
            "phase={} elapsed_ms={:.3}",
            phase,
            start.elapsed().as_secs_f64() * 1000.0
        ),
    );
}

fn premultiplied_to_unmultiplied_rgba(src: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(src.len());
    for px in src.chunks_exact(4) {
        let r = px[0] as u32;
        let g = px[1] as u32;
        let b = px[2] as u32;
        let a = px[3] as u32;
        if a == 0 {
            out.extend_from_slice(&[0, 0, 0, 0]);
            continue;
        }
        let unpremul = |c: u32| -> u8 {
            let v = ((c * 255 + a / 2) / a).min(255);
            v as u8
        };
        out.push(unpremul(r));
        out.push(unpremul(g));
        out.push(unpremul(b));
        out.push(a as u8);
    }
    out
}

#[cfg(test)]
mod tests {
    use super::{
        build_root_viewport, merge_update_diagnostic, APP_ID, APP_TITLE, DEFAULT_WINDOW_SIZE,
        MIN_WINDOW_SIZE,
    };

    #[test]
    fn quit_shortcuts_do_not_close_the_root_viewport() {
        use eframe::egui::{Context, Event, Key, Modifiers, RawInput, ViewportCommand, ViewportId};

        for modifiers in [
            Modifiers {
                ctrl: true,
                command: true,
                ..Modifiers::NONE
            },
            Modifiers {
                mac_cmd: true,
                command: true,
                ..Modifiers::NONE
            },
        ] {
            let ctx = Context::default();
            super::configure_quit_shortcuts(&ctx);
            for repeat in [false, true] {
                let output = ctx.run_ui(
                    RawInput {
                        modifiers,
                        events: vec![Event::Key {
                            key: Key::Q,
                            physical_key: Some(Key::Q),
                            pressed: true,
                            repeat,
                            modifiers,
                        }],
                        ..RawInput::default()
                    },
                    |_| {},
                );
                assert!(
                    !output.viewport_output[&ViewportId::ROOT]
                        .commands
                        .contains(&ViewportCommand::Close),
                    "quit chord must not close the app: {modifiers:?}, repeat={repeat}"
                );
            }

            let output = ctx.run_ui(RawInput::default(), |ui| {
                ui.ctx().send_viewport_cmd(ViewportCommand::Close);
            });
            assert!(output.viewport_output[&ViewportId::ROOT]
                .commands
                .contains(&ViewportCommand::Close));
        }
    }

    #[test]
    fn startup_update_diagnostics_preserve_recovery_and_helper_failures() {
        let mut message = None;
        merge_update_diagnostic(&mut message, "recovery failure".to_string());
        merge_update_diagnostic(&mut message, "helper failure".to_string());

        assert_eq!(
            message.as_deref(),
            Some("recovery failure\n\nhelper failure")
        );
    }

    #[test]
    fn build_root_viewport_applies_defaults() {
        let viewport = build_root_viewport(None, None);

        assert_eq!(viewport.title.as_deref(), Some(APP_TITLE));
        assert_eq!(viewport.app_id.as_deref(), Some(APP_ID));
        assert_eq!(viewport.inner_size, Some(DEFAULT_WINDOW_SIZE));
        assert_eq!(viewport.min_inner_size, Some(MIN_WINDOW_SIZE));
        assert_eq!(viewport.position, None);
    }

    #[test]
    fn build_root_viewport_prefers_restored_geometry_and_icon() {
        let icon = eframe::egui::IconData {
            rgba: vec![255, 0, 0, 255],
            width: 1,
            height: 1,
        };
        let size = eframe::egui::vec2(900.0, 700.0);

        let viewport = build_root_viewport(Some(size), Some(icon));

        assert_eq!(viewport.position, None);
        assert_eq!(viewport.inner_size, Some(size));
        assert_eq!(viewport.min_inner_size, Some(MIN_WINDOW_SIZE));
        assert!(viewport.icon.is_some());
    }
}
