use super::*;

fn canonical_or_self(path: &Path) -> PathBuf {
    path.canonicalize().unwrap_or_else(|_| path.to_path_buf())
}

#[test]
fn sanitize_saved_tabs_keeps_missing_roots_lazy_and_clamps_active_tab() {
    let root = test_root("saved-tabs-sanitize");
    fs::create_dir_all(&root).expect("create root");
    let missing_root = root.join("missing");
    let tabs = vec![
        SavedTabState {
            root: root.to_string_lossy().to_string(),
            use_filelist: true,
            use_regex: false,
            ignore_case: true,
            include_files: true,
            include_dirs: true,
            max_depth: crate::indexer::MaxDepth::limited(2).expect("valid depth"),
            follow_links: true,
            query: "ok".to_string(),
            query_history: Vec::new(),
            tab_accent: Some(TabAccentColor::Teal),
        },
        SavedTabState {
            root: missing_root.to_string_lossy().to_string(),
            use_filelist: false,
            use_regex: true,
            ignore_case: true,
            include_files: true,
            include_dirs: false,
            max_depth: crate::indexer::MaxDepth::unlimited(),
            follow_links: false,
            query: "skip".to_string(),
            query_history: Vec::new(),
            tab_accent: Some(TabAccentColor::Amber),
        },
    ];

    let (sanitized, active) =
        FlistWalkerApp::sanitize_saved_tabs(&tabs, Some(99)).expect("sanitized tabs");
    assert_eq!(sanitized.len(), 2);
    assert_eq!(active, 1);
    assert_eq!(sanitized[0].query, "ok");
    assert_eq!(sanitized[0].tab_accent, Some(TabAccentColor::Teal));
    assert_eq!(sanitized[0].max_depth.value(), Some(2));
    assert!(sanitized[0].follow_links);
    assert_eq!(PathBuf::from(&sanitized[1].root), missing_root);
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn choose_startup_root_prefers_last_root_over_default_root() {
    let fallback_root = PathBuf::from("/fallback");
    let last_root = PathBuf::from("/last");
    let default_root = PathBuf::from("/default");

    let chosen = FlistWalkerApp::choose_startup_root(
        fallback_root.clone(),
        false,
        true,
        None,
        Some(last_root.clone()),
        Some(default_root),
    );

    assert_eq!(chosen, last_root);
}

#[test]
fn choose_startup_root_prefers_default_root_when_restore_tabs_is_disabled() {
    let fallback_root = PathBuf::from("/fallback");
    let last_root = PathBuf::from("/last");
    let default_root = PathBuf::from("/default");

    let chosen = FlistWalkerApp::choose_startup_root(
        fallback_root,
        false,
        false,
        None,
        Some(last_root),
        Some(default_root.clone()),
    );

    assert_eq!(chosen, default_root);
}

#[test]
fn choose_startup_root_keeps_missing_saved_roots_lazy() {
    let fallback_root = PathBuf::from("/fallback");
    let missing_last_root = PathBuf::from("/missing-last");
    let missing_default_root = PathBuf::from("/missing-default");

    let restored_with_default = FlistWalkerApp::choose_startup_root(
        fallback_root.clone(),
        false,
        false,
        None,
        Some(missing_last_root.clone()),
        Some(missing_default_root.clone()),
    );
    let restored_with_tabs = FlistWalkerApp::choose_startup_root(
        fallback_root,
        false,
        true,
        None,
        Some(missing_last_root.clone()),
        Some(missing_default_root),
    );

    assert_eq!(restored_with_default, PathBuf::from("/missing-default"));
    assert_eq!(restored_with_tabs, missing_last_root);
}

#[test]
fn set_as_default_is_disabled_while_restore_tabs_config_is_enabled() {
    let root = test_root("set-default-disabled-by-restore-tabs");
    fs::create_dir_all(&root).expect("create root");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    assert!(!FlistWalkerApp::can_set_current_root_as_default_with(true));

    app.set_current_root_as_default_with(true);

    assert!(app.shell.features.root_browser.default_root.is_none());
    assert_eq!(
        app.shell.runtime.notice,
        FlistWalkerApp::SET_DEFAULT_DISABLED_BY_RESTORE_TABS_NOTICE
    );
    assert_eq!(
        FlistWalkerApp::SET_DEFAULT_DISABLED_BY_RESTORE_TABS_TOOLTIP,
        "Unavailable while Restore Tabs is enabled. The last session takes priority at startup, so the default root is not used."
    );
    assert_eq!(
        FlistWalkerApp::SET_DEFAULT_DISABLED_BY_RESTORE_TABS_NOTICE,
        "Set as default is unavailable while Restore Tabs is enabled because the last session takes priority at startup."
    );
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn explicit_query_or_depth_suppresses_session_and_restores_default_root_precedence() {
    let unlimited = crate::indexer::MaxDepth::unlimited();
    let limited = crate::indexer::MaxDepth::limited(2).expect("limited depth");

    assert!(FlistWalkerApp::restore_session_allowed(
        true, false, "", unlimited, false
    ));
    assert!(!FlistWalkerApp::restore_session_allowed(
        true, false, "needle", unlimited, false
    ));
    assert!(!FlistWalkerApp::restore_session_allowed(
        true, false, "", limited, false
    ));
    assert!(!FlistWalkerApp::restore_session_allowed(
        true, true, "", unlimited, false
    ));
    assert!(!FlistWalkerApp::restore_session_allowed(
        false, false, "", unlimited, false
    ));

    let chosen = FlistWalkerApp::choose_startup_root(
        PathBuf::from("/fallback"),
        false,
        false,
        None,
        Some(PathBuf::from("/last-session")),
        Some(PathBuf::from("/default")),
    );
    assert_eq!(chosen, PathBuf::from("/default"));
}

#[test]
fn set_as_default_is_enabled_when_restore_tabs_config_is_disabled() {
    let root = test_root("set-default-enabled-without-restore-tabs");
    fs::create_dir_all(&root).expect("create root");

    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());

    assert!(FlistWalkerApp::can_set_current_root_as_default_with(false));
    app.set_current_root_as_default_with(false);

    let saved = app
        .shell
        .features
        .root_browser
        .default_root
        .as_ref()
        .expect("default root");
    assert_eq!(canonical_or_self(saved), canonical_or_self(&root));
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn save_ui_state_uses_default_root_as_last_root_when_restore_tabs_is_disabled() {
    let default_root = test_root("save-ui-state-default-root");
    let current_root = test_root("save-ui-state-current-root");
    let ui_state_dir = test_root("save-ui-state-dir");
    let ui_state_path = ui_state_dir.join(".flistwalker_ui_state.json");
    fs::create_dir_all(&default_root).expect("create default root");
    fs::create_dir_all(&current_root).expect("create current root");
    fs::create_dir_all(&ui_state_dir).expect("create ui state dir");

    let mut app = FlistWalkerApp::new(current_root.clone(), 50, String::new());
    app.shell.features.root_browser.default_root = Some(default_root.clone());
    app.save_ui_state_to_path(&ui_state_path);

    let saved = FlistWalkerApp::load_ui_state_from_path(&ui_state_path);
    let saved_last_root = saved.last_root.expect("last root");
    let saved_default_root = saved.default_root.expect("default root");
    assert_eq!(
        canonical_or_self(Path::new(&saved_last_root)),
        canonical_or_self(&default_root)
    );
    assert_eq!(
        canonical_or_self(Path::new(&saved_default_root)),
        canonical_or_self(&default_root)
    );

    let _ = fs::remove_file(&ui_state_path);
    let _ = fs::remove_dir_all(&default_root);
    let _ = fs::remove_dir_all(&current_root);
    let _ = fs::remove_dir_all(&ui_state_dir);
}

#[test]
fn choose_startup_root_prefers_restored_tab_over_last_root() {
    let restored_root = PathBuf::from("/restored");
    let last_root = PathBuf::from("/last");
    let tabs = vec![SavedTabState {
        root: restored_root.to_string_lossy().to_string(),
        use_filelist: true,
        use_regex: false,
        ignore_case: true,
        include_files: true,
        include_dirs: true,
        max_depth: crate::indexer::MaxDepth::unlimited(),
        follow_links: false,
        query: String::new(),
        query_history: Vec::new(),
        tab_accent: Some(TabAccentColor::Emerald),
    }];

    let chosen = FlistWalkerApp::choose_startup_root(
        PathBuf::from("/fallback"),
        false,
        true,
        Some(&(tabs, 0)),
        Some(last_root),
        None,
    );

    assert_eq!(chosen, restored_root);
}

#[test]
fn initialize_tabs_from_saved_restores_active_tab_and_defers_background_refresh() {
    let root_a = test_root("restore-tabs-a");
    let root_b = test_root("restore-tabs-b");
    fs::create_dir_all(&root_a).expect("create root a");
    fs::create_dir_all(&root_b).expect("create root b");
    let mut app = FlistWalkerApp::new(root_a.clone(), 50, String::new());
    let (tx, rx) = bounded_request_channel::<IndexRequest>(2);
    app.shell.indexing.tx = tx;
    reset_index_request_state_for_test(&mut app);

    app.initialize_tabs_from_saved(
        vec![
            SavedTabState {
                root: root_a.to_string_lossy().to_string(),
                use_filelist: true,
                use_regex: false,
                ignore_case: true,
                include_files: true,
                include_dirs: true,
                max_depth: crate::indexer::MaxDepth::unlimited(),
                follow_links: false,
                query: "alpha".to_string(),
                query_history: Vec::new(),
                tab_accent: Some(TabAccentColor::Azure),
            },
            SavedTabState {
                root: root_b.to_string_lossy().to_string(),
                use_filelist: false,
                use_regex: true,
                ignore_case: true,
                include_files: true,
                include_dirs: false,
                max_depth: crate::indexer::MaxDepth::unlimited(),
                follow_links: false,
                query: "beta".to_string(),
                query_history: Vec::new(),
                tab_accent: Some(TabAccentColor::Crimson),
            },
        ],
        1,
    );

    assert_eq!(app.shell.tabs.len(), 2);
    assert_eq!(app.shell.tabs.active_tab, 1);
    assert_eq!(app.shell.runtime.root, root_b);
    assert_eq!(app.shell.runtime.query_state.query, "beta");
    assert_eq!(
        app.shell.tabs.get(1).expect("tab 1").tab_accent,
        Some(TabAccentColor::Crimson)
    );
    assert_eq!(
        app.shell
            .tabs
            .get(0)
            .expect("tab 0")
            .index_state
            .lifecycle(),
        TabResourceLifecycle::Dormant
    );
    assert!(matches!(
        app.shell.indexing.lifecycle(),
        TabResourceLifecycle::Loading | TabResourceLifecycle::Refreshing
    ));

    let req = rx.try_recv().expect("active tab refresh");
    assert_eq!(req.root, root_b);
    assert!(rx.try_recv().is_err());

    let _ = fs::remove_dir_all(&root_a);
    let _ = fs::remove_dir_all(&root_b);
}

#[test]
fn initialize_tabs_from_saved_keeps_current_row_empty_until_results_exist_regression() {
    let root = test_root("restore-tabs-default-row");
    fs::create_dir_all(&root).expect("create root");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    let (tx, _rx) = bounded_request_channel::<IndexRequest>(2);
    app.shell.indexing.tx = tx;
    reset_index_request_state_for_test(&mut app);

    app.initialize_tabs_from_saved(
        vec![SavedTabState {
            root: root.to_string_lossy().to_string(),
            use_filelist: true,
            use_regex: false,
            ignore_case: true,
            include_files: true,
            include_dirs: true,
            max_depth: crate::indexer::MaxDepth::unlimited(),
            follow_links: false,
            query: String::new(),
            query_history: Vec::new(),
            tab_accent: None,
        }],
        0,
    );

    assert_eq!(app.shell.runtime.current_row, None);
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn switching_to_restored_background_tab_triggers_lazy_refresh() {
    let root_a = test_root("restore-tabs-switch-a");
    let root_b = test_root("restore-tabs-switch-b");
    fs::create_dir_all(&root_a).expect("create root a");
    fs::create_dir_all(&root_b).expect("create root b");
    let mut app = FlistWalkerApp::new(root_a.clone(), 50, String::new());
    let (tx, rx) = bounded_request_channel::<IndexRequest>(2);
    app.shell.indexing.tx = tx;
    reset_index_request_state_for_test(&mut app);

    app.initialize_tabs_from_saved(
        vec![
            SavedTabState {
                root: root_a.to_string_lossy().to_string(),
                use_filelist: true,
                use_regex: false,
                ignore_case: true,
                include_files: true,
                include_dirs: true,
                max_depth: crate::indexer::MaxDepth::unlimited(),
                follow_links: false,
                query: "alpha".to_string(),
                query_history: Vec::new(),
                tab_accent: Some(TabAccentColor::Olive),
            },
            SavedTabState {
                root: root_b.to_string_lossy().to_string(),
                use_filelist: true,
                use_regex: false,
                ignore_case: true,
                include_files: true,
                include_dirs: true,
                max_depth: crate::indexer::MaxDepth::unlimited(),
                follow_links: false,
                query: "beta".to_string(),
                query_history: Vec::new(),
                tab_accent: Some(TabAccentColor::Indigo),
            },
        ],
        1,
    );
    let _ = rx.try_recv().expect("initial active refresh");

    app.switch_to_tab_index(0);

    let req = rx.try_recv().expect("background tab lazy refresh");
    assert_eq!(req.root, root_a);
    assert!(matches!(
        app.shell.indexing.lifecycle(),
        TabResourceLifecycle::Loading | TabResourceLifecycle::Refreshing
    ));

    let _ = fs::remove_dir_all(&root_a);
    let _ = fs::remove_dir_all(&root_b);
}

#[test]
fn restored_tab_lazy_refresh_starts_for_query_and_source_matrix() {
    for (use_filelist, query) in [(false, ""), (false, "needle"), (true, ""), (true, "needle")] {
        let case = format!(
            "restore-tabs-matrix-{}-{}",
            if use_filelist { "filelist" } else { "walker" },
            if query.is_empty() { "empty" } else { "query" }
        );
        let root_a = test_root(&format!("{case}-a"));
        let root_b = test_root(&format!("{case}-b"));
        fs::create_dir_all(&root_a).expect("create root a");
        fs::create_dir_all(&root_b).expect("create root b");
        let mut app = FlistWalkerApp::new(root_a.clone(), 50, String::new());
        let (tx, rx) = bounded_request_channel::<IndexRequest>(2);
        app.shell.indexing.tx = tx;
        reset_index_request_state_for_test(&mut app);

        app.initialize_tabs_from_saved(
            vec![
                SavedTabState {
                    root: root_a.to_string_lossy().to_string(),
                    use_filelist,
                    use_regex: false,
                    ignore_case: true,
                    include_files: true,
                    include_dirs: true,
                    max_depth: crate::indexer::MaxDepth::unlimited(),
                    follow_links: false,
                    query: query.to_string(),
                    query_history: Vec::new(),
                    tab_accent: None,
                },
                SavedTabState {
                    root: root_b.to_string_lossy().to_string(),
                    use_filelist: false,
                    use_regex: false,
                    ignore_case: true,
                    include_files: true,
                    include_dirs: true,
                    max_depth: crate::indexer::MaxDepth::unlimited(),
                    follow_links: false,
                    query: String::new(),
                    query_history: Vec::new(),
                    tab_accent: None,
                },
            ],
            1,
        );
        let _ = rx.try_recv().expect("initial active refresh");

        app.switch_to_tab_index(0);

        let request = rx.try_recv().expect("lazy refresh in transition");
        assert_eq!(request.root, root_a);
        assert_eq!(request.use_filelist, use_filelist);
        assert_eq!(app.shell.runtime.query_state.query, query);
        assert!(app.shell.indexing.in_progress);
        assert!(app.shell.runtime.status_line.contains("Indexing..."));

        let _ = fs::remove_dir_all(&root_a);
        let _ = fs::remove_dir_all(&root_b);
    }
}

#[test]
fn restored_tab_activation_prioritizes_active_batch_over_background_backlog_regression() {
    let root_a = test_root("restore-tabs-active-response-priority-a");
    let root_b = test_root("restore-tabs-active-response-priority-b");
    fs::create_dir_all(&root_a).expect("create root a");
    fs::create_dir_all(&root_b).expect("create root b");
    let mut app = FlistWalkerApp::new(root_a.clone(), 50, String::new());
    let (index_req_tx, index_req_rx) = bounded_request_channel::<IndexRequest>(2);
    let (index_res_tx, index_res_rx) = mpsc::channel::<IndexResponse>();
    app.shell.indexing.tx = index_req_tx;
    app.shell.indexing.rx = index_res_rx;
    reset_index_request_state_for_test(&mut app);

    app.initialize_tabs_from_saved(
        vec![
            SavedTabState {
                root: root_a.to_string_lossy().to_string(),
                use_filelist: true,
                use_regex: false,
                ignore_case: true,
                include_files: true,
                include_dirs: true,
                max_depth: crate::indexer::MaxDepth::unlimited(),
                follow_links: false,
                query: "needle".to_string(),
                query_history: Vec::new(),
                tab_accent: None,
            },
            SavedTabState {
                root: root_b.to_string_lossy().to_string(),
                use_filelist: false,
                use_regex: false,
                ignore_case: true,
                include_files: true,
                include_dirs: true,
                max_depth: crate::indexer::MaxDepth::unlimited(),
                follow_links: false,
                query: String::new(),
                query_history: Vec::new(),
                tab_accent: None,
            },
        ],
        1,
    );
    let old_active = index_req_rx.try_recv().expect("initial active request");
    assert!(
        !app.shell
            .tabs
            .get(0)
            .expect("dormant restored tab")
            .index_state
            .index_in_progress
    );

    app.switch_to_tab_index(0);
    let new_active = index_req_rx
        .try_recv()
        .expect("activated restored tab request");
    assert_eq!(new_active.root, root_a);
    assert!(new_active.use_filelist);
    assert!(app.shell.indexing.in_progress);

    for index in 0..128 {
        index_res_tx
            .send(IndexResponse::Batch {
                request_id: old_active.request_id,
                entries: vec![IndexEntry {
                    path: root_b.join(format!("background-{index}.txt")),
                    kind: EntryKind::file(),
                    kind_known: true,
                }],
            })
            .expect("queue old background batch");
    }
    let active_path = root_a.join("needle.txt");
    index_res_tx
        .send(IndexResponse::Started {
            request_id: new_active.request_id,
            source: IndexSource::Walker,
        })
        .expect("queue active start");
    index_res_tx
        .send(IndexResponse::Batch {
            request_id: new_active.request_id,
            entries: vec![IndexEntry {
                path: active_path.clone(),
                kind: EntryKind::file(),
                kind_known: true,
            }],
        })
        .expect("queue active batch");

    app.poll_index_response_with_budget_for_test(Duration::from_secs(1));

    assert_eq!(app.shell.indexing.build.index.source, IndexSource::Walker);
    assert!(app
        .shell
        .indexing
        .build
        .index
        .entries
        .iter()
        .any(|entry| entry.path == active_path));

    for _ in 0..4 {
        app.poll_index_response_with_budget_for_test(Duration::from_secs(1));
    }
    assert_eq!(
        app.shell
            .indexing
            .background_states
            .get(&old_active.request_id)
            .expect("deferred background state")
            .entries
            .len(),
        128,
        "active prioritization must defer rather than discard live background batches"
    );

    let _ = fs::remove_dir_all(&root_a);
    let _ = fs::remove_dir_all(&root_b);
}

#[test]
fn background_tab_activation_consumes_dormant_lifecycle_once() {
    let root_a = test_root("background-activation-consumes-pending-a");
    let root_b = test_root("background-activation-consumes-pending-b");
    fs::create_dir_all(&root_a).expect("create root a");
    fs::create_dir_all(&root_b).expect("create root b");
    let indexed_file = root_a.join("indexed.txt");
    fs::write(&indexed_file, "indexed").expect("write indexed file");

    let mut app = FlistWalkerApp::new(root_a.clone(), 50, String::new());
    let (index_req_tx, index_req_rx) = bounded_request_channel::<IndexRequest>(2);
    let (index_res_tx, index_res_rx) = mpsc::channel::<IndexResponse>();
    app.shell.indexing.tx = index_req_tx;
    app.shell.indexing.rx = index_res_rx;
    reset_index_request_state_for_test(&mut app);

    app.initialize_tabs_from_saved(
        vec![
            SavedTabState {
                root: root_a.to_string_lossy().to_string(),
                use_filelist: true,
                use_regex: false,
                ignore_case: true,
                include_files: true,
                include_dirs: true,
                max_depth: crate::indexer::MaxDepth::unlimited(),
                follow_links: false,
                query: String::new(),
                query_history: Vec::new(),
                tab_accent: Some(TabAccentColor::Olive),
            },
            SavedTabState {
                root: root_b.to_string_lossy().to_string(),
                use_filelist: true,
                use_regex: false,
                ignore_case: true,
                include_files: true,
                include_dirs: true,
                max_depth: crate::indexer::MaxDepth::unlimited(),
                follow_links: false,
                query: String::new(),
                query_history: Vec::new(),
                tab_accent: Some(TabAccentColor::Indigo),
            },
        ],
        1,
    );
    let _ = index_req_rx.try_recv().expect("initial active refresh");

    let background_tab_id = app.shell.tabs.get(0).expect("tab 0").id;

    let (search_tx_req, _search_rx_req) = mpsc::channel::<SearchRequest>();
    let (search_tx_res, search_rx_res) = mpsc::channel::<SearchResponse>();
    app.shell.search.tx = search_tx_req;
    app.shell.search.rx = search_rx_res;
    let search_request_id = app.shell.search.allocate_request_id();
    app.shell
        .search
        .bind_request_tab(search_request_id, background_tab_id);

    let (preview_tx_req, preview_rx_req) = mpsc::channel::<PreviewRequest>();
    let (preview_tx_res, preview_rx_res) = mpsc::channel::<PreviewResponse>();
    app.shell.worker_bus.preview.tx = preview_tx_req;
    app.shell.worker_bus.preview.rx = preview_rx_res;
    let (kind_tx_req, kind_rx_req) = bounded_request_channel::<KindResolveRequest>(4);
    let (kind_tx_res, kind_rx_res) = mpsc::channel::<KindResolveResponse>();
    app.shell.worker_bus.kind.tx = kind_tx_req;
    app.shell.worker_bus.kind.rx = kind_rx_res;
    let preview_request_id = 41;
    app.bind_preview_request_to_tab(preview_request_id, background_tab_id);

    let background_index_request_id = 77;
    app.shell
        .indexing
        .request_tabs
        .insert(background_index_request_id, background_tab_id);
    app.shell
        .tabs
        .get_mut(0)
        .expect("tab 0")
        .index_state
        .pending_index_request_id = Some(background_index_request_id);
    app.shell
        .tabs
        .get_mut(0)
        .expect("tab 0")
        .index_state
        .index_in_progress = true;

    search_tx_res
        .send(SearchResponse {
            request_id: search_request_id,
            results: vec![(indexed_file.clone(), 9.0)],
            total_match_count: 1,
            sort_mode: ResultSortMode::Score,
            sort_scope: ResultSortScope::ShownResults,
            error: None,
        })
        .expect("send background search response");
    preview_tx_res
        .send(PreviewResponse {
            canceled: false,
            request_id: preview_request_id,
            path: indexed_file.clone(),
            preview: "preview-body".to_string(),
        })
        .expect("send background preview response");
    index_res_tx
        .send(IndexResponse::Batch {
            request_id: background_index_request_id,
            entries: vec![IndexEntry {
                path: indexed_file.clone(),
                kind: EntryKind::file(),
                kind_known: true,
            }],
        })
        .expect("send background batch");
    index_res_tx
        .send(IndexResponse::Finished {
            request_id: background_index_request_id,
            source: IndexSource::Walker,
        })
        .expect("send background finished");

    app.poll_search_response();
    app.poll_preview_response();
    app.poll_index_response();

    assert_eq!(app.shell.tabs.active_tab, 1);
    assert_eq!(app.shell.runtime.root, root_b);
    let background = app.shell.tabs.get(0).expect("tab 0");
    assert!(background.result_state.committed.preview.is_empty());
    assert!(background.preview_reload_pending);
    assert_eq!(app.preview_request_tab(preview_request_id), None);
    assert_eq!(
        app.shell
            .tabs
            .get(0)
            .expect("tab 0")
            .result_state
            .committed
            .entries
            .len(),
        1
    );
    assert_eq!(
        app.shell
            .tabs
            .get(0)
            .expect("tab 0")
            .result_state
            .committed
            .entries[0],
        indexed_file
    );

    app.switch_to_tab_index(0);

    assert!(
        index_req_rx.try_recv().is_err(),
        "a Ready background generation must be promoted without reindex"
    );
    assert_eq!(app.shell.tabs.active_tab, 0);
    assert_eq!(app.shell.runtime.root, root_a);
    assert_eq!(app.shell.indexing.lifecycle(), TabResourceLifecycle::Ready);
    assert_eq!(app.shell.runtime.results.len(), 1);
    assert_eq!(app.shell.runtime.results[0].0, indexed_file);

    let kind_request = kind_rx_req
        .try_recv()
        .expect("Ready Walker activation resolves retained unknown kind");
    assert_eq!(kind_request.path, indexed_file);
    assert_eq!(app.shell.runtime.preview, "Resolving entry type...");
    kind_tx_res
        .send(KindResolveResponse {
            tab_id: app.current_tab_id().expect("active tab id"),
            epoch: kind_request.epoch,
            path: indexed_file.clone(),
            kind: Some(EntryKind::file()),
        })
        .expect("send restored kind response");
    app.poll_kind_response();
    let reload_request = preview_rx_req
        .try_recv()
        .expect("Ready activation dispatches preview reload");
    assert_eq!(reload_request.path, indexed_file);
    preview_tx_res
        .send(PreviewResponse {
            canceled: false,
            request_id: reload_request.request_id,
            path: indexed_file.clone(),
            preview: "preview-body".to_string(),
        })
        .expect("send activation preview response");
    app.poll_preview_response();
    assert_eq!(app.shell.runtime.preview, "preview-body");

    let _ = fs::remove_dir_all(&root_a);
    let _ = fs::remove_dir_all(&root_b);
}

#[test]
fn close_tab_triggers_dormant_survivor_refresh() {
    let root_a = test_root("close-tab-pending-refresh-a");
    let root_b = test_root("close-tab-pending-refresh-b");
    fs::create_dir_all(&root_a).expect("create root a");
    fs::create_dir_all(&root_b).expect("create root b");

    let mut app = FlistWalkerApp::new(root_a.clone(), 50, String::new());
    let (index_req_tx, index_req_rx) = bounded_request_channel::<IndexRequest>(2);
    let (_index_res_tx, index_res_rx) = mpsc::channel::<IndexResponse>();
    app.shell.indexing.tx = index_req_tx;
    app.shell.indexing.rx = index_res_rx;
    reset_index_request_state_for_test(&mut app);

    app.initialize_tabs_from_saved(
        vec![
            SavedTabState {
                root: root_a.to_string_lossy().to_string(),
                use_filelist: true,
                use_regex: false,
                ignore_case: true,
                include_files: true,
                include_dirs: true,
                max_depth: crate::indexer::MaxDepth::unlimited(),
                follow_links: false,
                query: String::new(),
                query_history: Vec::new(),
                tab_accent: Some(TabAccentColor::Olive),
            },
            SavedTabState {
                root: root_b.to_string_lossy().to_string(),
                use_filelist: true,
                use_regex: false,
                ignore_case: true,
                include_files: true,
                include_dirs: true,
                max_depth: crate::indexer::MaxDepth::unlimited(),
                follow_links: false,
                query: String::new(),
                query_history: Vec::new(),
                tab_accent: Some(TabAccentColor::Indigo),
            },
        ],
        1,
    );
    let _ = index_req_rx.try_recv().expect("initial active refresh");

    app.close_tab_index(1);

    let refresh_req = index_req_rx
        .try_recv()
        .expect("survivor pending restore refresh");
    assert_eq!(refresh_req.root, root_a);
    assert!(matches!(
        app.shell.indexing.lifecycle(),
        TabResourceLifecycle::Loading | TabResourceLifecycle::Refreshing
    ));

    let _ = fs::remove_dir_all(&root_a);
    let _ = fs::remove_dir_all(&root_b);
}

#[test]
fn restoring_closed_startup_restored_background_tab_triggers_lazy_refresh() {
    let root_a = test_root("closed-startup-restored-tab-a");
    let root_b = test_root("closed-startup-restored-tab-b");
    fs::create_dir_all(&root_a).expect("create root a");
    fs::create_dir_all(&root_b).expect("create root b");

    let mut app = FlistWalkerApp::new(root_a.clone(), 50, String::new());
    let (index_req_tx, index_req_rx) = bounded_request_channel::<IndexRequest>(2);
    let (_index_res_tx, index_res_rx) = mpsc::channel::<IndexResponse>();
    app.shell.indexing.tx = index_req_tx;
    app.shell.indexing.rx = index_res_rx;
    reset_index_request_state_for_test(&mut app);

    app.initialize_tabs_from_saved(
        vec![
            SavedTabState {
                root: root_a.to_string_lossy().to_string(),
                use_filelist: true,
                use_regex: false,
                ignore_case: true,
                include_files: true,
                include_dirs: true,
                max_depth: crate::indexer::MaxDepth::unlimited(),
                follow_links: false,
                query: "alpha".to_string(),
                query_history: Vec::new(),
                tab_accent: Some(TabAccentColor::Olive),
            },
            SavedTabState {
                root: root_b.to_string_lossy().to_string(),
                use_filelist: true,
                use_regex: false,
                ignore_case: true,
                include_files: true,
                include_dirs: true,
                max_depth: crate::indexer::MaxDepth::unlimited(),
                follow_links: false,
                query: "beta".to_string(),
                query_history: Vec::new(),
                tab_accent: Some(TabAccentColor::Indigo),
            },
        ],
        1,
    );
    let _ = index_req_rx.try_recv().expect("initial active refresh");

    app.close_tab_index(0);
    assert_eq!(app.shell.tabs.len(), 1);
    assert_eq!(app.shell.tabs.len(), 1);

    app.restore_recently_closed_tab();

    assert_eq!(app.shell.tabs.len(), 2);
    assert_eq!(app.shell.tabs.active_tab, 0);
    assert_eq!(app.shell.runtime.root, root_a);
    let refresh_req = index_req_rx
        .try_recv()
        .expect("restored closed startup tab refresh");
    assert_eq!(refresh_req.root, root_a);
    assert!(matches!(
        app.shell.indexing.lifecycle(),
        TabResourceLifecycle::Loading | TabResourceLifecycle::Refreshing
    ));

    let _ = fs::remove_dir_all(&root_a);
    let _ = fs::remove_dir_all(&root_b);
}

#[test]
fn follow_links_saved_tabs_default_false_and_round_trip() {
    let legacy: SavedTabState = serde_json::from_str(
        r#"{"root":"root","use_filelist":true,"use_regex":false,"include_files":true,"include_dirs":true,"query":""}"#,
    ).expect("legacy tab");
    assert!(!legacy.follow_links);
    let enabled = SavedTabState {
        follow_links: true,
        ..legacy
    };
    let restored: SavedTabState =
        serde_json::from_str(&serde_json::to_string(&enabled).expect("serialize tab"))
            .expect("restore tab");
    assert!(restored.follow_links);
    assert!(!FlistWalkerApp::restore_session_allowed(
        true,
        false,
        "",
        crate::indexer::MaxDepth::unlimited(),
        true,
    ));
}
