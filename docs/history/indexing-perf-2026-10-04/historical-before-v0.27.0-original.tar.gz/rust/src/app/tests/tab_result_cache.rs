use super::*;

#[test]
fn close_tab_invalidates_memory_cache_for_immediate_resample() {
    let root = test_root("close-tab-memory-resample");
    fs::create_dir_all(&root).expect("create dir");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    assert_eq!(app.shell.tabs.len(), 2);

    let sentinel = u64::MAX;
    app.shell.ui.memory_usage_bytes = Some(sentinel);
    let stale = Instant::now()
        .checked_sub(Duration::from_secs(5))
        .unwrap_or_else(Instant::now);
    app.shell.ui.last_memory_sample = stale;

    app.close_tab_index(1);

    assert_eq!(app.shell.tabs.len(), 1);
    assert_ne!(app.shell.ui.memory_usage_bytes, Some(sentinel));
    assert!(app.shell.ui.last_memory_sample > stale);
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn close_tab_clears_filelist_and_request_routing_for_removed_tab() {
    let root = test_root("close-tab-clears-routing");
    fs::create_dir_all(&root).expect("create dir");
    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.create_new_tab();
    assert_eq!(app.shell.tabs.len(), 2);

    let removed_tab_id = app.shell.tabs.get(0).expect("tab 0").id;
    let survivor_tab_id = app.shell.tabs.get(1).expect("tab 1").id;
    let path = root.join("item.txt");
    fs::write(&path, "x").expect("write file");

    app.shell.features.filelist.workflow.pending_after_index = Some(PendingFileListAfterIndex {
        tab_id: removed_tab_id,
        root: root.clone(),
    });
    app.shell.features.filelist.workflow.pending_confirmation = Some(PendingFileListConfirmation {
        tab_id: removed_tab_id,
        root: root.clone(),
        entries: vec![path.clone()],
        existing_path: root.join("FileList.txt"),
    });
    app.shell
        .features
        .filelist
        .workflow
        .pending_ancestor_confirmation = Some(PendingFileListAncestorConfirmation {
        tab_id: removed_tab_id,
        root: root.clone(),
        entries: vec![path.clone()],
    });
    app.shell
        .features
        .filelist
        .workflow
        .pending_use_walker_confirmation = Some(PendingFileListUseWalkerConfirmation {
        source_tab_id: removed_tab_id,
        root: root.clone(),
    });
    let filelist_cancel = Arc::new(AtomicBool::new(false));
    app.shell.features.filelist.workflow.pending_request_id = Some(61);
    app.shell.features.filelist.workflow.pending_request_tab_id = Some(removed_tab_id);
    app.shell.features.filelist.workflow.pending_root = Some(root.clone());
    app.shell.features.filelist.workflow.pending_cancel = Some(Arc::clone(&filelist_cancel));
    app.shell.features.filelist.workflow.in_progress = true;

    app.shell.indexing.request_tabs.insert(11, removed_tab_id);
    app.shell.indexing.request_tabs.insert(12, survivor_tab_id);
    app.shell.indexing.pending_queue.push_back(IndexRequest {
        request_id: 11,
        tab_id: removed_tab_id,
        root: root.clone(),
        use_filelist: true,
        include_files: true,
        include_dirs: true,
        max_depth: crate::indexer::MaxDepth::unlimited(),
        follow_links: false,
    });
    app.shell.indexing.pending_queue.push_back(IndexRequest {
        request_id: 12,
        tab_id: survivor_tab_id,
        root: root.clone(),
        use_filelist: true,
        include_files: true,
        include_dirs: true,
        max_depth: crate::indexer::MaxDepth::unlimited(),
        follow_links: false,
    });
    if let Ok(mut latest) = app.shell.indexing.latest_request_ids.lock() {
        latest.insert(removed_tab_id, 11);
        latest.insert(survivor_tab_id, 12);
    }
    app.shell
        .indexing
        .background_states
        .insert(11, BackgroundIndexState::default());
    app.shell
        .indexing
        .background_states
        .insert(12, BackgroundIndexState::default());

    app.shell.search.bind_request_tab(21, removed_tab_id);
    app.shell.search.bind_request_tab(22, survivor_tab_id);
    app.bind_preview_request_to_tab(31, removed_tab_id);
    app.bind_preview_request_to_tab(32, survivor_tab_id);
    app.bind_action_request_to_tab(41, removed_tab_id);
    app.bind_action_request_to_tab(42, survivor_tab_id);
    app.bind_sort_request_to_tab(51, removed_tab_id);
    app.bind_sort_request_to_tab(52, survivor_tab_id);

    app.close_tab_index(0);

    assert_eq!(app.shell.tabs.len(), 1);
    assert_eq!(app.shell.tabs.get(0).expect("tab 0").id, survivor_tab_id);
    assert!(app
        .shell
        .features
        .filelist
        .workflow
        .pending_after_index
        .is_none());
    assert!(app
        .shell
        .features
        .filelist
        .workflow
        .pending_confirmation
        .is_none());
    assert!(app
        .shell
        .features
        .filelist
        .workflow
        .pending_ancestor_confirmation
        .is_none());
    assert!(app
        .shell
        .features
        .filelist
        .workflow
        .pending_use_walker_confirmation
        .is_none());
    assert!(filelist_cancel.load(Ordering::Relaxed));
    assert!(app
        .shell
        .features
        .filelist
        .workflow
        .pending_request_id
        .is_none());
    assert!(app
        .shell
        .features
        .filelist
        .workflow
        .pending_request_tab_id
        .is_none());
    assert!(app.shell.features.filelist.workflow.pending_root.is_none());
    assert!(app
        .shell
        .features
        .filelist
        .workflow
        .pending_cancel
        .is_none());
    assert_eq!(app.shell.indexing.request_tabs.get(&11), None);
    assert_eq!(
        app.shell.indexing.request_tabs.get(&12),
        Some(&survivor_tab_id)
    );
    assert!(app
        .shell
        .indexing
        .pending_queue
        .iter()
        .all(|req| req.tab_id != removed_tab_id));
    assert!(app.shell.indexing.background_states.contains_key(&12));
    assert!(!app.shell.indexing.background_states.contains_key(&11));
    if let Ok(latest) = app.shell.indexing.latest_request_ids.lock() {
        assert_eq!(latest.get(&removed_tab_id), None);
        assert_eq!(latest.get(&survivor_tab_id), Some(&12));
    }
    assert_eq!(app.shell.search.take_request_tab(21), None);
    assert_eq!(app.shell.search.take_request_tab(22), Some(survivor_tab_id));
    assert_eq!(app.preview_request_tab(31), None);
    assert_eq!(app.preview_request_tab(32), Some(survivor_tab_id));
    assert_eq!(app.action_request_tab(41), None);
    assert_eq!(app.action_request_tab(42), Some(survivor_tab_id));
    assert_eq!(app.sort_request_tab(51), None);
    assert_eq!(app.sort_request_tab(52), Some(survivor_tab_id));

    let _ = fs::remove_dir_all(&root);
}

#[test]
fn inactive_tab_results_are_retained_for_immediate_activation() {
    let root = test_root("inactive-tab-results-retained");
    fs::create_dir_all(&root).expect("create dir");
    let first = root.join("first.txt");
    let second = root.join("second.txt");
    fs::write(&first, "a").expect("write first");
    fs::write(&second, "b").expect("write second");

    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.shell.ui.show_preview = false;
    app.shell.indexing.in_progress = false;
    app.shell.indexing.pending_request_id = None;
    app.shell.runtime.entries = Arc::new(vec![
        unknown_entry(first.clone()),
        unknown_entry(second.clone()),
    ]);
    app.shell.runtime.base_results = vec![(first.clone(), 10.0), (second.clone(), 5.0)];
    app.shell.runtime.results = app.shell.runtime.base_results.clone();
    app.shell.runtime.current_row = Some(1);
    app.shell.runtime.preview = "preview".to_string();

    app.create_new_tab();

    assert_eq!(app.shell.tabs.len(), 2);
    assert!(
        !app.shell
            .tabs
            .get(0)
            .expect("tab 0")
            .result_state
            .results_compacted
    );
    assert_eq!(
        app.shell
            .tabs
            .get(0)
            .expect("tab 0")
            .result_state
            .committed
            .results
            .len(),
        2
    );
    assert_eq!(
        app.shell
            .tabs
            .get(0)
            .expect("tab 0")
            .result_state
            .committed
            .base_results
            .len(),
        2
    );
    assert!(app
        .shell
        .tabs
        .get(0)
        .expect("tab 0")
        .result_state
        .committed
        .preview
        .is_empty());

    app.switch_to_tab_index(0);

    assert_eq!(app.shell.runtime.results.len(), 2);
    assert_eq!(app.shell.runtime.results[0].0, first);
    assert_eq!(app.shell.runtime.results[1].0, second);
    assert_eq!(app.shell.runtime.current_row, Some(1));
    assert!(
        !app.shell
            .tabs
            .get(0)
            .expect("tab 0")
            .result_state
            .results_compacted
    );
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn explicitly_compacted_empty_query_restore_rebuilds_results_from_current_entries() {
    let root = test_root("empty-query-compacted-restore-current-index");
    fs::create_dir_all(&root).expect("create dir");
    let current = root.join("current.txt");
    let stale = root.join("stale.txt");
    fs::write(&current, "current").expect("write current");
    fs::write(&stale, "stale").expect("write stale");

    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.shell.ui.show_preview = false;
    app.shell.indexing.in_progress = false;
    app.shell.indexing.pending_request_id = None;
    app.shell.runtime.entries = Arc::new(vec![unknown_entry(current.clone())]);
    app.shell.runtime.base_results = vec![(current.clone(), 10.0), (stale, 5.0)];
    app.shell.runtime.results = app.shell.runtime.base_results.clone();
    app.shell.runtime.total_match_count = 1;
    app.shell.runtime.current_row = Some(0);

    app.create_new_tab();
    {
        let inactive = app.shell.tabs.get_mut(0).expect("inactive tab");
        inactive.result_state.committed.results.clear();
        inactive.result_state.results_compacted = true;
    }
    app.switch_to_tab_index(0);

    assert_eq!(app.shell.runtime.results, vec![(current, 0.0)]);
    assert_eq!(app.shell.runtime.total_match_count, 1);
    assert_eq!(app.shell.runtime.current_row, Some(0));
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn non_score_sorted_inactive_tab_keeps_results_for_fast_activation() {
    let root = test_root("inactive-tab-keeps-sorted-results");
    fs::create_dir_all(&root).expect("create dir");
    let first = root.join("b.txt");
    let second = root.join("a.txt");
    fs::write(&first, "b").expect("write first");
    fs::write(&second, "a").expect("write second");

    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.shell.indexing.in_progress = false;
    app.shell.indexing.pending_request_id = None;
    app.shell.runtime.entries = Arc::new(vec![
        unknown_entry(first.clone()),
        unknown_entry(second.clone()),
    ]);
    app.shell.runtime.base_results = vec![(first.clone(), 10.0), (second.clone(), 5.0)];
    app.shell.runtime.results = vec![(second.clone(), 5.0), (first.clone(), 10.0)];
    app.shell.runtime.result_sort_mode = ResultSortMode::NameAsc;
    app.shell.runtime.current_row = Some(0);

    app.create_new_tab();

    let inactive = app.shell.tabs.get(0).expect("tab 0");
    assert!(!inactive.result_state.results_compacted);
    assert_eq!(inactive.result_state.committed.results.len(), 2);
    assert_eq!(inactive.result_state.committed.results[0].0, second);

    app.switch_to_tab_index(0);

    assert_eq!(app.shell.runtime.result_sort_mode, ResultSortMode::NameAsc);
    assert_eq!(app.shell.runtime.results.len(), 2);
    assert_eq!(app.shell.runtime.results[0].0, second);
    assert!(!app.shell.worker_bus.sort.in_progress);

    let _ = fs::remove_dir_all(&root);
}

#[test]
fn metadata_sorted_inactive_tab_does_not_request_metadata_on_activation() {
    let root = test_root("inactive-tab-keeps-metadata-sorted-results");
    fs::create_dir_all(&root).expect("create dir");
    let first = root.join("old.txt");
    let second = root.join("new.txt");
    fs::write(&first, "old").expect("write first");
    fs::write(&second, "new").expect("write second");

    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    let (sort_tx, sort_rx) = mpsc::channel::<SortMetadataRequest>();
    app.shell.worker_bus.sort.tx = sort_tx;
    app.shell.indexing.in_progress = false;
    app.shell.indexing.pending_request_id = None;
    app.shell.runtime.entries = Arc::new(vec![
        unknown_entry(first.clone()),
        unknown_entry(second.clone()),
    ]);
    app.shell.runtime.base_results = vec![(first.clone(), 10.0), (second.clone(), 5.0)];
    app.shell.runtime.results = vec![(second.clone(), 5.0), (first.clone(), 10.0)];
    app.shell.runtime.result_sort_mode = ResultSortMode::ModifiedDesc;
    app.shell.runtime.current_row = Some(0);

    app.create_new_tab();
    app.switch_to_tab_index(0);

    assert_eq!(
        app.shell.runtime.result_sort_mode,
        ResultSortMode::ModifiedDesc
    );
    assert_eq!(app.shell.runtime.results.len(), 2);
    assert_eq!(app.shell.runtime.results[0].0, second);
    assert!(!app.shell.worker_bus.sort.in_progress);
    assert!(sort_rx.try_recv().is_err());

    let _ = fs::remove_dir_all(&root);
}

#[test]
fn tab_activation_restores_visible_cursor_when_selection_is_missing() {
    let root = test_root("tab-activation-restore-cursor");
    fs::create_dir_all(&root).expect("create dir");
    let first = root.join("first.txt");
    let second = root.join("second.txt");
    fs::write(&first, "a").expect("write first");
    fs::write(&second, "b").expect("write second");

    let mut app = FlistWalkerApp::new(root.clone(), 50, String::new());
    app.shell.ui.show_preview = false;
    app.shell.indexing.in_progress = false;
    app.shell.indexing.pending_request_id = None;
    app.shell.runtime.entries = Arc::new(vec![
        unknown_entry(first.clone()),
        unknown_entry(second.clone()),
    ]);
    app.shell.runtime.base_results = vec![(first.clone(), 10.0), (second.clone(), 5.0)];
    app.shell.runtime.results = app.shell.runtime.base_results.clone();
    app.shell.runtime.current_row = None;
    app.sync_active_tab_state();

    app.create_new_tab();
    app.switch_to_tab_index(0);

    assert_eq!(app.shell.runtime.current_row, Some(0));
    assert!(app.shell.ui.scroll_to_current);
    let _ = fs::remove_dir_all(&root);
}
