# Changelog

このファイルは Keep a Changelog 形式と SemVer に沿って管理します。

## [Unreleased]
### Added
- なし。

### Changed
- なし。

### Fixed
- なし。

### Breaking
- なし。

### Deprecated
- なし。

### Security
- なし。

### Known issues
- なし。

## [0.27.0] - 2026-09-06
### Added
- TUI に preset の一覧・絞り込み・追加・編集・削除・適用を追加し、非アクティブ資源の回収を bounded にした。
- walker に opt-in の symbolic link / junction 追跡を追加し、許可 root 内へ投影した相対結果と循環・重複防止を GUI / CLI / TUI で共有した。

### Changed
- 検索・index・並び順・highlight の契約を統一し、深さ、FileList、query 履歴、tab 復元をまたぐ結果の一貫性を高めた。
- config 読み込みと preview 生成を bounded worker へ移し、重い I/O や payload 解放が GUI frame を妨げないようにした。
- tab の追加・並べ替え・復元・非アクティブ資源管理と、preset picker/editor の表示・入力・エラー処理を整理した。
- GUI 証跡を一時領域へ限定し、仕様・UX・repository contract・native test fixture の検証を強化した。

### Fixed
- 結果一覧を上下に移動した際、cursor が viewport 端へ張り付いたり見えなくなったりする問題を修正した。
- anchored exact query の空 alternative が全候補へ一致する問題を修正した。
- 小さい画面や session 復元時に control、dialog、window が画面外へ出る問題を修正した。
- tab 末尾の追加ボタン位置、追加直後の詳細・preview 初期化、復元 tab の表示状態を修正した。
- Windows の universal GUI binary 起動時に console window が表示される問題を修正した。
- macOS の application Quit shortcut が tab close と競合する問題を修正した。

### Breaking
- なし。

### Deprecated
- なし。

### Security
- macOS menu 制御に既存 lockfile 内の `objc2` 系 package を直接利用し、license notice と OSS review を同期した。release asset と updater の trust 境界は変更していない。

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。
- v0.24.3 の updater は `fw-*` を含む現在の checksum manifest を読めないため、v0.24.3 利用者は同じ variant の binary と `SHA256SUMS` を手動で取得・検証して一度置き換える必要がある。v0.24.4 以降へ移行後は通常の自動更新を再利用できる。

## [0.26.0] - 2026-09-04
### Added
- リポジトリ変更を決定的に分類・検証する agent workflow と、Validation Matrix に基づく検証支援ツールを追加した。
- tag 作成前に default branch の実物配布 bundle を4 platformで生成し、署名、28 asset、26-entry checksum、N-1 updater互換性を検証できる manual release candidate 経路を追加した。

### Changed
- 復元 tab と非アクティブ tab の index worker、mailbox、結果、選択状態を一体の resource lifecycle として管理し、開始・中断・回収・再開時の所有権と処理量を bounded にした。
- index 応答の arbitration、finalization、state反映を分離し、増分結果、tab切替、session復元が競合してもUI操作を優先できる構成へ整理した。
- stateful endurance、walker性能、非同期検証を決定的な境界と状態条件で判定するよう強化し、host速度に依存する待機条件を除いた。
- AI-first開発フロー、変更前後のreview、`origin/master`起点のbranch作成、docs/SDD/Validation Matrixの運用を文書化した。

### Fixed
- 許可済みroot配下へのsymlink経由の操作を不正に拒否する問題を修正し、正規化後のtargetがroot境界内にある場合だけ実行できるようにした。
- 検索結果のcursor移動がpin focusやpanel描画で失われる問題を修正した。
- cleanup後のindex mailbox再生成、worker喪失、古い応答によるtab engagementの巻き戻りを防止した。
- 一部結果の更新やinactive resource回収後に、選択項目とbackground selectionが復元されない問題を修正した。
- agentの新規変更branchが古いlocal masterを起点にできる問題を防ぎ、`origin/master`との一致を必須にした。

### Breaking
- なし。

### Deprecated
- なし。

### Security
- 依存関係の追加・更新はなく、release candidate経路はread-only権限で動作し、tag push専用の公開jobと分離した。

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。
- v0.24.3 の updater は `fw-*` を含む現在の checksum manifest を読めないため、v0.24.3 利用者は同じ variant の binary と `SHA256SUMS` を手動で取得・検証して一度置き換える必要がある。v0.24.4 以降へ移行後は通常の自動更新を再利用できる。

## [0.25.1] - 2026-09-02
### Added
- なし。

### Changed
- 復元した tab の初回 index を優先し、高スループットの index 処理中も一覧操作の応答性を維持するようにした。
- worker の内部モジュール構成を整理し、index・状態・通信の責務境界を明確にした。
- updater の再起動経路を対応対象へ限定し、更新後の状態復旧と表示診断を安定化した。
- anyhow 1.0.104 と ico 0.5.0 へ更新し、依存ライセンス notice と review 記録を同期した。
- v0.25.0 を直前公開版 updater capability として明示登録し、v0.25.1 の exact manifest を release 前に検証できるようにした。

### Fixed
- 再起動後に更新が成功しているにもかかわらず、誤って updater failure と表示する問題を修正した。
- 対応外 platform で updater restart flag が誤って有効になる問題を修正した。

### Breaking
- なし。

### Deprecated
- なし。

### Security
- updater は従来どおり `SHA256SUMS.sig` の署名検証後に `SHA256SUMS` の checksum を照合する。今回の依存更新に伴う新しい公開 API や権限変更はない。

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。
- v0.24.3 の updater は `fw-*` を含む現在の checksum manifest を読めないため、v0.24.3 利用者は同じ variant の binary と `SHA256SUMS` を手動で取得・検証して一度置き換える必要がある。v0.24.4 以降へ移行後は通常の自動更新を再利用できる。

## [0.25.0] - 2026-08-30
### Added
- GUI のメインパネルから `Presets...` ボタンで検索 preset picker を開けるようにした。既存の `Ctrl+Shift+P`（macOS は `Cmd+Shift+P`）と同じ picker を利用できる。
- GUI/TUI の preset、名前付き root、履歴、overlay、modal を含む application-owned UI へ、設定で有効化された Emacs 風の移動・確定・キャンセル・単一行編集操作を共通適用した。

### Changed
- adaptive walker の候補供給、共有 frontier、open-directory frame、child batch の処理を bounded に整理し、大きな root での初期表示とキャンセル時の応答性を改善した。
- adaptive walker のキャンセル／互換性／release matrix、stateful endurance、GUI staged query smoke の検証を拡充し、キュー境界をまたぐ状態遷移の回帰検証を追加した。
- GUI の modal 分離、macOS 入力、CI compatibility signature、および frontier saturation の決定性を改善した。
- updater の直前公開版 capability として v0.24.5 を明示登録し、v0.25.0 の exact 26-entry checksum manifest との N-1 互換性を release 前に検証できるようにした。

### Fixed
- 自動更新の manifest、signature、checksum、network、activation 失敗時に、候補を消費した状態で手動復旧手順と release URL を案内する専用 failure modal を表示するようにした。

### Breaking
- なし。

### Deprecated
- なし。

### Security
- 依存関係の追加・更新はなく、updater は従来どおり `SHA256SUMS.sig` の署名検証後に `SHA256SUMS` の checksum を照合する。

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。
- v0.24.3 の updater は `fw-*` を含む現在の checksum manifest を読めないため、v0.24.3 利用者は同じ variant の binary と `SHA256SUMS` を手動で取得・検証して一度置き換える必要がある。v0.24.4 以降へ移行後は通常の自動更新を再利用できる。

## [0.24.5] - 2026-08-26
### Added
- GUI の通常検索欄と履歴検索フィルターで、`emacs_keybindings_enabled` と `ctrl_w_deletes_word_in_query` を有効にした場合だけ `Ctrl+W` で直前の単語を削除できる opt-in 設定を追加した。TUI の既存動作と、設定無効時の GUI の tab 終了動作は維持する。

### Changed
- GUI / CLI の history と text editing policy を共有化し、検索入力の挙動と回帰テストの対応を一貫させた。
- インデックス中の tab 切替・再有効化を応答性重視の routing に整理し、CI の変更範囲判定、native clippy、release warning gate を強化した。
- 現行 Rust 実装に不要な内部 surface と、役割を終えた Python prototype を整理・撤去した。
- Linux release packaging の README 生成で Markdown backtick が shell command substitution される warning を修正した。

### Fixed
- インデックス処理中の tab 遷移で、古い worker 応答が現在の状態を巻き戻したり、切替後の更新を遅延させたりする問題を修正した。
- updater の N-1 compatibility checker が未知の公開版能力を version 大小比較で推測せず、未登録 capability や非増加 version を fail closed にするよう修正した。

### Breaking
- なし。

### Deprecated
- なし。

### Security
- updater は従来どおり `SHA256SUMS.sig` の署名検証後に `SHA256SUMS` の checksum を照合する。今回の変更範囲に依存関係の追加・更新はない。

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。
- v0.24.3 の updater は `fw-*` を含む現在の checksum manifest を読めないため、v0.24.3 利用者は同じ variant の binary と `SHA256SUMS` を手動で取得・検証して一度置き換える必要がある。v0.24.4 以降へ移行後は通常の自動更新を再利用できる。

## [0.24.4] - 2026-08-25
### Added
- なし。

### Changed
- GUI / CLI の非同期 worker と tab / session 状態の応答 routing を強化し、古い応答や FileList discovery が現在の操作状態を巻き戻さないようにした。
- updater の transaction、helper 起動、再起動復旧と CI の rollout 検証導線を強化した。

### Fixed
- preset 適用後の検索クエリカーソルが末尾へ移動しない問題を修正した。
- FileList discovery の stale request が後続のインデックス状態へ影響する問題を修正した。
- CLI 専用 `fw` asset を含む checksum manifest を updater が受け入れられない問題を修正した。

### Breaking
- なし。

### Deprecated
- なし。

### Security
- updater は従来どおり `SHA256SUMS.sig` の署名検証後に `SHA256SUMS` の checksum を照合する。今回の変更範囲に依存関係の追加・更新はない。

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.24.3] - 2026-08-23
### Added
- GUI 起動経路を含まない高速な CLI 専用 standalone バイナリ `fw` を追加し、短い一回検索や TUI 起動を簡潔に実行できるようにした。

### Changed
- updater のライフサイクル、helper 起動、再起動復旧、E2E 検証導線を強化し、古い guardian cache や Windows artifact path による誤判定を防ぐようにした。
- CI の updater guardian 運用、署名 manifest 設定、macOS 診断コンパイル、rollout 記録を更新した。

### Fixed
- Windows updater E2E の署名 manifest と artifact 連携が安定して実行されない問題を修正した。
- macOS で updater transaction の診断コードがコンパイルできない問題を修正した。

### Breaking
- なし。

### Deprecated
- なし。

### Security
- updater は従来どおり `SHA256SUMS.sig` の署名検証後に `SHA256SUMS` の checksum を照合する。今回の変更範囲に依存関係の追加・更新はない。

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.24.2] - 2026-08-21
### Added
- 非同期 worker の状態遷移を固定 seed で再生する stateful endurance 検証と、実 worker の scheduled soak 検証を追加した。

### Changed
- tab identity、active owner、request routing を非同期イベントの interleaving 後も維持し、古い応答が別 tab の状態を巻き戻さないようにした。
- FileList/index 完了時の結果件数 settlement と、release/CI の stateful endurance・大規模検索・GUI 証跡の検証導線を強化した。

### Fixed
- index 完了後に表示される結果件数が古い値のまま残る問題を修正した。
- 混在した日本語 preview 文が不自然に分割・表示される問題を修正した。
- Windows self-update の restart failure recovery を bounded retry と旧 bundle の検証付き再起動へ強化した。

### Breaking
- なし。

### Deprecated
- なし。

### Security
- self-update は従来どおり `SHA256SUMS.sig` の署名検証後に `SHA256SUMS` の checksum を照合する。今回の変更範囲に依存関係の追加・更新はない。

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.24.1] - 2026-08-19
### Added
- CI policy guardian の検査スクリプトと unit test を追加し、workflow の権限・runner・action pin・監査設定を検証できるようにした。

### Changed
- 定期 security audit / latest canary が成功へ復帰した際、同じタイトルで GitHub Actions が作成した障害 issue だけを自動クローズするようにした。
- SVG 描画依存を `resvg 0.48.1` へ更新し、保守終了した `rustybuzz` / `ttf-parser` を依存グラフから除去した。
- 復元したタブを選択した際、バックグラウンドの古い要求よりアクティブタブのインデクシングを優先するようにした。

### Fixed
- CI recovery と project quality の運用・検証を強化した。

### Breaking
- なし。

### Deprecated
- なし。

### Security
- `RUSTSEC-2026-0192` / `RUSTSEC-2026-0206` の保守終了警告を、SVG・フォント処理依存の更新によって解消した。

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.24.0] - 2026-08-19
### Added
- GUI の検索 preset picker から現在の検索状態を preset として追加し、選択した preset を確認付きで削除できるようにした。
- GUI / CLI / TUI の検索で `--max-depth N` と同等の最大深度を設定できるようにし、Walker と FileList の候補検索、preset、tab state に反映した。FileList 作成は従来どおり完全走査する。

### Changed
- Windows の updater helper 起動を、verbatim path の失敗時に正規化パスへ再試行できるように整理し、install directory を current directory に強制しないようにした。

### Fixed
- 長い Windows パスや UNC パスで updater helper の起動に失敗するケースと、失敗時のエラーメッセージに verbatim prefix が露出する問題を修正した。

### Breaking
- なし。

### Deprecated
- なし。

### Security
- なし。

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.23.0] - 2026-08-17
### Added
- GUI に `Ctrl+Shift+P`（macOS は `Cmd+Shift+P`）で開く検索 preset picker を追加した。preset 名の fuzzy filter と現在 tab への適用、`F2` / `Edit` からの編集、absolute path の直接入力と folder picker、Named Root の追加・編集・削除、rename時のpreset参照追従、delete時のsnapshot fallbackを提供する。メイン画面への常設 control と副作用 actionは追加しない。

### Changed
- 検索候補projectionとprefix cacheを再利用し、GUI/CLI/TUIの新しい検索要求が古い要求をcancelするようにして、10万件候補のquery-shape性能と最新request優先を強化した。
- 検索性能回帰ゲートをrequired CIからweekly workflowへ移し、required CIの決定性を維持しながら定期性能監視を継続するようにした。
- machine PRのrebase/auto-merge後にlocal feature branchを安全に同期・整理する運用条件を明確化した。
- FileList writeのunit testへ明示的なancestor fixture境界を追加し、CLI integration fixtureをworkspace内へ限定して、coverage実行がユーザーprofileのfilesystem状態へ依存しないようにした。

### Fixed
- macOS以外のbuildでmacOS updater helper codeをコンパイル対象に含めないよう条件を修正した。
- preset pickerのfooterが小さいviewportで切れる問題を修正した。
- presetとNamed Rootの表示・保存時にWindows verbatim path prefixが露出する問題を修正した。
- 同一rootのpreset適用でIgnore Listの切替が検索候補へ反映されず、非同期response後にpreset sortが失われる問題を修正した。preset所有stateをatomic transitionで適用し、tab所有のsort scopeとrequest freshnessを維持する。
- Windows release ZIP内の案内ファイルがflat asset用のversion付き名称になる問題を修正し、archive契約どおり`README.txt`を同梱する。
- Windows release packagingとarchive検証をfresh Windows PowerShell 5.1 processでも実行できるようにした。

### Breaking
- なし。

### Deprecated
- なし。

### Security
- `webbrowser`を1.2.2へ更新し、RUSTSEC-2026-0257の監査失敗を解消した。許容済みのunmaintained transitive warningは`docs/OSS_COMPLIANCE.md`の管理条件を維持する。

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.22.1] - 2026-08-07
### Added
- GUI に、`Help` 操作と F1 から開ける検索構文の案内を追加した。

### Changed
-

### Fixed
- Windows の通常 CLI 起動が呼び出し元コンソールへ接続したまま完了するように修正した。
- Windows の TUI でパス表記を正規化し、表示と選択結果の不整合を修正した。
- GUI の保存済み root ドロップダウンで行全体をクリックして選択できるように修正した。

### Breaking
-

### Deprecated
-

### Security
-

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.22.0] - 2026-08-06
### Added
- CLI / TUI の保存済み root 選択と、`name:`、`path:`、`dir:`、`ext:` によるフィールド指定検索を追加した。

### Changed
- CLI の色付き出力を検索ハイライトと同じ一致範囲に揃えた。
- GUI から検索プリセット操作を削除し、検索画面を簡素化した。

### Fixed
- CLI / TUI の検索で ignore ファイルを適用するよう修正した。
- `ext:` 検索の対象をファイルに限定し、同名拡張子のディレクトリを結果から除外した。

### Breaking
- なし。

### Deprecated
- なし。

### Security
- なし。

### Known issues
- macOS 配布物は未 notarized の場合がある。

## [0.21.0] - 2026-08-04
### Added
- GUI に `Help` 操作と `F1` ショートカットで開けるモーダルのショートカット一覧を追加した。表示中は背景のショートカットを受け付けず、OS の primary modifier と Emacs keybinding 設定を反映する。
- CLI に `--color auto|always|never` を追加した。既定の `auto` は対話端末だけで色を出力し、pipe/redirect の path-only 出力を維持する。

### Changed
- GUI 実装を eframe 0.35 API へ移行し、描画と入力の既存操作契約を維持した。
- GitHub Actions の cache と artifact download action、および Rust の serde 依存を更新し、関連する OSS notice と release/CI 証跡を追従させた。

### Fixed
- `flistwalker --update` をヘッドレス環境で実行した場合に GUI restart mode を要求して失敗する問題を修正した。

### Breaking
- なし。

### Deprecated
- なし。

### Security
- 自己更新の署名・checksum 検証、sidecars-first/binary-last、rollback/recovery の既存保護契約を維持した。

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.20.1] - 2026-08-01
### Added
- なし。

### Changed
- walker、CLI/TUI、GUI 描画、updater transaction の内部責務を owner module 単位へ分割し、検索・更新の主要仕様を維持しながら保守境界を明確化した。利用者が認識できる挙動変更は、下記の不具合修正に限定される。
- updater transaction の marker model、filesystem safety policy、OS process/replacement primitive、回帰テスト、platform-specific な production/test コンパイル境界を分離し、rollback/recovery と marker-v1 の互換契約を独立して検証できるようにした。

### Fixed
- Windows の自己更新で既存ファイルを置換する処理を外部 PowerShell から native `ReplaceFileW` へ切り替え、複数の console window が表示される問題と PowerShell の有無に依存する失敗を解消した。
- Windows updater の verbatim path、backup 有無、置換失敗時の source 保持を回帰テストで固定した。
- GUI の FileList 作成成功通知が、自動再インデックス完了時に消えず、完了内容を確認できるようにした。
- 起動時の更新確認失敗ダイアログを modal 化し、表示中の検索文字入力・選択移動を遮断した。`Return` / `Escape` は選択項目の実行や query の消去を行わず、ダイアログだけを閉じる。

### Breaking
- なし。

### Deprecated
- なし。

### Security
- 署名・checksum 検証、no-overwrite、hash/type 再検証、sidecars-first/binary-last、rollback/recovery の既存 self-update 保護契約を維持した。

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.20.0] - 2026-07-29
### Added
- batch CLI でコマンドを安全に複数実行できるようにし、引数境界を保った実行とエラー表示を提供した。
- CLI と interactive TUI に更新通知を追加した。

### Changed
- TUI のフレーム描画を調整し、入力中の描画応答性を改善した。
- Dependabot の rebase auto-merge と CI policy の検査を強化した。

### Fixed
- なし。

### Breaking
- なし。

### Deprecated
- なし。

### Security
- CI policy の merge command 検査を厳格化し、保護ブランチ運用の迂回を防止した。

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.19.1] - 2026-07-28
### Added
- interactive TUI の runtime shortcut 設定を適用し、Emacs キーバインド時の履歴とヘルプ表示も設定に合わせるようにした。

### Changed
- TUI の walker 初期化を runtime config の adaptive walker 設定へ統一した。
- CI の policy guardian と監査ポリシーを追加し、依存 Action、`regex` 1.13.1、`crossterm` 0.29.0 を更新して release/CI 経路の保護と依存関係を最新化した。

### Fixed
- CLI の early mode より前に runtime config を初期化し、TUI の indexing と応答性を安定化した。
- macOS CI のホスト速度に依存するテストを安定化した。

### Breaking
- なし。

### Deprecated
- なし。

### Security
- trusted-base の CI Policy Guardian が監査対象の workflow policy を検査し、監査を不正に skip する変更を fail-closed で検出する。

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.19.0] - 2026-07-26
### Added
- interactive TUI に保存済みルートの選択・更新、ソート、プレビュー履歴、ヘルプ、現在行への認可済み open/reveal 操作、トランザクション型 FileList 作成を追加した。
- batch CLI に保存済みルート選択、全ソートモード、認可済み open/reveal、トランザクション型 FileList 作成を追加した。

### Changed
- GUI、CLI、TUI で検索結果のソート契約、非同期履歴永続化、FileList 読み書き、クエリ評価を共通化した。
- terminal UI 依存を追加し、関連する OSS notice と CI の性能・キャッシュ耐性を更新した。

### Fixed
- FileList 作成時の panic と、保存済みルート一覧中の進捗表示、fresh walker state を使用しない TUI FileList 作成を修正した。

### Breaking
- なし。

### Deprecated
- なし。

### Security
- query history は既定で平文永続化される。必要なら runtime config の `history_persist_disabled=true` を設定する。
- 自動更新の対象ビルドは埋め込み公開鍵で `SHA256SUMS.sig` を検証し、その後 `SHA256SUMS` の checksum を照合する。

### Known issues
- macOS 配布物は未 notarized の場合がある。

## [0.18.14] - 2026-07-15
### Added
- Preview にファイルサイズ、更新日時、作成日時、ファイル種別、シンボリックリンク情報を表示するようにした。

### Changed
- terminal / link entry の kind resolution と preview routing を整理し、関連する回帰テストを追加した。
- ドキュメントのナビゲーションと構造索引を整理した。
- Unix socket 分類テストの一時パスを短縮し、環境依存の失敗を避けた。

### Fixed
- 検索やタブ切り替えをまたぐ deferred link resolution が結果状態へ正しく反映されるようにした。

### Breaking
-

### Deprecated
-

### Security
- cross-platform CI の `cargo audit` で、文書化済みの accepted advisory だけを継続的に許容するようにし、`quick-xml` / `rustybuzz` / `ttf-parser` の transitive advisory を `docs/OSS_COMPLIANCE.md` で追跡した。

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.18.13] - 2026-07-10
### Added
- タブをピン留めしたときに現在の行へ留まるか、次の行へ選択を移すかを runtime config で選べるようにした。
- 結果一覧をファイルサイズ順でソートできるようにした。フォルダはサイズを持たないため、同順位として名前順で安定化する。

### Changed
- 入力ダイアログと履歴入力まわりの内部モジュール構成を整理し、保守性を改善した。
- adaptive walker のバックグラウンド遷移と worker 状態の変化を含む index 完了処理を整理し、関連する回帰テストを追加した。

### Fixed
- 同じ完全一致トークンを複数回含む検索で、各トークンに対応する出現回数を正しく要求するようにした。
- インデックス作成中にタブを切り替えた場合でも、切り替え前の取り込み済み・保留中エントリとバックグラウンド到着分を統合し、部分的な index で完了扱いにならないようにした。

### Breaking
-

### Deprecated
-

### Security
- `cargo audit` の accepted advisory を release workflow で明示的に扱い、許容済みの transitive warning で配布が停止しないようにした。

### Known issues
-

## [0.18.12] - 2026-06-23
### Added
-

### Changed
- トップパネルの操作部をコンパクトな中央寄せ行にまとめ、ラベルとチェックボックスの視覚的な揃いを改善した。
- `Score` 以外のソートでは inactive tab に結果を保持するようにし、タブ切り替え時の再利用を速くした。

### Fixed
- root 変更、新規タブ作成、background indexing 完了後の total match count を適切に更新し、結果件数表示の stale state を防ぐようにした。

### Breaking
-

### Deprecated
-

### Security
- `cargo audit` で `memmap2` の transitive advisory `RUSTSEC-2026-0186` が 1 件検出されるが、`eframe` / `winit` / `resvg` / `usvg` 由来の許容済み警告として `docs/OSS_COMPLIANCE.md` で追跡している。

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.18.11] - 2026-06-21
### Added
- `docs/INDEX.md` を追加し、README / SDD / release / validation への入口を整理した。
- 検索結果に sort scope と total match counts を表示するようにした。

### Changed
-

### Fixed
- Manage root list の viewport を parent geometry に合わせて中央寄せするようにした。

### Breaking
-

### Deprecated
-

### Security
-

### Known issues
-

## [0.18.10] - 2026-06-13
### Added
- 保存済み root の `Manage list` で選択項目を直接編集し、重複や無効な path を検証して更新できるようにした。
- Windows PowerShell だけで GNU toolchain の依存確認、任意導入、release build、生成物検証を行えるスクリプトと回帰テストを追加した。

### Changed
- 保存済み root の編集開始時に入力欄へ focus して全選択し、削除の確認、`Apply` / `OK` の反映境界を一貫させた。
- tagged release workflow で署名秘密鍵から導出した公開鍵、配布 build の公開鍵、checksum 署名を照合し、期待する asset と license notice を公開前に検証するようにした。
- native folder dialog dependencyを更新し、macOSでfuture-incompatibleな旧Objective-C依存を配布buildから除外した。

### Fixed
- macOS の `/var` と `/private/var`、Windows の短縮 path と長い path など、同一 root の別表記を重複として判定できるようにした。
- クロスプラットフォーム CI で OS 固有 path の前提が混在して失敗する問題と、Windows resource build test の配置に起因する Clippy エラーを修正した。
- 同一 tag の既存 GitHub Release asset を release workflow が上書きできないようにした。
- macOS release buildで自動更新helperの未使用import、未使用field、未使用functionが警告される問題を、対応OSに沿った条件コンパイル境界へ修正した。
- `v0.18.9` release candidateの公開前warning gateで検出した警告を解消し、警告を含むcandidateを公開しない運用を適用した。

### Breaking
-

### Deprecated
-

### Security
- release checksum の署名鍵と配布クライアントの検証鍵が一致しない場合に release を停止し、公開済み tag / asset を不変として扱うようにした。

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.18.9] - 2026-06-13 (unpublished release candidate)
- 公開前warning gateでmacOS release buildの警告を検出したため、このcandidateは公開せず、修正版 `0.18.10` へ置き換えた。

## [0.18.8] - 2026-06-09
### Added
- GUI の保存済み root 操作を `Manage list` に統合し、別ウィンドウで path 直接入力または `Browse...` による追加、チェックボックス選択による削除、`Apply` / `OK` / `Cancel` の draft 反映境界を扱えるようにした。

### Changed
-

### Fixed
- Manage list の下部操作ボタンの表示軸を揃え、hover / active 状態でも 1 つのボタンだけ上下に膨らまないようにした。
- Manage list の保存済み root 更新テストが実ユーザーの saved roots ファイルを書き換えないよう、テスト用保存先を隔離した。
- Browse で存在しない root から開始する場合でも、既存の親ディレクトリへフォールバックしてフォルダ選択を開けるようにした。

### Breaking
-

### Deprecated
-

### Security
-

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.18.7] - 2026-06-07
### Added
- GUI で現在プロセス中に閉じたタブを `Ctrl+Shift+T`（macOS では `Cmd+Shift+T`）で直近順に復元できるようにした。
- 初見の開発者や Agent 向けに `docs/ARCHITECTURE_OVERVIEW.md` を追加し、主要 runtime flow、責務マップ、変更種別ごとの入口を整理した。

### Changed
- SDD / 詳細設計 / テスト計画文書を topic 別ファイルへ分割し、トップレベル文書を entrypoint として使いやすくした。
- `docs/TESTPLAN.md` と Validation Matrix を変更種別別チェックリストとして強化し、docs-only、GUI、indexing、search、release/update、runtime config の検証入口を明確化した。
- TC / VM / SP の表・規範セクションを ID 昇順へ整理し、release preflight skill に ID Ordering gate を追加した。

### Fixed
-

### Breaking
-

### Deprecated
-

### Security
-

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.18.6] - 2026-06-05
### Added
-

### Changed
- runtime config の emacs keybinding toggle を README / SDD 文書へ追記し、設定 UI と既定 config 生成から参照できるようにした。
- release preflight gate を強化し、version・docs・Validation Matrix・OSS notice・asset 名・GUI 証跡・CI/release build warning の確認手順を明確化した。
- 公開向け release 文書から開発・手動試験専用 update override env 名を除去した。

### Fixed
- クエリ入力欄がフォーカスされていない状態でも `Ctrl+V` が Page Down として動作するようにした。
- タブ更新後の action request が blocked 状態に残り、選択項目の実行やオープンが進まない問題を修正した。

### Breaking
-

### Deprecated
-

### Security
-

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.18.5] - 2026-06-03
### Added
-

### Changed
- タブ close ボタンの hover 表示を、タブ色と同系色の背景・細い枠線・カーソル表示へ変更し、close 領域とタブ本体の押下領域を判別しやすくした。
- SDD 文書の trace ID を整理し、重複していた `TC-117` を解消して self-update 無効化のテストIDを `TC-140` に分離した。

### Fixed
- 保存済み window 位置が現在のマルチディスプレイ表示範囲外にある場合、起動時に表示範囲内へ補正するようにした。

### Breaking
-

### Deprecated
-

### Security
-

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.18.4] - 2026-05-24
### Added
- GUI のタブ行右端に設定ボタンを追加し、runtime config を既定のアプリケーションまたはフォールバックのテキストエディタで開けるようにした。

### Changed
- capped walker の `Finished` 受信後は `Indexing...` を先に解除し、残り entry drain と terminal cleanup を内部後処理として継続するようにした。
- active indexing 中の空クエリ・フィルタなし表示で、表示更新のために index entries 全件を `runtime.entries` へ clone しないようにした。
- kind filter 用の unknown path queue 構築で、全 path の中間 `Vec<PathBuf>` を作らず、必要な path だけを直接 queue へ積むようにした。

### Fixed
- 500,000 entries で capped walker が終端した後、`Walker capped...` notice が消える直前に UI が固まる問題を修正した。
- capped walker の後処理で大きな pending entry queue を UI thread 上で同期 shrink していた問題を修正した。
- notice / status line 更新時に OS メモリ使用量を同期サンプリングして UI 操作が重くなりうる問題を修正した。
- `Finished` 後の terminal state 確定で、Ignore List などのフィルタ対象全件を UI thread で再走査していた問題を修正した。

### Breaking
-

### Deprecated
-

### Security
-

### Known issues
-

## [0.18.3] - 2026-05-22
### Added
-

### Changed
- リリースノート作成手順を強化し、前回 tag から対象 tag/HEAD までの git range を一次情報として使うことを明確化した。

### Fixed
- adaptive walker の limit 制御が低速 I/O 環境で過剰に worker 数を増やしうる問題を修正した。
- adaptive walker が高速 I/O 環境で改善余地のある増加探索を早めに止めうる問題を修正し、境界到達時も探索方向を保持するようにした。

### Breaking
-

### Deprecated
-

### Security
-

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.18.2] - 2026-05-21
### Added
-

### Changed
- FileList の読み込みを再利用バッファと大きめの read buffer で高速化し、line-only fast path のオーバーヘッドを下げた。
- FileList indexing で nested FileList が早期に見つかった場合は初回 stream の結果を再利用し、root FileList の二度読みを避けるようにした。
- FileList indexing の batch 境界を調整し、worker から UI へ流す batch overhead を下げた。
- adaptive walker の既定値を docs と揃え、チューニング計測とレビュー反映を通じて worker 上限とキャンセル挙動を再調整した。

### Fixed
- FileList indexing の batch 境界を 1024 件に固定する回帰テストを追加した。
- adaptive walker の review gaps を反映し、backpressure とキャンセル周辺の挙動を安定化した。

### Breaking
-

### Deprecated
-

### Security
-

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.18.1] - 2026-05-20
### Added
-

### Changed
- Walker backend を adaptive のみに整理し、jwalk fallback と `walker_threads` runtime config option を削除した。既存 config に残る `walker_threads` / `developer.walker_backend` は読み込み時に削除される。
- runtime config が未作成または既存 config に一般向け項目が欠けている場合、`walker_max_entries` / `history_persist_disabled` / `restore_tabs_enabled` を既定値で補完するようにした。
- Walker の上限到達 notice を、環境変数ではなく runtime config の `walker_max_entries` を案内する文言へ更新した。

### Fixed
- Indexing 中の status line `Entries` が、UI 反映済み entry と受信済み pending entry の合算を表示するようにした。

### Breaking
- `jwalk` fallback と `walker_threads` runtime config option を削除した。

### Deprecated
-

### Security
-

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.18.0] - 2026-05-20
### Added
- adaptive walker の比較 perf test を GitHub Actions の perf regression workflow に追加し、jwalk との件数・速度比較を CI で継続確認できるようにした。
- リリースノート作成 skill に、前タグから対象タグ/HEAD までの git range を本文ソースにする手順を明記した。

### Changed
- Walker backend の既定を adaptive walker に変更した。暫定 rollback として developer config の `walker_backend = "jwalk"` で jwalk に戻せる。
- `walker_threads` 未指定時の既定値を論理コア数に応じて最大 8、最低 1 にし、adaptive walker の初期 read_dir 上限は最大値の半分から開始するようにした。
- 低コア環境向けに、adaptive walker の worker 上限が 1 の場合は thread pool を作らず serial fast path で走査するようにした。
- adaptive walker の transitional tuning knobs は削除候補であることを docs に明記し、通常運用を `walker_threads` 中心に寄せた。
- release 前チェックに Rust warning / clippy warning / release build log warning が残っていないことを追加した。
- release 前の docs 整理として、古い eframe upgrade note と完了済み large-file reduction plan を削除し、GUI smoke 実績ファイルを report template に置き換えた。

### Fixed
- adaptive walker のキャンセルが走査側で先に検知された場合でも、index worker が `Finished` ではなく `Canceled` として扱うようにした。
- adaptive walker の developer max override が `walker_threads` を迂回しないよう、最大同時 read_dir 数を `walker_threads` 以下に clamp した。
- adaptive walker の producer queue に backpressure を入れ、高 fanout root で consumer 停止後に entry queue が膨らみ続けないようにした。

### Breaking
-

### Deprecated
-

### Security
-

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.17.6] - 2026-05-19
### Added
-

### Changed
- `Set as default` がタブ復元中に無効化される場合の tooltip / notice を、環境変数名ではなく runtime config の Restore tabs 設定を指す表現へ更新した。
- リリース同梱 README と公開文書の runtime config 案内を最新の保存先・`restore_tabs_enabled` / `history_persist_disabled` / walker tuning keys に合わせた。
- developer-only adaptive walker backend の計測と worker 上限調整を追加し、jwalk と比較しながら opt-in で評価できるようにした。

### Fixed
- adaptive walker backend で Windows の Explorer 互換 junction（例: `Documents\My Music` / `My Pictures` / `My Videos`）が候補化される問題を修正した。

### Breaking
-

### Deprecated
-

### Security
-

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.17.5] - 2026-05-14
### Added
-

### Changed
- macOS release build script と release workflow cache を調整し、GitHub-hosted macOS runner の Cargo shim / PATH 差異で release asset build が失敗しないようにした。

### Fixed
- 検索窓フォーカス中の `Ctrl+Shift+C` / `Cmd+Shift+C` が backend で `Event::Copy` に正規化される場合でも、選択中または PIN 済み path をコピーできるようにした。

### Breaking
-

### Deprecated
-

### Security
-

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.17.4] - 2026-05-11
### Added
-

### Changed
- 検索、ソート、インデックス filter 同期の一時 allocation / clone を削減し、大規模候補での CPU・メモリ効率を改善した。
- Windows GNU 開発セットアップ手順を追加し、WSL/Linux からの Windows 向けビルド導線を確認しやすくした。
- CI の cache / coverage artifact / cargo tool reinstall / perf regression cadence を調整し、GitHub Actions 上の安定性を改善した。

### Fixed
- Walker の kind resolution churn を抑え、表示中結果に必要な種別解決へ絞ることで、大規模 root での不要な metadata 処理を減らした。

### Breaking
-

### Deprecated
-

### Security
-

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.17.3] - 2026-04-26
### Added
- GUI visual smoke validation gate と fixture script を追加し、release 前の視覚確認結果を記録できるようにした。

### Changed
- `eframe` / `egui` を `0.34.1` 系へ更新し、paste audit warning に対応した。
- search / indexer / updater / render の境界を分割し、検索評価、FileList 階層処理、self-update release/staging 処理の責務を整理した。

### Fixed
- `!` 除外と ignore list の一致を fuzzy fallback なしの literal / anchor 判定に揃え、想定外の候補除外を防いだ。
- self-update staging の一時ファイル・一時ディレクトリ作成を堅牢化し、既存パスの再利用を拒否するようにした。
- 検索結果更新時のカーソル表示維持と、不要な FileList prompt 表示を修正した。

### Breaking
-

### Deprecated
-

### Security
-

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.17.2] - 2026-04-24
### Added
-

### Changed
- Windows の runtime config / UI state / saved roots / window trace を `%LocalAppData%\\flistwalker\\` へ移し、Linux/macOS は `~/.flistwalker/` に統一した。
- `flistwalker.ignore.txt.example` をバイナリへ埋め込み、sample は起動時にローカル生成するようにした。
- self-update と release packaging から sample asset 依存を外し、配布物を `README.txt` / `LICENSE.txt` / `THIRD_PARTY_NOTICES.txt` に整理した。

### Fixed
- 旧 settings 配置から新しい settings 置き場への移行と、ignore sample の初回導線を両立できるようにした。
- updater の asset 契約から不要になった sample 系の互換コードを削除した。

### Breaking
-

### Deprecated
-

### Security
-

### Known issues
-

## [0.17.1] - 2026-04-23
### Added
- Windows では runtime config / UI state / saved roots / window trace を実行ファイルと同じフォルダへ保存し、旧 home 配置からの自動移行も行うようにした。
- release asset に `flistwalker.ignore.txt.example` のサンプルを追加し、self-update 時も同梱するようにした。

### Changed
- `Ignore List` チェックボックスを `Use Ignore List` に改め、公開文書もこれに合わせて整理した。
- runtime config の自動生成は、環境変数で実際に設定されている項目だけを書き込み、未設定の項目は省略するようにした。

### Fixed
- runtime config の自動生成で、`0` / `false` のような明示的な env 設定を落とさないようにした。
- `Files` / `Folders` の高速経路でも ignore list を確実に適用するようにした。

### Breaking
-

### Deprecated
-

### Security
-

### Known issues
-

## [0.17.0] - 2026-04-22
### Added
- 実行ファイルと同じフォルダに置く `flistwalker.ignore.txt` による検索除外リストを追加し、既定で有効化した。
- 起動時に環境変数から runtime config を seed して `~/.flistwalker_config.json` を自動生成するようにした。

### Changed
- runtime config の公開文書を一般ユーザ向けに整理し、高度な設定項目は案内しないようにした。
- Windows GNU ビルドでの更新確認に `rustls` を使うよう戻し、TLS backend 未設定エラーを回避した。
- Linux の軽量 perf gate を hosted runner のばらつきに合わせて緩和した。
- GitHub Actions の Clippy and Coverage job で `actions/upload-artifact` を Node 24 対応版へ更新した。

### Fixed
- Release 用 README の生成と macOS release packaging の文面崩れを修正した。
- Clippy が嫌う runtime config の初期化パターンを整理した。

### Breaking

### Deprecated

### Security
- 更新アセットは署名付き `SHA256SUMS.sig` と checksum 照合で検証する。

### Known issues
- macOS 配布物は notarization 環境が整うまで未 notarized の場合がある。

## [0.16.1] - 2026-04-06
### Fixed
- オンデマンドファイルを含む巨大なエントリリスト（50万件超）でのIndexingフリーズを修正。`Arc<Vec<Entry>>` に対する O(N) クローンを排除し、メタデータ解決中のUIハングを解消。
- `all_entries` 走査時の不要なパス複製と中間ベクタ生成を削減し、インデックス完了後の後処理を高速化。

## [0.16.0] - 2026-04-02
### Added
- `Entry { path, kind }` domain model を導入し、index/search/app 間の候補表現を統一した。
- structural refactoring 後の GUI smoke test 手順を `docs/TESTPLAN.md` に追加し、別環境での確認結果を記録できるようにした。

### Changed
- `FlistWalkerApp` の責務を段階的に再編し、worker bus、runtime UI state、query/history state、search coordinator、cache/root browser/request-tab routing を専用 state holder へ分離した。
- `index_pipeline` test を機能別の複数 module へ分割し、`ARCHITECTURE.md` / `DESIGN.md` / `TESTPLAN.md` を現行構成へ追従更新した。
- structural refactoring の完了に伴い temporary change plan rule を `AGENTS.md` から削除した。

### Fixed
- incremental search/index path の不要 clone を削減し、`sync_entries_from_incremental` と `apply_entry_filters` の全量再確保を抑制した。
- `SearchCoordinator`、cache state、launch seed/bootstrap bag の field 直書きを減らし、request lifecycle と初期化経路の局所性を改善した。
- `cargo clippy --all-targets -- -D warnings` と `cargo doc --no-deps` が通るように state accessor と bootstrap 型を整理した。

### Breaking
- 

### Deprecated
- 

### Security
- structural refactoring 後も self-update の sidecar 文書、署名検証、checksum 検証まわりの手動確認経路を維持し、GUI smoke 手順へ記録した。
- macOS 配布物は当面未 notarized のまま publish する場合がある。

### Known issues
- macOS の自動更新は未対応で、GitHub Releases からの手動更新が必要。
- macOS 配布物は未 notarized の場合がある。

## [0.15.0] - 2026-04-01
### Added
- tagged release 前に Linux / macOS / Windows native で `cargo test --locked` と `cargo audit` を実行する preflight gate を追加した。
- 通常 CI に Windows native runner を追加し、Windows 固有分岐の回帰を早めに検出できるようにした。
- `main.rs` の root viewport 構築を helper 化し、起動 geometry / icon / app_id の回帰を test で固定した。

### Changed
- `app.rs` の責務を段階的に分離し、tab lifecycle、pipeline、cache、search/index coordinator、session/state helper を専用 module へ移した。
- `eframe` / `egui` を `0.29.1` 系へ更新し、`run_native`、text cursor、IME、widget API の追従を行った。
- `EFRAME-UPGRADE-NOTES`、architecture 関連 docs、OSS compliance 運用メモを現在の構成に合わせて更新した。

### Fixed
- CLI の `--limit` に暗黙で入っていた 1000 件上限を撤廃した。
- Results 行の描画と hitbox のずれで、表示がセンタリングされクリックが効きにくくなる回帰を修正した。
- 日本語 IME の確定文字が消える問題と、変換中 Space が半角スペースとして混入する問題を修正した。

### Breaking
- 

### Deprecated
- 

### Security
- release 前 gate を workflow に追加し、tag push から draft release 作成までの導線で未検証 build が通らないようにした。
- 依存更新に合わせて `THIRD_PARTY_NOTICES.txt` を更新し、OSS compliance チェック運用を docs に明文化した。
- macOS 配布物は当面未 notarized のまま publish する場合がある。

### Known issues
- macOS の自動更新は未対応で、GitHub Releases からの手動更新が必要。
- macOS 配布物は未 notarized の場合がある。

## [0.14.0] - 2026-03-31
### Added
- タブごとに accent color を設定できるようにし、active / inactive で見分けやすい表示を追加した。
- regex モードでも plain token と plain OR token は引き続き fuzzy 条件で一致するようにした。
- 起動時更新確認失敗を、ネットワークや feed の問題を調べやすい専用ダイアログで確認できるようにした。
- 起動時更新確認失敗ダイアログを強制表示する内部検証用フラグ `FLISTWALKER_FORCE_UPDATE_CHECK_FAILURE` を追加した。

### Changed
- 非空 query の結果一覧描画を可視行中心に絞り、検索入力中やカーソル移動時の UI 応答性を改善した。
- 起動時更新確認失敗ダイアログの文言を一般ユーザ向けに見直し、`Details` セクションで内部エラーを分けて表示するようにした。

### Fixed
- 検索窓で query が入っている状態でも、左右カーソル移動や Backspace が重くなりやすい問題を改善した。
- 起動時の自己更新チェックが失敗したとき、何も表示されず原因が分からないままになる問題を修正した。

### Breaking
- 

### Deprecated
- 

### Security
- 自己更新の起動時確認失敗も可視化し、ネットワーク・feed・asset 不整合の切り分けをしやすくした。
- macOS 配布物は当面未 notarized のまま publish する場合がある。

### Known issues
- macOS の自動更新は未対応で、GitHub Releases からの手動更新が必要。
- macOS 配布物は未 notarized の場合がある。

## [0.13.4] - 2026-03-30
### Added
- 実行バイナリと同じディレクトリに `FLISTWALKER_DISABLE_SELF_UPDATE` ファイルがある場合も、自己更新を無効化できるようにした。

### Changed
- `FileList` / Walker の初期インデクシング経路を見直し、Windows と WSL をまたぐ運用でも高速経路を優先するようにした。
- `Create File List` 完了後の再読み込みは、そのまま現在タブを使って進めるようにした。
- 自己更新は standalone バイナリだけでなく、対応する `LICENSE.txt` と `THIRD_PARTY_NOTICES.txt` も同じディレクトリへ配置するようにした。

### Fixed
- `Create File List` 完了後のバックグラウンド再インデックスで worker 送信に失敗した場合、タブが進行中表示のまま残る問題を修正した。

### Breaking
- 

### Deprecated
- 

### Security
- standalone バイナリ配布に対応する `LICENSE` / `THIRD_PARTY_NOTICES` sidecar asset を自己更新でも追従配置するようにした。
- `THIRD_PARTY_NOTICES.txt` に自己更新関連依存の notice 反映漏れを補完した。

### Known issues
- macOS の自動更新は未対応で、GitHub Releases からの手動更新が必要。

## [0.13.3] - 2026-03-29
### Added
- 更新署名用の鍵ペアを生成する `generate_update_keypair` helper を追加した。

### Changed
- Windows の一般 `.ps1` は既定で直接実行せず、既定アプリでオープンするようにした。
- 自己更新の release packaging と GitHub Actions workflow で `SHA256SUMS.sig` を生成・添付するようにした。
- 自動更新対象ビルドは埋め込み公開鍵の有無で auto/manual-only を切り替えるようにした。

### Fixed
- `FileList` の Windows 形式相対パスを、実行環境に存在する候補を優先して解釈するようにし、Linux/macOS での誤解釈を防いだ。

### Breaking
- 

### Deprecated
- 

### Security
- 自己更新は `SHA256SUMS.sig` の署名検証と `SHA256SUMS` の checksum 検証を通過した asset のみ適用するようにした。
- 一般ファイル操作で選択した `.ps1` に `ExecutionPolicy Bypass` を使わないようにした。

### Known issues
- macOS の自動更新は未対応で、GitHub Releases からの手動更新が必要。

## [0.13.2] - 2026-03-29
### Added
- Create File List の保留中および実行中に、GUI から明示的にキャンセルできるようにした。
- フッター右端に現在の version を常時表示するようにした。

### Changed
- Create File List 実行中の status panel は、長い path や notice が表示されても右端の version 表示と干渉しないレイアウトにした。

### Fixed
- 自己更新ダイアログで `Download and Restart` を複数回押しても、重複した更新 request を送らないようにした。
- `FileList.txt` と UI state / saved roots の保存を atomic write にし、途中中断で既存ファイルを失いにくくした。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- macOS の自動更新は未対応で、GitHub Releases からの手動更新が必要。

## [0.13.1] - 2026-03-29
### Added
- CLI で `--version` / `-V` により現在の version を表示できるようにした。
- `FLISTWALKER_DISABLE_SELF_UPDATE=1` を追加し、起動時の更新確認と更新適用を明示的に無効化できるようにした。

### Changed
- 自己更新の無効化フラグが有効な場合は、GUI 起動時の update request を送らず、updater 側でも更新処理を開始しないようにした。

### Fixed
- 

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- macOS の自動更新は未対応で、GitHub Releases からの手動更新が必要。

## [0.13.0] - 2026-03-28
### Added
- 起動時に GitHub Releases を確認し、新しい version があれば自己更新ダイアログを表示するようにした。
- Windows 向けに、same-version / downgrade / custom feed を安全に試せる PowerShell の手動検証スクリプトを追加した。

### Changed
- 更新ダイアログに `Don't show again until the next version` を追加し、抑止した target version は次の version が出るまで再表示しないようにした。
- 起動時の更新確認は UI を block せず、Windows/Linux は staged update 後に再起動、macOS は手動更新案内のみとする運用にした。

### Fixed
- Shift+Double Click で Shift+Enter と同じく親フォルダを開けるようにした。
- 起動時にネットワークがオフラインでも、更新確認失敗をエラー表示せず通常どおり起動・操作できるようにした。

### Breaking
- 

### Deprecated
- 

### Security
- ダウンロードした更新 asset は `SHA256SUMS` と照合した場合のみ適用し、配布 notice へ追加依存のライセンス情報を反映した。

### Known issues
- macOS の自動更新は未対応で、GitHub Releases からの手動更新が必要。

## [0.12.3] - 2026-03-28
### Added
- 

### Changed
- Windows のファイル/フォルダ Action 通知と失敗通知で、表示上は `\\?\` / `\\?\UNC\` を除去し、ユーザ向けパス表示を読みやすくした。

### Fixed
- Windows で Action フッタや `Action failed:` 通知に `\\?\` が表示される問題を修正した。
- Windows で `&` などの特殊記号を含むパスを開く・親フォルダを開く際に、`cmd /C start` 経由のシェル解釈で失敗しうる問題を修正した。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- 

## [0.12.2] - 2026-03-27
### Added
- 

### Changed
- 空白区切りの通常検索 token は、subsequence だけで一致する候補よりもリテラル一致する候補を高く順位付けするようにした。

### Fixed
- 空白区切り query で、各 token のリテラル一致が十分に順位へ反映されず、意図した候補が上位に出にくい問題を改善した。
- Windows で `\\?\` / `\\?\UNC\` 付きパスを扱う場合、Result 表示の相対パスと検索対象の相対化規約がずれて、見えていない絶対パス側の文字でヒットしうる問題を改善した。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- 

## [0.12.1] - 2026-03-26
### Added
- Results の属性表示に `LINK` を追加し、シンボリックリンクと Windows ショートカット（`.lnk`）を判別できるようにした。

### Changed
- CHANGELOG の欠落していた過去リリース記録を補完し、版履歴を参照しやすくした。

### Fixed
- 

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- 

## [0.12.0] - 2026-03-24
### Added
- 

### Changed
- 検索クエリを要求単位で前処理し、候補ごとの path 文字列化と正規化の重複を減らした。
- 大規模候補集合では検索 worker 内で並列評価を行い、表示用ランキングは partial top-N 抽出へ切り替えて、数十万件規模でも検索応答を改善した。
- 非アクティブタブは `results` と preview の表示キャッシュを compact し、再表示時は `base_results` から復元するようにした。

### Fixed
- 数十万件規模の結果集合で、全件ソートと重複正規化がボトルネックになって検索が遅くなる問題を改善した。
- 重いタブを複数開いたまま運用すると、非アクティブタブの結果表示キャッシュが残り続けてメモリを圧迫しやすい問題を改善した。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- 

## [0.11.6] - 2026-03-21
### Added
- GUI の検索オプションに `Ignore Case` チェックボックスを追加し、既定で有効にした。

### Changed
- 検索結果とハイライトで共有クエリ解釈を使うようにし、`'` / `!` / `^` / `$` / `|` の挙動を一致させた。
- 検索結果更新時は current row を行番号ベースで維持し、結果数が減った場合のみ末尾へ丸めるようにした。
- GUI 起動直後および `Esc` / `Ctrl+G` の検索キャンセル後は、候補が存在する場合に 1 行目を既定選択にした。

### Fixed
- 検索窓がインアクティブなときに `Home` / `End` / `PageUp` / `PageDown` で結果一覧を操作できるようにした。
- 検索結果の再適用でカーソルが勝手に先頭へ飛ばず、保持できる場合は同じ行番号を維持するようにした。
- 検索欄フォーカス中でも `Esc` / `Ctrl+G` のキャンセル後に結果一覧へ戻り、カーソルが消えないようにした。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- 

## [0.11.5] - 2026-03-19
### Added
- `Ctrl+1` から `Ctrl+9` で左から対応するタブへ直接切り替えられるようにした。

### Changed
- `Ctrl+Tab` / `Ctrl+Shift+Tab` のタブ切り替えをブラウザ系アプリと同じ操作系にそろえ、macOS でも `Ctrl` 系ショートカットとして扱うようにした。
- README のショートカット説明を実装に合わせて更新した。

### Fixed
- 検索欄と履歴検索欄へ複数行テキストを貼り付けたときに、改行や不可視の書式文字がそのまま残って検索しづらくなる問題を修正した。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- 

## [0.11.4] - 2026-03-18
### Added
- 

### Changed
- 

### Fixed
- タブドラッグ移動の追加後に、通常のマウスクリックでタブ切り替えできなくなっていた問題を修正した。
- 結果ソートのプルダウンで `Modified` / `Created` 項目が折り返されて 2 行表示になる問題を修正した。
- worker shutdown 時に `sort-metadata` request channel の切り離しが漏れ、終了時に timeout しやすい問題を修正した。
- macOS で `Preview` 表示設定がアプリ再起動後に引き継がれない問題を修正した。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- 

## [0.11.3] - 2026-03-17
### Added
- 

### Changed
- Windows GNU release profile と post-build strip を追加し、配布 EXE サイズを縮小した。

### Fixed
- Windows GNU ビルドで生成した EXE に複数サイズのアイコンを埋め込み、Explorer / タスクバー / 通知領域で `flist-walker` のアイコンが汎用アイコンへ化ける問題を修正した。
- `Create File List` 系の確認ダイアログ表示中に、十字キーや `Enter` / `Space` がメインウィンドウへ漏れてしまう問題を修正した。
- GUI 終了時に worker shutdown timeout まで待たされ、close 操作が重くなる問題を修正した。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- 

## [0.11.2] - 2026-03-17
### Added
- 

### Changed
- 

### Fixed
- Windows GNU ビルドで生成した EXE に複数サイズのアイコンを埋め込み、Explorer / タスクバー / 通知領域で `flist-walker` のアイコンが汎用アイコンへ化ける問題を修正した。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- 

## [0.11.1] - 2026-03-16
### Added
- タブをドラッグアンドドロップで並べ替えられるようにした。
- release asset と standalone バイナリに `THIRD_PARTY_NOTICES` を同梱するようにした。

### Changed
- Windows 向けクロスビルドを `x86_64-pc-windows-gnu` + mingw-w64 ベースへ移行した。

### Fixed
- 結果ソートのラベル位置を調整し、selector と縦位置がずれる問題を修正した。
- Linux/WSL 上で Windows 向け EXE 名の大文字小文字差異によりビルド後処理が失敗する問題を修正した。
- CI matrix job で bash shell 解決が不安定になる問題を修正した。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- Linux など `created()` を取得できない環境では、`Created` ソート時に該当項目は末尾へ並ぶ。
- macOS 配布物は publish 前に notarization 確認が必要。

## [0.11.0] - 2026-03-14
### Added
- 結果ペインに `Score` / `Name` / `Modified` / `Created` のソートを追加した。
- `Modified` / `Created` ソート用に、検索結果だけを対象にした非同期属性取得と上限付きキャッシュを追加した。
- `FLISTWALKER_DISABLE_HISTORY_PERSIST=1` により、query history 永続化を明示的に無効化できるようにした。

### Changed
- ソート適用後もカーソルは同じアイテムへ追従せず、同じ行番号に留まるようにした。
- `Create File List` で祖先 FileList への追記がありうる場合は、事前確認を必須にした。

### Fixed
- Windows/macOS CI で共通に落ちていたアクション要求キュー投入テストの不安定要因を修正した。
- `cargo audit` で検出された `idna 0.4.0` 依存を解消し、CI が通らない問題を修正した。
- GitHub Actions の release asset 集約が macOS `.app` bundle 内部の `FlistWalker` / `Info.plist` / `FlistWalker.icns` まで拾ってしまう問題を修正した。
- query history の履歴検索アクションと default root 起動順の不整合を修正した。

### Breaking
- 

### Deprecated
- 

### Security
- `FileList.txt` に root 外パスが含まれていても、実行/オープン直前に現在 root 配下かを検証し、root 外アクションを拒否するようにした。
- 通常 CI に Linux と `cargo audit` を追加し、release 対象 OS と依存脆弱性を継続検証するようにした。
- query history は既定で平文永続化されるため、必要に応じて `FLISTWALKER_DISABLE_HISTORY_PERSIST=1` を利用する運用を明示した。

### Known issues
- Linux など `created()` を取得できない環境では、`Created` ソート時に該当項目は末尾へ並ぶ。
- macOS 配布物は publish 前に notarization 確認が必要。

## [0.10.3] - 2026-03-09
### Added
- 

### Changed
- 

### Fixed
- Windows の 8.3 短縮パスと macOS の `/private` パス差分により cross-platform test が不安定になる問題を修正した。
- query history の UI state 永続化テストが共有保存先へ依存し、並列実行時に干渉して失敗する問題を修正した。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- 

## [0.10.2] - 2026-03-09
### Added
- 

### Changed
- 

### Fixed
- release 用 `README` 生成時に shell literal が展開され、PowerShell 環境変数例や `Set as default` 表記が崩れる問題を修正した。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- notarization 前の macOS アプリは Gatekeeper 警告の対象になる場合がある。

## [0.10.1] - 2026-03-09
### Added
- `Create File List` 実行時に、子 `FileList` 参照を祖先 `FileList` へ伝搬して追記できるようにした。

### Changed
- draft release 公開前の preflight 手順と、タブ復元を含む release 運用ドキュメントを更新した。

### Fixed
- OneDrive など Cloud Files API の placeholder を provider 横断で検出し、プレビュー読み込み対象から除外するようにした。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- notarization 前の macOS アプリは Gatekeeper 警告の対象になる場合がある。

## [0.10.0] - 2026-03-07
### Added
- 

### Changed
- `Esc` を `Ctrl+G` と同じ clear/cancel 操作へ統一し、`Ctrl+Shift+R` を廃止した。
- `Ctrl+R` を query history のファジー検索へ変更し、同じ検索欄で履歴検索中とわかる表示および `Enter` / `Ctrl+J` / `Ctrl+M` による展開を追加した。
- query history を全タブ共通で最大100件まで永続化するようにした。

### Fixed
- 

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- notarization 前の macOS アプリは Gatekeeper 警告の対象になる場合がある。

## [0.9.2] - 2026-03-07
### Added
- 

### Changed
- 

### Fixed
- GitHub Actions の macOS release build に、サポート対象の Intel runner を使うように修正した。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- notarization 前の macOS アプリは Gatekeeper 警告の対象になる場合がある。

## [0.9.1] - 2026-03-07
### Added
- tag push を契機に Linux / Windows / macOS 向け asset をビルドし、draft release まで自動作成する workflow を追加した。
- open/execute 実行中は、フッターに spinner と進捗ラベルを表示するようにした。

### Changed
- リリース asset 方針と draft release 運用を、GitHub Actions ベースのフローへ更新した。

### Fixed
- 前回起動時に使っていた root を UI state へ保持し、更新後の再起動でも startup root が意図せず初期化されないようにした。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- notarization 前の macOS アプリは Gatekeeper 警告の対象になる場合がある。

## [0.9.0] - 2026-03-07
### Added
- macOS 向けショートカット差分を整理し、`Cmd+T` / `Cmd+W` / `Cmd+Tab` 系と `Cmd+Shift+C` を主要操作として揃えた。
- タブ単位の検索履歴を追加し、`Ctrl+R` / `Ctrl+Shift+R` で前後移動できるようにした。
- `FLISTWALKER_RESTORE_TABS=1` による opt-in のタブセッション復元を追加した。
- macOS 向け `.app` / zip / tar.gz のリリースアセット生成スクリプトを追加した。

### Changed
- `rust/src/app.rs` を `tests` / `workers` / `session` / `input` / `render` に段階分割し、責務境界を明確化した。
- `Shift+Enter` の格納フォルダオープンは同一フォルダを重複起動しない挙動に統一した。
- README とリリース導線を Windows/macOS 両対応前提へ更新した。

### Fixed
- index/search/preview/action の並行処理を hardening し、古い応答で UI 状態が巻き戻る経路を抑制した。
- worker shutdown と join timeout を見直し、終了時のハングや stale request の取り残しを抑えた。
- incremental query narrowing 用の prefix candidate cache を追加し、絞り込み中の検索応答を改善した。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- notarization 前の macOS アプリは Gatekeeper 警告の対象になる場合がある。

## [0.8.0] - 2026-03-04
### Added
- 

### Changed
- 階層 FileList 展開の判定を「全ディレクトリ探索」から「読み込み済み候補内の `FileList.txt` / `filelist.txt` 完全一致検出」へ変更。
- 階層 FileList 展開の処理キューを浅い階層優先の優先度キューへ変更し、多数のネスト FileList での探索効率を改善。

### Fixed
- 階層 FileList 展開中の子 FileList 解析でも supersede による中断が効くように修正。
- FileList ストリーミング時の不要な全件保持を減らし、メモリ圧迫に起因する体感遅延を抑制。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- macOS アセットは未提供。

## [0.7.2] - 2026-03-04
### Added
- 

### Changed
- 

### Fixed
- `Use FileList` 有効時でも、実際のソースが Walker fallback の場合は `FileList` OFF 時と同じ操作系で扱うようにした。
- ファイル/フォルダの open/execute を UI スレッド外の worker へ移し、遅い I/O で画面が固まる問題を修正した。
- Preview 境界ドラッグ中に Results 一覧が巻き込まれてスクロールしてしまう問題を修正した。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- notarization 前の macOS アプリは Gatekeeper 警告の対象になる場合がある。

## [0.7.1] - 2026-03-04
### Added
- 

### Changed
- 

### Fixed
- GUI ワーカーに shutdown フラグ共有と `Drop` 時の `join` を追加し、中断時の終了処理を明示化。
- `Ctrl+C` などのシグナル受信で shutdown 要求を立て、GUI 側で window close へ収束させる終了経路を追加。
- walker インデックスのキャンセル確認間隔を短縮し、多数エントリ走査中の中断反映を改善。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- macOS アセットは未提供。

## [0.7.0] - 2026-03-03
### Added
- 

### Changed
- `Files` / `Folders` 切り替え時は、現在のトグル状態（include flags）で再インデックスする動作へ変更。
- `Use FileList` 有効時の `Create File List` は、FileList 優先フローの整合性を維持する実行順へ調整。

### Fixed
- Root 変更時にタブタイトルが即時追従しない問題を修正し、メモリ表示の定期更新も安定化。
- ウィンドウリサイズ時に Preview 幅が意図せず変わる問題を修正。
- 検索窓フォーカス系ショートカットと Tab 操作の回帰を修正。
- `Use FileList` 利用中に `Files` / `Folders` フィルタを操作できてしまう不整合を解消（無効化）。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- macOS アセットは未提供。

## [0.6.0] - 2026-03-02
### Added
- ステータスバーにプロセスのメモリ使用量表示を追加した。

### Changed
- walker を並列走査するようにし、大規模ツリーの探索スループットを改善した。
- `FileList` I/O 削減、path kind 判定の遅延、preview cache の総バイト上限化、タブ間の重複データ削減でメモリ使用量を抑制した。
- walker cap と調整用環境変数を引き上げ、チューニング方針を見直した。

### Fixed
- アクティブタブ状態の毎フレーム clone や一時バッファ肥大化に起因する無駄な負荷を減らした。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- macOS アセットは未提供。

## [0.5.1] - 2026-02-27
### Added
- タブタイトル上でのマウス中クリックによるタブクローズ操作を追加。

### Changed
- 

### Fixed
- OR 条件（`|`）で左右それぞれに `'` を付けたクエリ（例: `'abc|xyz`, `abc|'xyz`, `'abc|'xyz`）を検索仕様どおりに評価するよう修正。
- 上記クエリで左辺/右辺に `'` を付けた場合に、可視判定とハイライト表示が崩れる問題を修正。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- macOS アセットは未提供。

## [0.5.0] - 2026-02-28
### Added
- 検索クエリ入力欄に OR 条件（`|`）のヒントをマウスポインタ位置へ表示するツールチップを追加した。
- Results 一覧で OR 条件ごとのハイライト表示に対応した。

### Changed
- `Use FileList` 有効時は、FileList のストリーミング読み込みを優先しつつ、パス種別判定を遅延する方式へ変更した。

### Fixed
- Preview 非表示時に不要なプレビュー I/O を行わないようにした。
- 検索欄フォーカス中でも `Ctrl+N` / `Ctrl+P` / `Ctrl+Shift+C` / `Ctrl+G` を使えるように再調整した。
- `Tab` / `Shift+Tab` のピン操作と、タブ単位の index/search スケジューリングを安定化した。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- macOS アセットは未提供。

## [0.4.0] - 2026-02-25
### Added
- 

### Changed
- 

### Fixed
- 日本語 IME の通常入力モードと日本語入力モードの両方で、Space 入力が安定して通るように修正した。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- macOS アセットは未提供。

## [0.3.3] - 2026-02-25
### Added
- 

### Changed
- デバッグトレースは既定で無効化し、必要時のみ有効化する運用へ変更した。

### Fixed
- インデクシング中のストリーミング更新を安定化し、大規模候補での待ち時間を短縮した。
- IME 入力とウィンドウ操作が競合したときに、入力やフォーカス挙動が不安定になる問題を修正した。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- macOS アセットは未提供。

## [0.3.2] - 2026-02-24
### Added
- 

### Changed
- 

### Fixed
- ライトテーマ時に Results の非ハイライト文字色が薄すぎる問題を修正し、可読性を改善。
- 大規模 FileList 読み込みで `Source: None` 表示が長時間残り、再読込反映が遅延しやすい問題を修正（ストリーミング解析 + supersede 中断対応）。
- `Create File List` は一時ファイルをローカル temp に生成してから最終配置へ移動する方式に変更（クロスデバイスは copy フォールバック）。
- 検索窓フォーカス中の `Ctrl+Shift+C` で検索文字列が優先コピーされる回帰を再修正（後段でパスコピー実行）。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- macOS アセットは未提供。

## [0.3.1] - 2026-02-23
### Added
- 

### Changed
- 

### Fixed
- Preview の内容が長い場合でも Preview 領域外へ描画がはみ出さないように修正し、フッター（`Entries` / `Results`）表示が隠れないよう改善。
- `Copy Path(s)` 実行時のフッター通知 `Copied path:` から Windows 拡張パス接頭辞（`\\?\`）を除去。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- macOS アセットは未提供。

## [0.3.0] - 2026-02-20
### Added
- Root 行に `Set as default` を追加し、次回起動時の既定 Root を保存・適用。
- 既存 `FileList.txt` / `filelist.txt` がある場合の上書き確認ダイアログを追加。

### Changed
- ウィンドウ位置/サイズ、Results/Preview 分割幅、Preview 表示状態を永続化。
- `Create File List` は再 Walker を行わず、最新インデックス結果を再利用する方式へ変更。
- インデックス中の `Create File List` は完了後に遅延実行する動作へ変更。
- 結果行の自動スクロールを「可視範囲外になった時のみ追従」に調整。
- 複数トークン検索時、各トークンの完全一致候補を優先しやすいスコアリングへ調整。

### Fixed
- `Entries` 表示が Root 変更/Refresh Index 後に古い件数を保持する問題を修正。
- `Ctrl+L` の検索窓フォーカス動作をトグル化。
- 検索窓フォーカス中の `Ctrl+Shift+C` で検索文字列がコピーされる問題を修正（Results パスのみコピー）。
- 全角入力時に Space/Shift+Space が効かない問題を修正（半角スペース挿入）。
- FileList 作成中に Root 変更が発生しても UI 状態を巻き戻さないよう安定化。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- macOS アセットは未提供。

## [0.2.1] - 2026-02-19
### Added
- 結果一覧で `Ctrl+V` / `Alt+V` によるページ移動を追加。
- `FileList` のパス解釈を拡張し、バックスラッシュ相対パス・引用符付き行・Windows絶対パス（WSL変換含む）を許容。

### Changed
- `Use FileList` の初期値を OFF に変更。
- `Files` / `Folders` は再インデックスではなく表示フィルタとして即時反映する動作へ変更。
- リリースzip同梱の実行ファイル名を `flistwalker.exe` に変更。
- リリースzip同梱 `README.txt` を拡充（操作手順・検索演算子・ショートカット・オプション説明）。

### Fixed
- インデクシング中にオプション切替すると `Source: None` 固定や更新停止が起きる問題を修正（旧リクエストの中断制御を追加）。
- インデクシング中のスクロール位置が先頭へ戻る問題を修正。
- オンデマンドファイルに対する無駄なプレビュー読み込みを抑止。
- `Tab` 複数選択時に検索窓とボタン間でフォーカスが不安定に移動する問題を緩和。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- macOS アセットは未提供。

## [0.2.0] - 2026-02-18
### Added
- FileList 作成フローの状態遷移テスト（成功/失敗/再インデックス）を追加。
- CLI 契約テストを拡張（スコア付き出力、0件、不正 root）。

### Changed
- インデックス中の逐次表示方針を改善し、空クエリ時は即時反映、非空クエリ時は時間窓で間引き反映する方式に更新。
- 正規表現検索はクエリ単位で事前コンパイルして再利用。

### Fixed
- Windows で `.ps1` を選択した際に実行されない問題を修正（PowerShell 明示起動）。
- 無効な正規表現が「0件ヒット」に見える問題を修正し、GUI notice へ検索エラーを表示。
- 起動直後/Root 変更直後に結果が一瞬表示後に消える不具合を修正。
- プレビューキャッシュの上限未設定によるメモリ増加リスクを修正（FIFO 上限）。

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- macOS アセットは未提供。

## [0.1.0] - 2026-02-17
### Added
- 初回公開。
- Windows 向けに `exe単体 + zip` を提供。

### Changed
- Rust 版をメイン実装として整理。

### Fixed
- 

### Breaking
- 

### Deprecated
- 

### Security
- 

### Known issues
- macOS アセットは未提供。

[Unreleased]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.27.0...HEAD
[0.27.0]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.26.0...v0.27.0
[0.26.0]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.25.1...v0.26.0
[0.25.1]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.25.0...v0.25.1
[0.25.0]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.24.5...v0.25.0
[0.24.5]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.24.4...v0.24.5
[0.24.4]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.24.3...v0.24.4
[0.24.3]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.24.2...v0.24.3
[0.24.2]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.24.1...v0.24.2
[0.24.1]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.24.0...v0.24.1
[0.24.0]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.23.0...v0.24.0
[0.23.0]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.22.1...v0.23.0
[0.22.1]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.22.0...v0.22.1
[0.22.0]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.21.0...v0.22.0
[0.21.0]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.20.1...v0.21.0
[0.20.1]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.20.0...v0.20.1
[0.20.0]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.19.1...v0.20.0
[0.19.1]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.19.0...v0.19.1
[0.19.0]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.18.14...v0.19.0
[0.18.14]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.18.13...v0.18.14
[0.18.13]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.18.12...v0.18.13
[0.18.12]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.18.11...v0.18.12
[0.18.11]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.18.10...v0.18.11
[0.18.10]: https://github.com/ShinjiKawamura255/flist-walker/compare/v0.18.9...v0.18.10
[0.18.9]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.18.9
[0.18.8]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.18.8
[0.18.7]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.18.7
[0.18.6]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.18.6
[0.18.5]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.18.5
[0.18.4]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.18.4
[0.18.3]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.18.3
[0.18.2]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.18.2
[0.18.1]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.18.1
[0.18.0]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.18.0
[0.17.6]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.17.6
[0.17.5]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.17.5
[0.17.4]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.17.4
[0.17.3]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.17.3
[0.17.2]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.17.2
[0.17.1]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.17.1
[0.17.0]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.17.0
[0.16.1]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.16.1
[0.16.0]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.16.0
[0.15.0]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.15.0
[0.14.0]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.14.0
[0.13.4]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.13.4
[0.13.3]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.13.3
[0.13.2]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.13.2
[0.13.1]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.13.1
[0.13.0]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.13.0
[0.12.3]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.12.3
[0.12.2]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.12.2
[0.12.1]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.12.1
[0.12.0]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.12.0
[0.11.6]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.11.6
[0.11.5]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.11.5
[0.11.4]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.11.4
[0.11.3]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.11.3
[0.11.2]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.11.2
[0.11.1]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.11.1
[0.11.0]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.11.0
[0.10.3]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.10.3
[0.10.2]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.10.2
[0.10.1]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.10.1
[0.10.0]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.10.0
[0.9.2]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.9.2
[0.9.1]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.9.1
[0.9.0]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.9.0
[0.8.0]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.8.0
[0.7.2]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.7.2
[0.7.1]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.7.1
[0.7.0]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.7.0
[0.6.0]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.6.0
[0.5.1]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.5.1
[0.5.0]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.5.0
[0.4.0]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.4.0
[0.3.3]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.3.3
[0.3.2]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.3.2
[0.3.1]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.3.1
[0.3.0]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.3.0
[0.2.1]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.2.1
[0.2.0]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.2.0
[0.1.0]: https://github.com/ShinjiKawamura255/flist-walker/releases/tag/v0.1.0
