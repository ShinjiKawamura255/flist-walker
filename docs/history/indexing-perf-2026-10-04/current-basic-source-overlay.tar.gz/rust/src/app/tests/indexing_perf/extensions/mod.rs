//! Additional actual-worker profiles; the cold basic trace remains independent.
use super::*;
mod cases;
mod driver;
mod fixture;
mod oracle;
mod runner;
mod supplementary;

#[test]
fn tc_229_real_worker_extended_profiles_smoke() {
    if crate::app::tests::indexing_perf::harness::child_process::isolate(
        module_path!(),
        "tc_229_real_worker_extended_profiles_smoke",
    ) {
        return;
    }
    use cases::Profile;
    use fixture::{ExtendedFixture, Shape};
    let mut fixtures = Vec::new();
    for profile in Profile::ALL
        .into_iter()
        .filter(|p| !p.parser() && *p != Profile::Truncated)
    {
        if !fixtures.iter().any(|(shape, _)| *shape == profile.shape()) {
            fixtures.push((profile.shape(), ExtendedFixture::new(4096, profile.shape())));
        }
    }
    let b = ExtendedFixture::new(4096, Shape::FlatFiles);
    let c = ExtendedFixture::new(4096, Shape::FlatFiles);
    for profile in Profile::ALL
        .into_iter()
        .filter(|p| !p.parser() && *p != Profile::Truncated)
    {
        let f = &fixtures
            .iter()
            .find(|(shape, _)| *shape == profile.shape())
            .unwrap()
            .1;
        let others = if profile == Profile::TabChain {
            vec![&b, &c]
        } else if profile.tabs() {
            vec![&b]
        } else {
            vec![]
        };
        for source in profile.sources() {
            eprintln!("EXTENSION_SMOKE {} {}", profile.name(), source.name());
            let row = driver::run(f, &others, profile, source, true, false);
            assert_eq!(row["correct"], true);
        }
    }
}

#[derive(Default)]
struct ExtendedTruth {
    successful_terminal: bool,
    owned_physical_complete: bool,
    owned_request_released: bool,
    snapshot_valid: bool,
    debt: bool,
    latest_results_valid: bool,
}
impl ExtendedTruth {
    fn index_ready(&self) -> bool {
        self.successful_terminal
            && self.owned_physical_complete
            && self.owned_request_released
            && self.snapshot_valid
            && !self.debt
    }
    fn results_ready(&self) -> bool {
        self.index_ready() && self.latest_results_valid
    }
}

struct DeliveredProof {
    dispatched: Instant,
    delivered: Instant,
    owned_identity: bool,
    successful: bool,
    count: usize,
}
impl DeliveredProof {
    fn completed_while_unsettled(&self, start: Instant, cutoff: Instant) -> bool {
        self.owned_identity
            && self.successful
            && self.count > 0
            && self.dispatched >= start
            && self.delivered >= self.dispatched
            && self.delivered <= cutoff
    }
}

fn owned_background_ingested(_active_count: usize, background_count: usize) -> usize {
    background_count
}

#[test]
fn tc_229_failed_or_stale_terminal_and_debt_cannot_complete() {
    let mut truth = ExtendedTruth {
        successful_terminal: true,
        owned_physical_complete: true,
        owned_request_released: true,
        snapshot_valid: true,
        latest_results_valid: true,
        ..Default::default()
    };
    assert!(truth.results_ready());
    truth.successful_terminal = false;
    assert!(
        !truth.index_ready(),
        "Failed/Canceled cannot certify successful completion"
    );
    truth.successful_terminal = true;
    truth.owned_request_released = false;
    assert!(
        !truth.index_ready(),
        "bookkeeping release belongs to own request"
    );
    truth.owned_request_released = true;
    truth.debt = true;
    assert!(
        !truth.results_ready(),
        "background finalizer/reclaim debt remains"
    );
}
#[test]
fn tc_229_successful_rx_requires_owned_identity_and_interval() {
    let start = Instant::now();
    let mut proof = DeliveredProof {
        dispatched: start + Duration::from_millis(1),
        delivered: start + Duration::from_millis(2),
        owned_identity: true,
        successful: true,
        count: 1,
    };
    let cutoff = start + Duration::from_millis(10);
    assert!(proof.completed_while_unsettled(start, cutoff));
    proof.owned_identity = false;
    assert!(
        !proof.completed_while_unsettled(start, cutoff),
        "stale id/epoch/path cannot prove work"
    );
    proof.owned_identity = true;
    proof.successful = false;
    assert!(!proof.completed_while_unsettled(start, cutoff));
    proof.successful = true;
    proof.count = 0;
    assert!(!proof.completed_while_unsettled(start, cutoff));
    proof.count = 1;
    proof.dispatched = start - Duration::from_millis(1);
    assert!(!proof.completed_while_unsettled(start, cutoff));
    proof.dispatched = start + Duration::from_millis(1);
    proof.delivered = cutoff + Duration::from_millis(1);
    assert!(!proof.completed_while_unsettled(start, cutoff));
}
#[test]
fn tc_229_warm_checkpoints_do_not_use_active_committed_count() {
    assert_eq!(owned_background_ingested(100_000, 10_000), 10_000);
}

#[test]
fn tc_229_revoked_closed_mailbox_preserves_physical_terminal_offer() {
    let mailbox = IndexResponseMailbox::new();
    mailbox.enable_perf_observation();
    mailbox.close();
    mailbox.record_terminal_offer(
        &crate::app::worker::protocol::IndexResponse::Failed {
            request_id: 7,
            error: "index receiver closed".into(),
        },
        false,
    );
    mailbox.record_terminal_send_returned();
    let observation = mailbox.perf_observation();
    assert_eq!(
        observation.terminal_kind, None,
        "closed mailbox did not publish success"
    );
    assert_eq!(observation.terminal_offer_kind, Some("failed"));
    assert_eq!(observation.terminal_offer_current, Some(false));
    assert!(observation.terminal_send_returned >= observation.terminal_offered);
}

fn physical_request_complete(
    observation: &crate::app::index_mailbox::IndexPerfObservation,
) -> bool {
    observation.request_processing_returned.is_some()
}
#[test]
fn tc_229_cleanup_closed_without_physical_return_cannot_complete() {
    let mut observation = crate::app::index_mailbox::IndexPerfObservation {
        mailbox_closed: true,
        terminal_offer_kind: Some("canceled"),
        ..Default::default()
    };
    assert!(!physical_request_complete(&observation));
    observation.request_processing_returned = Some(Instant::now());
    assert!(physical_request_complete(&observation));
}

#[test]
fn tc_229_terminal_cleanup_without_actual_return_is_not_t2() {
    let truth = ExtendedTruth {
        successful_terminal: true,
        owned_request_released: true,
        snapshot_valid: true,
        latest_results_valid: true,
        owned_physical_complete: false,
        ..Default::default()
    };
    assert!(
        !truth.index_ready(),
        "successful terminal and bookkeeping cleanup do not prove worker return"
    );
}

#[test]
fn tc_229_empty_query_all_matches_sort_proves_successful_worker_response() {
    if crate::app::tests::indexing_perf::harness::child_process::isolate(
        module_path!(),
        "tc_229_empty_query_all_matches_sort_proves_successful_worker_response",
    ) {
        return;
    }
    let fixture = fixture::ExtendedFixture::new(4096, fixture::Shape::FlatMixed);
    let row = driver::run(
        &fixture,
        &[],
        cases::Profile::NameAll,
        Source::FileList,
        true,
        false,
    );
    assert!(
        row["aux_observations"]
            .as_array()
            .unwrap()
            .iter()
            .any(|o| o["flow"] == "search-sort" && o["successful"] == true),
        "empty-query sort needs owned successful worker RX rather than fuzzy evaluation count: aux={} bindings={} workers={}",row["aux_observations"],row["search_dispatch_bindings"],row["worker_observations"]
    );
}

#[test]
fn tc_229_search_sort_rejects_type_mode_stale_error_and_zero_candidates() {
    if crate::app::tests::indexing_perf::harness::child_process::isolate(
        module_path!(),
        "tc_229_search_sort_rejects_type_mode_stale_error_and_zero_candidates",
    ) {
        return;
    }
    let mut driver = Driver::new();
    driver.settle_startup();
    let root = driver.app.shell.runtime.root.clone();
    let i = &mut driver.app.shell.indexing;
    i.perf_search_bindings
        .push(crate::app::index_coordinator::SearchDispatchBinding {
            request_id: 7,
            tab_id: 1,
            epoch: 9,
            root: root.clone(),
            query: String::new(),
            candidates: 1000,
            candidate_ptr: 11,
            sort_mode: ResultSortMode::NameAsc,
            sort_scope: ResultSortScope::AllMatches,
            at: Instant::now(),
        });
    let accepts = |i: &crate::app::index_coordinator::IndexCoordinator,
                   id,
                   tab,
                   epoch,
                   root: &std::path::Path,
                   mode,
                   scope,
                   nonempty: bool,
                   error: bool| {
        let response = crate::app::SearchResponse {
            request_id: id,
            results: if nonempty {
                vec![(root.join("item"), 0.0)]
            } else {
                vec![]
            },
            total_match_count: usize::from(nonempty),
            sort_mode: mode,
            sort_scope: scope,
            error: error.then(|| "test search error".to_owned()),
        };
        i.perf_search_sort_owned(
            &response,
            crate::app::index_coordinator::PerfSearchSortIdentity {
                tab,
                epoch,
                root,
                query: "",
            },
        )
    };
    assert!(accepts(
        i,
        7,
        1,
        9,
        &root,
        ResultSortMode::NameAsc,
        ResultSortScope::AllMatches,
        true,
        false
    ));
    for (id, tab, epoch, mode, scope, nonempty, error) in [
        (
            8,
            1,
            9,
            ResultSortMode::NameAsc,
            ResultSortScope::AllMatches,
            true,
            false,
        ),
        (
            7,
            2,
            9,
            ResultSortMode::NameAsc,
            ResultSortScope::AllMatches,
            true,
            false,
        ),
        (
            7,
            1,
            10,
            ResultSortMode::NameAsc,
            ResultSortScope::AllMatches,
            true,
            false,
        ),
        (
            7,
            1,
            9,
            ResultSortMode::Score,
            ResultSortScope::AllMatches,
            true,
            false,
        ),
        (
            7,
            1,
            9,
            ResultSortMode::NameAsc,
            ResultSortScope::ShownResults,
            true,
            false,
        ),
        (
            7,
            1,
            9,
            ResultSortMode::NameAsc,
            ResultSortScope::AllMatches,
            false,
            false,
        ),
        (
            7,
            1,
            9,
            ResultSortMode::NameAsc,
            ResultSortScope::AllMatches,
            true,
            true,
        ),
    ] {
        assert!(!accepts(
            i, id, tab, epoch, &root, mode, scope, nonempty, error
        ));
    }
    assert!(!accepts(
        i,
        7,
        1,
        9,
        &root.join("wrong-root"),
        ResultSortMode::NameAsc,
        ResultSortScope::AllMatches,
        true,
        false
    ));
    i.perf_search_bindings[0].candidates = 0;
    assert!(!accepts(
        i,
        7,
        1,
        9,
        &root,
        ResultSortMode::NameAsc,
        ResultSortScope::AllMatches,
        true,
        false
    ));
}

fn completed_search_sort(
    stats: &crate::app::worker::search_perf::SearchPerfObservation,
    start: Instant,
    dispatch: Instant,
    delivered: Instant,
    cutoff: Instant,
    candidates: usize,
) -> bool {
    !stats.skipped_canceled
        && stats.canceled_at.is_none()
        && candidates > 0
        && stats.candidates == candidates
        && dispatch >= start
        && delivered <= cutoff
        && stats
            .started_at
            .zip(stats.completed_at)
            .is_some_and(|(begin, end)| begin >= dispatch && end >= begin && end <= delivered)
}
#[test]
fn tc_229_empty_sort_queued_canceled_or_late_work_cannot_prove_overlap() {
    use crate::app::worker::search_perf::SearchPerfObservation;
    let start = Instant::now();
    let dispatch = start + Duration::from_millis(1);
    let delivered = start + Duration::from_millis(4);
    let cutoff = start + Duration::from_millis(5);
    let mut stats = SearchPerfObservation::default();
    assert!(!completed_search_sort(
        &stats, start, dispatch, delivered, cutoff, 1000
    ));
    stats.started_at = Some(start + Duration::from_millis(2));
    stats.completed_at = Some(start + Duration::from_millis(3));
    stats.candidates = 1000;
    assert!(completed_search_sort(
        &stats, start, dispatch, delivered, cutoff, 1000
    ));
    stats.skipped_canceled = true;
    assert!(!completed_search_sort(
        &stats, start, dispatch, delivered, cutoff, 1000
    ));
    stats.skipped_canceled = false;
    stats.canceled_at = Some(start + Duration::from_millis(3));
    assert!(!completed_search_sort(
        &stats, start, dispatch, delivered, cutoff, 1000
    ));
    stats.canceled_at = None;
    assert!(!completed_search_sort(
        &stats, start, dispatch, delivered, cutoff, 0
    ));
    assert!(!completed_search_sort(
        &stats, start, dispatch, delivered, cutoff, 999
    ));
    assert!(!completed_search_sort(
        &stats, start, dispatch, delivered, dispatch, 1000
    ));
    stats.completed_at = None;
    assert!(!completed_search_sort(
        &stats, start, dispatch, delivered, cutoff, 1000
    ));
}

#[derive(Clone, Default)]
struct PlannedRequest {
    id: u64,
    tab: u64,
    revoked_by: Option<u64>,
    completed_predecessor: bool,
    permission_at: Option<Instant>,
    permission_reason: Option<&'static str>,
}
struct RequestProof {
    id: u64,
    tab: u64,
    finished: bool,
    physical_complete: bool,
    source_root_correct: bool,
    revoked_abort: bool,
}
fn planned_requests_valid(planned: &[PlannedRequest], actual: &[RequestProof]) -> bool {
    if planned.is_empty() || planned.len() != actual.len() {
        return false;
    }
    let mut ids = std::collections::HashSet::new();
    if !planned.iter().all(|p| ids.insert(p.id)) {
        return false;
    }
    ids.clear();
    if !actual.iter().all(|p| ids.insert(p.id)) {
        return false;
    }
    planned.iter().all(|p| {
        let Some(a) = actual.iter().find(|a| a.id == p.id && a.tab == p.tab) else {
            return false;
        };
        if !a.physical_complete {
            return false;
        }
        if let Some(next) = p.revoked_by {
            if !planned
                .iter()
                .any(|n| n.id == next && n.tab == p.tab && n.id > p.id)
            {
                return false;
            }
            (a.finished && a.source_root_correct) || a.revoked_abort
        } else {
            (p.completed_predecessor || !planned.iter().any(|n| n.tab == p.tab && n.id > p.id))
                && a.finished
                && a.source_root_correct
        }
    })
}
#[test]
fn tc_229_planned_requests_reject_secondary_cancel_extra_and_unplanned_revocation() {
    let plans = vec![
        PlannedRequest {
            id: 1,
            tab: 1,
            revoked_by: None,
            ..Default::default()
        },
        PlannedRequest {
            id: 2,
            tab: 2,
            revoked_by: None,
            ..Default::default()
        },
    ];
    let proof = |id, tab, finished| RequestProof {
        id,
        tab,
        finished,
        physical_complete: true,
        source_root_correct: true,
        revoked_abort: !finished,
    };
    assert!(planned_requests_valid(
        &plans,
        &[proof(1, 1, true), proof(2, 2, true)]
    ));
    assert!(
        !planned_requests_valid(&plans, &[proof(1, 1, true), proof(2, 2, false)]),
        "secondary latest canceled cannot use old snapshot"
    );
    assert!(
        !planned_requests_valid(
            &plans,
            &[proof(1, 1, true), proof(2, 2, true), proof(3, 1, true)]
        ),
        "unexpected extra work changes the scenario"
    );
    let unplanned = vec![
        plans[0].clone(),
        PlannedRequest {
            id: 3,
            tab: 1,
            revoked_by: None,
            ..Default::default()
        },
    ];
    assert!(
        !planned_requests_valid(&unplanned, &[proof(1, 1, false), proof(3, 1, true)]),
        "later unplanned request does not authorize earlier failure"
    );
    let mut authorized = unplanned;
    authorized[0].revoked_by = Some(3);
    assert!(planned_requests_valid(
        &authorized,
        &[proof(1, 1, false), proof(3, 1, true)]
    ));
}

fn abort_after_permission(abort: Option<Instant>, permission: Option<Instant>) -> bool {
    matches!((abort, permission), (Some(a), Some(p)) if a >= p)
}
#[test]
fn tc_229_later_operation_cannot_authorize_earlier_abort() {
    let first = Instant::now();
    let later = first + Duration::from_millis(1);
    assert!(!abort_after_permission(Some(first), Some(later)));
    assert!(!abort_after_permission(Some(first), None));
    assert!(!abort_after_permission(None, Some(first)));
    assert!(abort_after_permission(Some(later), Some(first)));
}

fn dependent_input_allowed(requested: u64, active: Option<u64>, pending: Option<u64>) -> bool {
    active == Some(requested) && pending.is_none()
}
#[test]
fn tc_229_dependent_input_waits_for_actual_target_activation() {
    assert!(!dependent_input_allowed(2, Some(1), Some(2)));
    assert!(!dependent_input_allowed(2, Some(2), Some(2)));
    assert!(!dependent_input_allowed(2, Some(1), None));
    assert!(dependent_input_allowed(2, Some(2), None));
}

fn planned_unsent_discard(
    o: &crate::app::index_mailbox::IndexPerfObservation,
    permission: Option<Instant>,
    released: bool,
) -> bool {
    o.allocation_observed
        && o.admitted_at.is_none()
        && o.mailbox_closed
        && released
        && abort_after_permission(o.mailbox_closed_at, permission)
}
#[test]
fn tc_229_unsent_discard_never_substitutes_admitted_worker_return() {
    let at = Instant::now();
    let mut o = crate::app::index_mailbox::IndexPerfObservation {
        allocation_observed: true,
        mailbox_closed: true,
        mailbox_closed_at: Some(at + Duration::from_millis(1)),
        ..Default::default()
    };
    assert!(!planned_unsent_discard(&o, None, true));
    assert!(!planned_unsent_discard(&o, Some(at), false));
    assert!(planned_unsent_discard(&o, Some(at), true));
    o.admitted_at = Some(at);
    assert!(!planned_unsent_discard(&o, Some(at), true));
    assert!(!physical_request_complete(&o));
    o.request_processing_returned = Some(at + Duration::from_millis(2));
    assert!(physical_request_complete(&o));
}

fn requires_latest_generation(plans: &[PlannedRequest], id: u64, tab: u64) -> bool {
    !plans.iter().any(|p| p.tab == tab && p.id > id)
}
#[test]
fn tc_229_completed_latest_cannot_bypass_owned_generation() {
    let mut plans = vec![PlannedRequest {
        id: 1,
        tab: 1,
        completed_predecessor: true,
        ..Default::default()
    }];
    assert!(requires_latest_generation(&plans, 1, 1));
    plans.push(PlannedRequest {
        id: 2,
        tab: 2,
        ..Default::default()
    });
    assert!(requires_latest_generation(&plans, 1, 1));
    plans.push(PlannedRequest {
        id: 3,
        tab: 1,
        ..Default::default()
    });
    assert!(!requires_latest_generation(&plans, 1, 1));
    assert!(requires_latest_generation(&plans, 3, 1));
}
fn request_acquisition_owned(
    o: &crate::app::index_mailbox::IndexPerfObservation,
    root: &std::path::Path,
    source: Source,
) -> bool {
    (o.admitted_at.is_none() || o.admitted_root.as_deref() == Some(root))
        && (o.started_source.is_none() && o.started_root.is_none() && o.started_published.is_none()
            || o.started_source == Some(source.name()) && o.started_root.as_deref() == Some(root))
}
#[test]
fn tc_229_revoked_abort_rejects_wrong_actual_root_or_source() {
    let root = std::path::Path::new("owned-root");
    let mut o = crate::app::index_mailbox::IndexPerfObservation {
        admitted_at: Some(Instant::now()),
        admitted_root: Some("wrong-root".into()),
        ..Default::default()
    };
    assert!(!request_acquisition_owned(&o, root, Source::Walker));
    o.admitted_root = Some(root.into());
    o.started_source = Some("Walker");
    o.started_root = Some("wrong-root".into());
    assert!(!request_acquisition_owned(&o, root, Source::Walker));
    o.started_root = Some(root.into());
    o.started_source = Some("FileList");
    assert!(!request_acquisition_owned(&o, root, Source::Walker));
    o.started_source = Some("Walker");
    assert!(request_acquisition_owned(&o, root, Source::Walker));
    o.started_source = None;
    o.started_root = None;
    assert!(request_acquisition_owned(&o, root, Source::Walker));
    o.admitted_root = None;
    assert!(!request_acquisition_owned(&o, root, Source::Walker));
    o.admitted_at = None;
    assert!(request_acquisition_owned(&o, root, Source::Walker));
}

#[test]
fn tc_229_unmeasured_promotion_control_is_empty_and_quiescent() {
    if crate::app::tests::indexing_perf::harness::child_process::isolate(
        module_path!(),
        "tc_229_unmeasured_promotion_control_is_empty_and_quiescent",
    ) {
        return;
    }
    use cases::Profile;
    use fixture::{ExtendedFixture, Shape};
    let a = ExtendedFixture::new(4096, Shape::FlatFiles);
    let b = ExtendedFixture::new(4096, Shape::FlatFiles);
    let row = driver::run(
        &a,
        &[&b],
        Profile::Promotion,
        Source::FileList,
        false,
        false,
    );
    assert_eq!(row["correct"], true);
    assert_eq!(row["index_requests"].as_array().unwrap().len(), 1);
    let untouched = &row["unmeasured_tab_observations"].as_array().unwrap()[0];
    assert_eq!(untouched["all_entries"], 0);
    assert_eq!(untouched["visible_entries"], 0);
    assert_eq!(untouched["measured_allocation_count"], 0);
    assert_eq!(untouched["index_debt"], false);
}

#[test]
fn tc_229_all_tab_profile_controls_preserve_own_expected_state() {
    if crate::app::tests::indexing_perf::harness::child_process::isolate(
        module_path!(),
        "tc_229_all_tab_profile_controls_preserve_own_expected_state",
    ) {
        return;
    }
    use cases::Profile;
    use fixture::{ExtendedFixture, Shape};
    let a = ExtendedFixture::new(4096, Shape::FlatFiles);
    let b = ExtendedFixture::new(4096, Shape::FlatFiles);
    let c = ExtendedFixture::new(4096, Shape::FlatFiles);
    for profile in Profile::ALL.into_iter().filter(|p| p.tabs()) {
        let companions = if profile == Profile::TabChain {
            vec![&b, &c]
        } else {
            vec![&b]
        };
        for source in profile.sources() {
            eprintln!(
                "EXTENSION_CONTROL_SMOKE {} {}",
                profile.name(),
                source.name()
            );
            let row = driver::run(&a, &companions, profile, source, false, false);
            assert_eq!(row["correct"], true);
            assert_eq!(row["contention_eligible"], true);
        }
    }
}
