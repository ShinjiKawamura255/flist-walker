use super::cases::Profile;
use super::fixture::{EmptyRootPublication, ExtendedFixture};
use super::oracle::{ExtendedOracle, Filter};
use super::*;

struct OwnedRequest {
    id: u64,
    tab: u64,
    allocated_at: Instant,
    observation: crate::app::index_mailbox::IndexPerfHandle,
}
impl OwnedRequest {
    fn observation(&self) -> crate::app::index_mailbox::IndexPerfObservation {
        self.observation.lock().expect("index observation").clone()
    }
}
fn collect_requests(driver: &Driver, ledger: &mut Vec<OwnedRequest>) {
    for a in &driver.app.shell.indexing.perf_allocations {
        if !ledger.iter().any(|r| r.id == a.id) {
            ledger.push(OwnedRequest {
                id: a.id,
                tab: a.tab.expect("owned tab"),
                allocated_at: a.at,
                observation: Arc::clone(&a.observation),
            });
        }
    }
}
fn record_planned_new(driver: &Driver, plans: &mut Vec<PlannedRequest>, tab: u64, count: usize) {
    let new = driver
        .app
        .shell
        .indexing
        .perf_allocations
        .iter()
        .filter(|a| !plans.iter().any(|p| p.id == a.id))
        .collect::<Vec<_>>();
    assert_eq!(
        new.len(),
        count,
        "unexpected index allocation count for owned operation/tab={tab}"
    );
    for a in new {
        assert_eq!(a.tab, Some(tab), "request allocated for unexpected tab");
        if let Some(previous) = plans.iter_mut().rev().find(|p| p.tab == tab) {
            let observed = driver
                .app
                .shell
                .indexing
                .perf_allocations
                .iter()
                .find(|r| r.id == previous.id)
                .unwrap()
                .observation
                .lock()
                .unwrap();
            if observed.terminal_kind == Some("finished") {
                previous.completed_predecessor = true;
            } else {
                assert!(
                    previous.permission_at.is_some(),
                    "no planned revocation permission for predecessor {}",
                    previous.id
                );
                assert!(previous.revoked_by.is_none());
                previous.revoked_by = Some(a.id);
            }
        }
        plans.push(PlannedRequest {
            id: a.id,
            tab,
            revoked_by: None,
            ..Default::default()
        });
    }
}
fn permit_revocation(
    driver: &Driver,
    plans: &mut [PlannedRequest],
    tab: u64,
    reason: &'static str,
) {
    let Some(p) = plans.iter_mut().rev().find(|p| p.tab == tab) else {
        return;
    };
    if p.permission_at.is_some() {
        return;
    }
    let a = driver
        .app
        .shell
        .indexing
        .perf_allocations
        .iter()
        .find(|a| a.id == p.id)
        .unwrap();
    let o = a.observation.lock().unwrap();
    if o.terminal_kind == Some("finished") {
        p.completed_predecessor = true;
        return;
    }
    assert!(
        !o.mailbox_closed
            && !matches!(o.terminal_kind, Some("canceled" | "failed"))
            && !matches!(o.terminal_offer_kind, Some("canceled" | "failed")),
        "operation cannot retroactively authorize an aborted request {}: {o:?}",
        p.id
    );
    p.permission_at = Some(Instant::now());
    p.permission_reason = Some(reason);
}
fn refresh_allocation(
    driver: &Driver,
    plans: &mut Vec<PlannedRequest>,
    deferred: &mut HashMap<u64, usize>,
    tab: u64,
) {
    let count = driver
        .app
        .shell
        .indexing
        .perf_allocations
        .iter()
        .filter(|a| !plans.iter().any(|p| p.id == a.id))
        .count();
    if count == 0 {
        assert_eq!(driver.app.current_tab_id(), Some(tab));
        assert!(
            driver
                .app
                .shell
                .indexing
                .refresh_after_pending_finish
                .is_some(),
            "missing immediate or planned deferred refresh"
        );
        // A second click while the same production deferred refresh flag is set
        // coalesces, rather than authorizing an extra request.
        deferred.insert(tab, 1);
    } else {
        record_planned_new(driver, plans, tab, 1);
    }
}
fn capture_deferred(
    driver: &Driver,
    plans: &mut Vec<PlannedRequest>,
    deferred: &mut HashMap<u64, usize>,
) {
    let arrivals = driver
        .app
        .shell
        .indexing
        .perf_allocations
        .iter()
        .filter(|a| !plans.iter().any(|p| p.id == a.id))
        .map(|a| a.tab.unwrap())
        .collect::<Vec<_>>();
    for tab in arrivals {
        assert_eq!(deferred.remove(&tab), Some(1), "unplanned frame allocation");
        record_planned_new(driver, plans, tab, 1);
    }
}
fn planned_switch(
    driver: &mut Driver,
    n: usize,
    plans: &mut Vec<PlannedRequest>,
    future: &mut HashMap<u64, usize>,
) -> bool {
    let tab = driver.app.shell.tabs.get(n).expect("switch target");
    let id = tab.id;
    let lifecycle = tab.index_state.lifecycle();
    let pending = tab.index_state.pending_index_request_id;
    let deferred = pending.is_none()
        && tab.index_state.pending_index_finish.is_none()
        && (tab.index_state.root_after_pending_finish.is_some()
            || tab.index_state.refresh_after_pending_finish.is_some());
    let auto = driver.app.shell.tabs.active_tab_index() != n
        && (deferred
            || pending.is_none()
                && matches!(
                    lifecycle,
                    crate::app::TabResourceLifecycle::Dormant
                        | crate::app::TabResourceLifecycle::Evicted
                ));
    if let Some(warm) = driver.app.shell.indexing.warm_tab_id {
        if warm != id && Some(warm) != driver.app.current_tab_id() {
            permit_revocation(driver, plans, warm, "switch-evicts-previous-Warm");
        }
    }
    if auto {
        permit_revocation(driver, plans, id, "lifecycle-activation-refresh");
    }
    driver.app.switch_to_tab_index(n);
    let active = driver.app.current_tab_id() == Some(id);
    if active {
        record_planned_new(driver, plans, id, usize::from(auto));
    } else {
        assert_eq!(
            driver.app.shell.tabs.pending_activation_tab_id,
            Some(id),
            "unowned deferred activation"
        );
        record_planned_new(driver, plans, id, 0);
        if auto {
            assert!(
                future.insert(id, 1).is_none(),
                "duplicate planned deferred activation"
            );
        }
    }
    active
}
fn request_complete(driver: &Driver, r: &OwnedRequest, plans: &[PlannedRequest]) -> bool {
    let o = r.observation();
    physical_request_complete(&o)
        || (plans.iter().any(|p| p.id == r.id && p.revoked_by.is_some())
            && planned_unsent_discard(
                &o,
                plans
                    .iter()
                    .find(|p| p.id == r.id)
                    .and_then(|p| p.permission_at),
                driver
                    .app
                    .shell
                    .indexing
                    .perf_released_requests
                    .contains_key(&r.id),
            ))
}
fn proofs(
    driver: &Driver,
    ledger: &[OwnedRequest],
    plans: &[PlannedRequest],
    roots: &[&ExtendedFixture],
    tabs: &[u64],
    source: Source,
) -> Vec<RequestProof> {
    ledger
        .iter()
        .map(|r| {
            let o = r.observation();
            let n = tabs.iter().position(|id| *id == r.tab).expect("owned tab");
            let fresh = if driver.app.current_tab_id() == Some(r.tab) {
                driver.app.shell.runtime.freshness.as_ref()
            } else {
                driver
                    .app
                    .shell
                    .tabs
                    .get(n)
                    .unwrap()
                    .result_state
                    .committed
                    .freshness
                    .as_ref()
            };
            let latest_identity = fresh.is_some_and(|f| {
                f.request_id == r.id
                    && f.root == roots[n].root
                    && match (source, &f.source) {
                        (Source::Walker, IndexSource::Walker) => true,
                        (Source::FileList, IndexSource::FileList(path)) => {
                            path == &roots[n].root.join("FileList.txt")
                        }
                        _ => false,
                    }
            });
            let source_root = o.started_source == Some(source.name())
                && o.terminal_source == Some(source.name())
                && o.started_root.as_ref() == Some(&roots[n].root);
            let revoked = plans.iter().any(|p| p.id == r.id && p.revoked_by.is_some());
            RequestProof {
                id: r.id,
                tab: r.tab,
                finished: o.terminal_kind == Some("finished"),
                physical_complete: request_complete(driver, r, plans),
                source_root_correct: source_root
                    && request_acquisition_owned(&o, &roots[n].root, source)
                    && (!requires_latest_generation(plans, r.id, r.tab) || latest_identity),
                revoked_abort: revoked
                    && request_acquisition_owned(&o, &roots[n].root, source)
                    && abort_after_permission(
                        o.mailbox_closed_at
                            .into_iter()
                            .chain(
                                if matches!(o.terminal_offer_kind, Some("canceled" | "failed")) {
                                    o.terminal_offered
                                } else {
                                    None
                                },
                            )
                            .min(),
                        plans
                            .iter()
                            .find(|p| p.id == r.id)
                            .and_then(|p| p.permission_at),
                    )
                    && (o.terminal_kind == Some("canceled")
                        || o.mailbox_closed
                            && o.terminal_offer_current == Some(false)
                            && (matches!(o.terminal_offer_kind, Some("finished" | "canceled"))
                                || o.terminal_offer_kind == Some("failed")
                                    && o.terminal_offer_error.as_deref()
                                        == Some("index receiver closed"))
                        || planned_unsent_discard(
                            &o,
                            plans
                                .iter()
                                .find(|p| p.id == r.id)
                                .and_then(|p| p.permission_at),
                            driver
                                .app
                                .shell
                                .indexing
                                .perf_released_requests
                                .contains_key(&r.id),
                        )
                        || o.mailbox_closed
                            && o.skipped_closed_before_start
                            && o.request_processing_returned.is_some()),
            }
        })
        .collect()
}
pub(super) fn configure(
    driver: &mut Driver,
    fixture: &ExtendedFixture,
    source: Source,
    filter: Filter,
    links: bool,
) {
    let app = &mut driver.app;
    app.shell.runtime.root = fixture.root.clone();
    app.shell.runtime.use_filelist = source == Source::FileList;
    app.shell.runtime.include_files = filter.files;
    app.shell.runtime.include_dirs = filter.dirs;
    app.shell.runtime.ignore_case = filter.ignore_case;
    app.shell.ui.ignore_list_enabled = filter.ignore_enabled;
    app.shell.runtime.ignore_list_terms = Arc::new(vec!["SKIP".into()]);
    app.shell.runtime.follow_links = links;
    app.sync_active_tab_state();
}
fn default_filter() -> Filter {
    Filter {
        files: true,
        dirs: true,
        ignore_enabled: false,
        ignore_case: true,
    }
}
fn tab_debt(tab: &crate::app::AppTabState) -> bool {
    let i = &tab.index_state;
    i.index_in_progress
        || i.pending_index_request_id.is_some()
        || i.pending_index_entries_request_id.is_some()
        || i.pending_index_finish.is_some()
        || i.build_reclaim_pending
        || i.refresh_after_pending_finish.is_some()
        || i.root_after_pending_finish.is_some()
        || !i.build.pending_entries.is_empty()
        || i.build.active_filter.is_some()
        || i.kind_resolution_in_progress
        || !i.build.pending_kind_paths.is_empty()
        || !i.build.in_flight_kind_paths.is_empty()
        || i.search_resume_pending
        || i.search_rerun_pending
}
pub(super) fn all_index_debt(driver: &Driver) -> bool {
    let i = &driver.app.shell.indexing;
    i.tx.load().queued != 0
        || i.tx.load().inflight != 0
        || driver.index_debt()
        || !i.pending_queue.is_empty()
        || !i.inflight_requests.is_empty()
        || !i.request_tabs.is_empty()
        || !i.background_states.is_empty()
        || i.background_finalizations.keys().next().is_some()
        || i.deferred_response.is_some()
        || !i.deferred_non_active_responses.is_empty()
        || driver.app.shell.tabs.pending_activation_tab_id.is_some()
        || driver
            .app
            .shell
            .tabs
            .iter()
            .enumerate()
            .any(|(n, t)| n != driver.app.shell.tabs.active_tab_index() && tab_debt(t))
}
pub(super) fn result_debt(driver: &Driver) -> bool {
    let app = &driver.app;
    app.shell.search.in_progress()
        || app.shell.search.pending_request_id().is_some()
        || app.shell.indexing.search_resume_pending
        || app.shell.indexing.search_rerun_pending
        || app.shell.worker_bus.sort.in_progress
        || app.shell.worker_bus.sort.pending_request_id.is_some()
        || app.shell.worker_bus.preview.in_progress
        || app.shell.worker_bus.preview.pending_request_id.is_some()
        || app
            .shell
            .worker_bus
            .preview
            .worker_inflight_request_id
            .is_some()
        || app.shell.worker_bus.preview.latest_request.is_some()
        || app.parked_preview_request.is_some()
        || app.deferred_latest_preview_request.is_some()
        || app.deferred_preview_response.is_some()
        || app.shell.tabs.iter().enumerate().any(|(n, t)| {
            n != app.shell.tabs.active_tab_index()
                && (t.search_in_progress
                    || t.preview_in_progress
                    || t.result_state.sort_in_progress
                    || t.pending_request_id.is_some()
                    || t.pending_preview_request_id.is_some()
                    || t.result_state.pending_sort_request_id.is_some())
        })
}
pub(super) fn settle_setup(driver: &mut Driver) {
    let begin = Instant::now();
    loop {
        driver.paced_frame();
        if !all_index_debt(driver) && !result_debt(driver) {
            break;
        }
        assert!(
            begin.elapsed() < Duration::from_secs(120),
            "setup did not settle"
        );
    }
}
fn owned_count(driver: &Driver, tab: u64, request: Option<u64>) -> usize {
    let app = &driver.app;
    if app.current_tab_id() == Some(tab) {
        return driver.ingested();
    }
    let t = app.shell.tabs.iter().find(|t| t.id == tab).unwrap();
    if let Some(id) = request {
        if let Some(f) = app.shell.indexing.background_finalizations.get(&id) {
            return f.completed_entries.len();
        }
        if let Some(s) = app.shell.indexing.background_states.get(&id) {
            return s.entries.len() + t.index_state.build.index.entries.len();
        }
        if t.index_state.pending_index_request_id == Some(id) {
            return t.index_state.build.index.entries.len();
        }
    }
    t.result_state.committed.all_entries.len()
}
fn request_for(driver: &Driver, tab: u64) -> Option<u64> {
    driver.app.shell.indexing.latest_request_for_tab(tab)
}
fn actual_signature(root: &std::path::Path, entries: &[Entry]) -> String {
    let mut p = entries.iter().map(|e| e.path.clone()).collect::<Vec<_>>();
    p.sort();
    format!("{:016x}", signature(root, p.iter()))
}

pub(super) fn run(
    fixture: &ExtendedFixture,
    companions: &[&ExtendedFixture],
    profile: Profile,
    source: Source,
    condition: bool,
    full: bool,
) -> serde_json::Value {
    assert!(!profile.parser());
    fixture.prepare_source(source);
    for f in companions {
        f.prepare_source(source);
    }
    let mut driver = Driver::new();
    driver.settle_startup();
    let mut tabs = vec![driver.app.current_tab_id().unwrap()];
    if profile.tabs() {
        for _ in 0..if profile == Profile::TabChain { 2 } else { 1 } {
            driver.app.create_new_tab();
            tabs.push(driver.app.current_tab_id().unwrap());
        }
    }
    let mut setup_roots = vec![fixture];
    setup_roots.extend_from_slice(companions);
    for n in (0..tabs.len()).rev() {
        driver.app.switch_to_tab_index(n);
        configure(
            &mut driver,
            setup_roots[n],
            source,
            profile.filter(false),
            profile == Profile::Links,
        );
    }
    settle_setup(&mut driver);
    assert!(driver.app.shell.runtime.all_entries.is_empty());
    let mut empty_publication = profile
        .stable()
        .then(|| EmptyRootPublication::new(setup_roots[1], source));
    // The final App owner is declared after the publication guard: workers stop
    // before its rollback on every panic path.
    let mut driver = driver;
    let mut initial_b = serde_json::Value::Null;
    if profile.stable() {
        driver.app.switch_to_tab_index(1);
        settle_setup(&mut driver);
        driver.app.shell.indexing.perf_observe_requests = true;
        driver.app.request_index_refresh();
        let empty_id = driver
            .app
            .shell
            .indexing
            .pending_request_id
            .expect("empty B request");
        let empty_observation = driver
            .app
            .shell
            .indexing
            .response_mailboxes
            .lock()
            .unwrap()
            .get(&empty_id)
            .expect("empty B mailbox")
            .perf_handle();
        settle_setup(&mut driver);
        assert!(driver.app.shell.runtime.all_entries.is_empty());
        assert!(driver.app.shell.runtime.entries.is_empty());
        let observed = empty_observation.lock().unwrap().clone();
        assert_eq!(observed.terminal_kind, Some("finished"));
        assert_eq!(observed.started_source, Some(source.name()));
        assert_eq!(observed.terminal_source, Some(source.name()));
        let f = driver
            .app
            .shell
            .runtime
            .freshness
            .as_ref()
            .expect("actual empty B freshness");
        assert_eq!(f.request_id, empty_id);
        assert_eq!(f.root, setup_roots[1].root);
        assert!(match (&source, &f.source) {
            (Source::FileList, IndexSource::FileList(path)) =>
                path == &setup_roots[1].root.join("FileList.txt"),
            (Source::Walker, IndexSource::Walker) => true,
            _ => false,
        });
        initial_b = serde_json::json!({"request_id":empty_id,"root":f.root,"actual_source":format!("{:?}",f.source),"all_entries":0,"visible_entries":0,"generation":f.request_id,"actual_success":true});
        driver.app.switch_to_tab_index(0);
        settle_setup(&mut driver);
    }
    let seed = profile.stable()
        || matches!(
            profile,
            Profile::Reclaim | Profile::WarmReclaim | Profile::TabChain
        );
    if seed {
        let seed_tabs = if profile.stable() { 1 } else { tabs.len() };
        for (n, setup_root) in setup_roots.iter().enumerate().take(seed_tabs) {
            driver.app.switch_to_tab_index(n);
            configure(
                &mut driver,
                setup_root,
                source,
                profile.filter(false),
                false,
            );
            driver.app.request_index_refresh();
            settle_setup(&mut driver);
            assert_eq!(
                driver.app.shell.runtime.all_entries.len(),
                setup_root.expected.len()
            );
        }
        driver.app.switch_to_tab_index(0);
        settle_setup(&mut driver);
    }
    // Real old -> distinct new membership in the same roots, before t0.
    let generations = if matches!(profile, Profile::Reclaim | Profile::WarmReclaim) {
        setup_roots
            .iter()
            .take(if profile == Profile::WarmReclaim && !condition {
                1
            } else {
                tabs.len()
            })
            .map(|&f| f.next_generation())
            .collect::<Vec<_>>()
    } else {
        Vec::new()
    };
    let mut driver = driver;
    let roots = setup_roots
        .iter()
        .enumerate()
        .map(|(n, f)| generations.get(n).map_or(*f, |g| g.fixture()))
        .collect::<Vec<_>>();
    if profile.stable() {
        driver.app.switch_to_tab_index(1);
        settle_setup(&mut driver);
        assert!(
            driver.app.shell.runtime.all_entries.is_empty(),
            "B must have an empty committed prestate"
        );
    }
    let target = if profile.stable() { 1 } else { 0 };
    let filter = profile.filter(condition);
    let (mode, scope) = profile.sort(condition);
    let expected = ExtendedOracle::new(
        roots[0],
        source,
        filter,
        profile.query(condition),
        mode,
        scope,
        driver.app.shell.runtime.limit,
    );
    let quiet_oracles = roots
        .iter()
        .take(tabs.len())
        .enumerate()
        .map(|(n, f)| {
            ExtendedOracle::new(
                if profile == Profile::WarmReclaim && !condition && n == 1 {
                    setup_roots[n]
                } else {
                    f
                },
                source,
                default_filter(),
                "",
                ResultSortMode::Score,
                ResultSortScope::ShownResults,
                driver.app.shell.runtime.limit,
            )
        })
        .collect::<Vec<_>>();
    let stable_ptr = if profile.stable() {
        let tab = driver.app.shell.tabs.get(0).unwrap();
        assert!(
            quiet_oracles[0].valid_snapshot(
                &tab.result_state.committed.all_entries,
                &tab.result_state.committed.entries
            ),
            "untimed initial A fixture membership"
        );
        Some(Arc::as_ptr(&tab.result_state.committed.entries) as usize)
    } else {
        None
    };
    // Static filter profiles use the same emitted logical workload in both halves.
    if !matches!(profile, Profile::IgnoreCase | Profile::MidIgnore) {
        configure(
            &mut driver,
            roots[target],
            source,
            profile.filter(condition),
            profile == Profile::Links,
        );
    }
    if profile.stable() {
        assert!(!all_index_debt(&driver) && !result_debt(&driver));
        let f = driver
            .app
            .shell
            .runtime
            .freshness
            .as_ref()
            .expect("B freshness before publication");
        assert_eq!(f.request_id, initial_b["request_id"].as_u64().unwrap());
        assert_eq!(f.root, roots[1].root);
        empty_publication
            .take()
            .unwrap()
            .restore()
            .expect("restore full B fixture");
    }
    driver.app.shell.indexing.perf_observe_requests = true;
    driver.app.shell.indexing.perf_observe_history = true;
    driver.app.shell.indexing.perf_observe_aux = true;
    driver.app.shell.search.perf_enabled = true;
    let initial = serde_json::json!({"active_tab":tabs[target],"active_snapshot_entries":driver.app.shell.runtime.all_entries.len(),"stable_A_entries":if profile.stable(){fixture.expected.len()}else{0},"source":source.name(),"depth":"unlimited","seeded_old_snapshot":seed,"B_committed_empty_setup":initial_b});
    let start = Instant::now();
    driver.app.request_index_refresh();
    let mut primary = driver.app.shell.indexing.pending_request_id.unwrap();
    let mut ledger = Vec::new();
    let mut plans = Vec::new();
    let mut deferred_allocations = HashMap::new();
    record_planned_new(&driver, &mut plans, tabs[target], 1);
    collect_requests(&driver, &mut ledger);
    if profile.stable() {
        assert!(
            planned_switch(&mut driver, 0, &mut plans, &mut deferred_allocations),
            "stable A switch must activate its settled snapshot"
        );
        assert_eq!(driver.app.shell.indexing.warm_tab_id, Some(tabs[1]));
        assert!(
            driver.app.shell.indexing.pending_request_id.is_none(),
            "A must remain settled without refreshing"
        );
    } else if condition
        && matches!(
            profile,
            Profile::Warm | Profile::Promotion | Profile::WarmReclaim
        )
    {
        driver.app.request_background_index_refresh_for_tab(1);
        record_planned_new(&driver, &mut plans, tabs[1], 1);
        collect_requests(&driver, &mut ledger);
    }
    let mut events = Vec::<serde_json::Value>::new();
    let mut transition_events = Vec::<serde_json::Value>::new();
    let mut pending_transition: Option<(usize, usize)> = None;
    let mut gui_sort_completions = Vec::new();
    let mut driver_overhead = Duration::ZERO;
    let mut stage = 0;
    let mut done_inputs = !condition
        || !matches!(
            profile,
            Profile::IgnoreCase
                | Profile::MidIgnore
                | Profile::SearchIgnore
                | Profile::EditFiles
                | Profile::NameShown
                | Profile::ModifiedShown
                | Profile::NameAll
                | Profile::ModifiedAll
                | Profile::Promotion
                | Profile::TabChain
                | Profile::StableSelective
                | Profile::StableDense
                | Profile::StableEdit
                | Profile::Preview
        );
    let mut t2 = None;
    let mut t2_load = None;
    let mut cutoff = Duration::ZERO;
    let mut frame_max = Duration::ZERO;
    let mut frames = 0;
    let mut high_water = HashMap::<(u64, u8, usize), usize>::new();
    let mut previous = Vec::new();
    let mut last_progress = Duration::ZERO;
    let mut max_gap = Duration::ZERO;
    let mut previous_ingested = 0;
    let mut last_ingest = Duration::ZERO;
    let mut max_ingest_gap = Duration::ZERO;
    let mut deadline = ProgressDeadline::new(Duration::from_secs(30));
    let t3;
    loop {
        let loop_begin = Instant::now();
        collect_requests(&driver, &mut ledger);
        if all_index_debt(&driver) || ledger.iter().any(|r| !request_complete(&driver, r, &plans)) {
            cutoff = start.elapsed();
        }
        let primary_tab = tabs[target];
        let ingested = owned_background_ingested(
            driver.app.shell.runtime.all_entries.len(),
            owned_count(&driver, primary_tab, Some(primary)),
        );
        let logical = roots[target]
            .expected
            .iter()
            .filter(|r| if r.is_dir { filter.dirs } else { filter.files })
            .count();
        let frame_begin = Instant::now();
        let mut completed_transition_this_frame = false;
        if let Some((n, input_stage)) = pending_transition {
            if dependent_input_allowed(
                tabs[n],
                driver.app.current_tab_id(),
                driver.app.shell.tabs.pending_activation_tab_id,
            ) {
                completed_transition_this_frame = true;
                transition_events.push(serde_json::json!({"stage":input_stage,"actual_activated_ms":ms(start.elapsed()),"tab_id":tabs[n],"root":roots[n].root}));
                if profile == Profile::TabChain {
                    permit_revocation(
                        &driver,
                        &mut plans,
                        tabs[n],
                        "explicit-TabChain-refresh-after-activation",
                    );
                    driver.app.request_index_refresh();
                    refresh_allocation(&driver, &mut plans, &mut deferred_allocations, tabs[n]);
                    collect_requests(&driver, &mut ledger);
                    transition_events.push(serde_json::json!({"stage":input_stage,"explicit_refresh_ms":ms(start.elapsed()),"tab_id":tabs[n],"root":roots[n].root}));
                    if input_stage == 2 {
                        primary = driver
                            .app
                            .shell
                            .indexing
                            .pending_request_id
                            .unwrap_or(primary);
                        done_inputs = true;
                    }
                } else if input_stage == 1 {
                    done_inputs = true;
                }
                pending_transition = None;
                stage = input_stage + 1;
            }
        }
        if condition
            && !done_inputs
            && pending_transition.is_none()
            && !completed_transition_this_frame
        {
            let threshold = match stage {
                0 => logical / 10,
                1 => logical / 4,
                _ => logical / 2,
            };
            let checkpoint = if profile == Profile::TabChain && stage > 0 {
                owned_count(
                    &driver,
                    tabs[stage.min(2)],
                    request_for(&driver, tabs[stage.min(2)]),
                )
            } else {
                ingested
            };
            let threshold = if profile == Profile::TabChain {
                logical / 10
            } else {
                threshold
            };
            if checkpoint >= threshold.max(1) {
                let input_at = Instant::now();
                match profile {
                    Profile::IgnoreCase => {
                        driver.app.set_ignore_case(true);
                        done_inputs = true;
                    }
                    Profile::MidIgnore => {
                        permit_revocation(
                            &driver,
                            &mut plans,
                            tabs[0],
                            "IgnoreList-PreserveSort-refresh",
                        );
                        driver.app.shell.ui.ignore_list_enabled = true;
                        driver
                            .app
                            .maybe_reindex_from_filter_toggles(false, false, false, true);
                        refresh_allocation(&driver, &mut plans, &mut deferred_allocations, tabs[0]);
                        collect_requests(&driver, &mut ledger);
                        primary = driver
                            .app
                            .shell
                            .indexing
                            .pending_request_id
                            .unwrap_or(primary);
                        done_inputs = true;
                    }
                    Profile::SearchIgnore | Profile::StableSelective | Profile::StableDense => {
                        driver.query(profile.query(true));
                        done_inputs = true;
                    }
                    Profile::EditFiles | Profile::StableEdit => {
                        driver.query(match stage {
                            0 => "item",
                            1 => "needle",
                            _ => "",
                        });
                        if stage == 2 {
                            done_inputs = true;
                        }
                    }
                    Profile::NameShown
                    | Profile::ModifiedShown
                    | Profile::NameAll
                    | Profile::ModifiedAll => {
                        let has_rows = !driver.app.shell.runtime.base_results.is_empty();
                        driver.app.set_result_sort_scope(scope);
                        driver.app.set_result_sort_mode(mode);
                        if profile == Profile::NameShown && has_rows {
                            gui_sort_completions.push(Instant::now());
                        }
                        done_inputs = true;
                    }
                    Profile::Promotion => {
                        let n = if stage == 0 { 1 } else { 0 };
                        if planned_switch(&mut driver, n, &mut plans, &mut deferred_allocations) {
                            transition_events.push(serde_json::json!({"stage":stage,"actual_activated_ms":ms(start.elapsed()),"tab_id":tabs[n],"root":roots[n].root}));
                            if stage == 1 {
                                done_inputs = true;
                            }
                        } else {
                            pending_transition = Some((n, stage));
                        }
                        collect_requests(&driver, &mut ledger);
                    }
                    Profile::TabChain => {
                        let n = if stage == 2 { 0 } else { stage + 1 };
                        if planned_switch(&mut driver, n, &mut plans, &mut deferred_allocations) {
                            transition_events.push(serde_json::json!({"stage":stage,"actual_activated_ms":ms(start.elapsed()),"tab_id":tabs[n],"root":roots[n].root}));
                            permit_revocation(
                                &driver,
                                &mut plans,
                                tabs[n],
                                "explicit-TabChain-refresh",
                            );
                            driver.app.request_index_refresh();
                            refresh_allocation(
                                &driver,
                                &mut plans,
                                &mut deferred_allocations,
                                tabs[n],
                            );
                            transition_events.push(serde_json::json!({"stage":stage,"explicit_refresh_ms":ms(start.elapsed()),"tab_id":tabs[n],"root":roots[n].root}));
                            if stage == 2 {
                                primary = driver
                                    .app
                                    .shell
                                    .indexing
                                    .pending_request_id
                                    .unwrap_or(primary);
                                done_inputs = true;
                            }
                        } else {
                            pending_transition = Some((n, stage));
                        }
                        collect_requests(&driver, &mut ledger);
                    }
                    Profile::Preview => {
                        driver.app.shell.ui.show_preview = true;
                        assert!(driver.app.shell.runtime.results.len() > stage);
                        driver.app.shell.runtime.set_current_row(Some(stage));
                        driver.app.request_preview_for_current();
                        if stage == 2 {
                            done_inputs = true;
                        }
                    }
                    _ => {
                        done_inputs = true;
                    }
                }
                events.push(serde_json::json!({"stage":stage,"at_ms":ms(input_at.duration_since(start)),"GUI_ingested":checkpoint,"query":match profile{Profile::EditFiles|Profile::StableEdit=>match stage{0=>"item",1=>"needle",_=>""},_=>profile.query(true)},"active_tab":driver.app.current_tab_id(),"input":"production-handler","requested_tab":pending_transition.map(|(n,_)|tabs[n]).or(driver.app.current_tab_id()),"requested_root":pending_transition.map(|(n,_)|&roots[n].root).unwrap_or(&driver.app.shell.runtime.root)}));
                if pending_transition.is_none() {
                    stage += 1;
                }
            }
        }
        if all_index_debt(&driver) || ledger.iter().any(|r| !request_complete(&driver, r, &plans)) {
            cutoff = start.elapsed();
        }
        driver.frame();
        frame_max = frame_max.max(driver.last_frame_end.duration_since(frame_begin));
        frames += 1;
        capture_deferred(&driver, &mut plans, &mut deferred_allocations);
        record_planned_new(&driver, &mut plans, primary_tab, 0);
        let now = driver.last_frame_end.duration_since(start);
        collect_requests(&driver, &mut ledger);
        if matches!(profile, Profile::MidIgnore | Profile::TabChain) {
            if let Some(id) = request_for(&driver, tabs[target]) {
                primary = id;
            }
        }
        if profile.stable() {
            assert_eq!(driver.app.current_tab_id(), Some(tabs[0]));
            assert_eq!(driver.app.shell.runtime.root, roots[0].root);
            assert_eq!(
                driver.app.shell.runtime.entries.len(),
                fixture.expected.len(),
                "A candidate cardinality remains fixed"
            );
            assert_eq!(
                Arc::as_ptr(&driver.app.shell.runtime.entries) as usize,
                stable_ptr.unwrap(),
                "A candidate Arc must remain unchanged without pinning"
            );
            assert!(
                request_for(&driver, tabs[0]).is_none(),
                "A does not refresh"
            );
        }
        let i = &driver.app.shell.indexing;
        for r in &ledger {
            let count = owned_count(&driver, r.tab, Some(r.id));
            let f = i.background_finalizations.get(&r.id);
            for (phase, value) in [
                (0, count),
                (1, f.map_or(0, |f| f.filter_cursor)),
                (2, f.map_or(0, |f| f.kind_cursor)),
            ] {
                let mark = high_water.entry((r.id, phase, stage)).or_default();
                *mark = (*mark).max(value);
            }
        }
        if let Some(f) = &i.build.active_filter {
            let mark = high_water.entry((primary, 3, stage)).or_default();
            *mark = (*mark).max(f.cursor);
        }
        let evaluated = i
            .perf_aux
            .iter()
            .filter(|o| o.successful && o.delivered_at.is_some())
            .count()
            + driver
                .app
                .shell
                .search
                .perf_workers
                .values()
                .map(|w| worker_progress(&w.lock().unwrap()).0)
                .sum::<usize>();
        let progress = vec![
            high_water.values().sum(),
            ledger.iter().map(|r| r.observation().entries_emitted).sum(),
            evaluated,
        ];
        max_gap = max_gap.max(now.saturating_sub(last_progress));
        if progress != previous {
            last_progress = now;
            previous = progress;
            assert!(
                !deadline.observe(now, true),
                "constructive progress deadline {}",
                profile.name()
            );
        } else {
            assert!(
                !deadline.observe(now, false),
                "constructive stall {}",
                profile.name()
            );
        }
        let current_ingested = owned_count(&driver, tabs[target], Some(primary));
        if current_ingested > previous_ingested {
            max_ingest_gap = max_ingest_gap.max(now.saturating_sub(last_ingest));
            last_ingest = now;
            previous_ingested = current_ingested;
        }
        let primary_observation = ledger
            .iter()
            .find(|r| r.id == primary)
            .unwrap()
            .observation();
        let released = ledger
            .iter()
            .all(|r| i.perf_released_requests.contains_key(&r.id));
        let debt =
            all_index_debt(&driver) || ledger.iter().any(|r| !request_complete(&driver, r, &plans));
        let snapshot_valid = if profile.stable() {
            driver
                .app
                .shell
                .tabs
                .get(1)
                .unwrap()
                .result_state
                .committed
                .all_entries
                .len()
                == logical
        } else {
            driver.app.shell.runtime.all_entries.len() == logical
        };
        let truth = ExtendedTruth {
            successful_terminal: primary_observation.terminal_kind == Some("finished")
                && planned_requests_valid(
                    &plans,
                    &proofs(&driver, &ledger, &plans, &roots, &tabs, source),
                ),
            owned_physical_complete: ledger.iter().all(|r| request_complete(&driver, r, &plans)),
            owned_request_released: released,
            snapshot_valid,
            debt: debt || !deferred_allocations.is_empty() || pending_transition.is_some(),
            latest_results_valid: driver.app.shell.runtime.query_state.query
                == profile.query(condition)
                && driver.app.shell.runtime.result_sort_mode == mode
                && driver.app.shell.runtime.result_sort_scope == scope
                && (if scope == ResultSortScope::AllMatches {
                    expected.valid_results(
                        &driver.app.shell.runtime.results,
                        driver.app.shell.runtime.total_match_count,
                    )
                } else {
                    expected.valid_shown_results(
                        &driver.app.shell.runtime.results,
                        driver.app.shell.runtime.total_match_count,
                        &driver.app.shell.runtime.base_results,
                    )
                })
                && !result_debt(&driver),
        };
        if truth.index_ready() && done_inputs && t2.is_none() {
            let candidate_t2_load = driver.app.shell.indexing.tx.load();
            for p in plans
                .iter()
                .filter(|p| requires_latest_generation(&plans, p.id, p.tab))
            {
                let n = tabs.iter().position(|id| *id == p.tab).unwrap();
                if driver.app.current_tab_id() == Some(p.tab) {
                    if !expected.valid_snapshot(
                        &driver.app.shell.runtime.all_entries,
                        &driver.app.shell.runtime.entries,
                    ) {
                        let runtime = &driver.app.shell.runtime;
                        let filter = profile.filter(condition);
                        let records = roots[0]
                            .expected
                            .iter()
                            .filter(|r| if r.is_dir { filter.dirs } else { filter.files })
                            .collect::<Vec<_>>();
                        let paths = records.iter().map(|r| &r.path).collect::<HashSet<_>>();
                        let actual = runtime
                            .all_entries
                            .iter()
                            .map(|e| &e.path)
                            .collect::<HashSet<_>>();
                        let first = runtime
                            .all_entries
                            .iter()
                            .zip(&records)
                            .enumerate()
                            .find(|(_, (e, r))| e.path != r.path);
                        let freshness = runtime.freshness.as_ref();
                        let by_path = records
                            .iter()
                            .map(|r| (&r.path, r.is_dir))
                            .collect::<HashMap<_, _>>();
                        eprintln!(
                            "INDEX_PERF_FAILURE {}",
                            serde_json::json!({
                                "profile":profile.name(),"source":source.name(),"condition":condition,"stage":stage,"done_inputs":done_inputs,"pending_transition":pending_transition,
                                "current_tab":driver.app.current_tab_id(),"latest_planned_tab":p.tab,"latest_planned_request":p.id,"active_root":runtime.root,"expected_root":roots[0].root,
                                "freshness_root":freshness.map(|f| &f.root),"freshness_source":freshness.map(|f|format!("{:?}",f.source)),"freshness_request":freshness.map(|f|f.request_id),
                                "all_len":runtime.all_entries.len(),"visible_len":runtime.entries.len(),"expected_all_len":records.len(),"unique_paths":actual.len(),"missing_paths":paths.difference(&actual).count(),"extra_paths":actual.difference(&paths).count(),
                                "kind_mismatches":runtime.all_entries.iter().filter(|e| by_path.get(&e.path).is_some_and(|is_dir|e.kind.is_some_and(|k|k.is_dir!=Some(*is_dir)))).count(),
                                "first_order_mismatch":first.map(|(index,(entry,record))|serde_json::json!({"index":index,"actual_relative":entry.path.strip_prefix(&roots[0].root).ok(),"expected_relative":record.path.strip_prefix(&roots[0].root).ok(),"actual_kind":format!("{:?}",entry.kind),"expected_dir":record.is_dir})),
                                "quiet_oracle_matches":quiet_oracles.iter().map(|o|o.valid_snapshot(&runtime.all_entries,&runtime.entries)).collect::<Vec<_>>(),"input_trace":events,"transition_trace":transition_events
                            })
                        );
                        panic!("latest active request membership");
                    }
                } else {
                    let snapshot = &driver.app.shell.tabs.get(n).unwrap().result_state.committed;
                    assert!(
                        quiet_oracles[n].valid_snapshot(&snapshot.all_entries, &snapshot.entries),
                        "latest background request membership"
                    );
                }
            }
            t2 = Some(now);
            t2_load = Some(candidate_t2_load);
        }
        if truth.results_ready() && done_inputs {
            if profile == Profile::Preview && condition {
                let path = &driver.app.shell.runtime.results
                    [driver.app.shell.runtime.current_row.unwrap()]
                .0;
                let text = fs::read_to_string(path).unwrap();
                if driver.app.shell.runtime.preview.is_empty()
                    && driver.app.shell.runtime.preview_document.is_none()
                {
                    driver.paced_frame();
                    continue;
                }
                let shown = driver
                    .app
                    .shell
                    .runtime
                    .preview_document
                    .as_ref()
                    .map(|d| d.body())
                    .unwrap_or(&driver.app.shell.runtime.preview);
                assert!(
                    shown.contains(text.trim()),
                    "latest preview content must match own selected path"
                );
            }
            driver_overhead += loop_begin
                .elapsed()
                .saturating_sub(driver.last_frame_end.duration_since(frame_begin));
            t3 = now;
            break;
        }
        assert!(now<Duration::from_secs(120),"extension did not settle {:?}/{source:?}/condition={condition};stage={stage};query={};debt={debt};released={released};snapshot={snapshot_valid};all={};visible={};results={};total={};target={primary}",profile,driver.app.shell.runtime.query_state.query,driver.app.shell.runtime.all_entries.len(),driver.app.shell.runtime.entries.len(),driver.app.shell.runtime.results.len(),driver.app.shell.runtime.total_match_count);
        driver_overhead += loop_begin
            .elapsed()
            .saturating_sub(driver.last_frame_end.duration_since(frame_begin));
        let next = frame_begin + FRAME_PERIOD;
        if let Some(wait) = next.checked_duration_since(Instant::now()) {
            thread::sleep(wait);
        }
    }
    let t2 = t2.unwrap();
    let allocated = driver
        .app
        .shell
        .indexing
        .perf_allocations
        .iter()
        .map(|a| a.id)
        .collect::<std::collections::BTreeSet<_>>();
    let recorded = ledger
        .iter()
        .map(|r| r.id)
        .collect::<std::collections::BTreeSet<_>>();
    let planned = plans
        .iter()
        .map(|p| p.id)
        .collect::<std::collections::BTreeSet<_>>();
    let released = driver
        .app
        .shell
        .indexing
        .perf_released_requests
        .iter()
        .filter(|(_, at)| **at >= start)
        .map(|(id, _)| *id)
        .collect::<std::collections::BTreeSet<_>>();
    assert_eq!(allocated, recorded, "complete allocation history");
    assert_eq!(recorded, planned, "exact operation-owned request manifest");
    assert_eq!(planned, released, "exact measured release history");
    assert!(
        expected.valid_snapshot(
            &driver.app.shell.runtime.all_entries,
            &driver.app.shell.runtime.entries
        ),
        "final active snapshot oracle {}",
        profile.name()
    );
    let mut unmeasured_tab_observations = Vec::new();
    for (n, oracle) in quiet_oracles.iter().enumerate() {
        if n == driver.app.shell.tabs.active_tab_index() {
            continue;
        }
        let tab = driver.app.shell.tabs.get(n).unwrap();
        let measured = plans.iter().any(|p| p.tab == tab.id);
        let seeded = matches!(profile, Profile::WarmReclaim | Profile::TabChain);
        if measured || seeded {
            assert!(
                oracle.valid_snapshot(
                    &tab.result_state.committed.all_entries,
                    &tab.result_state.committed.entries
                ),
                "background tab membership {} tab{n}",
                profile.name()
            );
        } else {
            assert!(
                tab.result_state.committed.all_entries.is_empty(),
                "unmeasured B all entries must remain empty"
            );
            assert!(
                tab.result_state.committed.entries.is_empty(),
                "unmeasured B visible entries must remain empty"
            );
            assert!(!tab_debt(tab), "unmeasured B must remain quiescent");
            assert!(!ledger.iter().any(|r| r.tab == tab.id));
            assert!(
                !driver
                    .app
                    .shell
                    .indexing
                    .perf_allocations
                    .iter()
                    .any(|a| a.tab == Some(tab.id)),
                "unmeasured B must have no index allocation"
            );
        }
        if !measured {
            let freshness = tab.result_state.committed.freshness.as_ref();
            unmeasured_tab_observations.push(serde_json::json!({"tab_id":tab.id,"prestate":if seeded{"untimed-seeded-owned-snapshot"}else{"configured-unmeasured-startup-empty"},"configured_root":tab.root,"actual_committed_root":freshness.map(|f|&f.root),"actual_committed_source":freshness.map(|f|format!("{:?}",f.source)),"actual_committed_generation":freshness.map(|f|f.request_id),"all_entries":tab.result_state.committed.all_entries.len(),"visible_entries":tab.result_state.committed.entries.len(),"index_debt":tab_debt(tab),"measured_allocation_count":0}));
        }
    }
    let quiesce = Instant::now();
    while driver.app.shell.search.perf_workers.values().any(|w| {
        let w = w.lock().unwrap();
        w.completed_at.is_none() && w.canceled_at.is_none()
    }) {
        assert!(quiesce.elapsed() < Duration::from_secs(5));
        thread::sleep(Duration::from_millis(1));
    }
    let workers = driver
        .app
        .shell
        .search
        .perf_workers
        .iter()
        .map(|(id, w)| (*id, w.lock().unwrap().clone()))
        .collect::<Vec<_>>();
    let genuine = workers
        .iter()
        .filter(|(_, w)| genuine_search_overlap(w, start, cutoff))
        .map(|(id, _)| *id)
        .collect::<HashSet<_>>();
    let bindings = &driver.app.shell.indexing.perf_search_bindings;
    let full_evaluations = workers
        .iter()
        .filter(|(id, w)| {
            genuine_search_overlap(w, start, cutoff)
                && w.evaluated_candidates == fixture.expected.len()
                && bindings.iter().any(|b| {
                    b.request_id == *id
                        && b.tab_id == tabs[0]
                        && b.root == fixture.root
                        && b.candidates == fixture.expected.len()
                        && Some(b.candidate_ptr) == stable_ptr
                        && b.at >= start
                })
        })
        .map(|(id, _)| *id)
        .collect::<HashSet<_>>();
    let query_executed = |query: &str| {
        bindings
            .iter()
            .any(|b| b.query == query && full_evaluations.contains(&b.request_id))
    };
    let aux = driver
        .app
        .shell
        .indexing
        .perf_aux
        .iter()
        .filter(|o| o.delivered_at.is_some())
        .map(|o| {
            let proof = DeliveredProof {
                dispatched: o.dispatched_at,
                delivered: o.delivered_at.unwrap(),
                owned_identity: tabs.contains(&o.tab_id),
                successful: o.successful,
                count: o.count,
            };
            (
                o.flow,
                proof.completed_while_unsettled(start, start + cutoff),
            )
        })
        .collect::<Vec<_>>();
    let aux_count = |flow| aux.iter().filter(|(f, ok)| *f == flow && *ok).count();
    let producers = ledger
        .iter()
        .filter_map(|r| {
            let o = r.observation();
            Some((
                r.tab,
                o.started_published?,
                o.data_publish_end?,
                o.entries_emitted,
            ))
        })
        .collect::<Vec<_>>();
    let concurrent_index_producers = producers.iter().enumerate().any(|(n, (tab, a, b, count))| {
        *count > 0
            && producers
                .iter()
                .skip(n + 1)
                .any(|(other, c, d, entries)| *entries > 0 && tab != other && a < d && c < b)
    });
    let index_input_progress = events
        .iter()
        .all(|e| e["GUI_ingested"].as_u64().unwrap_or(0) > 0);
    let sort_rx_completed = driver
        .app
        .shell
        .indexing
        .perf_aux
        .iter()
        .filter(|o| o.flow == "search-sort" && o.successful)
        .filter(|o| {
            o.delivered_at.is_some_and(|delivered| {
                workers.iter().any(|(id, w)| {
                    *id == o.request_id
                        && completed_search_sort(
                            w,
                            start,
                            o.dispatched_at,
                            delivered,
                            start + cutoff,
                            o.count,
                        )
                })
            })
        })
        .count();
    let eligible = !condition
        || match profile {
            Profile::StableSelective | Profile::StableDense => query_executed(profile.query(true)),
            Profile::StableEdit => {
                full_evaluations.len() >= 2 && query_executed("item") && query_executed("needle")
            }
            Profile::SearchIgnore => !genuine.is_empty(),
            Profile::EditFiles => genuine.len() >= 2,
            Profile::NameAll | Profile::ModifiedAll => sort_rx_completed > 0,
            Profile::ModifiedShown => aux_count("sort") > 0,
            Profile::Preview => aux_count("preview") > 0,
            Profile::Warm | Profile::WarmReclaim => concurrent_index_producers,
            Profile::Promotion => {
                concurrent_index_producers && events.len() == 2 && index_input_progress
            }
            Profile::TabChain => events.len() == 3 && index_input_progress && ledger.len() >= 4,
            Profile::NameShown => gui_sort_completions
                .iter()
                .any(|at| *at >= start && *at <= start + cutoff),
            _ => true,
        };
    if full {
        assert!(eligible,"actual operation must overlap GUI indexing {} {source:?}; workers={workers:?};aux={aux:?};cutoff={cutoff:?}",profile.name());
    }
    let p = ledger.iter().find(|r| r.id == primary).unwrap();
    let observation = p.observation();
    assert_eq!(observation.terminal_kind, Some("finished"));
    assert_eq!(
        observation.started_source,
        Some(source.name()),
        "own successful request source"
    );
    assert_eq!(
        observation.terminal_source,
        Some(source.name()),
        "own finished source"
    );
    if matches!(profile, Profile::NestedEarly | Profile::NestedLate) {
        assert_eq!(
            observation.replacements, 1,
            "nested override must publish real ReplaceAll"
        );
        assert_eq!(
            observation.nested_input_reused,
            Some(profile == Profile::NestedEarly),
            "actual nested reuse/reread branch"
        );
    }
    let records=ledger.iter().map(|r|{let o=r.observation();let planned_revocation=plans.iter().any(|p|p.id==r.id&&p.revoked_by.is_some());
        assert!(request_complete(&driver,r,&plans));
        assert!(planned_requests_valid(&plans, &proofs(&driver,&ledger,&plans,&roots,&tabs,source)), "unexpected index request graph/outcome");
        serde_json::json!({"request_id":r.id,"tab_id":r.tab,"allocated_ms":ms(r.allocated_at.duration_since(start)),"terminal_kind":o.terminal_kind,"allocation_observed":o.allocation_observed,"admitted_ms":o.admitted_at.map(|at|ms(at.duration_since(start))),"admitted_root_matches":o.admitted_root.as_ref()==Some(&roots[tabs.iter().position(|t|*t==r.tab).unwrap()].root),"actual_admitted_root":o.admitted_root,"actual_started_root":o.started_root,"expected_root":roots[tabs.iter().position(|t|*t==r.tab).unwrap()].root,"latest_generation_required":requires_latest_generation(&plans,r.id,r.tab),"skipped_closed_before_start":o.skipped_closed_before_start,"unsent_planned_discard":planned_unsent_discard(&o,plans.iter().find(|p|p.id==r.id).and_then(|p|p.permission_at),driver.app.shell.indexing.perf_released_requests.contains_key(&r.id)),"mailbox_closed_ms":o.mailbox_closed_at.map(|at|ms(at.duration_since(start))),"planned_revocation":planned_revocation,"completed_predecessor":plans.iter().find(|p|p.id==r.id).unwrap().completed_predecessor,"permission_ms":plans.iter().find(|p|p.id==r.id).unwrap().permission_at.map(|at|ms(at.duration_since(start))),"permission_reason":plans.iter().find(|p|p.id==r.id).unwrap().permission_reason,"planned_revoked_by":plans.iter().find(|p|p.id==r.id).unwrap().revoked_by,"mailbox_closed":o.mailbox_closed,"actual_terminal_offer_kind":o.terminal_offer_kind,"terminal_offer_error":o.terminal_offer_error,"terminal_offer_current":o.terminal_offer_current,"terminal_offered_ms":o.terminal_offered.map(|at|ms(at.duration_since(start))),"request_processing_returned_ms":o.request_processing_returned.map(|at|ms(at.duration_since(start))),"started_source":o.started_source,"terminal_source":o.terminal_source,"started_ms":o.started_published.map(|x|ms(x.duration_since(start))),"entries_emitted":o.entries_emitted,"batches":o.batches,"replacements":o.replacements,"data_publish_end_ms":o.data_publish_end.map(|x|ms(x.duration_since(start))),"terminal_publish_ms":o.terminal_published.map(|x|ms(x.duration_since(start))),"bookkeeping_released_ms":ms(driver.app.shell.indexing.perf_released_requests[&r.id].duration_since(start))})}).collect::<Vec<_>>();
    let binding_rows=bindings.iter().map(|b|serde_json::json!({"request_id":b.request_id,"tab_id":b.tab_id,"root_is_stable_A":b.root==fixture.root,"query":b.query,"candidate_count":b.candidates,"sort_mode":format!("{:?}",b.sort_mode),"sort_scope":format!("{:?}",b.sort_scope),"epoch":b.epoch,"candidate_is_initial_A":Some(b.candidate_ptr)==stable_ptr,"dispatched_ms":ms(b.at.duration_since(start)),"candidate_signature":if Some(b.candidate_ptr)==stable_ptr{Some(quiet_oracles[0].signature())}else{None}})).collect::<Vec<_>>();
    let aux_rows=driver.app.shell.indexing.perf_aux.iter().map(|o|serde_json::json!({"flow":o.flow,"request_id":o.request_id,"tab_id":o.tab_id,"epoch":o.epoch,"owned_tab_root":tabs.iter().position(|t|*t==o.tab_id).map(|n|roots[n].signature()),"path":o.path.as_ref().map(|p|p.strip_prefix(&roots[0].root).unwrap_or(p).to_string_lossy()),"count":o.count,"enqueue_or_dispatch_ms":ms(o.dispatched_at.duration_since(start)),"delivered_ms":o.delivered_at.map(|at|ms(at.duration_since(start))),"successful":o.successful,"route_outcome":o.route,"received_kind_epoch":o.received_kind_epoch,"strict_current_kind_epoch_matches":o.received_kind_epoch.map(|e|e==o.epoch)})).collect::<Vec<_>>();
    let worker_rows=workers.iter().map(|(id,w)|serde_json::json!({"request_id":id,"candidates":w.candidates,"evaluated_candidates":w.evaluated_candidates,"started_ms":w.started_at.map(|x|ms(x.duration_since(start))),"evaluation_completed_ms":w.evaluation_completed_at.map(|x|ms(x.duration_since(start))),"completed_ms":w.completed_at.map(|x|ms(x.duration_since(start))),"canceled_ms":w.canceled_at.map(|x|ms(x.duration_since(start))),"skipped_canceled":w.skipped_canceled})).collect::<Vec<_>>();
    let source_matches = |s: &IndexSource| {
        matches!(
            (source, s),
            (Source::FileList, IndexSource::FileList(_)) | (Source::Walker, IndexSource::Walker)
        )
    };
    assert!(source_matches(
        &driver.app.shell.indexing.build.index.source
    ));
    assert!(driver.app.shell.runtime.query_state.search_error.is_none());
    let snapshot = if profile.stable() {
        &driver
            .app
            .shell
            .tabs
            .get(1)
            .unwrap()
            .result_state
            .committed
            .all_entries
    } else {
        &driver.app.shell.runtime.all_entries
    };
    let mut row = serde_json::json!({"schema_version":1,"profile_family":"extension","source":source.name(),"comparison":profile.name(),"case":if condition{profile.name()}else{"B0"},"sample_entries":fixture.records.len(),"fixture_shape":format!("{:?}",fixture.shape),"fixture_signature":fixture.signature(),"request_id":primary,"index_ready_ms":ms(t2),"results_ready_ms":ms(t3),"data_publish_end_ms":ms(observation.data_publish_end.unwrap().duration_since(start)),"terminal_publish_ms":ms(observation.terminal_published.unwrap().duration_since(start)),"bookkeeping_released_ms":ms(driver.app.shell.indexing.perf_released_requests[&primary].duration_since(start)),"last_confirmed_snapshot_unsettled_ms":ms(cutoff),"max_no_work_progress_ms":ms(max_gap),"max_ingest_gap_ms":ms(max_ingest_gap),"max_frame_ms":ms(frame_max),"frames":frames,"correct":true,"contention_eligible":eligible,"snapshot_signature":actual_signature(&roots[target].root,snapshot),"results_signature":format!("{:016x}",signature(&roots[0].root,driver.app.shell.runtime.results.iter().map(|(p,_)|p))),"full_wait_ms":ms(observation.full_wait),"full_count":observation.full_retries,"blocked_batches":observation.blocked_batches,"batches":observation.batches,"entries_emitted":observation.entries_emitted});
    row.as_object_mut().unwrap().extend(serde_json::json!({"measurement_kind":"headless-GUI-actual-workers","comparison_kind":profile.comparison_kind(),"condition_description":profile.condition_description(condition),"driver_overhead_ms":ms(driver_overhead),"GUI_sort_completed_ms":gui_sort_completions.iter().map(|at|ms(at.duration_since(start))).collect::<Vec<_>>(),"search_dispatch_bindings":binding_rows,"nested_input_reused":observation.nested_input_reused,"initial_state":initial,"input_trace":events,"tab_transition_trace":transition_events,"index_requests":records,"unmeasured_tab_observations":unmeasured_tab_observations,"allocated_request_ids":allocated,"planned_request_ids":planned,"released_request_ids":released,"worker_observations":worker_rows,"overlap_executions":genuine.len(),"index_sender_load_at_t2":{"queued":t2_load.as_ref().unwrap().queued,"inflight":t2_load.as_ref().unwrap().inflight,"capacity":t2_load.as_ref().unwrap().capacity},"final_index_sender_load":{"queued":driver.app.shell.indexing.tx.load().queued,"inflight":driver.app.shell.indexing.tx.load().inflight,"capacity":driver.app.shell.indexing.tx.load().capacity},"search_sort_worker_completed_while_index_unsettled":sort_rx_completed,"full_candidate_evaluations":full_evaluations.len(),"actual_index_producer_interval_overlap":concurrent_index_producers,"aux_completed_while_index_unsettled":{"kind":aux_count("kind"),"sort":aux_count("sort"),"preview":aux_count("preview")},"aux_observations":aux_rows,"aux_observer_limit_per_flow":256,"aux_known_flows":["kind","sort","preview","search-sort"],"strict_kind_sort_preview_cpu_duration":"NOT_OBSERVED","aux_proof_counts":"sampled-owned-successful-received; search-sort may route Background/Stale","settings":{"files":filter.files,"folders":filter.dirs,"ignore_enabled":filter.ignore_enabled,"ignore_case":filter.ignore_case,"sort_mode":format!("{mode:?}"),"sort_scope":format!("{scope:?}"),"query":profile.query(condition),"follow_links":profile==Profile::Links},"expected_final_logical_entries":roots[target].expected.iter().filter(|r|if r.is_dir{filter.dirs}else{filter.files}).count(),"expected_query_match_count":expected.expected_count(),"intended_extra_index_requests":if condition&&matches!(profile,Profile::Warm|Profile::Promotion|Profile::WarmReclaim){1}else{0},"native":false}).as_object().unwrap().clone());
    drop(driver);
    drop(roots);
    drop(generations);
    row
}

#[test]
fn tc_229_observation_ledger_does_not_pin_closed_heavy_mailbox() {
    if crate::app::tests::indexing_perf::harness::child_process::isolate(
        module_path!(),
        "tc_229_observation_ledger_does_not_pin_closed_heavy_mailbox",
    ) {
        return;
    }
    let mut driver = Driver::new();
    driver.settle_startup();
    driver.app.shell.indexing.perf_observe_requests = true;
    driver.app.shell.indexing.perf_observe_history = true;
    let tab = driver.app.current_tab_id();
    let id = driver.app.shell.indexing.allocate_request_id(tab);
    let mailbox = driver.mailbox(id);
    mailbox
        .try_publish(crate::app::worker::protocol::IndexResponse::Batch {
            request_id: id,
            entries: vec![
                crate::app::worker::protocol::IndexEntry {
                    path: driver.app.shell.runtime.root.join("owned-heavy.txt"),
                    kind: crate::entry::EntryKind::file(),
                    kind_known: true
                };
                1024
            ],
        })
        .unwrap();
    let mut ledger = Vec::new();
    collect_requests(&driver, &mut ledger);
    let weak = Arc::downgrade(&mailbox);
    driver.app.shell.indexing.cleanup_request(id);
    drop(mailbox);
    assert!(
        weak.upgrade().is_none(),
        "observations must not retain unconsumed Batch payload through closed mailbox"
    );
    assert_eq!(ledger.len(), 1);
}
