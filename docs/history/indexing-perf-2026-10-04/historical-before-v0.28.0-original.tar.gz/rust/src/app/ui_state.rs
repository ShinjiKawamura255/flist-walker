use super::{SavedWindowGeometry, TabDragState};
use eframe::egui;
use std::time::Instant;

pub(super) struct RuntimeUiState {
    pub(super) search_assist: super::search_assist::SearchAssist,
    pub(super) selection_inspector: Option<super::selection_ux::SelectionInspector>,
    pub(super) pending_copy_shortcut: bool,
    pub(super) root_dropdown_highlight: Option<usize>,
    pub(super) scroll_to_current: bool,
    pub(super) preview_resize_in_progress: bool,
    pub(super) focus_query_requested: bool,
    pub(super) unfocus_query_requested: bool,
    pub(super) query_cursor_to_end_requested: bool,
    pub(super) show_preview: bool,
    pub(super) help_open: bool,
    pub(super) ignore_list_enabled: bool,
    pub(super) preview_panel_width: f32,
    pub(super) window_geometry: Option<SavedWindowGeometry>,
    pub(super) pending_window_geometry: Option<SavedWindowGeometry>,
    pub(super) last_window_geometry_change: Instant,
    pub(super) ui_state_dirty: bool,
    pub(super) last_ui_state_save: Instant,
    pub(super) last_memory_sample: Instant,
    pub(super) memory_usage_bytes: Option<u64>,
    pub(super) ime_composition_active: bool,
    pub(super) prev_space_down: bool,
    pub(super) query_input_id: egui::Id,
    pub(super) tab_drag_state: Option<TabDragState>,
    pub(super) pending_render_commands: Vec<super::render::RenderCommand>,
    pub(super) cjk_font_applied: bool,
    pub(super) max_depth_draft: usize,
}

impl RuntimeUiState {
    pub(super) fn new(
        show_preview: bool,
        ignore_list_enabled: bool,
        preview_panel_width: f32,
    ) -> Self {
        Self {
            search_assist: Default::default(),
            selection_inspector: None,
            pending_copy_shortcut: false,
            root_dropdown_highlight: None,
            scroll_to_current: true,
            preview_resize_in_progress: false,
            focus_query_requested: true,
            unfocus_query_requested: false,
            query_cursor_to_end_requested: false,
            show_preview,
            help_open: false,
            preview_panel_width,
            window_geometry: None,
            pending_window_geometry: None,
            last_window_geometry_change: Instant::now(),
            ui_state_dirty: false,
            last_ui_state_save: Instant::now(),
            last_memory_sample: Instant::now(),
            memory_usage_bytes: None,
            ime_composition_active: false,
            prev_space_down: false,
            query_input_id: egui::Id::new("query-input"),
            tab_drag_state: None,
            pending_render_commands: Vec::new(),
            ignore_list_enabled,
            cjk_font_applied: false,
            max_depth_draft: 0,
        }
    }

    pub(super) fn show_preview(&self) -> bool {
        self.show_preview
    }

    pub(super) fn set_show_preview(&mut self, show_preview: bool) {
        self.show_preview = show_preview;
    }

    #[cfg(test)]
    pub(super) fn ignore_list_enabled(&self) -> bool {
        self.ignore_list_enabled
    }

    #[cfg(test)]
    pub(super) fn set_ignore_list_enabled(&mut self, value: bool) {
        self.ignore_list_enabled = value;
    }

    pub(super) fn preview_panel_width(&self) -> f32 {
        self.preview_panel_width
    }

    pub(super) fn set_preview_panel_width(&mut self, width: f32) {
        self.preview_panel_width = width;
    }

    pub(super) fn preview_resize_in_progress(&self) -> bool {
        self.preview_resize_in_progress
    }

    pub(super) fn set_preview_resize_in_progress(&mut self, value: bool) {
        self.preview_resize_in_progress = value;
    }

    pub(super) fn scroll_to_current(&self) -> bool {
        self.scroll_to_current
    }

    pub(super) fn root_dropdown_highlight(&self) -> Option<usize> {
        self.root_dropdown_highlight
    }

    pub(super) fn set_root_dropdown_highlight(&mut self, value: Option<usize>) {
        self.root_dropdown_highlight = value;
    }

    pub(super) fn query_input_id(&self) -> egui::Id {
        self.query_input_id
    }

    pub(super) fn focus_query_requested(&self) -> bool {
        self.focus_query_requested
    }

    pub(super) fn unfocus_query_requested(&self) -> bool {
        self.unfocus_query_requested
    }
}
