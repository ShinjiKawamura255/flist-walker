use super::FlistWalkerApp;
use crate::fs_atomic::acquire_sidecar_lock;
use crate::fs_atomic::{atomic_write_replaced_destination, write_bytes_atomic, write_text_atomic};
use crate::path_utils::{normalize_windows_path_buf, path_key};
#[cfg(not(test))]
use crate::runtime_config::settings_base_dir;
use crate::runtime_config::{legacy_settings_base_dirs, migrate_file_if_needed};
use eframe::egui;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::HashSet;
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::mpsc::{self, Sender};
use std::sync::{Mutex, OnceLock};
use std::thread;
use std::time::{Duration, Instant};

static UI_STATE_PERSISTENCE: OnceLock<Mutex<UiStatePersistenceRegistry>> = OnceLock::new();

const UI_STATE_PERSISTENCE_RETRY_DELAY: Duration = Duration::from_millis(50);
const UI_STATE_PERSISTENCE_LOCK_TIMEOUT: Duration = Duration::from_millis(250);

#[derive(Clone, Debug)]
pub(super) struct UiStatePatch(Value);

impl Default for UiStatePatch {
    fn default() -> Self {
        Self(Value::Object(Default::default()))
    }
}

impl UiStatePatch {
    pub(super) fn from_json(value: Value) -> Self {
        Self(if value.is_object() {
            value
        } else {
            Value::Object(Default::default())
        })
    }

    fn from_ui_state(state: &UiState) -> Self {
        Self::from_json(
            serde_json::to_value(state).unwrap_or_else(|_| Value::Object(Default::default())),
        )
    }

    fn without_history(mut self) -> Self {
        if let Value::Object(map) = &mut self.0 {
            map.remove("query_history");
        }
        self
    }
}

#[derive(Clone)]
struct PendingUiStateWrite {
    generation: u64,
    patch: UiStatePatch,
    history_delta: Vec<String>,
}

enum UiStatePersistenceCommand {
    Enqueue {
        patch: UiStatePatch,
        history_delta: Vec<String>,
    },
    CommitSettings {
        request: SettingsCommitRequest,
        response: Sender<SettingsCommitResponse>,
    },
    Flush(Sender<Result<(), String>>),
    Shutdown(Sender<Result<(), String>>),
}

pub(super) struct SettingsCommitRequest {
    pub(super) request_id: u64,
    pub(super) patch: UiStatePatch,
    pub(super) saved_roots: Option<(PathBuf, String)>,
}

pub(super) struct SettingsCommitReceipt {
    pub(super) canonical_default_root: Option<PathBuf>,
}

pub(super) struct SettingsCommitResponse {
    pub(super) request_id: u64,
    pub(super) result: Result<SettingsCommitReceipt, String>,
}

pub struct AsyncHistoryPersistence {
    tx: Sender<UiStatePersistenceCommand>,
    history_persist_disabled: bool,
    handle: Mutex<Option<thread::JoinHandle<()>>>,
}

impl AsyncHistoryPersistence {
    pub fn new_default() -> Option<Self> {
        let path = FlistWalkerApp::ui_state_file_path()?;
        Some(Self::new(path, FlistWalkerApp::history_persist_disabled()))
    }

    pub fn new(path: PathBuf, history_persist_disabled: bool) -> Self {
        Self::new_with_lock_timeout(
            path,
            history_persist_disabled,
            UI_STATE_PERSISTENCE_LOCK_TIMEOUT,
        )
    }

    fn new_with_lock_timeout(
        path: PathBuf,
        history_persist_disabled: bool,
        lock_timeout: Duration,
    ) -> Self {
        let (tx, rx) = mpsc::channel();
        let handle = thread::spawn(move || {
            run_ui_state_persistence_worker(rx, path, history_persist_disabled, lock_timeout)
        });
        Self {
            tx,
            history_persist_disabled,
            handle: Mutex::new(Some(handle)),
        }
    }

    pub fn enqueue_history(&self, history_delta: Vec<String>) -> Result<(), String> {
        if self.history_persist_disabled {
            return Ok(());
        }
        self.tx
            .send(UiStatePersistenceCommand::Enqueue {
                patch: UiStatePatch::default(),
                history_delta: normalize_history_delta(history_delta),
            })
            .map_err(|_| "UI-state persistence worker is unavailable".to_string())
    }

    pub fn flush(&self, timeout: Duration) -> Result<(), String> {
        let (tx, rx) = mpsc::channel();
        self.tx
            .send(UiStatePersistenceCommand::Flush(tx))
            .map_err(|_| "UI-state persistence worker is unavailable".to_string())?;
        rx.recv_timeout(timeout)
            .map_err(|_| "UI-state persistence flush timed out".to_string())?
    }

    pub fn shutdown(self, timeout: Duration) -> Result<(), String> {
        let (tx, rx) = mpsc::channel();
        self.tx
            .send(UiStatePersistenceCommand::Shutdown(tx))
            .map_err(|_| "UI-state persistence worker is unavailable".to_string())?;
        let result = rx
            .recv_timeout(timeout)
            .map_err(|_| "UI-state persistence shutdown timed out".to_string())?;
        result?;
        let Some(handle) = self.handle.lock().ok().and_then(|mut handle| handle.take()) else {
            return Ok(());
        };
        let (joined_tx, joined_rx) = mpsc::channel();
        thread::spawn(move || {
            let _ =
                joined_tx.send(handle.join().map_err(|_| {
                    "UI-state persistence worker panicked during shutdown".to_string()
                }));
        });
        joined_rx
            .recv_timeout(timeout)
            .map_err(|_| "UI-state persistence worker join timed out".to_string())?
    }

    #[cfg(test)]
    fn enqueue_patch_for_test(&self, patch: UiStatePatch, history_delta: Vec<String>) {
        let _ = self.tx.send(UiStatePersistenceCommand::Enqueue {
            patch,
            history_delta: normalize_history_delta(history_delta),
        });
    }
}

#[derive(Default)]
struct UiStatePersistenceRegistry {
    senders: std::collections::HashMap<PathBuf, Sender<UiStatePersistenceCommand>>,
    history_snapshots: std::collections::HashMap<PathBuf, Vec<String>>,
}

fn ui_state_persistence_registry() -> &'static Mutex<UiStatePersistenceRegistry> {
    UI_STATE_PERSISTENCE.get_or_init(|| Mutex::new(UiStatePersistenceRegistry::default()))
}

fn spawn_detached_ui_state_persistence_worker(
    path: PathBuf,
    history_persist_disabled: bool,
) -> Sender<UiStatePersistenceCommand> {
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        run_ui_state_persistence_worker(
            rx,
            path,
            history_persist_disabled,
            UI_STATE_PERSISTENCE_LOCK_TIMEOUT,
        )
    });
    tx
}

fn enqueue_ui_state_patch(
    path: PathBuf,
    patch: UiStatePatch,
    history_snapshot: Vec<String>,
    history_persist_disabled: bool,
) {
    let Ok(mut registry) = ui_state_persistence_registry().lock() else {
        return;
    };
    let history_delta = if history_persist_disabled {
        Vec::new()
    } else {
        let history_snapshot = normalize_history_recency(history_snapshot);
        let previous = registry.history_snapshots.entry(path.clone()).or_default();
        let delta = history_delta_from_snapshot(previous, &history_snapshot);
        *previous = history_snapshot;
        delta
    };
    let sender = registry
        .senders
        .entry(path.clone())
        .or_insert_with(|| {
            spawn_detached_ui_state_persistence_worker(path.clone(), history_persist_disabled)
        })
        .clone();
    drop(registry);
    let _ = sender.send(UiStatePersistenceCommand::Enqueue {
        patch: patch.without_history(),
        history_delta,
    });
}

fn persistence_sender_for_path(
    path: PathBuf,
    history_persist_disabled: bool,
) -> Result<Sender<UiStatePersistenceCommand>, String> {
    let mut registry = ui_state_persistence_registry()
        .lock()
        .map_err(|_| "UI-state persistence registry is unavailable".to_string())?;
    Ok(registry
        .senders
        .entry(path.clone())
        .or_insert_with(|| {
            spawn_detached_ui_state_persistence_worker(path, history_persist_disabled)
        })
        .clone())
}

pub(super) fn enqueue_settings_commit(
    ui_state_path: PathBuf,
    history_persist_disabled: bool,
    request: SettingsCommitRequest,
) -> Result<mpsc::Receiver<SettingsCommitResponse>, String> {
    let sender = persistence_sender_for_path(ui_state_path, history_persist_disabled)?;
    let (response_tx, response_rx) = mpsc::channel();
    sender
        .send(UiStatePersistenceCommand::CommitSettings {
            request,
            response: response_tx,
        })
        .map_err(|_| "UI-state persistence worker is unavailable".to_string())?;
    Ok(response_rx)
}

fn flush_ui_state_persistence(path: &Path, timeout: Duration) {
    let sender = ui_state_persistence_registry()
        .lock()
        .ok()
        .and_then(|registry| registry.senders.get(path).cloned());
    let Some(sender) = sender else {
        return;
    };
    let (tx, rx) = mpsc::channel();
    if sender.send(UiStatePersistenceCommand::Flush(tx)).is_ok() {
        let _ = rx.recv_timeout(timeout);
    }
}

#[cfg(test)]
fn shutdown_ui_state_persistence_for_test(path: &Path, timeout: Duration) {
    let sender = ui_state_persistence_registry()
        .lock()
        .ok()
        .and_then(|mut registry| {
            registry.history_snapshots.remove(path);
            registry.senders.remove(path)
        });
    let Some(sender) = sender else {
        return;
    };
    let (tx, rx) = mpsc::channel();
    if sender.send(UiStatePersistenceCommand::Shutdown(tx)).is_ok() {
        let _ = rx.recv_timeout(timeout);
    }
}

fn run_ui_state_persistence_worker(
    rx: mpsc::Receiver<UiStatePersistenceCommand>,
    path: PathBuf,
    history_persist_disabled: bool,
    lock_timeout: Duration,
) {
    let mut next_generation = 1u64;
    let mut pending = Vec::<PendingUiStateWrite>::new();
    loop {
        let command = rx.recv_timeout(UI_STATE_PERSISTENCE_RETRY_DELAY);
        let mut flush_reply = None;
        let mut shutdown_reply = None;
        let mut settings_commit = None;
        let mut disconnected = false;
        match command {
            Ok(UiStatePersistenceCommand::Enqueue {
                patch,
                history_delta,
            }) => {
                push_pending_ui_state_write(
                    &mut pending,
                    &mut next_generation,
                    patch,
                    history_delta,
                );
            }
            Ok(UiStatePersistenceCommand::CommitSettings { request, response }) => {
                settings_commit = Some((request, response));
            }
            Ok(UiStatePersistenceCommand::Flush(reply)) => flush_reply = Some(reply),
            Ok(UiStatePersistenceCommand::Shutdown(reply)) => shutdown_reply = Some(reply),
            Err(mpsc::RecvTimeoutError::Timeout) => {}
            Err(mpsc::RecvTimeoutError::Disconnected) => disconnected = true,
        }
        if flush_reply.is_none()
            && shutdown_reply.is_none()
            && settings_commit.is_none()
            && !disconnected
        {
            while let Ok(command) = rx.try_recv() {
                match command {
                    UiStatePersistenceCommand::Enqueue {
                        patch,
                        history_delta,
                    } => push_pending_ui_state_write(
                        &mut pending,
                        &mut next_generation,
                        patch,
                        history_delta,
                    ),
                    UiStatePersistenceCommand::CommitSettings { request, response } => {
                        settings_commit = Some((request, response));
                        break;
                    }
                    UiStatePersistenceCommand::Flush(reply) => {
                        flush_reply = Some(reply);
                        break;
                    }
                    UiStatePersistenceCommand::Shutdown(reply) => {
                        shutdown_reply = Some(reply);
                        break;
                    }
                }
            }
        }
        let result = if let Some((request, response)) = settings_commit {
            let request_id = request.request_id;
            let result = commit_settings(
                &path,
                &pending,
                history_persist_disabled,
                lock_timeout,
                request,
            )
            .map_err(|error| error.to_string());
            if result.is_ok() {
                pending.clear();
            }
            let _ = response.send(SettingsCommitResponse { request_id, result });
            Ok(())
        } else if pending.is_empty() {
            Ok(())
        } else {
            write_pending_ui_state(&path, &pending, history_persist_disabled, lock_timeout)
                .map(|_| pending.clear())
                .map_err(|error| error.to_string())
        };
        if let Some(reply) = flush_reply {
            let _ = reply.send(result.clone());
        }
        if let Some(reply) = shutdown_reply {
            let _ = reply.send(result);
            break;
        }
        if disconnected {
            break;
        }
    }
}

fn build_ui_state_document(
    path: &Path,
    pending: &[PendingUiStateWrite],
    extra_patch: Option<&UiStatePatch>,
    history_persist_disabled: bool,
) -> std::io::Result<Value> {
    let mut document = fs::read_to_string(path)
        .ok()
        .and_then(|text| serde_json::from_str::<Value>(&text).ok())
        .filter(Value::is_object)
        .unwrap_or_else(|| Value::Object(Default::default()));
    for write in pending {
        merge_json_leaves(&mut document, &write.patch.0);
    }
    if let Some(patch) = extra_patch {
        merge_json_leaves(&mut document, &patch.0);
    }
    if !history_persist_disabled {
        let history = document
            .get("query_history")
            .and_then(Value::as_array)
            .map(|values| {
                values
                    .iter()
                    .filter_map(Value::as_str)
                    .map(ToOwned::to_owned)
                    .collect::<Vec<_>>()
            })
            .unwrap_or_default();
        let mut history = normalize_history_recency(history);
        for delta in pending.iter().flat_map(|write| write.history_delta.iter()) {
            append_history_delta(&mut history, delta.clone());
        }
        if let Value::Object(map) = &mut document {
            map.insert(
                "query_history".to_string(),
                Value::Array(history.into_iter().map(Value::String).collect()),
            );
        }
    }
    canonicalize_last_root_for_persistence(&mut document);
    canonicalize_default_root_for_persistence(&mut document);
    Ok(document)
}

fn commit_settings(
    ui_state_path: &Path,
    pending: &[PendingUiStateWrite],
    history_persist_disabled: bool,
    lock_timeout: Duration,
    request: SettingsCommitRequest,
) -> std::io::Result<SettingsCommitReceipt> {
    commit_settings_with_writer(
        ui_state_path,
        pending,
        history_persist_disabled,
        lock_timeout,
        request,
        write_bytes_atomic,
    )
}

fn commit_settings_with_writer<W>(
    ui_state_path: &Path,
    pending: &[PendingUiStateWrite],
    history_persist_disabled: bool,
    lock_timeout: Duration,
    request: SettingsCommitRequest,
    mut write_atomic: W,
) -> std::io::Result<SettingsCommitReceipt>
where
    W: FnMut(&Path, &[u8]) -> std::io::Result<()>,
{
    let _lock = acquire_sidecar_lock(ui_state_path, lock_timeout)?;
    let ui_state_previous = read_optional_file(ui_state_path)?;
    let document = build_ui_state_document(
        ui_state_path,
        pending,
        Some(&request.patch),
        history_persist_disabled,
    )?;
    let serialized = serde_json::to_string_pretty(&document).map_err(std::io::Error::other)?;
    let canonical_default_root = document
        .get("default_root")
        .and_then(Value::as_str)
        .filter(|value| !value.is_empty())
        .map(PathBuf::from)
        .map(normalize_windows_path_buf);

    let mut roots_rollback = None;
    if let Some((roots_path, roots_text)) = request.saved_roots.as_ref() {
        let previous = read_optional_file(roots_path)?;
        if let Err(error) = write_atomic(roots_path, roots_text.as_bytes()) {
            if atomic_write_replaced_destination(&error) {
                if let Err(rollback_error) =
                    restore_atomic_target(roots_path, previous.as_deref(), &mut write_atomic)
                {
                    return Err(std::io::Error::other(format!(
                        "{error}; saved-roots rollback failed: {rollback_error}"
                    )));
                }
            }
            return Err(error);
        }
        roots_rollback = Some((roots_path, previous));
    }

    if let Err(error) = write_atomic(ui_state_path, serialized.as_bytes()) {
        let mut rollback_errors = Vec::new();
        if atomic_write_replaced_destination(&error) {
            if let Err(rollback_error) = restore_atomic_target(
                ui_state_path,
                ui_state_previous.as_deref(),
                &mut write_atomic,
            ) {
                rollback_errors.push(format!("UI-state rollback failed: {rollback_error}"));
            }
        }
        if let Some((roots_path, previous)) = roots_rollback {
            if let Err(rollback_error) =
                restore_atomic_target(roots_path, previous.as_deref(), &mut write_atomic)
            {
                rollback_errors.push(format!("saved-roots rollback failed: {rollback_error}"));
            }
        }
        if !rollback_errors.is_empty() {
            return Err(std::io::Error::other(format!(
                "{error}; {}",
                rollback_errors.join("; ")
            )));
        }
        return Err(error);
    }

    Ok(SettingsCommitReceipt {
        canonical_default_root,
    })
}

fn read_optional_file(path: &Path) -> std::io::Result<Option<Vec<u8>>> {
    match fs::read(path) {
        Ok(bytes) => Ok(Some(bytes)),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(None),
        Err(error) => Err(error),
    }
}

fn restore_atomic_target<W>(
    path: &Path,
    previous: Option<&[u8]>,
    write_atomic: &mut W,
) -> std::io::Result<()>
where
    W: FnMut(&Path, &[u8]) -> std::io::Result<()>,
{
    match previous {
        Some(bytes) => write_atomic(path, bytes),
        None => fs::remove_file(path).or_else(|error| {
            if error.kind() == std::io::ErrorKind::NotFound {
                Ok(())
            } else {
                Err(error)
            }
        }),
    }
}

fn push_pending_ui_state_write(
    pending: &mut Vec<PendingUiStateWrite>,
    next_generation: &mut u64,
    patch: UiStatePatch,
    history_delta: Vec<String>,
) {
    pending.push(PendingUiStateWrite {
        generation: *next_generation,
        patch,
        history_delta,
    });
    *next_generation = next_generation.saturating_add(1);
}

fn write_pending_ui_state(
    path: &Path,
    pending: &[PendingUiStateWrite],
    history_persist_disabled: bool,
    lock_timeout: Duration,
) -> std::io::Result<()> {
    debug_assert!(pending
        .windows(2)
        .all(|writes| writes[0].generation < writes[1].generation));
    let _lock = acquire_sidecar_lock(path, lock_timeout)?;
    let document = build_ui_state_document(path, pending, None, history_persist_disabled)?;
    let text = serde_json::to_string_pretty(&document).map_err(std::io::Error::other)?;
    write_text_atomic(path, &text)
}

fn canonicalize_last_root_for_persistence(document: &mut Value) {
    let Some(last_root) = document
        .get("last_root")
        .and_then(Value::as_str)
        .filter(|value| !value.is_empty())
    else {
        return;
    };
    let canonical = PathBuf::from(last_root)
        .canonicalize()
        .unwrap_or_else(|_| PathBuf::from(last_root));
    if let Value::Object(map) = document {
        map.insert(
            "last_root".to_string(),
            Value::String(canonical.to_string_lossy().to_string()),
        );
    }
}

fn canonicalize_default_root_for_persistence(document: &mut Value) {
    let Some(default_root) = document
        .get("default_root")
        .and_then(Value::as_str)
        .filter(|value| !value.is_empty())
    else {
        return;
    };
    let canonical = PathBuf::from(default_root)
        .canonicalize()
        .unwrap_or_else(|_| PathBuf::from(default_root));
    if let Value::Object(map) = document {
        map.insert(
            "default_root".to_string(),
            Value::String(canonical.to_string_lossy().to_string()),
        );
    }
}

fn merge_json_leaves(target: &mut Value, patch: &Value) {
    match (target, patch) {
        (Value::Object(target), Value::Object(patch)) => {
            for (key, value) in patch {
                match target.get_mut(key) {
                    Some(existing) => merge_json_leaves(existing, value),
                    None => {
                        target.insert(key.clone(), value.clone());
                    }
                }
            }
        }
        (Value::Array(target), Value::Array(patch)) => {
            for (index, value) in patch.iter().enumerate() {
                if let Some(existing) = target.get_mut(index) {
                    merge_json_leaves(existing, value);
                } else {
                    target.push(value.clone());
                }
            }
            target.truncate(patch.len());
        }
        (target, patch) => *target = patch.clone(),
    }
}

fn normalize_history_delta(values: Vec<String>) -> Vec<String> {
    values
        .into_iter()
        .map(|value| value.trim().to_string())
        .filter(|value| !value.is_empty())
        .collect()
}

fn normalize_history_recency(values: Vec<String>) -> Vec<String> {
    let mut normalized = Vec::new();
    for value in normalize_history_delta(values) {
        append_history_delta(&mut normalized, value);
    }
    normalized
}

fn append_history_delta(history: &mut Vec<String>, delta: String) {
    history.retain(|existing| existing != &delta);
    history.push(delta);
    if history.len() > FlistWalkerApp::QUERY_HISTORY_MAX {
        let trim = history.len() - FlistWalkerApp::QUERY_HISTORY_MAX;
        history.drain(..trim);
    }
}

fn history_delta_from_snapshot(previous: &[String], current: &[String]) -> Vec<String> {
    let current = normalize_history_recency(current.to_vec());
    for start in (0..=current.len()).rev() {
        let mut replayed = normalize_history_recency(previous.to_vec());
        for delta in &current[start..] {
            append_history_delta(&mut replayed, delta.clone());
        }
        if replayed == current {
            return current[start..].to_vec();
        }
    }
    current
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub(super) enum TabAccentColor {
    Teal,
    Indigo,
    Azure,
    Amber,
    Olive,
    Emerald,
    Crimson,
    Magenta,
}

/// Startup placement resolved against physical monitor rectangles.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct StartupWindowPlacement {
    pub physical_position: Option<egui::Pos2>,
    pub logical_size: egui::Vec2,
    pub scale_factor: f32,
}

#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
pub(super) struct SavedWindowGeometry {
    pub(super) x: f32,
    pub(super) y: f32,
    pub(super) width: f32,
    pub(super) height: f32,
    pub(super) monitor_width: Option<f32>,
    pub(super) monitor_height: Option<f32>,
    #[serde(default)]
    pub(super) pixels_per_point: Option<f32>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub(super) struct UiState {
    pub(super) last_root: Option<String>,
    pub(super) default_root: Option<String>,
    pub(super) show_preview: Option<bool>,
    #[serde(default = "default_ignore_list_enabled")]
    pub(super) ignore_list_enabled: bool,
    pub(super) preview_panel_width: Option<f32>,
    #[serde(default)]
    pub(super) query_history: Vec<String>,
    #[serde(default)]
    pub(super) results_panel_width: Option<f32>,
    #[serde(default)]
    pub(super) tabs: Vec<SavedTabState>,
    pub(super) active_tab: Option<usize>,
    pub(super) window: Option<SavedWindowGeometry>,
    #[serde(default)]
    pub(super) skipped_update_target_version: Option<String>,
    #[serde(default)]
    pub(super) suppress_update_check_failure_dialog: bool,
}

impl Default for UiState {
    fn default() -> Self {
        Self {
            last_root: None,
            default_root: None,
            show_preview: None,
            ignore_list_enabled: true,
            preview_panel_width: None,
            query_history: Vec::new(),
            results_panel_width: None,
            tabs: Vec::new(),
            active_tab: None,
            window: None,
            skipped_update_target_version: None,
            suppress_update_check_failure_dialog: false,
        }
    }
}

#[derive(Clone, Debug, Default)]
pub(super) struct LaunchSettings {
    pub(super) last_root: Option<PathBuf>,
    pub(super) default_root: Option<PathBuf>,
    pub(super) show_preview: bool,
    pub(super) ignore_list_enabled: bool,
    pub(super) preview_panel_width: f32,
    pub(super) query_history: Vec<String>,
    pub(super) restore_tabs: Vec<SavedTabState>,
    pub(super) restore_active_tab: Option<usize>,
    pub(super) skipped_update_target_version: Option<String>,
    pub(super) suppress_update_check_failure_dialog: bool,
    #[cfg(test)]
    pub(super) test_settings_paths: Option<super::TestSettingsPaths>,
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct PersistedRootsAndHistory {
    pub last_root: Option<PathBuf>,
    pub default_root: Option<PathBuf>,
    pub saved_roots: Vec<PathBuf>,
    pub query_history: Vec<String>,
}

/// Reports whether query-history persistence is enabled for the current process.
/// Consumers use this before starting an interactive session so the terminal loop
/// never needs to inspect configuration or acquire persistence locks.
pub fn history_persistence_enabled() -> bool {
    !FlistWalkerApp::history_persist_disabled()
}

pub fn load_persisted_roots_and_history() -> PersistedRootsAndHistory {
    let ui_state = FlistWalkerApp::load_ui_state();
    let saved_roots = FlistWalkerApp::load_saved_roots();
    persisted_roots_and_history_from_ui_state(
        ui_state,
        saved_roots,
        FlistWalkerApp::history_persist_disabled(),
    )
}

pub fn load_persisted_roots_and_history_from_paths(
    ui_state_path: &Path,
    saved_roots_path: &Path,
    history_persist_disabled: bool,
) -> PersistedRootsAndHistory {
    persisted_roots_and_history_from_ui_state(
        FlistWalkerApp::read_ui_state_from_path(ui_state_path),
        read_saved_roots_from_path(saved_roots_path),
        history_persist_disabled,
    )
}

fn persisted_roots_and_history_from_ui_state(
    ui_state: UiState,
    saved_roots: Vec<PathBuf>,
    history_persist_disabled: bool,
) -> PersistedRootsAndHistory {
    PersistedRootsAndHistory {
        last_root: ui_state
            .last_root
            .map(PathBuf::from)
            .map(normalize_windows_path_buf),
        default_root: ui_state
            .default_root
            .map(PathBuf::from)
            .map(normalize_windows_path_buf),
        saved_roots,
        query_history: if history_persist_disabled {
            Vec::new()
        } else {
            ui_state
                .query_history
                .into_iter()
                .rev()
                .take(FlistWalkerApp::QUERY_HISTORY_MAX)
                .collect::<Vec<_>>()
                .into_iter()
                .rev()
                .collect()
        },
    }
}

#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub(super) struct SavedTabState {
    pub(super) root: String,
    pub(super) use_filelist: bool,
    pub(super) use_regex: bool,
    #[serde(default = "default_ignore_case")]
    pub(super) ignore_case: bool,
    pub(super) include_files: bool,
    pub(super) include_dirs: bool,
    #[serde(default)]
    pub(super) max_depth: crate::indexer::MaxDepth,
    #[serde(default)]
    pub(super) follow_links: bool,
    pub(super) query: String,
    #[serde(default)]
    pub(super) query_history: Vec<String>,
    #[serde(default)]
    pub(super) tab_accent: Option<TabAccentColor>,
}

fn default_ignore_case() -> bool {
    true
}

fn default_ignore_list_enabled() -> bool {
    true
}

impl FlistWalkerApp {
    pub(super) const SET_DEFAULT_DISABLED_BY_RESTORE_TABS_NOTICE: &'static str =
        "Set as default is unavailable while Restore Tabs is enabled because the last session takes priority at startup.";
    pub(super) const SET_DEFAULT_DISABLED_BY_RESTORE_TABS_TOOLTIP: &'static str =
        "Unavailable while Restore Tabs is enabled. The last session takes priority at startup, so the default root is not used.";

    pub(super) fn persist_state_and_shutdown(&mut self, phase: &str) {
        self.apply_stable_window_geometry(true);
        self.shell.ui.ui_state_dirty = true;
        if self.settings_commit_in_progress() {
            if let Some(path) = self.persistence_ui_state_file_path() {
                flush_ui_state_persistence(&path, Self::WORKER_JOIN_TIMEOUT);
            }
            self.poll_settings_commit_response();
        }
        self.maybe_save_ui_state(true);
        if let Some(path) = self.persistence_ui_state_file_path() {
            flush_ui_state_persistence(&path, Self::WORKER_JOIN_TIMEOUT);
        }
        let _ = self.shutdown_workers_with_timeout(Self::WORKER_JOIN_TIMEOUT, phase);
        Self::shutdown_window_trace(Self::WORKER_JOIN_TIMEOUT);
        #[cfg(test)]
        if let Some(path) = self.persistence_ui_state_file_path() {
            shutdown_ui_state_persistence_for_test(&path, Self::WORKER_JOIN_TIMEOUT);
        }
    }

    pub(super) fn ui_state_file_path() -> Option<PathBuf> {
        #[cfg(test)]
        {
            None
        }
        #[cfg(not(test))]
        {
            settings_base_dir().map(|base| Self::ui_state_file_path_in(&base))
        }
    }

    pub(super) fn persistence_ui_state_file_path(&self) -> Option<PathBuf> {
        #[cfg(test)]
        {
            self.test_settings_paths
                .as_ref()
                .map(|paths| paths.ui_state.clone())
        }
        #[cfg(not(test))]
        {
            Self::ui_state_file_path()
        }
    }

    pub(super) fn ui_state_file_path_in(base: &Path) -> PathBuf {
        base.join(".flistwalker_ui_state.json")
    }

    pub(super) fn load_ui_state() -> UiState {
        let Some(path) = Self::ui_state_file_path() else {
            return UiState::default();
        };
        let source_path = Self::migrate_or_legacy_ui_state_path(&path);
        let state = Self::read_ui_state_from_path(&source_path);
        seed_persisted_history_snapshot(path, &state.query_history);
        state
    }

    fn read_ui_state_from_path(path: &Path) -> UiState {
        let Ok(text) = fs::read_to_string(path) else {
            return UiState::default();
        };
        serde_json::from_str::<UiState>(&text).unwrap_or_default()
    }

    #[cfg(test)]
    pub(super) fn load_ui_state_from_path(path: &Path) -> UiState {
        Self::read_ui_state_from_path(path)
    }

    pub(super) fn load_launch_settings() -> LaunchSettings {
        Self::launch_settings_from_ui_state(Self::load_ui_state())
    }

    #[cfg(test)]
    pub(super) fn load_launch_settings_from_path(path: &Path) -> LaunchSettings {
        Self::launch_settings_from_ui_state(Self::read_ui_state_from_path(path))
    }

    #[cfg(test)]
    pub(super) fn load_launch_settings_from_path_with_history_persist_disabled(
        path: &Path,
        disabled: bool,
    ) -> LaunchSettings {
        Self::launch_settings_from_ui_state_inner(Self::read_ui_state_from_path(path), disabled)
    }

    fn launch_settings_from_ui_state(ui_state: UiState) -> LaunchSettings {
        Self::launch_settings_from_ui_state_inner(ui_state, Self::history_persist_disabled())
    }

    fn launch_settings_from_ui_state_inner(
        ui_state: UiState,
        history_persist_disabled: bool,
    ) -> LaunchSettings {
        let last_root = ui_state
            .last_root
            .as_deref()
            .map(PathBuf::from)
            .map(normalize_windows_path_buf);
        let default_root = ui_state
            .default_root
            .as_deref()
            .map(PathBuf::from)
            .map(normalize_windows_path_buf);
        let show_preview = ui_state.show_preview.unwrap_or(true);
        let preview_panel_width = ui_state
            .preview_panel_width
            .or(ui_state.results_panel_width)
            .unwrap_or(Self::DEFAULT_PREVIEW_PANEL_WIDTH)
            .max(Self::MIN_PREVIEW_PANEL_WIDTH);
        LaunchSettings {
            last_root,
            default_root,
            show_preview,
            ignore_list_enabled: ui_state.ignore_list_enabled,
            preview_panel_width,
            query_history: if history_persist_disabled {
                Vec::new()
            } else {
                ui_state
                    .query_history
                    .into_iter()
                    .rev()
                    .take(Self::QUERY_HISTORY_MAX)
                    .collect::<Vec<_>>()
                    .into_iter()
                    .rev()
                    .collect()
            },
            restore_tabs: ui_state.tabs,
            restore_active_tab: ui_state.active_tab,
            skipped_update_target_version: ui_state.skipped_update_target_version,
            suppress_update_check_failure_dialog: ui_state.suppress_update_check_failure_dialog,
            #[cfg(test)]
            test_settings_paths: None,
        }
    }

    pub(super) fn restore_tabs_enabled() -> bool {
        std::env::var("FLISTWALKER_RESTORE_TABS")
            .ok()
            .map(|value| {
                matches!(
                    value.trim().to_ascii_lowercase().as_str(),
                    "1" | "true" | "yes" | "on"
                )
            })
            .unwrap_or(false)
    }

    pub(super) fn sanitize_saved_tabs(
        tabs: &[SavedTabState],
        active_tab: Option<usize>,
    ) -> Option<(Vec<SavedTabState>, usize)> {
        let history_persist_disabled = Self::history_persist_disabled();
        let sanitized: Vec<SavedTabState> = tabs
            .iter()
            .filter_map(|tab| {
                let root = normalize_windows_path_buf(PathBuf::from(&tab.root));
                if root.as_os_str().is_empty() {
                    return None;
                }
                Some(SavedTabState {
                    root: root.to_string_lossy().to_string(),
                    use_filelist: tab.use_filelist,
                    use_regex: tab.use_regex,
                    ignore_case: tab.ignore_case,
                    include_files: tab.include_files,
                    include_dirs: tab.include_dirs,
                    max_depth: tab.max_depth,
                    follow_links: tab.follow_links,
                    query: tab.query.clone(),
                    query_history: if history_persist_disabled {
                        Vec::new()
                    } else {
                        tab.query_history
                            .iter()
                            .rev()
                            .take(Self::QUERY_HISTORY_MAX)
                            .cloned()
                            .collect::<Vec<_>>()
                            .into_iter()
                            .rev()
                            .collect()
                    },
                    tab_accent: tab.tab_accent,
                })
            })
            .collect();
        if sanitized.is_empty() {
            return None;
        }
        let active = active_tab
            .unwrap_or(0)
            .min(sanitized.len().saturating_sub(1));
        Some((sanitized, active))
    }

    pub(super) fn saved_roots_file_path() -> Option<PathBuf> {
        #[cfg(test)]
        {
            None
        }
        #[cfg(not(test))]
        {
            settings_base_dir().map(|base| Self::saved_roots_file_path_in(&base))
        }
    }

    pub(super) fn saved_roots_file_path_in(base: &Path) -> PathBuf {
        base.join(".flistwalker_roots.txt")
    }

    pub(super) fn persistence_saved_roots_file_path(&self) -> Option<PathBuf> {
        #[cfg(test)]
        {
            self.test_settings_paths
                .as_ref()
                .map(|paths| paths.saved_roots.clone())
        }
        #[cfg(not(test))]
        {
            Self::saved_roots_file_path()
        }
    }

    pub(super) fn load_saved_roots() -> Vec<PathBuf> {
        let Some(file) = Self::saved_roots_file_path() else {
            return Vec::new();
        };
        let file = Self::migrate_or_legacy_saved_roots_path(&file);
        read_saved_roots_from_path(&file)
    }

    #[cfg(test)]
    pub(super) fn load_saved_roots_from_path(file: &Path) -> Vec<PathBuf> {
        read_saved_roots_from_path(file)
    }
}

fn seed_persisted_history_snapshot(path: PathBuf, history: &[String]) {
    if let Ok(mut registry) = ui_state_persistence_registry().lock() {
        registry
            .history_snapshots
            .insert(path, normalize_history_recency(history.to_vec()));
    }
}

fn read_saved_roots_from_path(file: &Path) -> Vec<PathBuf> {
    let Ok(text) = fs::read_to_string(file) else {
        return Vec::new();
    };
    let mut out = Vec::new();
    let mut seen = HashSet::new();
    for raw in text.lines() {
        let line = raw.trim();
        if line.is_empty() {
            continue;
        }
        let path = normalize_windows_path_buf(PathBuf::from(line));
        let key = path_key(&path);
        if seen.insert(key) {
            out.push(path);
        }
    }
    out
}

impl FlistWalkerApp {
    fn migrate_or_legacy_ui_state_path(current_path: &Path) -> PathBuf {
        let legacy_paths = legacy_settings_base_dirs()
            .into_iter()
            .map(|base| Self::ui_state_file_path_in(&base))
            .collect::<Vec<_>>();
        Self::migrate_or_legacy_path(current_path, &legacy_paths)
    }

    fn migrate_or_legacy_saved_roots_path(current_path: &Path) -> PathBuf {
        let legacy_paths = legacy_settings_base_dirs()
            .into_iter()
            .map(|base| Self::saved_roots_file_path_in(&base))
            .collect::<Vec<_>>();
        Self::migrate_or_legacy_path(current_path, &legacy_paths)
    }

    fn migrate_or_legacy_path(current_path: &Path, legacy_paths: &[PathBuf]) -> PathBuf {
        if current_path.exists() {
            return current_path.to_path_buf();
        }
        for legacy_path in legacy_paths {
            if migrate_file_if_needed(current_path, legacy_path) {
                return current_path.to_path_buf();
            }
        }
        for legacy_path in legacy_paths {
            if legacy_path.exists() {
                return legacy_path.to_path_buf();
            }
        }
        current_path.to_path_buf()
    }

    pub(super) fn set_current_root_as_default(&mut self) {
        self.set_current_root_as_default_with(Self::restore_tabs_enabled());
    }

    pub(super) fn set_current_root_as_default_with(&mut self, restore_tabs_enabled: bool) {
        if !Self::can_set_current_root_as_default_with(restore_tabs_enabled) {
            self.set_notice(Self::SET_DEFAULT_DISABLED_BY_RESTORE_TABS_NOTICE);
            return;
        }
        self.start_default_root_settings_commit(self.shell.runtime.root.clone());
    }

    pub(super) fn can_set_current_root_as_default(&self) -> bool {
        Self::can_set_current_root_as_default_with(Self::restore_tabs_enabled())
            && !self.settings_commit_in_progress()
    }

    pub(super) fn can_set_current_root_as_default_with(restore_tabs_enabled: bool) -> bool {
        !restore_tabs_enabled
    }

    pub(super) fn save_ui_state(&self) {
        let Some(path) = self.persistence_ui_state_file_path() else {
            return;
        };
        let history_persist_disabled = Self::history_persist_disabled();
        let state = self.ui_state_snapshot(history_persist_disabled);
        enqueue_ui_state_patch(
            path,
            UiStatePatch::from_ui_state(&state),
            state.query_history,
            history_persist_disabled,
        );
    }

    #[cfg(test)]
    pub(super) fn save_ui_state_to_path(&self, path: &Path) {
        self.save_ui_state_to_path_inner(path, Self::history_persist_disabled());
    }

    #[cfg(test)]
    pub(super) fn save_ui_state_to_path_with_history_persist_disabled(
        &self,
        path: &Path,
        disabled: bool,
    ) {
        self.save_ui_state_to_path_inner(path, disabled);
    }

    fn ui_state_snapshot(&self, history_persist_disabled: bool) -> UiState {
        let last_root_for_startup = if !Self::restore_tabs_enabled() {
            self.shell
                .features
                .root_browser
                .default_root
                .clone()
                .or_else(|| Some(self.shell.runtime.root.clone()))
                .unwrap_or_else(|| self.shell.runtime.root.clone())
        } else {
            self.shell.runtime.root.clone()
        };
        UiState {
            last_root: Some(last_root_for_startup.to_string_lossy().to_string()),
            default_root: self
                .shell
                .features
                .root_browser
                .default_root
                .as_ref()
                .map(|p| p.to_string_lossy().to_string()),
            show_preview: Some(self.shell.ui.show_preview),
            ignore_list_enabled: self.shell.ui.ignore_list_enabled,
            preview_panel_width: Some(self.shell.ui.preview_panel_width),
            query_history: if history_persist_disabled {
                Vec::new()
            } else {
                self.shell
                    .runtime
                    .query_state
                    .query_history
                    .iter()
                    .cloned()
                    .collect()
            },
            results_panel_width: None,
            tabs: self.saved_tabs_for_ui_state(),
            active_tab: Some(self.shell.tabs.active_tab_index()),
            window: self.shell.ui.window_geometry.clone(),
            skipped_update_target_version: self
                .shell
                .features
                .update
                .state
                .skipped_target_version
                .clone(),
            suppress_update_check_failure_dialog: self
                .shell
                .features
                .update
                .state
                .suppress_check_failure_dialog,
        }
    }

    #[cfg(test)]
    fn save_ui_state_to_path_inner(&self, path: &Path, history_persist_disabled: bool) {
        if let Some(parent) = path.parent() {
            let _ = fs::create_dir_all(parent);
        }
        let state = self.ui_state_snapshot(history_persist_disabled);
        let mut state =
            serde_json::to_value(state).unwrap_or_else(|_| Value::Object(Default::default()));
        canonicalize_last_root_for_persistence(&mut state);
        if let Ok(text) = serde_json::to_string_pretty(&state) {
            let _ = write_text_atomic(path, &text);
            Self::append_window_trace(
                "save_ui_state",
                &format!(
                    "window={:?} preview_panel_width={:.1}",
                    self.shell.ui.window_geometry, self.shell.ui.preview_panel_width
                ),
            );
        }
    }

    pub(super) fn mark_ui_state_dirty(&mut self) {
        self.shell.ui.ui_state_dirty = true;
    }

    pub(super) fn maybe_save_ui_state(&mut self, force: bool) {
        if !self.shell.ui.ui_state_dirty {
            return;
        }
        if self.settings_commit_in_progress() {
            return;
        }
        if force || self.shell.ui.last_ui_state_save.elapsed() >= Self::UI_STATE_SAVE_INTERVAL {
            self.save_ui_state();
            self.shell.ui.ui_state_dirty = false;
            self.shell.ui.last_ui_state_save = Instant::now();
        }
    }

    pub(super) fn persist_ui_state_now(&mut self) {
        if self.settings_commit_in_progress() {
            self.shell.ui.ui_state_dirty = true;
            return;
        }
        self.save_ui_state();
        self.shell.ui.ui_state_dirty = false;
        self.shell.ui.last_ui_state_save = Instant::now();
    }

    #[cfg(test)]
    pub(super) fn persist_ui_state_to_path_now(&mut self, path: &Path) {
        self.save_ui_state_to_path(path);
        self.shell.ui.ui_state_dirty = false;
        self.shell.ui.last_ui_state_save = Instant::now();
    }

    fn to_stable_window_geometry(geom: SavedWindowGeometry) -> SavedWindowGeometry {
        let round = |v: f32| (v * 10.0).round() / 10.0;
        let mut width = round(geom.width.max(640.0));
        let mut height = round(geom.height.max(400.0));
        if let Some(mw) = geom.monitor_width {
            let cap = round(mw.max(640.0));
            width = width.min(cap);
        }
        if let Some(mh) = geom.monitor_height {
            let cap = round(mh.max(400.0));
            height = height.min(cap);
        }
        SavedWindowGeometry {
            x: round(geom.x),
            y: round(geom.y),
            width,
            height,
            monitor_width: geom.monitor_width.map(round),
            monitor_height: geom.monitor_height.map(round),
            pixels_per_point: geom.pixels_per_point,
        }
    }

    pub(super) fn window_geometry_from_rects(
        outer_rect: egui::Rect,
        inner_rect: Option<egui::Rect>,
        monitor_size: Option<egui::Vec2>,
    ) -> SavedWindowGeometry {
        let size_rect = inner_rect.unwrap_or(outer_rect);
        SavedWindowGeometry {
            x: outer_rect.min.x,
            y: outer_rect.min.y,
            width: size_rect.width(),
            height: size_rect.height(),
            monitor_width: monitor_size.map(|s| s.x),
            monitor_height: monitor_size.map(|s| s.y),
            pixels_per_point: None,
        }
    }

    pub fn startup_window_placement(
        monitors: &[(egui::Rect, f32)],
        current_monitor: Option<usize>,
        can_position: bool,
    ) -> Option<StartupWindowPlacement> {
        Some(Self::startup_window_placement_from_ui_state(
            Self::load_ui_state(),
            monitors,
            current_monitor,
            can_position,
        ))
    }

    pub(super) fn startup_window_placement_from_ui_state(
        ui_state: UiState,
        monitors: &[(egui::Rect, f32)],
        current_monitor: Option<usize>,
        can_position: bool,
    ) -> StartupWindowPlacement {
        let saved = ui_state.window.unwrap_or_else(|| SavedWindowGeometry {
            width: 1400.0,
            height: 900.0,
            ..Default::default()
        });
        Self::normalize_startup_placement(saved, monitors, current_monitor, can_position)
    }

    pub(super) fn normalize_startup_placement(
        saved: SavedWindowGeometry,
        monitors: &[(egui::Rect, f32)],
        current_monitor: Option<usize>,
        can_position: bool,
    ) -> StartupWindowPlacement {
        let positive = |value: f32| value.is_finite() && value > 0.0;
        let scale = saved.pixels_per_point.filter(|value| positive(*value));
        let physical_position = scale
            .filter(|_| can_position && saved.x.is_finite() && saved.y.is_finite())
            .map(|scale| egui::pos2(saved.x * scale, saved.y * scale))
            .filter(|position| position.is_finite());
        let valid = monitors
            .iter()
            .enumerate()
            .filter(|(_, (rect, scale))| {
                rect.is_finite()
                    && positive(rect.width())
                    && positive(rect.height())
                    && positive(*scale)
            })
            .collect::<Vec<_>>();
        let target = physical_position
            .and_then(|position| {
                valid
                    .iter()
                    .min_by(|(_, (left, _)), (_, (right, _))| {
                        left.clamp(position)
                            .distance_sq(position)
                            .total_cmp(&right.clamp(position).distance_sq(position))
                    })
                    .copied()
            })
            .or_else(|| {
                valid
                    .iter()
                    .find(|(index, _)| Some(*index) == current_monitor)
                    .copied()
            })
            .or_else(|| valid.first().copied());
        let bounded = |value: f32, fallback: f32, minimum: f32, previous_monitor: Option<f32>| {
            let value = if positive(value) { value } else { fallback };
            value.clamp(minimum, 16000.0).min(
                previous_monitor
                    .filter(|value| positive(*value))
                    .unwrap_or(16000.0)
                    .max(minimum),
            )
        };
        let mut logical_size = egui::vec2(
            bounded(saved.width, 1400.0, 640.0, saved.monitor_width),
            bounded(saved.height, 900.0, 400.0, saved.monitor_height),
        );
        let Some((_, (monitor, scale_factor))) = target else {
            return StartupWindowPlacement {
                physical_position: None,
                logical_size,
                scale_factor: 1.0,
            };
        };
        logical_size = logical_size.min(monitor.size() / *scale_factor);
        // Clamp against one real screen, never the bounding box across screen gaps.
        let clamp_to_monitor = |position: egui::Pos2| {
            let max = (monitor.max - logical_size * *scale_factor).max(monitor.min);
            egui::pos2(
                position.x.clamp(monitor.min.x, max.x),
                position.y.clamp(monitor.min.y, max.y),
            )
        };
        let physical_position = physical_position.map(clamp_to_monitor).or_else(|| {
            can_position.then(|| {
                // Regression guard: never delegate a positionless startup to the window
                // manager when a real monitor is known. Platform/default placement can otherwise
                // reuse an off-screen or display-gap position after the monitor layout changes.
                clamp_to_monitor(monitor.center() - logical_size * *scale_factor * 0.5)
            })
        });
        StartupWindowPlacement {
            physical_position,
            logical_size,
            scale_factor: *scale_factor,
        }
    }

    pub(super) fn apply_stable_window_geometry(&mut self, force: bool) {
        let Some(pending) = self.shell.ui.pending_window_geometry.clone() else {
            return;
        };
        if !force
            && self.shell.ui.last_window_geometry_change.elapsed()
                < Self::WINDOW_GEOMETRY_SETTLE_INTERVAL
        {
            return;
        }
        if self.shell.ui.window_geometry.as_ref() != Some(&pending) {
            self.shell.ui.window_geometry = Some(pending.clone());
            self.mark_ui_state_dirty();
            Self::append_window_trace(
                "window_geometry_committed",
                &format!(
                    "committed={:?} force={}",
                    self.shell.ui.window_geometry, force
                ),
            );
        }
        self.shell.ui.pending_window_geometry = None;
    }

    pub(super) fn capture_window_geometry(&mut self, ctx: &egui::Context) {
        let pixels_per_point = ctx.pixels_per_point();
        let next = ctx.input(|i| {
            let outer = i.viewport().outer_rect?;
            let inner = i.viewport().inner_rect;
            let monitor_size = i.viewport().monitor_size;
            let mut saved = Self::window_geometry_from_rects(outer, inner, monitor_size);
            saved.pixels_per_point = Some(pixels_per_point);
            Some(saved)
        });
        let Some(next) = next.map(Self::to_stable_window_geometry) else {
            return;
        };
        if let (Some(mw), Some(mh)) = (next.monitor_width, next.monitor_height) {
            let width_limit = (mw * 1.05).max(640.0);
            let height_limit = (mh * 1.05).max(400.0);
            if next.width > width_limit || next.height > height_limit {
                Self::append_window_trace(
                    "capture_window_geometry_rejected_oversize",
                    &format!(
                        "x={:.1} y={:.1} w={:.1} h={:.1} mw={:.1} mh={:.1}",
                        next.x, next.y, next.width, next.height, mw, mh
                    ),
                );
                return;
            }
        }
        if self.shell.ui.pending_window_geometry.as_ref() != Some(&next)
            && self.shell.ui.window_geometry.as_ref() != Some(&next)
        {
            let prev_committed = self.shell.ui.window_geometry.clone();
            let prev_pending = self.shell.ui.pending_window_geometry.clone();
            self.shell.ui.pending_window_geometry = Some(next);
            self.shell.ui.last_window_geometry_change = Instant::now();
            if Self::window_trace_verbose_enabled() {
                Self::append_window_trace(
                    "capture_window_geometry_changed",
                    &format!(
                        "prev_committed={:?} prev_pending={:?} next_pending={:?}",
                        prev_committed, prev_pending, self.shell.ui.pending_window_geometry
                    ),
                );
            }
        }
    }
}

#[cfg(test)]
mod tests;
