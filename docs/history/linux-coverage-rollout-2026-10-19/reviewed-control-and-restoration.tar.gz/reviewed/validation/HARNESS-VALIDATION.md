# Inert controller validation

The controller is bound to PR190, base3194f03, head1d93ed5 and13task-owned commits. Live authority remains pending; no snapshot/manifest/accepted approval has been created.

An initial local21-test pass was only one observation. Independent execution subsequently produced2errors: the fake API rewrote state.json nonatomically while the process suite read it, and killpg(pid,0) returned EPERM during helper-exit verification. That run is not relabelled PASS. Its failing fixture no longer retained the original PID, so same-PID host comparison was unavailable.

The fake API now atomically replaces state.json. The process harness uses an absolute Python shebang and PATH containing only the owned fake gh directory, so a fixture error cannot fall through to the actual gh executable. Teardown verifies the unique owned watchdog command, stops/waits its group, then removes the fixture; an unverified cleanup retains the directory. No live controller behavior was changed by these harness repairs.

A dedicated owned helper probe showed sandbox ps EPERM while the identical host ps succeeded; pid/group signal0 agreed while alive and after exit. The original killpg0 EPERM was not reproduced and remains unexplained. It is not proof of a controller defect or of successful exit.

Main's fixed host21tests passed at26885d1(26.045s) and at finalbea63e5/max12(26.103s). tests-host-bea63e5.log is the latter observation. All6actual-process scenarios use local fake state only: controller SIGKILL/SIGTERM/SIGSTOP, suspension while holding admission/restoration locks, forced restoration failure and pre-admission death. Forced failure leaves no restoration-success marker or protected-proof authority. No real GitHub/network/settings operation occurred.

Independent source/result review is separate from these main-owned host executions. The final rollout checkpoint must also inspect the fresh CI Gate, full settings/rules/check source snapshot, exact Guardian refusal, restoration payload, controller/manifest hashes and human authority.

The minor early-failure cleanup gap is repaired: if watchdog_pid was not yet observed, teardown validates watchdog-ready head/parent PID/process group before recovering the PID. Missing or invalid ownership retains the fixture and never signals. Three failing subcases became PASS. The final head/max13 harness ran22tests successfully, including6actual-process scenarios, in the main-owned host run tests-host-1d93ed5.log. This is not an independent execution claim.

For that final host invocation, the Python runner reported22tests/OK/26.107s. The outer shell then exited1 because its reporting variable used zsh reserved name status. This is retained as a wrapper failure, not a test failure or an exit0 invocation; no test was retried to relabel it.
