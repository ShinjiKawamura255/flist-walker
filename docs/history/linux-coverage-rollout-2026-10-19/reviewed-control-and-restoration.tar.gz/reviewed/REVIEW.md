# PR #190 CI保護変更の最終確認用データ

状態: 準備完了。独立最終レビュー結果は別添FINAL-REVIEW.mdを参照。実行承認待ち。設定変更・auto-merge登録・マージは未実行です。

## 固定対象

- repository: ShinjiKawamura255/flist-walker / PR190
- base:3194f03c27f9a72f06a836dbd02e9141d8740a26
- head:1d93ed589dda141eceeefc6b0877e2be0c01f400 /13task-owned commits
- branch:codex/fix-candidate-build-and-timeout
- manifest SHA256:58d308316f8c2874651e815ee4ac5495a63142c9fb06925d2ec089bb676efb4c
- CI run39238474595:通常10jobすべてSUCCESS。CI Gate118018474209/app15368。
- Guardian39238472362/check118013232971/app15368は想定4pathの構造変更拒否。guardian.jsonと原ログを保存。
- snapshotのopen master PRは190だけ、auto_merge=null、applied rules/rulesetsは空。

## 承認後に限る実行範囲

1. exact manifest/head/base/CI/check source/actor/唯一のPR/設定不変を再確認。専用sessionの独立watchdogを起動・ready確認してから、PR190へrebase auto-mergeを1回だけ登録します。
2. required_status_checksだけをtemporary.jsonへ一時変更します。strict=trueとCI Gate/app15368を維持し、Guardianのみrequiredから外します。他のrepository/protection設定は変更しません。
3. merge待機は最大60秒。finallyで直ちにrestore.jsonへ復元し、repository/protection全体・rules・PR・masterを読み戻します。main停止や中断には独立watchdogが180秒deadlineで復元に着手します。各APIは12秒timeout、復元は最大3試行で、復元処理はdeadlineと別枠です。復元未確認なら成功扱いせずproofを開始しません。
4. 完全復元後、通常保護下で2件以上の意味ある証跡文書commitを含むproof PRを作成します。native診断/CI/source/LCOVと実制御/snapshot/復元/readbackの記録を保持・索引化します。両required check成功後に通常のrebase auto-mergeで通し、commit順序・件数・message・author・stable patch ID・tree・single parent・merge commit0・remote自動削除を照合します。
5. 上記保護経路検証成功後、承認済みのPR180再開を行います。元head/branchを確認し、Draft・auto-merge未登録で再開します。PR179は記録とbranchを残してclosedを維持します。

## 残る調査と検証の限界

元のLinux SIGSEGVは未解明です。今回のnative fixture4coreと実TC165意図的SIGABRTの採取成功・非再発は、元障害の因果的修正を証明しません。承認対象には、未解明のまま調査継続用の診断経路を適用する判断を含みます。

exact-head coverage85.523783%、report complete=true/exit0/errorsなし/RESTORED。Windows patch-leaf実テストもPASS。全ログ/annotationsは独立確認済み:外部Action DEP0005が1件、macOS capacity NOTICEが1件、製品/Rust/test/clippy/audit警告0。外部警告は限定minor評価であり、新release候補や公開の警告例外は付与していません。

controller/testは既に独立レビュー済み。main所有host harnessは22tests/OKと6実プロセス負例を確認。後続zsh報告wrapperのexit1は別の失敗として保持し、独立actual-process再実行成功とは記載していません。今回の新snapshotに対するpure validationはPASS。

タグ作成・release公開、admin bypass、master直接push、手動remote branch削除、他worktree操作は含みません。承認後もdrift時は停止し、固定データを無断更新しません。

## ファイル

manifest.jsonはsnapshot/restore/temporary/guardian/controllerのSHA256を固定します。REVIEW-INPUTS.jsonは補助証跡・tests・本説明とFOLLOW-UPを含む全固定入力を列挙します。accepted approvalファイル・実行output・成功markerはありません。

独立レビュー結果は固定入力を変更せず、別ファイルFINAL-REVIEW.mdへ記録します。実行承認はこのデータとreviewを確認した人間の明示判断が必要です。
